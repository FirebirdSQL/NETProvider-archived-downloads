//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird.Services
{
	/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/overview/*'/>
	public sealed class FbServerProperties : FbService
	{
		#region PROPERTIES

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="Version"]/*'/>
		public int Version
		{
			get
			{
				byte[] buffer	= queryService(new byte[] {GdsCodes.isc_info_svc_version});
				ArrayList info	= base.parseQueryInfo(buffer);
						
				return info.Count != 0 ? (int)info[0] : 0;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="ServerVersion"]/*'/>
		public string ServerVersion
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_server_version});
				ArrayList info = base.parseQueryInfo(buffer);

				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="Implementation"]/*'/>
		public string Implementation
		{
			get
			{
				byte[] buffer	= queryService(new byte[] {GdsCodes.isc_info_svc_implementation});
				ArrayList info	= base.parseQueryInfo(buffer);

				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="RootDirectory"]/*'/>
		public string RootDirectory
		{			
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_env});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="LockManager"]/*'/>
		public string LockManager
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_env_lock});
				ArrayList info = base.parseQueryInfo(buffer);

				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="MessageFile"]/*'/>
		public string MessageFile
		{			
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_env_msg});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="DatabasesInfo"]/*'/>
		public FbDatabasesInfo DatabasesInfo
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_svr_db_info});
				ArrayList info = base.parseQueryInfo(buffer);

				return info.Count != 0 ? (FbDatabasesInfo)info[0] : new FbDatabasesInfo();
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="ServerConfig"]/*'/>
		public FbServerConfig ServerConfig
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_config});
				ArrayList info = base.parseQueryInfo(buffer);

				return info.Count != 0 ? (FbServerConfig)info[0] : new FbServerConfig();
			}
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/constructor[@name="FbServerProperties"]/*'/>
		public FbServerProperties() : base()
		{
		}
		
		#endregion
	}
}
