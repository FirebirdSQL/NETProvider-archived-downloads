//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbViewColumnUsage : FbAbstractDbSchema
	{
		#region CONSTRUCTORS

		public FbViewColumnUsage() : base("ViewColumnUsage")
		{
		}

		#endregion

		#region ADD_METHODS

		public override void AddTables()
		{
			AddTable("rdb$view_relations vrel");
		}

		public override void AddRestrictionColumns()
		{
			AddRestrictionColumn("vrel.rdb$view_name", "VIEW_NAME", null);
			AddRestrictionColumn("rfr.rdb$field_name", "COLUMN_NAME", null);
		}

		public override void AddDataColumns()
		{
			AddDataColumn("fld.rdb$field_type"		, "DATA_TYPE");
			AddDataColumn("fld.rdb$field_sub_type"	, "SUB_DATA_TYPE");
			AddDataColumn("fld.rdb$field_length"	, "COLUMN_SIZE");
			AddDataColumn("fld.rdb$field_precision"	, "NUMERIC_PRECISION");
			AddDataColumn("fld.rdb$field_scale"		, "NUMERIC_SCALE");
			AddDataColumn("rfr.rdb$field_position"	, "COLUMN_ORDINAL");
			AddDataColumn("rfr.rdb$default_value"	, "COLUMN_DEFAULT");
			AddDataColumn("rfr.rdb$null_flag"		, "IS_NULLABLE");
			AddDataColumn("rfr.rdb$update_flag"		, "IS_READONLY");
			AddDataColumn("fld.rdb$description"		, "DESCRIPTION");
		}

		public override void AddJoins()
		{
			AddJoin("left join", "rdb$relation_fields rfr"	, "vrel.rdb$view_name = rfr.rdb$relation_name");
			AddJoin("left join", "rdb$fields fld"			, "rfr.rdb$field_source = fld.rdb$field_name");
		}

		public override void AddOrderByColumns()
		{
			AddOrderBy("vrel.rdb$view_name");
			AddOrderBy("rfr.rdb$field_position");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region PARSE_METHODS

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}