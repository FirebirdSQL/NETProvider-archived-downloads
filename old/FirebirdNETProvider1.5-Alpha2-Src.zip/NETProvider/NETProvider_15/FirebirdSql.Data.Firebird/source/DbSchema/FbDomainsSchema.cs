//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbDomainsSchema : FbAbstractDbSchema
	{
		#region CONSTRUCTORS

		public FbDomainsSchema() : base("Domains")
		{
		}

		#endregion

		#region ADD_METHODS

		public override void AddTables()
		{
			AddTable("rdb$fields");
		}

		public override void AddRestrictionColumns()
		{
			AddRestrictionColumn("rdb$field_name", "DOMAIN_NAME", null);
		}

		public override void AddDataColumns()
		{
			AddDataColumn("rdb$field_type"		, "DOMAIN_DATA_TYPE");
			AddDataColumn("rdb$field_sub_type"	, "DOMAIN_SUB_TYPE");
			AddDataColumn("rdb$field_length"	, "DOMAIN_SIZE");
			AddDataColumn("rdb$field_precision"	, "DOMAIN_PRECISION");
			AddDataColumn("rdb$field_scale"		, "DOMAIN_SCALE");
			AddDataColumn("rdb$null_flag"		, "IS_NULLABLE");
			AddDataColumn("rdb$dimensions"		, "ARRAY_DIMENSIONS");
			AddDataColumn("rdb$description"		, "DESCRIPTION");
		}

		public override void AddJoins()
		{
		}

		public override void AddOrderByColumns()
		{
			AddOrderBy("rdb$field_name");
		}

		public override void AddWhereFilters()
		{
			AddWhereFilter("not rdb$field_name starting with 'RDB$'");
		}

		#endregion

		#region PARSE_METHODS

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}