//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/overview/*'/>
	public enum FbDbSchemaType
	{
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Character_Sets"]/*'/>
		Character_Sets,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Check_Constraints"]/*'/>
		Check_Constraints,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Check_Constraints_By_Table"]/*'/>
		Check_Constraints_By_Table,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Collations"]/*'/>
		Collations,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Columns"]/*'/>
		Columns,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Column_Privileges"]/*'/>
		Column_Privileges,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Domains"]/*'/>
		Domains,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Foreign_Keys"]/*'/>
		Foreign_Keys,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Functions"]/*'/>
		Functions,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Generators"]/*'/>
		Generators,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Indexes"]/*'/>
		Indexes,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Primary_Keys"]/*'/>
		Primary_Keys,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Procedure_Parameters"]/*'/>
		Procedure_Parameters,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Procedure_Privileges"]/*'/>
		Procedure_Privileges,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Procedures"]/*'/>
		Procedures,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Provider_Types"]/*'/>
		Provider_Types,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Roles"]/*'/>
		Roles,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Statistics"]/*'/>
		Statistics,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Tables"]/*'/>
		Tables,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Table_Constraint"]/*'/>
		Table_Constraint,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Table_Privileges"]/*'/>
		Table_Privileges,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Table_Statistics"]/*'/>
		Table_Statistics,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Triggers"]/*'/>
		Triggers,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Usage_Privileges"]/*'/>
		Usage_Privileges,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="View_Column_Usage"]/*'/>
		View_Column_Usage,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="Views"]/*'/>
		Views,
		/// <include file='Doc/en_EN/FbDbSchemaType.xml' path='doc/enum[@name="FbDbSchemaType"]/field[@name="View_Privileges"]/*'/>
		View_Privileges
	}
}
