//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;
using System.Text;

namespace FirebirdSql.Data.Firebird.Gds
{
	#region STRUCTS
	
	internal struct GdsArrayBound
	{
		public int LowerBound;
		public int UpperBound;
	}

	internal struct GdsArrayDesc
	{
		public byte		DataType;
		public short	Scale;			// Scale for numeric datatypes
		public short	Length;			// Legth in bytes of each array element
		public string	FieldName;		// Column name - 32
		public string	RelationName;	// Table name -32
		public short	Dimensions;		// Number of array dimensions 
		public short	Flags;			// Specifies wheter array is to be accesed in
		// row mayor or column-mayor order
		public GdsArrayBound[] Bounds; // Lower and upper bounds for each dimension - 16
	}

	#endregion

	internal abstract class GdsSlice
	{
		#region CONSTANTS

		public const int ARRAY_DESC_COLUMN_MAJOR = 1;	/* Set for FORTRAN */

		#endregion

		#region FIELDS

		private long				handle;
		private GdsDbAttachment	db;
		private GdsTransaction		transaction;
		private string				tableName;
		private string				fieldName;
		private string				rdbFieldName;

		#endregion

		#region PROPERTIES

		public long Handle
		{
			get { return handle; }
		}

		public GdsDbAttachment DB
		{
			get { return db; }
		}

		#endregion

		#region CONSTRUCTORS

		public GdsSlice(GdsDbAttachment db, 
						GdsTransaction transaction, 
						long handle,
						string fieldName,
						string tableName)
		{
			this.db				= db;
			this.transaction	= transaction;
			this.handle			= handle;
			this.tableName		= tableName;
			this.fieldName		= fieldName;
		}

		#endregion

		#region METHODS
	
		protected GdsArrayDesc LookupDesc()
		{
			GdsArrayDesc desc = new GdsArrayDesc();

			GdsStatement statement = new GdsStatement(getArrayDesc(), db);

			statement.Allocate();
			statement.Prepare();
			statement.Execute();

			object[] row;
			if((row = statement.Fetch()) != null)
			{								
				desc.RelationName	= tableName;
				desc.FieldName		= fieldName;
				desc.DataType		= Convert.ToByte(row[0]);
				desc.Scale			= Convert.ToInt16(row[1]);
				desc.Length			= Convert.ToInt16(row[2]);
				desc.Dimensions		= Convert.ToInt16(row[3]);
				desc.Flags			= 0;

				rdbFieldName = row[4].ToString();
			}			
			else
			{
				throw new InvalidOperationException();
			}
			
			statement.Drop();
			statement = null;

			return desc;
		}

		protected GdsArrayDesc LookupBounds()
		{
			int				i;
			GdsArrayDesc	desc = LookupDesc();

			GdsStatement statement = new GdsStatement(getArrayBounds(), db);

			statement.Allocate();
			statement.Prepare();
			statement.Execute();

			i = 0;
			desc.Bounds = new GdsArrayBound[16];
			object[] row;
			while((row = statement.Fetch()) != null)
			{				
				desc.Bounds[i].LowerBound = Convert.ToInt32(row[0]);
				desc.Bounds[i].UpperBound = Convert.ToInt32(row[1]);

				i++;
			}			
			
			statement.Drop();
			statement = null;

			return desc;
		}

		public string GenerateSDL(GdsArrayDesc desc)
		{
			int 			n;
			int 			from;
			int 			to;
			int 			increment;
			int 			dimensions;
			GdsArrayBound tail;
			string			sdl;
				
			dimensions = desc.Dimensions;
		
			if (dimensions > 16)
			{
				throw new GdsException(GdsCodes.isc_invalid_dimension);
			}
		
			sdl = String.Empty;					
			sdl = stuff(sdl, 
						4, 
						GdsCodes.isc_sdl_version1, 
						GdsCodes.isc_sdl_struct, 
						1,
						desc.DataType);
			
			switch (desc.DataType) 
			{
				case GdsCodes.blr_short:
				case GdsCodes.blr_long:
				case GdsCodes.blr_int64:
				case GdsCodes.blr_quad:
					sdl = stuffSdl(sdl, (byte)desc.Scale);
					break;
			
				case GdsCodes.blr_text:
				case GdsCodes.blr_cstring:
				case GdsCodes.blr_varying:
					sdl = stuffWord(sdl, desc.Length);
					break;

				default:
					break;
			}
		
			sdl = stuffString(sdl, GdsCodes.isc_sdl_relation, desc.RelationName);
			sdl = stuffString(sdl, GdsCodes.isc_sdl_field, desc.FieldName);
					
			if ((desc.Flags & ARRAY_DESC_COLUMN_MAJOR) == ARRAY_DESC_COLUMN_MAJOR)
			{
				from		= dimensions - 1;
				to 			= -1;
				increment 	= -1;
			}
			else 
			{
				from 		= 0;
				to 			= dimensions;
				increment 	= 1;
			}
		
			for (n = from; n != to; n += increment) 
			{
				tail = desc.Bounds[n];
				if (tail.LowerBound == 1) 
				{
					sdl = stuff(sdl, 2, GdsCodes.isc_sdl_do1, n);
				}
				else 
				{
					sdl = stuff(sdl, 2, GdsCodes.isc_sdl_do2, n);
					
					sdl = stuffLiteral(sdl, (int)tail.LowerBound);				
				}
				sdl = stuffLiteral(sdl, (int)tail.UpperBound);
			}
		
			sdl = stuff(sdl, 5, GdsCodes.isc_sdl_element, 1, GdsCodes.isc_sdl_scalar, 0, dimensions);
		
			for (n = 0; n < dimensions; n++)
			{
				sdl = stuff(sdl, 2, GdsCodes.isc_sdl_variable, n);
			}
		
			return stuffSdl(sdl, GdsCodes.isc_sdl_eoc);
		}

		public byte[] GetSlice(GdsArrayDesc desc, int slice_length)
		{
			string 	sdl;
		
			// Generate array field sdl string
			sdl = GenerateSDL(desc);

			lock (db) 
			{
				try 
				{					
					db.Send.WriteInt(GdsCodes.op_get_slice);	// Op code
					db.Send.WriteInt(transaction.Handle); 		// Transaction
					db.Send.WriteLong(handle);					// Array id
					db.Send.WriteInt(slice_length);				// Slice length
					db.Send.WriteString(sdl);					// Slice description language
					db.Send.WriteString("");					// Slice parameters					
					db.Send.WriteInt(0);						// Slice proper
					db.Send.Flush();

					return receiveSliceResponse(desc);
				}
				catch (IOException) 
				{
					throw new GdsException(GdsCodes.isc_net_read_err);
				}
			}
		}

		public void PutSlice(GdsArrayDesc desc, 
							System.Array source_array,
							int slice_length)
		{
			string 	sdl;
		
			// Generate array field sdl string
			sdl = GenerateSDL(desc);
								
			lock (db) 
			{
				try 
				{					
					db.Send.WriteInt(GdsCodes.op_put_slice);				// Op code
					db.Send.WriteInt(transaction.Handle);					// Transaction
					db.Send.WriteLong(handle);								// Array Handle
					db.Send.WriteInt(slice_length);							// Slice length
					db.Send.WriteString(sdl);								// Slice description language
					db.Send.WriteString("");								// Slice parameters
					db.Send.WriteSlice(desc, source_array, slice_length);	// Slice proper
					db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();
					
					handle = r.BlobHandle;
				}
				catch (IOException) 
				{
					throw new GdsException(GdsCodes.isc_net_read_err);
				}
			}			
		}
	
		#endregion

		#region PRIVATE_METHODS

		private string getArrayDesc()
		{
			StringBuilder sql = new StringBuilder();

			sql.Append(
				"SELECT Y.RDB$FIELD_TYPE, Y.RDB$FIELD_SCALE, Y.RDB$FIELD_LENGTH, Y.RDB$DIMENSIONS, X.RDB$FIELD_SOURCE " +
				"FROM RDB$RELATION_FIELDS X, RDB$FIELDS Y " +
				"WHERE X.RDB$FIELD_SOURCE = Y.RDB$FIELD_NAME ");

			if (tableName != null)
			{
				if (tableName.Length != 0)
				{
					sql.AppendFormat(" AND X.RDB$RELATION_NAME = '{0}'", tableName);
				}
			}
					
			if (fieldName != null)
			{
				if (fieldName.Length != 0)
				{
					sql.AppendFormat(" AND X.RDB$FIELD_NAME = '{0}'", fieldName);					
				}
			}
									
			return sql.ToString();
		}

		private string getArrayBounds()
		{
			StringBuilder sql = new StringBuilder();

			sql.Append("SELECT X.RDB$LOWER_BOUND, X.RDB$UPPER_BOUND FROM RDB$FIELD_DIMENSIONS X ");				
					
			if (fieldName != null)
			{
				if (fieldName.Length != 0)
				{
					sql.AppendFormat("WHERE X.RDB$FIELD_NAME = '{0}'", rdbFieldName);
				}
			}

			sql.Append(" ORDER BY X.RDB$DIMENSION");

			return sql.ToString();
		}

		private byte[] receiveSliceResponse(GdsArrayDesc desc)
		{
			try 
			{
				int op = db.ReadOperation();
				if (op == GdsCodes.op_slice)
				{
					return db.Receive.ReadSlice(desc);
				}
				else
				{
					db.OP = op;
					
					// Receive standard response
					db.ReceiveResponse();

					return null;
				}
			} 
			catch (IOException ex) 
			{
				// ex.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GdsException(GdsCodes.isc_arg_gds, 
										GdsCodes.isc_net_read_err, 
										ex.Message);
			}
		}

		private string stuff(string sdl, short count, params object[] va_arg)
		{	
			for (int i = 0; i < count; i++) 
			{
				sdl += Convert.ToChar(va_arg[i]);
			}
			
			return sdl;
		}
		
		private string stuffSdl(string sdl, byte sdlValue)
		{
			return stuff(sdl, 1, sdlValue);
		}

		private string stuffWord(string sdl, short sdlValue)
		{
			byte[] b = BitConverter.GetBytes(sdlValue);
			return stuff(sdl, 2, b[0], b[1]);
		}

		private string stuffLong(string sdl, int sdlValue)
		{
			byte[] b = BitConverter.GetBytes(sdlValue);
			return stuff(sdl, 4, b[0], b[1], b[2], b[3]);
		}
	
		private string stuffLiteral(string sdl, int sdlValue)
		{
			if (sdlValue >= -128 && sdlValue <= 127)
			{
				return stuff(sdl, 2, GdsCodes.isc_sdl_tiny_integer, sdlValue);
			}
		
			if (sdlValue >= -32768 && sdlValue <= 32767)
			{
				sdl = stuffSdl(sdl, GdsCodes.isc_sdl_short_integer);
				return stuffWord(sdl, (short)sdlValue);
			}
			
			sdl = stuffSdl(sdl, GdsCodes.isc_sdl_long_integer);

			return stuffLong(sdl, sdlValue);
		}
		
		private string stuffString(string sdl, int sdl_constant, string sdlValue)
		{
			sdl = stuffSdl(sdl, (byte)sdl_constant);
			sdl	= stuffSdl(sdl, (byte)sdlValue.Length);
		
			for(int i = 0; i < sdlValue.Length; i++)
			{
				sdl = stuffSdl(sdl, (byte)sdlValue[i]);
			}	
			
			return sdl;
		}

		#endregion
	}
}
