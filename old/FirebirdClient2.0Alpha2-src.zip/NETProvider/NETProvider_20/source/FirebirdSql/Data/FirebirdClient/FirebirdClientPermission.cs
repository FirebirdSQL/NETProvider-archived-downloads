using System;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Security.Permissions;

namespace FirebirdSql.Data.FirebirdClient
{
	[Serializable]
	public sealed class FirebirdClientPermission : DBDataPermission 
	{
		#region � Constructors �

		[Obsolete("FbPermission() is obsolte call FbPermission(PermissionState.None)", true)]
		public FirebirdClientPermission() : this(PermissionState.None)
		{
		}

		public FirebirdClientPermission(PermissionState state) : base(state)
		{
		}

		[Obsolete("FbPermission(PermissionState, bool) is obsolete", true)]
		public FirebirdClientPermission(PermissionState state, bool allowBlankPassword) : base(state, allowBlankPassword)
		{
		}
		
		#endregion

		#region � Internal Constructors �

        internal FirebirdClientPermission(string connectionString) : base(PermissionState.None)
        {
            this.Add(connectionString, "", KeyRestrictionBehavior.AllowOnly);
        }

		internal FirebirdClientPermission(DBDataPermission permission) : base (permission)
		{
		}

		internal FirebirdClientPermission(DBDataPermissionAttribute permissionAttribute) 
			: base (permissionAttribute)
		{
		}

		#endregion

		#region � Methods �

		public override IPermission Copy()
		{
			return new FirebirdClientPermission(this);
		}

		public override void Add(string connectionString, string restrictions, KeyRestrictionBehavior behavior)
		{
			base.Add(connectionString, restrictions, behavior);
		}

		#endregion
	}
}
