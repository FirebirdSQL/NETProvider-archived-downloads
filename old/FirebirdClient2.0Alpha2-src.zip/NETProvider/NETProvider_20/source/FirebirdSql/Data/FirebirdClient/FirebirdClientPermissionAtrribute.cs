using System;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Security.Permissions;

namespace FirebirdSql.Data.FirebirdClient
{
	[Serializable]
	[AttributeUsage(AttributeTargets.Assembly |
        AttributeTargets.Class | AttributeTargets.Struct |
		AttributeTargets.Constructor | AttributeTargets.Method,
        AllowMultiple=true, Inherited=false)]
	public sealed class FirebirdClientPermissionAttribute : DBDataPermissionAttribute 
	{
		#region � Constructors �

        public FirebirdClientPermissionAttribute(SecurityAction action)
            : base(action)
		{
		}

		#endregion

		#region � Methods �

		public override IPermission CreatePermission() 
		{
			return new FirebirdClientPermission(this);
		}

		#endregion
	}
}
