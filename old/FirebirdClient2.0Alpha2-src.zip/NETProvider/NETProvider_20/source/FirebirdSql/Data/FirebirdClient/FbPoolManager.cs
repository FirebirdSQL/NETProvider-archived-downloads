/*
 *	Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *	   The contents of this file are subject to the Initial 
 *	   Developer's Public License Version 1.0 (the "License"); 
 *	   you may not use this file except in compliance with the 
 *	   License. You may obtain a copy of the License at 
 *	   http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *	   Software distributed under the License is distributed on 
 *	   an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *	   express or implied. See the License for the specific 
 *	   language governing rights and limitations under the License.
 * 
 *	Copyright (c) 2002, 2005 Carlos Guzman Alvarez
 *	All Rights Reserved.
 */

using System;
using System.Collections;

namespace FirebirdSql.Data.FirebirdClient
{
    internal sealed class FbPoolManager
    {
        #region � Static Fields �

        private static FbPoolManager instance;

        #endregion

        #region � Static Properties �

        public static FbPoolManager Instance
        {
            get
            {
                if (FbPoolManager.instance == null)
                {
                    FbPoolManager.instance = new FbPoolManager();
                }

                return FbPoolManager.instance;
            }
        }

        #endregion

        #region � Fields �

        private Hashtable pools;
        private Hashtable handlers;

        #endregion

        #region � Properties �

        public int PoolsCount
        {
            get
            {
                if (this.pools != null)
                {
                    return this.pools.Count;
                }
                return 0;
            }
        }

        #endregion

        #region � Constructors �

        private FbPoolManager()
        {
            this.pools = Hashtable.Synchronized(new Hashtable());
            this.handlers = Hashtable.Synchronized(new Hashtable());
        }

        #endregion

        #region � Methods �

        public FbConnectionPool FindPool(string connectionString)
        {
            FbConnectionPool pool = null;

            lock (this)
            {
                if (this.pools.ContainsKey(connectionString.GetHashCode()))
                {
                    pool = (FbConnectionPool)pools[connectionString.GetHashCode()];
                }
            }

            return pool;
        }

        public FbConnectionPool CreatePool(string connectionString)
        {
            FbConnectionPool pool = null;

            lock (this)
            {
                pool = this.FindPool(connectionString);

                if (pool == null)
                {
                    lock (this.pools.SyncRoot)
                    {
                        int hashcode = connectionString.GetHashCode();

                        // Create an empty pool	handler
                        EmptyPoolEventHandler handler = new EmptyPoolEventHandler(this.OnEmptyPool);

                        this.handlers.Add(hashcode, handler);

                        // Create the new connection pool
                        pool = new FbConnectionPool(connectionString);

                        this.pools.Add(hashcode, pool);

                        pool.EmptyPool += handler;
                    }
                }
            }

            return pool;
        }

        public void ClearAllPools()
        {
            lock (this)
            {
                lock (this.pools.SyncRoot)
                {
                    FbConnectionPool[] tempPools = new FbConnectionPool[this.pools.Count];

                    this.pools.Values.CopyTo(tempPools, 0);

                    foreach (FbConnectionPool pool in tempPools)
                    {
                        // Clear pool
                        pool.Clear();
                    }

                    // Clear Hashtables
                    this.pools.Clear();
                    this.handlers.Clear();
                }
            }
        }

        public void ClearPool(string connectionString)
        {
            lock (this)
            {
                lock (this.pools.SyncRoot)
                {
                    int hashCode = connectionString.GetHashCode();

                    if (this.pools.ContainsKey(hashCode))
                    {
                        FbConnectionPool pool = (FbConnectionPool)this.pools[hashCode];

                        // Clear pool
                        pool.Clear();
                    }
                }
            }
        }

        #endregion

        #region � Private Methods �

        private void OnEmptyPool(object sender, EventArgs e)
        {
            lock (this.pools.SyncRoot)
            {
                int hashCode = (int)sender;

                if (this.pools.ContainsKey(hashCode))
                {
                    FbConnectionPool pool = (FbConnectionPool)this.pools[hashCode];
                    EmptyPoolEventHandler handler = (EmptyPoolEventHandler)this.handlers[hashCode];

                    pool.EmptyPool -= handler;

                    this.pools.Remove(hashCode);
                    this.handlers.Remove(hashCode);

                    pool = null;
                    handler = null;
                }
            }
        }

        #endregion
    }
}
