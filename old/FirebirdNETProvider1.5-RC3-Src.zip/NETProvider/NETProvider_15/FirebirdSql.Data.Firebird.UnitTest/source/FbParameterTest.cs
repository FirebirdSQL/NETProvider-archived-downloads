//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Data.Common;

using NUnit.Framework;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbParameterTest : BaseTest 
	{
		public FbParameterTest() : base()
		{		
		}
		
		[Test]
		public void ConstructorsTest()
		{
			FbParameter ctor01 = new FbParameter();
			FbParameter ctor02 = new FbParameter("ctor2", 10);
			FbParameter ctor03 = new FbParameter("ctor3", FbDbType.Char);
			FbParameter ctor04 = new FbParameter("ctor4", FbDbType.Integer, 4);
			FbParameter ctor05 = new FbParameter("ctor5", FbDbType.Integer, 4, "int_field");
			FbParameter ctor06 = new FbParameter(
				"ctor6", 
				FbDbType.Integer, 
				4, 
				ParameterDirection.Input, 
				false, 
				0, 
				0, 
				"int_field", 
				DataRowVersion.Original, 
				100);
		}
	}
}
