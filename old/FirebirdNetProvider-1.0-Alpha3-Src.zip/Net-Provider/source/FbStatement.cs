//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.Data;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <summary>
	/// fbstatement States
	/// </summary>
	internal enum CommandState {Deallocated,Allocated,Preparing,Prepared,Executing,Executed};

	/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="T:FbStatement"]/*'/>
	internal class FbStatement
	{
		#region FIELDS

		private isc_stmt_handle_impl	statement	= null;

		private FbConnection			connection	= null;
		private FbTransaction			transaction	= null;
		private FbResultset				resultset	= null;
		private FbParameterCollection	parameters	= new FbParameterCollection();
				
		private string					commandText;
		private CommandState			state		= CommandState.Deallocated;
		private CommandType				commandType	= CommandType.Text;

		private int						recordsAffected = -1;
		
		// Statement info
		private static byte[] stmtInfo  = new byte[]
		{
			GdsCodes.isc_info_sql_records,
			GdsCodes.isc_info_sql_stmt_type,
			GdsCodes.isc_info_end
		};

		// Statement info size
		private static int INFO_SIZE = 128;

		#endregion

		#region PROPERTIES

		public isc_stmt_handle_impl Statement
		{
			get{return statement;}
		}

		public int RecordsAffected
		{
			get{return recordsAffected;}
		}
		
		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="P:CommandType"]/*'/>
		public CommandType CommandType
		{
			get { return commandType; }
			set { commandType = value; }
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="P:Connection"]/*'/>
		public FbConnection Connection
		{
			get{return connection;}
			set
			{
				if(Transaction != null)
				{
					if(Transaction.Transaction != null)
					{
						throw new ArgumentException("Transaction in progress.");
					}
				}

				/*
				 * The connection is associated with the transaction
				 * so set the transaction object to return a null reference 
				 * if the connection is reset.
				 */
				if (connection != value)
				{										
					if(transaction != null)
					{
						transaction.Rollback();
						transaction = null;
					}

					if (statement != null)
					{
						Close(false);
						statement			= null;
					}
				}

				connection = value;
				statement = (isc_stmt_handle_impl)FbIscConnection.gds.get_new_isc_stmt_handle();
			}
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="P:Transaction"]/*'/>
		public FbTransaction Transaction
		{
			get{return transaction;}
			set
			{
				if(transaction != null)
				{
					if(transaction.Transaction == null)
					{
						transaction = value; 
					}
				}
				else
				{
					transaction = value;
				}
			}
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="P:Parameters"]/*'/>
		public FbParameterCollection Parameters
		{
			get  { return parameters; }
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="P:CommandText"]/*'/>
		public string CommandText
		{
			get{return commandText;}
			set{commandText = value;}
		}

		public FbResultset Resultset
		{
			get{return resultset;}
		}

		#endregion

		#region CONSTRUCTORS

		public FbStatement()
		{
		}

		public FbStatement(FbConnection conn, FbTransaction txn, FbParameterCollection parameters, string commandText)
		{
			connection  = conn;
			transaction = txn;

			this.parameters = parameters;
			this.commandText= commandText;
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="M:Execute"]/*'/>
		public void Execute()
		{
			try
			{
				if(state == CommandState.Deallocated)
				{
					Prepare();
				}

				state = CommandState.Executing;

				switch(CommandType)
				{
					case System.Data.CommandType.StoredProcedure:						
						FbIscConnection.gds.isc_dsql_execute2(
									transaction.Transaction, 
									statement, 
									GdsCodes.SQLDA_VERSION1, 
									GetInSqlda(), 
									statement.OutSqlda);
						break;

					default:
						FbIscConnection.gds.isc_dsql_execute(
								transaction.Transaction, 
								statement, 
								GdsCodes.SQLDA_VERSION1, 
								GetInSqlda());
						break;
				}			

				GetUpdateCount();
						
				if(connection.AutoCommit)
					Transaction.Commit();

				state = CommandState.Executed;
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		public void Prepare()
		{
			try
			{
				if(state == CommandState.Deallocated)
					AllocateStatement();

				state = CommandState.Preparing;

				XSQLDA output = FbIscConnection.gds.isc_dsql_prepare(
							transaction.Transaction, 
							statement, 
							CommandText, 
							connection.Charset, 
							connection.Dialect);
							
				// sqln: number of fields allocated
				// sqld: actual number of fields
				if (output.sqld != output.sqln)
					throw new FbException("Invalid number of allocated columns in resultset.");
				
				FbIscConnection.gds.isc_dsql_describe(statement, GdsCodes.SQLDA_VERSION1);
			
				XSQLDA input = FbIscConnection.gds.isc_dsql_describe_bind(
											statement, GdsCodes.SQLDA_VERSION1);

				// sqln: number of fields allocated
				// sqld: actual number of fields
				if (input.sqld != input.sqln)
					throw new FbException("Invalid number of allocated columns in resultset.");
		
				state = CommandState.Prepared;				

				resultset = new FbResultset(connection, transaction, statement);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="M:AllocateStatement"]/*'/>
		private void AllocateStatement()
		{
			try
			{
				if(statement == null)
					statement = (isc_stmt_handle_impl)FbIscConnection.gds.get_new_isc_stmt_handle();
				FbIscConnection.gds.isc_dsql_allocate_statement(connection.ic.db, statement);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="M:IsSelect"]/*'/>
		public bool IsSelect()
		{
			return statement.OutSqlda.sqld > 0  ? true : false;
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close(bool deallocate)
		{
			if(statement != null)
			{
				try
				{
					FbIscConnection.gds.isc_dsql_free_statement(statement, (deallocate) ? GdsCodes.DSQL_drop : GdsCodes.DSQL_close);

					state = deallocate ? CommandState.Deallocated : CommandState.Allocated;				
				}
				catch(GDSException ex)
				{
					throw new FbException(ex);
				}
			}
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="M:GetUpdateCount"]/*'/>
		private void GetUpdateCount()
		{
			SqlInfo info;

			try
			{				
				info = new SqlInfo(FbIscConnection.gds.isc_dsql_sql_info(
					statement, 
					stmtInfo.Length, 
					stmtInfo, 
					INFO_SIZE), 
					FbIscConnection.gds);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			recordsAffected = (info.InsertCount + info.UpdateCount + info.DeleteCount);

			recordsAffected = recordsAffected == 0 ? -1 : recordsAffected;
		}

		/// <include file='xmldoc/fbstatement.xml' path='doc/member[@name="M:GetInSqlda"]/*'/>		
		private XSQLDA GetInSqlda()
		{
			XSQLDA in_sqlda = statement.InSqlda;
			IEnumerator paramEnumerator = Parameters.GetEnumerator();

			if(in_sqlda == null)
				return in_sqlda;

			if(Parameters.Count != in_sqlda.sqlvar.Length)
			{
				throw new InvalidOperationException("Invalid number of parameters for command execution.");
			}
			
			int i = 0;
			while(paramEnumerator.MoveNext())
			{
				if(((FbParameter)paramEnumerator.Current).Direction == ParameterDirection.Input ||
				   ((FbParameter)paramEnumerator.Current).Direction == ParameterDirection.InputOutput)
				{
					switch (in_sqlda.sqlvar[i].sqltype & ~1)
					{
						case GdsCodes.SQL_TEXT:
						case GdsCodes.SQL_VARYING:							
							in_sqlda.sqlvar[i].sqldata = (string)(((FbParameter)paramEnumerator.Current).Value);
							break;

						case GdsCodes.SQL_SHORT:
							in_sqlda.sqlvar[i].sqldata = Int16.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
							break;

						case GdsCodes.SQL_LONG:
							in_sqlda.sqlvar[i].sqldata = Int32.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
							break;
			
						case GdsCodes.SQL_FLOAT:
							in_sqlda.sqlvar[i].sqldata = float.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
							break;
								
						case GdsCodes.SQL_DOUBLE:
						case GdsCodes.SQL_D_FLOAT:
							in_sqlda.sqlvar[i].sqldata = Double.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
							break;
							
						case GdsCodes.SQL_BLOB:
							if(in_sqlda.sqlvar[i].sqlsubtype == 1)
							{
								FbClob clob = new FbClob(Connection, Transaction);
								in_sqlda.sqlvar[i].sqldata = clob.Write(
									(((FbParameter)paramEnumerator.Current).Value).ToString());
							}
							else
							{
								FbBlob blob = new FbBlob(Connection, Transaction);
								in_sqlda.sqlvar[i].sqldata = blob.Write((byte[])
									((FbParameter)paramEnumerator.Current).Value);
							}
						
							break;
			
						case GdsCodes.SQL_ARRAY:
							// TODO: Write array data
							break;

						case GdsCodes.SQL_QUAD:
						case GdsCodes.SQL_INT64:
							in_sqlda.sqlvar[i].sqldata = Int64.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
							break;
								
						case GdsCodes.SQL_TIMESTAMP:
						case GdsCodes.SQL_TYPE_TIME:			
						case GdsCodes.SQL_TYPE_DATE:				
							in_sqlda.sqlvar[i].sqldata = DateTime.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
							break;
				
						default:
							throw new NotSupportedException("Unknown data type");
					}							

					if(in_sqlda.sqlvar[i].sqldata == System.DBNull.Value)
					{
						if((in_sqlda.sqlvar[i].sqltype & 1 ) == 0)
						{
							throw new InvalidOperationException("Parameter value cannot be null.");
						}
					}

					i++;
				}
			}

			return in_sqlda;
		}

		#endregion
	}
}
