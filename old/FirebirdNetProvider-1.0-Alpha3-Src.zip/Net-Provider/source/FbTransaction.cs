//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;
using System.Collections;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="T:FbTransaction"]/*'/>
	public sealed class FbTransaction : IDbTransaction
	{
		#region FIELDS

		internal isc_tr_handle_impl	tr;
		internal FbConnection		connection = null;
		internal IsolationLevel		isolationLevel = IsolationLevel.ReadCommitted;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="P:Connection"]/*'/>
		IDbConnection IDbTransaction.Connection
		{
			get{ return Connection; }			
		}

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="P:Connection"]/*'/>
		public FbConnection Connection
		{
			get{ return connection; }
			set{ connection = value; }
		}

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="P:IsolationLevel"]/*'/>
		public IsolationLevel IsolationLevel 
		{
			get { return isolationLevel; }
			set { isolationLevel = value; }
		}

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="P:Transaction"]/*'/>
		internal isc_tr_handle_impl Transaction
		{
			get { return tr; }			
		}

		#endregion

		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection)"]/*'/>
		public FbTransaction(FbConnection connection)
		{
			this.connection = connection;
		}				

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,System.Data.IsolationLevel)"]/*'/>
		public FbTransaction(FbConnection connection, IsolationLevel il)
		{
			this.isolationLevel = il;
			this.connection = connection;			
		}				

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="M:Dispose"]/*'/>
		public void Dispose()
		{
			if(connection != null)
			{
				if(Transaction.State == TxnState.TRANSACTIONSTARTED || 
					Transaction.State == TxnState.TRANSACTIONPREPARED)
				{
					Rollback();
				}
			}

			connection	= null;
			tr			= null;
		}

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		internal void BeginTransaction()
		{
			try
			{
				// Initialization of transaction handler
				tr = (isc_tr_handle_impl)FbIscConnection.gds.get_new_isc_tr_handle();

				ArrayList iscTpb = new ArrayList();

				iscTpb.Add(GdsCodes.isc_tpb_version3);
				iscTpb.Add(GdsCodes.isc_tpb_write);
				iscTpb.Add(GdsCodes.isc_tpb_wait);

				/* Isolation level */
				switch(this.isolationLevel)
				{
					case IsolationLevel.Serializable:
						iscTpb.Add(GdsCodes.isc_tpb_consistency);						
						break;

					case IsolationLevel.RepeatableRead:				
						iscTpb.Add(GdsCodes.isc_tpb_concurrency);						
						break;

					case IsolationLevel.ReadUncommitted:
						iscTpb.Add(GdsCodes.isc_tpb_read_committed);
						iscTpb.Add(GdsCodes.isc_tpb_rec_version);
						break;

					case IsolationLevel.ReadCommitted:
					default:					
						iscTpb.Add(GdsCodes.isc_tpb_read_committed);
						iscTpb.Add(GdsCodes.isc_tpb_no_rec_version);
						break;
				}

				FbIscConnection.gds.isc_start_transaction(tr, connection.ic.db, iscTpb);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}

		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="M:Commit"]/*'/>
		public void Commit()
		{
			// Checks if exists a active transaction handler
			if(tr == null)
				return;

			try
			{
				FbIscConnection.gds.isc_commit_retaining(tr);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}
	
		/// <include file='xmldoc/fbtransaction.xml' path='doc/member[@name="M:Rollback"]/*'/>
		public void Rollback()
		{
			// Checks if exists a active transaction handler
			if(tr == null)
				return;

			try
			{
				FbIscConnection.gds.isc_rollback_transaction(tr);
				tr = null;
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}

		#endregion
	}
}
