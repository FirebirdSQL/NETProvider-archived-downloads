//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="T:FbErrorCollection"]/*'/>
	public sealed class FbErrorCollection : ArrayList
	{
		#region PROPERTIES

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="P:Item(System.String)"]/*'/>
		public FbError this[string errorMessage] 
		{
			get{return (FbError)this[IndexOf(errorMessage)];}
			set{this[IndexOf(errorMessage)] = (FbError)value;}
		}

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="P:Item(System.Int32)"]/*'/>
		public new FbError this[int errorIndex] 
		{
			get{return (FbError)base[errorIndex];}
			set{base[errorIndex] = (FbError)value;}
		}

		#endregion

		#region METHODS
	
		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:Contains(System.String)"]/*'/>
		public bool Contains(string errorMessage)
		{
			return(-1 != IndexOf(errorMessage));
		}
		
		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:IndexOf(System.String)"]/*'/>
		public int IndexOf(string errorMessage)
		{
			int index = 0;
			foreach(FbError item in this)
			{
				if (0 == _cultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:RemoveAt(System.String)"]/*'/>
		public void RemoveAt(string errorMessage)
		{
			RemoveAt(IndexOf(errorMessage));
		}

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:Add(System.Object)"]/*'/>
		public override int Add(object value)
		{
			return Add((FbError)value);
		}

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:Add(FirebirdSql.Data.Firebird.FbError)"]/*'/>
		public int Add(FbError error)
		{
			if (((FbError)error).Message != null)
			{
				return base.Add(error);
			}
			else
				throw new ArgumentException("error must be a message");
		}

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:Add(System.String,System.Int32)"]/*'/>
		public int Add(string errorMessage, int number)
		{
			return Add(new FbError(errorMessage, number));
		}

		/// <include file='xmldoc/fberrorcollection.xml' path='doc/member[@name="M:Add(System.Byte,System.Int32,System.String,System.Int32)"]/*'/>
		public int Add(byte classError, int line, string errorMessage, int number)
		{
			return Add(new FbError(classError, line, errorMessage, number));
		}
		
		private int _cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB, CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.IgnoreCase);
		}

		#endregion
	}
}
