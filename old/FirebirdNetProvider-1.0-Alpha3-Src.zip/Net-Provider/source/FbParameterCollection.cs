//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="T:FbParameterCollection"]/*'/>
	public sealed class FbParameterCollection : ArrayList, IDataParameterCollection
	{
		#region PROPERTIES

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="P:Item(System.String)"]/*'/>
		object IDataParameterCollection.this[string parameterName] 
		{
			get{ return this[parameterName]; }
			set{ this[parameterName] = (FbParameter)value; }
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="P:Item(System.String)"]/*'/>
		public FbParameter this[string parameterName] 
		{
			get{ return (FbParameter)this[IndexOf(parameterName)]; }
			set{ this[IndexOf(parameterName)] = (FbParameter)value; }
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="P:Item(System.Int32)"]/*'/>
		public new FbParameter this[int parameterIndex] 
		{
			get{ return (FbParameter)base[parameterIndex]; }
			set{ base[parameterIndex] = (FbParameter)value; }
		}
		
		#endregion

		#region METHODS

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Contains(System.String)"]/*'/>
		public bool Contains(string parameterName)
		{
			return(-1 != IndexOf(parameterName));
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:IndexOf(System.String)"]/*'/>
		public int IndexOf(string parameterName)
		{
			int index = 0;
			foreach(FbParameter item in this)
			{
				if (0 == _cultureAwareCompare(item.ParameterName, parameterName))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:RemoveAt(System.String)"]/*'/>
		public void RemoveAt(string parameterName)
		{
			RemoveAt(IndexOf(parameterName));
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Add(System.Object)"]/*'/>
		public override int Add(object value)
		{
			return base.Add((FbParameter)value);
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Add(FirebirdSql.Data.Firebird.FbParameter)"]/*'/>
		public FbParameter Add(FbParameter param)
		{
			if (param.ParameterName != null)
			{
				base.Add(param);
				
				return param;
			}
			else
				throw new ArgumentException("parameter must be named");
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Add(System.String,FirebirdSql.Data.Firebird.FbType)"]/*'/>
		public FbParameter Add(string parameterName, FbType type)
		{
			FbParameter param = new FbParameter(parameterName, type);			
			
			return Add(param);
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Add(System.String,System.Object)"]/*'/>
		public FbParameter Add(string parameterName, object value)
		{
			FbParameter param = new FbParameter(parameterName, value);

			return Add(param);
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Add(System.String,FirebirdSql.Data.Firebird.FbType,System.String)"]/*'/>
		public FbParameter Add(string parameterName, FbType fbType, string sourceColumn)
		{
			FbParameter param = new FbParameter(parameterName, fbType, sourceColumn);
			
			return Add(param);
		}

		/// <include file='xmldoc/fbparametercollection.xml' path='doc/member[@name="M:Add(System.String,FirebirdSql.Data.Firebird.FbType,System.Int32,System.String)"]/*'/>
		public FbParameter Add(string parameterName, FbType fbType, int size, string sourceColumn)
		{
			FbParameter param = new FbParameter(parameterName, fbType, size, sourceColumn);

			return Add(param);		
		}

		private int _cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB, CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.IgnoreCase);
		}

		#endregion
	}
}

