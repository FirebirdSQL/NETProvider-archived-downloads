//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.ComponentModel;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="T:FbCommand"]/*'/>
	public sealed class FbCommand : Component, IDbCommand, ICloneable
	{				
		#region FIELDS

		private FbStatement		statement		 = new FbStatement();
		private UpdateRowSource	updatedRowSource = UpdateRowSource.Both;
		private CommandBehavior	commandBehavior	 = CommandBehavior.Default;

		private int				actualCommand	 = -1;
		private bool			disposed		 = false;
		private string			commandText;
		private string[]		commands;
		private int				recordsAffected	 = -1;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandText"]/*'/>
		public string CommandText
		{
			get 
			{ 
				return commands[actualCommand] == null ? "" : commands[actualCommand];
			}
			set 
			{ 				
				commandText  = value;
				commands = commandText.Split(';');
				this.actualCommand = 0;
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandType"]/*'/>
		public CommandType CommandType
		{
			get { return statement.CommandType; }
			set { statement.CommandType = value; }
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandTimeout"]/*'/>
		public int CommandTimeout
		{
			get  { return 0; }
			set  { if (value != 0) throw new NotSupportedException(); }
		}
		
		IDbConnection IDbCommand.Connection
		{
			get{ return Connection;  }
			set{ Connection = (FbConnection)value;}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Connection"]/*'/>
		public FbConnection Connection
		{
			get{return statement.Connection;}
			set{statement.Connection = value;}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Parameters"]/*'/>
		IDataParameterCollection IDbCommand.Parameters
		{
			get  { return Parameters; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Parameters"]/*'/>
		public FbParameterCollection Parameters
		{
			get  { return statement.Parameters; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Transaction"]/*'/>
		IDbTransaction IDbCommand.Transaction
		{
			get{ return Transaction; }
			set{ Transaction = (FbTransaction)value; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Transaction"]/*'/>
		public FbTransaction Transaction
		{
			get{return statement.Transaction;}
			set{statement.Transaction = value;}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:UpdatedRowSource"]/*'/>
		public UpdateRowSource UpdatedRowSource
		{
			get { return updatedRowSource;  }
			set { updatedRowSource = value; }
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandBehavior"]/*'/>
		internal CommandBehavior CommandBehavior
		{
			get{return commandBehavior;}
		}

		internal FbStatement Statement
		{
			get{return statement;}
		}

		internal int RecordsAffected
		{
			get{return recordsAffected;}
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbCommand()
		{
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		public FbCommand(string cmdText)
		{
			this.CommandText = cmdText;
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor(System.String,FirebirdSql.Data.Firebird.FbConnection)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection)
		{
			this.CommandText = cmdText;
			this.Connection	 = connection;
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor(System.String,FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection, FbTransaction txn)
		{
			this.CommandText = cmdText;
			this.Connection  = connection;
			this.Transaction = txn;
		}				 

		#endregion

		#region DESTRUCTORS

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Finalize"]/*'/>
		~FbCommand() 
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false)is optimal in terms of
			// readability and maintainability.
			Dispose (false);
		}

		#endregion

		#region METHODS
		
		object ICloneable.Clone()
		{
			throw new NotImplementedException();
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if(!disposed)
			{
				try
				{
					if(disposing)
					{
						this.CommandText	= "";
						this.actualCommand	= -1;
						this.commands		= null;
						this.Parameters.Clear();
					}					

					disposed = true;
				}
				finally
				{
					base.Dispose(disposing);
				}
			}
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Cancel"]/*'/>
		public void Cancel()
		{			
			throw new NotSupportedException();
		}
		
		IDbDataParameter IDbCommand.CreateParameter()
		{
			return CreateParameter();
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:CreateParameter"]/*'/>
		public FbParameter CreateParameter()
		{
			return new FbParameter();
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteNonQuery"]/*'/>
		public int ExecuteNonQuery()
		{      
			if (Connection == null || Connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");

			if(!Connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			if(Connection.DataReader != null)
				throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");

			try
			{
				Prepare();
				statement.Execute();
			}
			catch(GDSException ex)
			{
				if(Connection.AutoCommit)
					Transaction.Rollback();

				throw new FbException(ex);
			}
			
			recordsAffected = statement.RecordsAffected;

			return recordsAffected;
		}
				
		IDataReader IDbCommand.ExecuteReader()
		{	
			return ExecuteReader();			
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteReader"]/*'/>
		public FbDataReader ExecuteReader()
		{	
			return ExecuteReader(CommandBehavior.Default);			
		}
		
		IDataReader IDbCommand.ExecuteReader(CommandBehavior behavior)
		{
			return ExecuteReader(behavior);
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteReader(System.Data.CommandBehavior)"]/*'/>	
		public FbDataReader ExecuteReader(CommandBehavior behavior)
		{
			if (Connection == null || Connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");

			if(!Connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			if(Connection.DataReader != null)
				throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");

			try
			{
				commandBehavior = behavior;
				
				Prepare();
				
				statement.Execute();
				recordsAffected = statement.RecordsAffected;
			}
			catch(GDSException ex)
			{
				if(Connection.AutoCommit)
					Transaction.Rollback();

				throw new FbException(ex);
			}

			return new FbDataReader(this);
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteScalar"]/*'/>
		public object ExecuteScalar()
		{
			object val = null;

			if (Connection == null || Connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");

			if(!Connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			if(Connection.DataReader != null)
				throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");

			try
			{
				Prepare();				
				
				statement.Execute();
				recordsAffected = statement.RecordsAffected;

				// Gets only the first row
				if(statement.Resultset.Fetch())
				{
					val = statement.Resultset.GetValue(0);
				}
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return val;
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Prepare"]/*'/>	
		public void Prepare()
		{
			if (Connection == null || Connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");			

			if(!Connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			try
			{
				if(Transaction == null)
				{					
					Transaction = Connection.BeginTransaction();
				}
				statement.CommandText = CommandText;
				statement.Prepare();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:NextResult"]/*'/>
		internal bool NextResult()
		{
			bool returnValue = false;

			actualCommand++;

			if(actualCommand>=commands.Length)
			{
				actualCommand--;
			}
			else
			{
				statement.Parameters.Clear();

				statement.Close(true);

				statement = new FbStatement(Connection, Transaction, Parameters, commands[actualCommand]);

				Prepare();
				
				statement.Execute();
				recordsAffected = statement.RecordsAffected;

				returnValue = true;
			}

			return returnValue;
		}
	
		#endregion
	}
}
