//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// Exception for use in the GDSImpl class
	/// </summary>
	internal class GDSException : Exception 
	{	
		#region FIELDS
		
		/// <summary>
		/// Exception type
		/// </summary>
		protected int			type;
		/// <summary>
		/// Exception number
		/// </summary>
		protected int			intParam;
		/// <summary>
		/// Exception string ????
		/// </summary>
		protected string		strParam;
		/// <summary>
		/// Exception message
		/// </summary>
		protected string		message;
		/// <summary>
		/// Child Exception
		/// </summary>
		protected GDSException	next;

		#endregion

		#region PROPERTIES
		/// <summary>
		/// Returns the parameter depending on the type of the 
		/// error code.
		/// </summary>
		public string StrParam
		{
			get
			{
				if ((type == GdsCodes.isc_arg_interpreted) ||
					(type == GdsCodes.isc_arg_string))
					return strParam;
				else
					if (type == GdsCodes.isc_arg_number)
					return "" + intParam;
				else
					return "";
			}
		}

		/// <summary>
		/// Int param
		/// </summary>
		public int IntParam
		{
			get{return intParam;}			
		}
	    
		/// <summary>
		/// Next exception
		/// </summary>
		public GDSException Next
		{
			get{return next;}
			set{next=value;}
		}

		/// <summary>
		/// Mensaje de la excepcin
		/// </summary>
		public override string Message
		{
			get{ return message; }
		}
		#endregion

		#region CONSTRUCTORS
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="intParam">Int param</param>
		public GDSException(int type, int intParam)
		{
			this.type = type;
			this.intParam = intParam;
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="strParam">String param</param>
		public GDSException(int type, string strParam) 
		{
			this.type = type;
			this.strParam = strParam;
		}
	    
		/// <summary>
		///	Construct instance of this class. This method correctly constructs 
		///	chain of exceptions for one string parameter.
		/// </summary>
		/// <param name="type">
		///		type of the exception, should be always 
		///		isc_arg_gds otherwise no message will be displayed.
		///	</param>
		/// <param name="fbErrorCode">
		///		Firebird error code, one of the constants declared
		///		in <see cref="IGDS"/> interface.
		///	</param>
		/// <param name="strParam">
		///		value of the string parameter that will substitute 
		///		<code>{0}</code> entry in error message corresponding to the specified
		///		error code.
		/// </param>
		public GDSException(int type, int fbErrorCode, string strParam) 
		{
			this.type		= type;
			this.intParam	= fbErrorCode;
			this.message	= "Unknown exception";
			this.next		= new GDSException(GdsCodes.isc_arg_string, strParam);
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="fbErrorCode"></param>
		public GDSException(int fbErrorCode) 
		{
			this.intParam	= fbErrorCode;
			this.type		= GdsCodes.isc_arg_gds;
			this.message	= "Unknown exception";
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="message"></param>
		public GDSException(string message) : base(message)
		{			
			this.message = message;
			this.type	 = GdsCodes.isc_arg_string;
		}
		#endregion

		#region METHODS
		/// <summary>
		/// Return the Firebird Error code
		/// </summary>
		/// <returns></returns>
		public int GetFbErrorCode() 
		{
			if (type == GdsCodes.isc_arg_number)
				return intParam;
			else
				return -1;
		}

		/// <summary>
		/// Returns a string representation of this exception. 
		/// </summary>
		/// <returns></returns>
		public override string ToString() 
		{
			string msg;
        
			GDSException child = this.next;
        
			// If represent a GDSMessage code, then let's format it nicely.
			if (type == GdsCodes.isc_arg_gds || type == GdsCodes.isc_arg_warning)
			{
				// get message
				GDSMessage message =
					GDSExceptionHelper.GetMessage(intParam);

				// substitute parameters using my children
				int paramCount = message.GetParamCount();
				for(int i = 0; i < paramCount; i++) 
				{
					if (child == null) break;
					message.SetParameter(i, child.StrParam);
					child = child.next;
				}

				// convert message to string
				msg = message.ToString();
			}
			else 
			{
				// No GDSMessage code, so use the default message.				
				msg = this.Message;
			}
  
			// Do we have more children? Then include their messages too.			
			if (child != null)
				msg += "\n" + child.ToString();
 
			return msg;
		}

		/// <summary>
		/// Returns a value indicating if the Exception is a server Warning
		/// </summary>
		/// <returns>Tru if is a Server Warining or false if not</returns>
		public bool IsWarning() 
		{
			return type == GdsCodes.isc_arg_warning;			
		}		
		#endregion
	}
}
