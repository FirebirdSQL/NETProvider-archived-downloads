//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// The class <code>XSQLVAR</code> is a c# mapping of the XSQLVAR server
	/// data structure used to represent one column for input and output.
	/// </summary>
	internal class XSQLVAR 
	{
		#region FIELDS
		/// <summary>
		/// SQL Type
		/// </summary>
		public int sqltype;
		/// <summary>
		/// Scale
		/// </summary>
		public int sqlscale;
		/// <summary>
		/// Subtype (Blobs Fields)
		/// </summary>
		public int sqlsubtype;
		/// <summary>
		/// Length
		/// </summary>
		public int sqllen;
		/// <summary>
		/// Data
		/// </summary>
		public object sqldata;
		/// <summary>
		/// Position ????
		/// </summary>
		public int sqlind;
		/// <summary>
		/// Name
		/// </summary>
		public string sqlname;
		/// <summary>
		/// Relation name
		/// </summary>
		public string relname;
		/// <summary>
		/// Owner name
		/// </summary>
		public string ownname;
		/// <summary>
		/// Alias name
		/// </summary>
		public string aliasname;
		#endregion

		#region CONSTRUCTORS
		/// <summary>
		/// Constructor
		/// </summary>
		public XSQLVAR() 
		{
		}

		/// <summary>
		/// Initializes a new instance of XSQLVAR class
		/// </summary>
		/// <param name="sqldata">Fiekd data</param>
		public XSQLVAR(object sqldata) 
		{
			this.sqldata = sqldata;
		}
		#endregion
	}
}
