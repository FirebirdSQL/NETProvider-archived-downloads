//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;
using FirebirdSql.Logging;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="T:FbDataReader"]/*'/>
	public sealed class FbDataReader : IDataReader
	{		
		#region FIELDS
		
		private Log4CSharp  log		  = null;
		private bool		open	  = true;
		private static int  STARTPOS  = -1;
		private int			position  = STARTPOS;
		private int			recordsAffected = -1;						
		private DataTable	schemaTable;
		FbCommand			command;		

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbCommand)"]/*'/>
		internal FbDataReader(FbCommand command)
		{
			command.Connection.DataReader = this;			

			this.schemaTable = null;
			this.command	 = command;

			UpdateRecordsAffected();

			#if (_DEBUG)
				log = new Log4CSharp(GetType(), "fbprov.log", Mode.APPEND);
			#endif
		}

		#endregion

		#region IDISPOSABLE_METHODS
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:Dispose"]/*'/>
		public void Dispose()
		{
			Close();
		}

		#endregion

		#region IDATAREADER_PROPERTIES_METHODS

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:Depth"]/*'/>
		public int Depth 
		{
			get {return 0;}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:IsClosed"]/*'/>
		public bool IsClosed
		{
			get  {return !open;}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:RecordsAffected"]/*'/>
		public int RecordsAffected 
		{
			get {return IsClosed ? recordsAffected : -1;}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close()
		{
			if(!open)
				return;
						
			if((command.CommandBehavior & CommandBehavior.CloseConnection) == CommandBehavior.CloseConnection)
			{
				command.Connection.Close();
			}

			command.Connection.DataReader = null;

			open	 = false;			
			position = STARTPOS;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:NextResult"]/*'/>
		public bool NextResult()
		{
			bool returnValue = command.NextResult();

			if( returnValue )
			{
				UpdateRecordsAffected();
				position  = STARTPOS;				
			}

			return returnValue;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:Read"]/*'/>
		public bool Read()
		{
			if(log!=null) log.Debug("read");

			if(command.CommandBehavior == CommandBehavior.SingleRow && position != -1)
				return false;

			try
			{
				command.Statement.Resultset.Fetch();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			if (command.Statement.Resultset.EOF)
			{
				return false;
			}
			else
			{
				position++;
				return true;
			}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetSchemaTable"]/*'/>
		public DataTable GetSchemaTable()
		{
			if(log!=null) log.Debug("GetSchemaTable");

			if(schemaTable != null)
				return schemaTable;

			DataRow		schemaRow;

			schemaTable = this.GetSchemaTableStructure();

			for (int i=0;i<FieldCount;i++)
			{
				schemaRow = schemaTable.NewRow();

				schemaRow["ColumnName"]		= GetAliasName(i);
				schemaRow["ColumnOrdinal"]	= i;
				schemaRow["ColumnSize"]		= GetSize(i);
				if(IsNumeric(i))
				{
					schemaRow["NumericPrecision"]= GetSize(i);
					schemaRow["NumericScale"]	 = GetScale(i);
				}
				else
				{
					schemaRow["NumericPrecision"]= System.DBNull.Value;
					schemaRow["NumericScale"]	 = System.DBNull.Value;
				}
				schemaRow["DataType"]		= GetFieldType(i);
				schemaRow["ProviderType"]	= GetProviderType(i);
				schemaRow["IsLong"]			= IsLong(i);
				schemaRow["AllowDBNull"]	= AllowDBNull(i);
				schemaRow["IsReadOnly"]		= IsReadOnly(i);
				schemaRow["IsUnique"]		= IsUnique(i);				
				schemaRow["IsKeyColumn"]	= IsKey(i);				
				schemaRow["IsAutoIncrement"]= false;
				schemaRow["BaseSchemaName"]	= null;
				schemaRow["BaseCatalogName"]= null;
				schemaRow["BaseTableName"]	= GetBaseTableName(i);
				schemaRow["BaseColumnName"]	= GetName(i);

				schemaTable.Rows.Add(schemaRow);
			}

			return schemaTable;
		}

		#endregion

		#region IDATARECORD_PROPERTIES_METHODS

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:Item(System.Int32)"]/*'/>
		public object this[int i]
		{
			get {return GetValue(i);}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:Item(System.String)"]/*'/>
		public object this [String name]
		{			
			get {return GetValue(GetOrdinal(name));}
		}
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:FieldCount"]/*'/>
		public int FieldCount
		{			
			get{return command.Statement.Resultset.FieldCount;}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetName(System.Int32)"]/*'/>
		public String GetName(int i)
		{
			return command.Statement.Resultset.GetName(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDataTypeName(System.Int32)"]/*'/>
		public String GetDataTypeName(int i)
		{
			return command.Statement.Resultset.GetDataTypeName(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetFieldType(System.Int32)"]/*'/>
		public Type GetFieldType(int i)
		{			
			return command.Statement.Resultset.GetFieldType(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetValue(System.Int32)"]/*'/>
		public Object GetValue(int i)
		{
			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetValue(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetValues(System.Object[])"]/*'/>
		public int GetValues(object[] values)
		{
			if(log!=null) log.Debug("GetValues");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");
			
			for(int i=0;i<FieldCount;i++)
			{
				values[i] = this.GetValue(i);
			}

			return values.Length;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetOrdinal(System.String)"]/*'/>
		public int GetOrdinal(string name)
		{
			if(log!=null) log.Debug("GetOrdinal");

			if(IsClosed)
				throw new InvalidOperationException("Reader closed");

			return command.Statement.Resultset.GetOrdinal(name);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetBoolean(System.Int32)"]/*'/>
		public bool GetBoolean(int i)
		{
			if(log!=null) log.Debug("GetBoolean");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetBoolean(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetByte(System.Int32)"]/*'/>
		public byte GetByte(int i)
		{
			if(log!=null) log.Debug("GetByte");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetByte(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetBytes(System.Int32,System.Int64,System.Byte[],System.Int32,System.Int32)"]/*'/>
		public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferOffset, int length)
		{
			if(log!=null) log.Debug("GetBytes");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetBytes(i, fieldOffset, buffer, bufferOffset, length);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetChar(System.Int32)"]/*'/>
		public char GetChar(int i)
		{
			if(log!=null) log.Debug("GetChar");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");
			
			return command.Statement.Resultset.GetChar(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetChars(System.Int32,System.Int64,System.Char[],System.Int32,System.Int32)"]/*'/>
		public long GetChars(int i, long fieldOffset, char[] buffer, int bufferOffset, int length)
		{
			if(log!=null) log.Debug("GetChars");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return command.Statement.Resultset.GetChars(i, fieldOffset, buffer, bufferOffset, length);
		}
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetGuid(System.Int32)"]/*'/>
		public Guid GetGuid(int i)
		{
			if(log!=null) log.Debug("GetGuid");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetGuid(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetInt16(System.Int32)"]/*'/>
		public Int16 GetInt16(int i)
		{
			if(log!=null) log.Debug("GetInt16");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetInt16(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetInt32(System.Int32)"]/*'/>
		public Int32 GetInt32(int i)
		{
			if(log!=null) log.Debug("GetInt32");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetInt32(i);
		}
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetInt64(System.Int32)"]/*'/>
		public Int64 GetInt64(int i)
		{
			if(log!=null) log.Debug("GetInt64");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetInt64(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetFloat(System.Int32)"]/*'/>
		public float GetFloat(int i)
		{
			if(log!=null) log.Debug("GetFloat");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetFloat(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDouble(System.Int32)"]/*'/>
		public double GetDouble(int i)
		{
			if(log!=null) log.Debug("GetDouble");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");
			
			return command.Statement.Resultset.GetDouble(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetString(System.Int32)"]/*'/>
		public String GetString(int i)
		{
			if(log!=null) log.Debug("GetString");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetString(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDecimal(System.Int32)"]/*'/>
		public Decimal GetDecimal(int i)
		{
			if(log!=null) log.Debug("GetDecimal");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetDecimal(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDateTime(System.Int32)"]/*'/>
		public DateTime GetDateTime(int i)
		{
			if(log!=null) log.Debug("GetDateTime");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			return command.Statement.Resultset.GetDateTime(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetData(System.Int32)"]/*'/>		
		public IDataReader GetData(int i)
		{
			if(log!=null) log.Debug("GetData");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return command.Statement.Resultset.GetData(i);
		}		

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsDBNull(System.Int32)"]/*'/>
		public bool IsDBNull(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			// return row[i] == null;
			return command.Statement.Statement.OutSqlda.sqlvar[i].sqlind == -1 ? true : false;
		}

		#endregion

		#region SPECIFIC_METHODS

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetAliasName(System.Int32)"]/*'/>
		private String GetAliasName(int i)
		{
			return command.Statement.Resultset.GetName(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetProviderType(System.Int32)"]/*'/>
		private int GetProviderType(int i)
		{
			return command.Statement.Resultset.GetProviderType(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetSize(System.Int32)"]/*'/>
		private int GetSize(int i)
		{
			return command.Statement.Resultset.GetSize(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetScale(System.Int32)"]/*'/>
		private int GetScale(int i)
		{
			return command.Statement.Resultset.GetScale(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetBaseTableName(System.Int32)"]/*'/>
		private String GetBaseTableName(int i)
		{
			return command.Statement.Resultset.GetName(i);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsNumeric(System.Int32)"]/*'/>
		private bool IsNumeric(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");

			XSQLDA sqlda = command.Statement.Statement.OutSqlda;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return FbField.IsNumeric(command.Statement.Statement.OutSqlda.sqlvar[i].sqltype);			
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsLong(System.Int32)"]/*'/>
		private bool IsLong(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");

			XSQLDA sqlda = command.Statement.Statement.OutSqlda;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return FbField.IsLong(command.Statement.Statement.OutSqlda.sqlvar[i].sqltype);			
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsKey(System.Int32)"]/*'/>
		private bool IsKey(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return FbField.IsKey(
					command.Transaction,
					null, null,
					sqlvar[i].relname,
					sqlvar[i].aliasname);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsUnique(System.Int32)"]/*'/>
		private bool IsUnique(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return FbField.IsUnique(
				command.Transaction,
				null, null,
				sqlvar[i].relname,
				sqlvar[i].aliasname);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsReadOnly(System.Int32)"]/*'/>
		private bool IsReadOnly(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return FbField.IsReadOnly(
				command.Transaction,
				null, null,
				sqlvar[i].relname,
				sqlvar[i].aliasname);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:AllowDBNull(System.Int32)"]/*'/>
		private bool AllowDBNull(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return (sqlvar[i].sqltype & 1) == 1 ? true : false;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetSchemaTableStructure"]/*'/>
		private DataTable GetSchemaTableStructure()
		{
			DataTable  schema = new DataTable("Schema");			

			// Schema table structure
			schema.Columns.Add("ColumnName"		, System.Type.GetType("System.String"));
			schema.Columns.Add("ColumnOrdinal"	, System.Type.GetType("System.Int32"));
			schema.Columns.Add("ColumnSize"		, System.Type.GetType("System.Int32"));
			schema.Columns.Add("NumericPrecision", System.Type.GetType("System.Int32"));
			schema.Columns.Add("NumericScale"	, System.Type.GetType("System.Int32"));
			schema.Columns.Add("DataType"		, System.Type.GetType("System.Type"));
			schema.Columns.Add("ProviderType"	, System.Type.GetType("System.Int32"));			
			schema.Columns.Add("IsLong"			, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("AllowDBNull"	, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsReadOnly"		, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsRowVersion"	, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsUnique"		, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsKeyColumn"	, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsAutoIncrement", System.Type.GetType("System.Boolean"));
			schema.Columns.Add("BaseSchemaName"	, System.Type.GetType("System.String"));
			schema.Columns.Add("BaseCatalogName", System.Type.GetType("System.String"));
			schema.Columns.Add("BaseTableName"	, System.Type.GetType("System.String"));
			schema.Columns.Add("BaseColumnName"	, System.Type.GetType("System.String"));
			
			return schema;
		}


		private void UpdateRecordsAffected()
		{
			if(command.RecordsAffected != -1)
			{
				recordsAffected = recordsAffected == -1 ? 0 : recordsAffected;
				recordsAffected += command.RecordsAffected;
			}
		}

		#endregion
	}
}
