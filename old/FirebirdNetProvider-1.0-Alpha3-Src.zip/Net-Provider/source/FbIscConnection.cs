using System;
//using System.Data;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="T:FbIscConnection"]/*'/>
	internal class FbIscConnection : IDisposable
	{
		public static IGDS				 gds = GDSFactory.NewGDS();
		internal isc_db_handle			 db;
		internal FbConnectionRequestInfo cri;

		private bool	disposed = false;

		private byte	dialect	 = 3;
		private string	charset	 = "";
		private string	role	 = "";		
		private string	user	 = "";
		private string	password = "";
		private string	database = "";

		internal byte Dialect{ get{return dialect;} }
		internal string Charset{ get{return charset;} }
		internal string Role{ get{return role;} }
		internal string User{ get{return user;} }
		internal string Password{ get{return password;} }
		internal string Database{ get{return database;} }

		public FbIscConnection()
		{			
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:Open"]/*'/>
		public void Open(byte dialect,
			string charset,
			string role,
			string user,
			string password,
			string database)
		{				
			try
			{
				// New instance of GDS class
				// gds = GDSFactory.NewGDS();
				// New instance of RequestConnectionInfo class
				cri = new FbConnectionRequestInfo();
				// New instance for Database handler
				db	= gds.get_new_isc_db_handle();				
				
				// DPB configuration
				cri.SetProperty(GdsCodes.isc_dpb_dummy_packet_interval, new byte[] {120, 10, 0, 0});
				cri.SetProperty(GdsCodes.isc_dpb_sql_dialect, new byte[] {dialect, 0, 0, 0});
				cri.SetProperty(GdsCodes.isc_dpb_lc_ctype, charset);
				if(role != null)
				{
					if(role.Length > 0)
					{
						cri.SetProperty(GdsCodes.isc_dpb_sql_role_name, role);
					}
				}					

				cri.SetUser(user);
				cri.SetPassword(password);

				// Connect to database
				gds.isc_attach_database(database, db, cri.Dpb);

				this.dialect  = dialect;
				this.charset  = charset;
				this.role	  = role;
				this.user     = user;
				this.password = password;
				this.database = database;
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}
		
		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close()
		{
			lock(db)
			{
				// Clear Warnings
				db.ClearWarnings();

				// Rollback all pending transactions
				if(db.HasTransactions())
				{						
					while (db.HasTransactions())
					{
						IEnumerator txnEnum = ((isc_db_handle_impl)db).Transactions.GetEnumerator();
						txnEnum.MoveNext();
						gds.isc_rollback_transaction((isc_tr_handle_impl)txnEnum.Current);
					}
				}
			}
		}

		public void Detach()
		{
			lock(db)
			{
				gds.isc_detach_database(db);
			}

			cri			= null;						
			gds			= null;
			db			= null;
		}

		public void Dispose()
		{
			if(!disposed)
			{
				try
				{
					Close();
					Detach();

					disposed = true;
				}
				catch(GDSException ex)
				{
					throw ex;
				}
			}
		}
	}
}