//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <summary>
	/// Implementation of <code>isc_tr_handle</code> interface
	/// <seealso cref="isc_tr_handle"/>
	/// </summary>
	internal class isc_tr_handle_impl : isc_tr_handle
	{
		#region FIELDS

		private int					rtr_id;
		private isc_db_handle_impl	rtr_rdb;
		private ArrayList			blobs = new ArrayList();		

		private TxnState			state = TxnState.NOTRANSACTION;

		#endregion

		#region PROPERTIES

		/// <summary>
		/// Gets or Sets a value representing the database handler associated 
		/// with the transaction
		/// </summary>
		public isc_db_handle DbHandle
		{
			get{return rtr_rdb;}
			set
			{
				this.rtr_rdb = (isc_db_handle_impl)value;
				rtr_rdb.AddTransaction(this);
			}
		}

		/// <summary>
		/// Gets a value representing the Transaction state.
		/// </summary>
		public TxnState State
		{
			get{return state;}
			set{state=value;}
		}
	
		/// <summary>
		/// Gets or Sets a value representing the Transaction ID
		/// </summary>
		public int TransactionId
		{
			get{return rtr_id;}
			set{rtr_id=value;}
		}

		#endregion

		#region CONSTRUCTORS

		/// <summary>
		/// Initializes a new instance of isc_tr_handle_impl class
		/// </summary>
		public isc_tr_handle_impl() 
		{
		}

		#endregion

		#region METHODS

		/// <summary>
		/// Removes a transaction handler
		/// </summary>
		internal void UnsetDbHandle()
		{
			rtr_rdb.RemoveTransaction(this);
			rtr_rdb = null;
		}

		/// <summary>
		/// Adds a blob to the transaction
		/// </summary>
		/// <param name="blob">An isc_blob_handle_impl object</param>
		internal void AddBlob(isc_blob_handle_impl blob) 
		{
			blobs.Add(blob);
		}

		/// <summary>
		/// Removes a blob of the transaction
		/// </summary>
		/// <param name="blob">An isc_blob_handle_impl object</param>
		internal void RemoveBlob(isc_blob_handle_impl blob) 
		{
			blobs.Remove(blob);
		}

		#endregion
	}
}
