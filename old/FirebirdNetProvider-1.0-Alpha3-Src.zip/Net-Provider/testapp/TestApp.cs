using System;
using System.Text;
using System.Data;
using System.Threading;
using System.Configuration;

using FirebirdSql.Data.Firebird;

class TestApp
{	
	[STAThread]
	static void Main()
	{			
		string connectionString =			
			"Database=" + ConfigurationSettings.AppSettings["Database"] + ";" + 
			"User="		+ ConfigurationSettings.AppSettings["User"]		+ ";" + 
			"Password=" + ConfigurationSettings.AppSettings["Password"] + ";" + 
			"Server="	+ ConfigurationSettings.AppSettings["Server"]	+ ";" + 
			"Port="		+ ConfigurationSettings.AppSettings["Port"]		+ ";" + 
			"Dialect="	+ ConfigurationSettings.AppSettings["Dialect"]	+ ";" + 
			"Charset="	+ ConfigurationSettings.AppSettings["Charset"]	+ ";" +
			"Role="		+ ConfigurationSettings.AppSettings["Role"]		+ ";" +
			"Connection Lifetime=" + ConfigurationSettings.AppSettings["Connection lifetime"] + ";" +
			"Pooling="	+ ConfigurationSettings.AppSettings["Pooling"];	
		
		TestCommandBuilder(connectionString);
		Console.ReadLine();
		TestSchemaTable(connectionString);		
		Console.ReadLine();
		TestBatchQuerys(connectionString);
		Console.ReadLine();
		TestReader(connectionString);
		Console.ReadLine();
		TestAdapter(connectionString);
		Console.ReadLine();
		TestUpdate(connectionString);
		Console.ReadLine();
	}

	static void TestCommandBuilder(string connectionString)
	{
		FbConnection  conn	  = new FbConnection(connectionString);
		FbTransaction txn;		

		try
		{			
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
						
			FbDataAdapter adapter = new FbDataAdapter(new FbCommand("select * from employee order by emp_no", conn, txn));
	
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Command Builder");

			FbCommandBuilder cb = new FbCommandBuilder(adapter);
			Console.WriteLine(cb.GetInsertCommand().CommandText);
			Console.WriteLine();
			Console.WriteLine(cb.GetUpdateCommand().CommandText);
			Console.WriteLine();
			Console.WriteLine(cb.GetDeleteCommand().CommandText);

			Console.WriteLine();
			Console.WriteLine("------------------------");
			Console.WriteLine();

			txn.Rollback();
			
			conn.Close();
		}
		catch(Exception ex)
		{
			Console.WriteLine("TestCommandBuilder - Exception message: {0}", ex.Message);
			conn.Close();
		}
	}

	static void TestSchemaTable(string connectionString)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;				
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
			
			FbCommand cmd = new FbCommand("select * from job", conn, txn);
	
			IDataReader reader = cmd.ExecuteReader();		
		
			DataTable schema = reader.GetSchemaTable();
			
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Schema Table");

			DataRow[] currRows = schema.Select(null, null, DataViewRowState.CurrentRows);

			foreach (DataRow myRow in currRows)
			{
				foreach (DataColumn myCol in schema.Columns)
					Console.Write("\t{0}", myRow[myCol]);

				Console.WriteLine("\t" + myRow.RowState);
			}

			Console.WriteLine();			
			Console.WriteLine("------------------------");
			Console.WriteLine();
	
			txn.Rollback();
	
			reader.Close();
		
			conn.Close();		
		}
		catch(Exception ex)
		{
			Console.WriteLine("TestSchemaTable - Exception message: {0}", ex.Message);
			conn.Close();			
		}
	}

	static void TestReader(string connectionString)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
						
			FbCommand cmd = new FbCommand("select * from EMPLOYEE", conn, txn);
			
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Data Reader");
			
			IDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				for(int i=0;i<reader.FieldCount;i++)
				{
					Console.Write(reader.GetValue(i) + "\t");					
				}
			
				Console.WriteLine();
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");
			Console.WriteLine();

			txn.Rollback();
	
			reader.Close();
			
			conn.Close();			
		}
		catch(Exception ex)
		{
			Console.WriteLine("TestReader - Exception message: {0}", ex.Message);
			conn.Close();			
		}
	}

	static void TestBatchQuerys(string connectionString)
	{		
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
			
			string querys = "select * from employee order by emp_no;" +
							"select * from department order by dept_no";

			FbCommand cmd = new FbCommand(querys, conn, txn);
	
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Batch Querys");
			Console.WriteLine();
			Console.WriteLine("Employee Data");

			IDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{				
				for(int i=0;i<reader.FieldCount;i++)
				{
					Console.Write("{0}\t", reader.GetValue(i));
				}
			
				Console.WriteLine();
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");
			Console.WriteLine();

			Console.WriteLine("Departaments Data");

			if(reader.NextResult())
			{
				while (reader.Read())
				{				
					for(int i=0;i<reader.FieldCount;i++)
					{
						Console.Write("{0}\t", reader.GetValue(i));
					}
				
					Console.WriteLine();
				}
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");
			Console.WriteLine();

			txn.Rollback();
	
			reader.Close();
		
			conn.Close();		
		}
		catch(Exception ex)
		{
			Console.WriteLine("TestBatchQuerys - Exception message: {0}", ex.Message);
			conn.Close();			
		}
	}
	
	static void TestAdapter(string connectionString)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();

			FbDataAdapter adapter = new FbDataAdapter(new FbCommand("select * from country", conn, txn));
			
			FbCommandBuilder cmdBuilder = new FbCommandBuilder(adapter);
			
			adapter.UpdateCommand = cmdBuilder.GetUpdateCommand();
			adapter.InsertCommand = cmdBuilder.GetInsertCommand();
			adapter.DeleteCommand = cmdBuilder.GetDeleteCommand();

			DataSet ds = new DataSet();
			adapter.Fill(ds, "country");			

			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Data Adapter");
			printDataSet(ds);
			Console.WriteLine("------------------------");
	
			ds.Tables["Country"].Rows[1]["Currency"] = "AdapTest";
			adapter.Update(ds, "Country");

			Console.WriteLine("------------------------");
			Console.WriteLine("Results of adapter.Update");
			printDataSet(ds);
			Console.WriteLine("------------------------");

			Console.WriteLine();

			txn.Rollback();
	
			conn.Close();
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}		
	}

	static void printDataSet(DataSet ds)
	{
		foreach (DataTable table in ds.Tables)
		{
			foreach (DataColumn col in table.Columns)
				Console.Write(col.ColumnName + "\t\t");
			Console.WriteLine();
			foreach (DataRow row in table.Rows)
			{
				for (int i = 0; i < table.Columns.Count; i++)
					Console.Write(row[i] + "\t\t");
				Console.WriteLine("");
			}
		}
	}

	static void TestUpdate(string connectionString)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();

			FbCommand cmd = new FbCommand("update JOB set JOB_REQUIREMENT = ? WHERE JOB_CODE = ?", conn, txn);

			cmd.Parameters.Add("@JOB_REQUIREMENT", "This a simple Clob test!!!");
			cmd.Parameters.Add("@JOB_CODE", "Accnt");

			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Update");

			int ret = cmd.ExecuteNonQuery();

			Console.WriteLine("Records Updated: {0}", ret );

			Console.WriteLine();
			Console.WriteLine("------------------------");
			Console.WriteLine();
											
			conn.Close();		
		}
		catch(Exception ex)
		{			
			Console.WriteLine("Exception message: {0}", ex.Message);
			conn.Close();
		}
	}

	static void TestExecuteProcedure(string connectionString)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();

			FbCommand cmd = new FbCommand("EXECUTE PROCEDURE ADD_EMP_PROJ ?", conn, txn);

			cmd.CommandType = CommandType.StoredProcedure;

			cmd.Parameters.Add("@EMP_NO", 2);
			cmd.Parameters.Add("@PROJ_ID", "").Direction = ParameterDirection.ReturnValue;
			
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - ExecuteProcedure");

			int ret = cmd.ExecuteNonQuery();

			Console.WriteLine();
			Console.WriteLine("------------------------");
			Console.WriteLine();
											
			conn.Close();		
		}
		catch(Exception ex)
		{			
			Console.WriteLine("Exception message: {0}", ex.Message);
			conn.Close();
		}
	}

	static void TestExecuteScalar(string connectionString)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = connectionString;
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
						
			FbCommand cmd = conn.CreateCommand();
			
			cmd.Transaction = conn.BeginTransaction();
			cmd.CommandText = "SELECT PHONE_EXT FROM EMPLOYEE WHERE EMP_NO = ?";
									
			cmd.Parameters.Add("@Emp_no", 2);
						
			string phone_ext = cmd.ExecuteScalar().ToString();
												
			conn.Close();			
		}
		catch(Exception ex)
		{
			Console.WriteLine("Exception message: {0}", ex.Message);
			conn.Close();			
		}
	}
}