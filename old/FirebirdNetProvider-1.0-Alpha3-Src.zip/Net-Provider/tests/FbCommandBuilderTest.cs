//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using NUnit.Framework;

using System;
using System.Data;
using FirebirdSql.Data.Firebird;


namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbCommandBuilderTest : BaseTest
	{
		FbConnection 	conn;
		FbTransaction	txn;
		FbDataAdapter	adapter;
		
		public FbCommandBuilderTest() : base()
		{
		}
		
		[SetUp]
		public void Setup()
		{
			conn = new FbConnection(GetConnectionString());
			conn.Open();
			
			txn = conn.BeginTransaction();
			
			adapter = new FbDataAdapter();
			adapter.SelectCommand = new FbCommand("SELECT * FROM EMPLOYEE WHERE EMP_NO = ?", conn, txn);
		}
		
		[TearDown]
		public void TearDown()
		{
			txn.Rollback();
			conn.Close();
		}
		
		[Test]
		public void GetInsertCommandTest()
		{
			FbCommandBuilder builder = new FbCommandBuilder(adapter);
			
			Console.WriteLine( builder.GetInsertCommand().CommandText );
		}
		
		[Test]
		public void GetUpdateCommandTestTest()
		{
			FbCommandBuilder builder = new FbCommandBuilder(adapter);
			
			Console.WriteLine( builder.GetUpdateCommand().CommandText );
		}
		
		[Test]
		public void GetDeleteCommandTest()
		{
			FbCommandBuilder builder = new FbCommandBuilder(adapter);
			
			Console.WriteLine( builder.GetDeleteCommand().CommandText );
		}
		
		[Test]
		public void RefreshSchemaTest()
		{
			FbCommandBuilder builder = new FbCommandBuilder(adapter);
			
			Console.WriteLine("Commands for original SQL statement: ");
			Console.WriteLine( builder.GetInsertCommand().CommandText );
			Console.WriteLine( builder.GetUpdateCommand().CommandText );
			Console.WriteLine( builder.GetDeleteCommand().CommandText );
			
			adapter.SelectCommand.CommandText = "SELECT * FROM CUSTOMER WHERE CUST_NO = ?";
			
			builder.RefreshSchema();
			
			Console.WriteLine("Commands for new SQL statement: ");
			
			Console.WriteLine( builder.GetInsertCommand().CommandText );
			Console.WriteLine( builder.GetUpdateCommand().CommandText );
			Console.WriteLine( builder.GetDeleteCommand().CommandText );
		}
		
		[Test]
		public void DeriveParameters()
		{
			FbCommandBuilder builder = new FbCommandBuilder();
			
			FbCommand command = new FbCommand("SELECT * FROM EMPLOYEE WHERE EMP_NO = ?", conn);			
			
			command.Transaction = conn.BeginTransaction();
			command.CommandType = CommandType.StoredProcedure;
						
			builder.DeriveParameters(command);
			
			Console.WriteLine("Derived Parameters");
			
			for (int i=0;i<command.Parameters.Count;i++)
			{
				Console.WriteLine("Parameter name: {0}\tParameter Source Column:{1}",
				                  command.Parameters[i].ParameterName,
				                  command.Parameters[i].SourceColumn);
			}
		}
	}
}
