//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Text;

using FirebirdSql.Data.Common;
using Borland.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	public class FbCommand : ISQLCommand
	{
		#region Fields

		private FbConnection		connection;
		private StatementBase		statement;
		private IscException		lastError;
		private int					transactionId;

		#endregion

		#region Internal Properties

		internal int RowsAffected
		{
			get 
			{
				if (this.statement != null)
				{
					return this.statement.RecordsAffected; 
				}
				return -1;
			}
		}

		#endregion

		#region Constructors

		public FbCommand(FbConnection connection)
		{
			this.connection	= connection;
		}

		#endregion

		#region ISQLCommand Methods

		public int Prepare(string sql, short paramCount)
		{
			try
			{
				if (this.statement != null)
				{
					this.Release();
				}

				this.transactionId = this.connection.GetTransactionId();
				if (this.transactionId < 0)
				{
					this.connection.BeginTransaction(this.transactionId, (int)(IsolationLevel.ReadCommitted));
				}

				ITransaction transaction = (ITransaction)this.connection.Transactions[this.transactionId];

				this.statement = this.connection.IscDb.CreateStatement(transaction);
				
				this.statement.Prepare(sql);
				this.statement.Describe();
				this.statement.DescribeParameters();
			}
			catch (IscException e)
			{
				this.lastError = e;
				this.RollbackImplicitTransaction();
			}

			return this.getErrorCode();
		}

		public int PrepareProc(string spName, short paramCount)
		{
			try
			{
				if (this.statement != null)
				{
					this.Release();
				}

				this.transactionId = this.connection.GetTransactionId();
				if (this.transactionId < 0)
				{
					this.connection.BeginTransaction(this.transactionId, (int)(IsolationLevel.ReadCommitted));
				}

				ITransaction transaction = (ITransaction)this.connection.Transactions[this.transactionId];

				this.statement = this.connection.IscDb.CreateStatement(transaction);

				this.statement.Prepare(spName);
				this.statement.Describe();
				this.statement.DescribeParameters();
			}
			catch (IscException e)
			{
				this.lastError = e;
				this.RollbackImplicitTransaction();
			}

			return this.getErrorCode();
		}

		public int Execute(out ISQLCursor cursor, ref short resultCols)
		{
			cursor		= null;
			resultCols	= 0;

			try
			{
				if (this.statement == null)
				{
					throw new InvalidOperationException("Command needs to be prepared before execution.");
				}

				if (this.transactionId == 0)
				{
					this.transactionId = this.connection.GetTransactionId();
					if (this.transactionId < 0)
					{
						this.connection.BeginTransaction(this.transactionId, (int)(IsolationLevel.ReadCommitted));
					}
				}

				ITransaction transaction = (ITransaction)this.connection.Transactions[this.transactionId];
				
				if (this.statement.IsPrepared)
				{
					this.Close();
				}

				this.statement.Execute();

				cursor = new FbCursor(this);

				if (this.statement.StatementType != DbStatementType.Select &&
					this.statement.StatementType != DbStatementType.SelectForUpdate &&
					this.statement.StatementType != DbStatementType.StoredProcedure)
				{
					this.CommitImplicitTransaction();
				}
				else
				{
					resultCols = this.statement.Fields.Count;
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
				this.RollbackImplicitTransaction();
			}
			
			return this.getErrorCode();
		}

		public int Close()
		{
			try
			{
				if (this.statement != null)
				{
					this.statement.Close();
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int Release()
		{
			try
			{
				this.RollbackImplicitTransaction();
				if (this.statement != null)
				{
					this.statement.Release();
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}
			finally
			{
				this.statement = null;
			}

			return this.getErrorCode();
		}

		public int GetStoredProcedureSQL(StringBuilder sql, ArrayList paramList)
		{
			try
			{
				sql.Insert(0, "SELECT * FROM ");

				if (paramList.Count > 0)
				{
					sql.Append("(");
					foreach (BdpSPParam parameter in paramList)
					{
						if (parameter.Direction == ParameterDirection.Input ||
							parameter.Direction == ParameterDirection.InputOutput)
						{
							sql.Append("?, ");
						}
					}
					sql.Remove(sql.Length - 2, 2);
					sql.Append(")");
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetRowsAffected(ref int rowsAffected)
		{
			try
			{
				if (this.statement != null)
				{
					rowsAffected = this.statement.RecordsAffected;
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetParameter(
			short		index, 
			short		childPos, 
			ref object	value, 
			ref bool	isNull)
		{
			try
			{
				value	= this.statement.Parameters[index].Value;
				isNull	= this.statement.Parameters[index].DbValue.IsDBNull();
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int SetParameter(
			short				index, 
			short				childPos, 
			ParameterDirection	paramDir, 
			BdpType				dataType, 
			BdpType				subType, 
			int					maxPrecision, 
			int					maxScale, 
			int					length, 
			object				value, 
			bool				isNullable)
		{
			try
			{
				// Set null flag
				if (value == null || value == DBNull.Value)
				{
					this.statement.Parameters[index].NullFlag = -1;
					this.statement.Parameters[index].Value = DBNull.Value;
				}
				else
				{
					this.statement.Parameters[index].NullFlag = 0;

					// Set parameter value
					switch (this.statement.Parameters[index].DbDataType)
					{
						case DbDataType.Array:
							if (this.statement.Parameters[index].ArrayHandle == null)
							{
								this.statement.Parameters[index].ArrayHandle = 
									this.statement.CreateArray(
									this.statement.Parameters[index].Relation,
									this.statement.Parameters[index].Name);
							}
							else
							{
								this.statement.Parameters[index].ArrayHandle.DB			= this.statement.DB;
								this.statement.Parameters[index].ArrayHandle.Transaction = this.statement.Transaction;
							}
					
							this.statement.Parameters[index].ArrayHandle.Handle = 0;
							this.statement.Parameters[index].ArrayHandle.Write((System.Array)value);
							this.statement.Parameters[index].Value = this.statement.Parameters[index].ArrayHandle.Handle;
							break;

						case DbDataType.Binary:
							BlobBase blob = this.statement.CreateBlob();
							blob.Write((byte[])value);
							this.statement.Parameters[index].Value = blob.Id;
							break;

						case DbDataType.Text:
							BlobBase clob = this.statement.CreateBlob();
							clob.Write((string)value);
							this.statement.Parameters[index].Value = clob.Id;
							break;
					
						default:
							this.statement.Parameters[index].Value = value;
							break;
					}
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			if (this.lastError != null)
			{
				errorMessage.Append(this.lastError.Message);

				this.lastError = null;
			}

			return 0;
		}
        
		#endregion

		#region Internal Methods

		internal int GetNextResult(out ISQLCursor cursor, ref short resultCols)
		{
			cursor = new FbCursor(this);
			resultCols = 0;

			return -1;
		}

		internal DbValue[] Fetch()
		{
			return this.statement.Fetch();			
		}

		internal RowDescriptor GetFieldsDescriptor()
		{
			if (this.statement != null)
			{
				return this.statement.Fields;
			}

			return null;
		}

		internal void CommitImplicitTransaction()
		{
			if (this.transactionId < 0)
			{
				try
				{
					int error = this.connection.Commit(this.transactionId);
					if (error != 0)
					{
						StringBuilder msg = new StringBuilder();
						this.connection.GetErrorMessage(ref msg);

						throw new IscException(msg.ToString());
					}
				}
				catch
				{
					this.connection.Rollback(this.transactionId);
					throw;
				}
				finally
				{
					this.transactionId = 0;
				}
			}
		}

		internal void RollbackImplicitTransaction()
		{
			if (this.transactionId < 0)
			{
				try
				{
					this.connection.Rollback(this.transactionId);
				}
				catch
				{
				}
				finally
				{
					this.transactionId = 0;
				}
			}
		}

		#endregion

		#region Private

		private int getErrorCode()
		{
			return (this.lastError != null ? this.lastError.ErrorCode : 0);
		}

		#endregion
	}
}
