//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbForeignKeysSchema : FbDbSchema
	{
		#region Constructors

		public FbForeignKeysSchema() : base("ForeignKeys", 2)
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
					"pidx.rdb$relation_name AS FK_TABLE_NAME, " +
					"pseg.rdb$field_name AS FK_COLUMN_NAME, " +
					"rc.rdb$constraint_name AS FK_NAME, " +
					"rc.rdb$relation_name AS PK_TABLE_NAME, " +
					"fseg.rdb$field_name AS PK_COLUMN_NAME, " +
					"fidx.rdb$foreign_key AS PK_NAME, " +
					"fseg.rdb$field_position AS ORDINAL, " +
					"ref.rdb$match_option AS MATCH_OPTION, " +
					"ref.rdb$update_rule AS UPDATE_RULE, " +
					"ref.rdb$delete_rule AS DELETE_RULE, " +
					"rc.rdb$index_name AS INDEX_NAME, " +
					"rc.rdb$deferrable AS IS_DEFERRABLE, " +
					"rc.rdb$initially_deferred AS INITIALLY_DEFERRED " +
				"FROM " +
					"rdb$relation_constraints rc " +
					"inner join rdb$indices fidx ON (rc.rdb$index_name = fidx.rdb$index_name AND rc.rdb$constraint_type = 'FOREIGN KEY') " +
					"inner join rdb$ref_constraints ref ON rc.rdb$constraint_name = ref.rdb$constraint_name " +
					"inner join rdb$index_segments fseg ON fidx.rdb$index_name = fseg.rdb$index_name " +
					"inner join rdb$indices pidx ON fidx.rdb$foreign_key = pidx.rdb$index_name " +
					"inner join rdb$index_segments pseg ON (fidx.rdb$index_name = pseg.rdb$index_name AND pseg.rdb$field_position=fseg.rdb$field_position)");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat("pidx.rdb$relation_name = @p{0}", index++);
				}

				if (restrictions.Length >= 2 && restrictions[1] != null)
				{
					if (where.Length > 0)
					{
						where.Append(" AND ");
					}

					where.AppendFormat("rc.rdb$relation_name = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rc.rdb$relation_name, rc.rdb$constraint_name, fseg.rdb$field_position");

			return sql;
		}

		#endregion
	}
}