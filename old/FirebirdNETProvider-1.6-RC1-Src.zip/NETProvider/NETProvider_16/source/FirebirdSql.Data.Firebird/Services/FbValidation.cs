//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird.Services
{
	#region Enumerations

	/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/overview/*'/>
    [Flags]
    public enum FbValidationFlags
	{
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="ValidateDatabase"]/*'/>
		ValidateDatabase	= 0x01,
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="SweepDatabase"]/*'/>
		SweepDatabase		= 0x02,
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="MendDatabase"]/*'/>
		MendDatabase		= 0x04,
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="CheckDatabase"]/*'/>
		CheckDatabase		= 0x10,
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="IgnoreChecksum"]/*'/>
		IgnoreChecksum		= 0x20,
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="KillShadows"]/*'/>
		KillShadows		 	= 0x40,
		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/struct[@name="FbValidationFlags"]/field[@name="Full"]/*'/>
		Full				= 0x80
	}

	#endregion

	/// <include file='Doc/en_EN/FbValidation.xml' path='doc/class[@name="FbValidation"]/overview/*'/>
	public sealed class FbValidation : FbService
	{
		#region Fields
		
		private FbValidationFlags	options;
		
		#endregion
		
		#region Properties

		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/class[@name="FbValidation"]/property[@name="Options"]/*'/>
		public FbValidationFlags Options
		{
			get { return this.options; }
			set { this.options = value; }
		}		
		
		#endregion
				
		#region Constructors

		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/class[@name="FbValidation"]/constructor[@name="ctor"]/*'/>
		public FbValidation() : base()
		{
		}
		
		#endregion
		
		#region Methods

		/// <include file='Doc/en_EN/FbValidation.xml' path='doc/class[@name="FbValidation"]/method[@name="Start"]/*'/>
		public void Start()
		{			
			// Configure Spb
			this.StartSpb = new SpbBuffer();
			this.StartSpb.Append(IscCodes.isc_action_svc_repair);
			this.StartSpb.Append(
				IscCodes.isc_spb_dbname, 
				this.Parameters.Database);
			this.StartSpb.Append(
				IscCodes.isc_spb_options, 
				(int)this.options);
						
			// Start execution
			this.StartTask();
		}
		
		#endregion
	}
}
