//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Collections;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class CharsetCollection : ICollection, IEnumerable
	{
		#region Fields

		private ArrayList charsets;

		#endregion

		#region Indexers

		public Charset this[int index]
		{
			get { return (Charset)this.charsets[index]; }
			set { this.charsets[index] = (Charset)value; }
		}

		public Charset this[string name] 
		{
			get { return (Charset)this[this.IndexOf(name)]; }
			set { this[this.IndexOf(name)] = (Charset)value; }
		}

		#endregion

		#region Constructors

		internal CharsetCollection()
		{
			this.charsets = ArrayList.Synchronized(new ArrayList());
		}

		#endregion

		#region ICollection Properties

		public int Count 
		{
			get { return this.charsets.Count; }
		}
		
		bool ICollection.IsSynchronized
		{
			get { return this.charsets.IsSynchronized; }
		}

		object ICollection.SyncRoot 
		{
			get { return this.charsets.SyncRoot; }
		}

		#endregion

		#region ICollection Methods

		public void CopyTo(Array array, int index)
		{
			this.CopyTo((Charset[])array, index);
		}
		
		#endregion

		#region IEnumerable Methods

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.charsets.GetEnumerator();
		}

		#endregion

		#region Methods

		public int IndexOf(int id)
		{
			int index = 0;

			foreach (Charset item in this)
			{
				if (item.ID == id)
				{
					return index;
				}
				index++;
			}

			return -1;
		}

		public int IndexOf(string name)
		{
			int index = 0;

			foreach (Charset item in this)
			{
				if (GlobalizationHelper.CultureAwareCompare(item.Name, name))
				{
					return index;
				}
				index++;
			}

			return -1;
		}
		
		internal Charset Add(
			int id, 
			string charset, 
			int bytesPerCharacter,
			string systemCharset)
		{
			Charset charSet = new Charset(
				id, 
				charset, 
				bytesPerCharacter, 
				systemCharset);

			this.Add(charSet);

			return charSet;
		}

		internal Charset Add(
			int id, 
			string charset, 
			int bytesPerCharacter,
			Encoding encoding)
		{
			Charset charSet = new Charset(
				id, 
				charset, 
				bytesPerCharacter,
				encoding);

			this.Add(charSet);

			return charSet;
		}

		internal Charset Add(Charset charset)
		{
			this.charsets.Add(charset);

			return charset;
		}

		#endregion
	}
}
