//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class IscErrorCollection : ICollection, IEnumerable
	{
		#region Fields

		private ArrayList errors;

		#endregion

		#region Indexers

		public IscError this[string errorMessage] 
		{
			get { return (IscError)this.errors[IndexOf(errorMessage)]; }
			set { this.errors[IndexOf(errorMessage)] = (IscError)value; }
		}

		public IscError this[int errorIndex] 
		{
			get { return (IscError)this.errors[errorIndex]; }
			set { this.errors[errorIndex] = (IscError)value; }
		}

		#endregion

		#region Constructors

		internal IscErrorCollection()
		{
			this.errors = ArrayList.Synchronized(new ArrayList());
		}

		#endregion

		#region ICollection Properties

		public int Count 
		{
			get { return this.errors.Count; }
		}
		
		bool ICollection.IsSynchronized
		{
			get { return this.errors.IsSynchronized; }
		}

		object ICollection.SyncRoot 
		{
			get { return this.errors.SyncRoot; }
		}

		#endregion

		#region ICollection Methods

		public void CopyTo(Array array, int index)
		{
			this.CopyTo((IscError[])array, index);
		}
		
		#endregion

		#region IEnumerable Methods

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.errors.GetEnumerator();
		}

		#endregion

		#region Methods

		internal int IndexOf(string errorMessage)
		{
			int index = 0;
			foreach (IscError item in this)
			{
				if (GlobalizationHelper.CultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}

			return -1;
		}
		
		public IscError Add(IscError error)
		{
			this.errors.Add(error);

			return error;
		}

		public IscError Add(int errorCode)
		{
			IscError error = new IscError(errorCode);			

			return this.Add(error);
		}

		public IscError Add(string message)
		{
			IscError error = new IscError(message);			

			return this.Add(error);
		}

		public IscError Add(int type, string strParam)
		{
			IscError error = new IscError(type, strParam);			

			return this.Add(error);
		}

		public IscError Add(int type, int errorCode)
		{
			IscError error = new IscError(type, errorCode);			

			return this.Add(error);
		}

		public IscError Add(int type, int errorCode, string strParam)
		{
			IscError error = new IscError(type, errorCode, strParam);

			return this.Add(error);
		}

		#endregion
	}
}
