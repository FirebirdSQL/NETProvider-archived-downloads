//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Runtime.InteropServices;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Embedded
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	abstract class FesAttachment : IAttachment
	{
		#region Fields

		private AttachmentParams	parameters;
		private int					handle;

		#endregion

		#region Properties

		public AttachmentParams Parameters
		{
			get { return this.parameters; }
		}

		public int Handle
		{
			get { return this.handle; }
			set { this.handle = value; }
		}

		public FactoryBase Factory
		{
			get { return FesFactory.Instance; }
		}

		public bool IsLittleEndian
		{
			get { return true; }
		}

		#endregion

		#region Constructors

		protected FesAttachment(AttachmentParams parameters)
		{
			this.parameters = parameters;
		}

		#endregion

		#region Static Methods

		public static int[] GetNewStatusVector()
		{
			return new int[IscCodes.ISC_STATUS_LENGTH];
		}

		#endregion

		#region Methods

		public int VaxInteger(byte[] buffer, int index, int length) 
		{
			return IscHelper.VaxInteger(buffer, index, length);

			/*
			byte[] innerBuffer = new byte[length];

			Buffer.BlockCopy(buffer, pos, innerBuffer, 0, length);

			return FbClient.isc_vax_integer(innerBuffer, (short)length);
			*/
		}

		#endregion

		#region Abstract Methods

		public abstract void SendWarning(IscException ex);

		#endregion

		#region Internal Methods

		internal void ParseStatusVector(int[] statusVector)
		{
			IscException exception = new IscException();

			for (int i = 0; i < statusVector.Length;)
			{
				int arg = statusVector[i++];
				switch (arg) 
				{
					case IscCodes.isc_arg_gds: 
						int er = statusVector[i++];
						if (er != 0) 
						{
							exception.Errors.Add(arg, er);
						}
						break;

					case IscCodes.isc_arg_end:
					{		
						if (exception.Errors.Count != 0 && !exception.IsWarning()) 
						{
							exception.BuildExceptionMessage();
							throw exception;
						}
						else
						{
							if (exception.Errors.Count != 0 && exception.IsWarning())
							{
								exception.BuildExceptionMessage();
								this.SendWarning(exception);
							}
						}
					}
					return;
					
					case IscCodes.isc_arg_interpreted:						
					case IscCodes.isc_arg_string:
					{
						IntPtr ptr = new IntPtr(statusVector[i++]);
						string arg_value = Marshal.PtrToStringAnsi(ptr);
						exception.Errors.Add(arg, arg_value);
					}
					break;

					case IscCodes.isc_arg_cstring:
					{
						int count = statusVector[i++];

						IntPtr ptr = new IntPtr(statusVector[i++]);
						string arg_value = Marshal.PtrToStringAnsi(ptr);
						exception.Errors.Add(arg, arg_value);
					}
					break;
					
					case IscCodes.isc_arg_win32:
					case IscCodes.isc_arg_number:
					{
						int arg_value = statusVector[i++];
						exception.Errors.Add(arg, arg_value);
					}
					break;
					
					default:
					{
						int e = statusVector[i++];
						if (e != 0) 
						{
							exception.Errors.Add(arg, e);
						}
					}
					break;
				}
			}
		}

		#endregion
	}
}
