//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;
using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Gds
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class GdsSvcAttachment : GdsAttachment, ISvcAttachment
	{
		#region Constructors

		public GdsSvcAttachment(AttachmentParams parameters) : base(parameters)
		{
		}

		#endregion

		#region Methods

		public void Attach(string service, SpbBuffer spb)
		{
			lock (this) 
			{
				try 
				{
					this.Connect();
					
					this.Send.Write(IscCodes.op_service_attach);
					this.Send.Write(0);
					this.Send.Write(service);
					this.Send.WriteBuffer(spb.ToArray());
					this.Send.Flush();

					try 
					{
						GdsResponse r = this.ReceiveResponse();
						this.Handle = r.ObjectHandle;
					} 
					catch (IscException g) 
					{
						this.Disconnect();
						throw g;
					}
				} 
				catch (IOException)
				{
					this.Disconnect();
					throw new IscException(IscCodes.isc_net_write_err);
				}
			}
		}

		public void Detach()
		{
			lock (this) 
			{	        
				try 
				{
					this.Send.Write(IscCodes.op_service_detach);
					this.Send.Write(this.Handle);
					this.Send.Flush();            
					
					GdsResponse r = this.ReceiveResponse();
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_network_error);
				}
				finally
				{
					try 
					{
						this.Disconnect();
					}
					catch (IOException) 
					{
						throw new IscException(IscCodes.isc_network_error);
					} 
				}
			}
		}				

		public void Start(SpbBuffer spb)
		{
			lock (this) 
			{
				try 
				{
					this.Send.Write(IscCodes.op_service_start);
					this.Send.Write(this.Handle);
					this.Send.Write(0);
					this.Send.WriteBuffer(spb.ToArray(), spb.Length);
					this.Send.Flush();

					try 
					{
						GdsResponse r = this.ReceiveResponse();
					} 
					catch (IscException g) 
					{
						throw g;
					}
				} 
				catch (IOException)
				{
					throw new IscException(IscCodes.isc_net_write_err);
				}
			}
		}

		public void Query(
			SpbBuffer	spb				,
			int 		requestLength	,
			byte[] 		requestBuffer	,
			int 		bufferLength	,
			byte[] 		buffer)
		{
			lock (this) 
			{			
				try 
				{					
					this.Send.Write(IscCodes.op_service_info);	//	operation
					this.Send.Write(this.Handle);				//	db_handle
					this.Send.Write(0);							//	incarnation					
					this.Send.WriteTyped(
						IscCodes.isc_spb_version, 
						spb.ToArray());							//	spb
					this.Send.WriteBuffer(
						requestBuffer, 
						requestLength);							//	request buffer
					this.Send.Write(bufferLength);				//	result buffer length

					this.Send.Flush();

					GdsResponse r = this.ReceiveResponse();

					Buffer.BlockCopy(r.Data, 0, buffer, 0, bufferLength);
				}
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_network_error);
				}
			}
		}
		
		public override void SendWarning(IscException warning) 
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}
