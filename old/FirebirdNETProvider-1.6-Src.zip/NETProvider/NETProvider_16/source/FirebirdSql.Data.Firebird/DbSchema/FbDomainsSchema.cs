/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.Data;
using System.Globalization;
using System.Text;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbDomainsSchema : FbDbSchema
	{
		#region Constructors

		public FbDomainsSchema() : base("Domains")
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
				"rdb$field_name AS DOMAIN_NAME, " +
				"rdb$field_type AS DOMAIN_DATA_TYPE, " +
				"rdb$field_sub_type AS DOMAIN_SUB_TYPE, " +
				"cast(rdb$field_length AS integer) AS DOMAIN_SIZE, " +
				"rdb$field_precision AS NUMERIC_PRECISION, " +
				"rdb$field_scale AS NUMERIC_SCALE, " +
				"rdb$null_flag AS IS_NULLABLE, " +
				"rdb$dimensions AS ARRAY_DIMENSIONS, " +
				"rdb$description AS DESCRIPTION " +
				"FROM " +
				"rdb$fields");

			where.Append("not rdb$field_name starting with 'RDB$'");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat(" AND rdb$field_name = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rdb$field_name");

			return sql;
		}

		protected override DataTable ProcessResult(DataTable schema)
		{
			DataColumn providerType = new DataColumn("PROVIDER_TYPE");
			providerType.Caption	= "Provider Type";
			providerType.DataType	= typeof(FbDbType);

			schema.Columns.Add(providerType);

			schema.BeginLoadData();

			foreach (DataRow row in schema.Rows)
			{
				int blrType = Convert.ToInt32(row["DOMAIN_DATA_TYPE"], CultureInfo.InvariantCulture.NumberFormat);
				
				int subType	= 0;
				if (row["DOMAIN_SUB_TYPE"] != System.DBNull.Value)
				{
					subType	= Convert.ToInt32(row["DOMAIN_SUB_TYPE"], CultureInfo.InvariantCulture.NumberFormat);
				}
				
				int scale = 0 ;
				if (row["NUMERIC_SCALE"] != System.DBNull.Value)
				{
					scale = Convert.ToInt32(row["NUMERIC_SCALE"], CultureInfo.InvariantCulture.NumberFormat);
				}

                row["NUMERIC_SCALE"] = scale;

                FbDbType dbType = (FbDbType)TypeHelper.GetDbDataType(blrType, subType, scale);

                row["PROVIDER_TYPE"] = dbType;

                if (dbType == FbDbType.Binary || dbType == FbDbType.Text)
                {
                    row["COLUMN_SIZE"] = Int32.MaxValue;
                }
            }

			schema.EndLoadData();
			schema.AcceptChanges();
            
			return schema;
		}
		
		#endregion
	}
}