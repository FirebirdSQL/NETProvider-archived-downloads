/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbForeignKeysSchema : FbDbSchema
	{
		#region Constructors

		public FbForeignKeysSchema() : base("ForeignKeys", 2)
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
				"pidx.rdb$relation_name AS FK_TABLE_NAME, " +
				"pseg.rdb$field_name AS FK_COLUMN_NAME, " +
				"rc.rdb$constraint_name AS FK_NAME, " +
				"rc.rdb$relation_name AS PK_TABLE_NAME, " +
				"fseg.rdb$field_name AS PK_COLUMN_NAME, " +
				"fseg.rdb$field_position AS ORDINAL_POSITION, " +
				"ref.rdb$match_option AS MATCH_OPTION, " +
				"ref.rdb$update_rule AS UPDATE_RULE, " +
				"ref.rdb$delete_rule AS DELETE_RULE, " +
				"rc.rdb$deferrable AS IS_DEFERRABLE, " +
				"rc.rdb$initially_deferred AS INITIALLY_DEFERRED " +
				"FROM " +
				"rdb$relation_constraints rc " +
				"inner join rdb$indices fidx ON (rc.rdb$index_name = fidx.rdb$index_name AND rc.rdb$constraint_type = 'FOREIGN KEY') " +
				"inner join rdb$ref_constraints ref ON rc.rdb$constraint_name = ref.rdb$constraint_name " +
				"inner join rdb$index_segments fseg ON fidx.rdb$index_name = fseg.rdb$index_name " +
				"inner join rdb$indices pidx ON fidx.rdb$foreign_key = pidx.rdb$index_name " +
				"inner join rdb$index_segments pseg ON (fidx.rdb$foreign_key = pseg.rdb$index_name AND pseg.rdb$field_position=fseg.rdb$field_position) ");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat("pidx.rdb$relation_name = @p{0}", index++);
				}

				if (restrictions.Length >= 2 && restrictions[1] != null)
				{
					if (where.Length > 0)
					{
						where.Append(" AND ");
					}

					where.AppendFormat("rc.rdb$relation_name = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY pidx.rdb$relation_name, rc.rdb$constraint_name, fseg.rdb$field_position");

			return sql;
		}

		#endregion
	}
}