//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird.Services
{
	#region ENUMS

	/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/overview/*'/>
	[Flags]
	public enum FbStatisticalFlags
	{
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="DataPages"]/*'/>
		DataPages				= 0x01,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="DatabaseLog"]/*'/>
		DatabaseLog				= 0x02,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="HeaderPages"]/*'/>
		HeaderPages				= 0x04,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="IndexPages"]/*'/>
		IndexPages				= 0x08,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="SystemTablesRelations"]/*'/>
		SystemTablesRelations	= 0x10,
	}

	#endregion

	/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/overview/*'/>
	public sealed class FbStatistical : FbService
	{
		#region FIELDS
		
		private string 				database;
		private FbStatisticalFlags 	options;
		
		#endregion

		#region PROPERTIES

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/property[@name="Database"]/*'/>
		public string Database
		{
			get { return database; }
			set { database = value; }
		}

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/property[@name="Options"]/*'/>
		public FbStatisticalFlags Options
		{
			get { return options; }
			set { options = value; }
		}
				
		#endregion

		#region CONSTRUCTORS

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/constructor[@name="FbStatistical"]/*'/>
		public FbStatistical() : base()
		{
			database = String.Empty;
		}		
		
		#endregion

		#region METHODS

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/constructor[@name="Start"]/*'/>
		public void Start()
		{		
			// Configure Spb
			startSpb = new GdsSpbBuffer();
			startSpb.Append(GdsCodes.isc_action_svc_db_stats);
			startSpb.Append(GdsCodes.isc_spb_dbname, database);
			startSpb.Append(GdsCodes.isc_spb_options, (int)options);
			
			// Start execution
			startTask();
		}
		
		#endregion		
	}
}
