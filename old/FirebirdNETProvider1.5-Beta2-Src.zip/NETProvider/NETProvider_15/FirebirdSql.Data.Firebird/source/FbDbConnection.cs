//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Collections;
using System.Text.RegularExpressions;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird
{	
	internal class FbDbConnection : MarshalByRefObject
	{
		#region FIELDS

		private GdsDbAttachment	db;
		private string				connectionString;
		private GdsAttachParams		parameters;
		private long				created;
		private long				lifetime;
		private bool				pooled;
		private Regex				search;

		#endregion

		#region PROPERTIES

		public GdsDbAttachment DB
		{
			get { return db; }
		}

		public string ConnectionString
		{
			get { return connectionString; }
			set
			{
				if (value == null)
				{
					value = String.Empty;
				}
				if (value != String.Empty)
				{
					parseConnectionString(value);
				}
				connectionString = value;
			}
		}

		public long Lifetime
		{
			get { return lifetime; }
		}
		public long Created
		{
			get { return created; }
			set { created = value; }
		}
		
		public bool Pooled
		{
			get { return pooled; }
			set { pooled = value; }
		}

		public GdsAttachParams Parameters
		{
			get { return parameters; }
		}

		#endregion

		#region CONSTRUCTORS

		public FbDbConnection()
		{
			parameters			= new GdsAttachParams();
			search				= new Regex(@"([\w\s\d]*)\s*=\s*([^;]*)");
			connectionString	= String.Empty;
			lifetime			= 0;
			created				= 0;
			pooled				= true;
		}

		public FbDbConnection(string connectionString) : this()
		{
			ConnectionString = connectionString;
		}

		#endregion

		#region METHODS

		public void Connect()
		{							
			try
			{
				db = new GdsDbAttachment(parameters);
				db.Attach();
			}
			catch (GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}
		
		public void Disconnect()
		{	
			try
			{
				db.Detach();
			}
			catch (GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		public void CancelEvents()
		{
			try
			{
				if (db.EventsAtt != null)
				{
					System.Threading.Thread.Sleep(10);

					lock (db.EventsAtt)
					{
						GdsEvent[] events = new GdsEvent[db.EventsAtt.Events.Values.Count];
						db.EventsAtt.Events.Values.CopyTo(events, 0);
						for (int i = 0; i < events.Length; i++)
						{
							GdsEvent gdsEvent = events[i];
							lock (gdsEvent)
							{
								db.CancelEvents(gdsEvent);
							}
						}

						db.EventsAtt.StopEventThread();
						db.EventsAtt.Detach();
					}
				}
			}
			catch (GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		private void parseConnectionString(string connectionString)
		{
			MatchCollection	elements = search.Matches(connectionString);

			foreach (Match element in elements)
			{
				if (element.Groups[2].Value.Trim().Length > 0)
				{
					switch (element.Groups[1].Value.Trim().ToLower())
					{
						case "datasource":
						case "server":
						case "host":
							parameters.Server = element.Groups[2].Value.Trim();
							break;

						case "database":
							parameters.FileName = element.Groups[2].Value.Trim();
							break;

						case "user name":
						case "user":
							parameters.UserName = element.Groups[2].Value.Trim();
							break;

						case "user password":
						case "password":
							parameters.UserPassword = element.Groups[2].Value.Trim();
							break;

						case "port":
							parameters.Port = Int32.Parse(element.Groups[2].Value.Trim());
							break;

						case "connection lifetime":
							lifetime = Int32.Parse(element.Groups[2].Value.Trim());
							break;

						case "timeout":
						case "connection timeout":
							parameters.Timeout = Int32.Parse(element.Groups[2].Value.Trim());
							break;

						case "packet size":
							parameters.PacketSize = Int32.Parse(element.Groups[2].Value.Trim());
							break;

						case "pooling":
							parameters.Pooling = Boolean.Parse(element.Groups[2].Value.Trim());
							break;

						case "dialect":
							parameters.Dialect = byte.Parse(element.Groups[2].Value.Trim());
							break;

						case "charset":
							parameters.Charset = element.Groups[2].Value.Trim();
							break;

						case "role":
							parameters.Role	= element.Groups[2].Value.Trim();
							break;
					}
				}
			}

			if (parameters.UserName == String.Empty || 
				parameters.UserPassword == String.Empty || 
				parameters.FileName == String.Empty || 
				parameters.Server == String.Empty || 
				parameters.Port == 0)
			{
				throw new ArgumentException("An invalid connection string argument has been supplied or a required connection string argument has not been supplied.");
			}
			else
			{
				if (parameters.PacketSize < 512 || parameters.PacketSize > 32767)
				{
					StringBuilder msg = new StringBuilder();

					msg.AppendFormat("'Packet Size' value of {0} is not valid.\r\nThe value should be an integer >= 512 and <= 32767.", parameters.PacketSize);

					throw new ArgumentException(msg.ToString());
				}
			}
		}

		public bool Verify()
		{
			int INFO_SIZE = 16;
			
			byte[] buffer = new byte[INFO_SIZE];
			
			// Do not actually ask for any information
			byte[] databaseInfo  = new byte[]
			{
				GdsCodes.isc_info_end
			};

			try 
			{
				db.GetDatabaseInfo(databaseInfo, INFO_SIZE, buffer);

				return true;
			}
			catch
			{
				return false;
			}
		}
		#endregion
	}
}
