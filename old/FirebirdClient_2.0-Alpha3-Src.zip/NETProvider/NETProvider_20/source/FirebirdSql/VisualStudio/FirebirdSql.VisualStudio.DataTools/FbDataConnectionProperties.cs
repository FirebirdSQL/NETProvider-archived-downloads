/*
 *  Visual Studio 2005 DDEX Provider for Firebird
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2005 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using Microsoft.VisualStudio.Data.AdoDotNet;

namespace FirebirdSql.VisualStudio.DataTools
{
    internal class FbDataConnectionProperties : AdoDotNetConnectionProperties
    {
        #region � Properties �

        public override bool IsComplete
        {
            get 
            {
                string[] basicProperties = this.GetBasicProperties();

                foreach (string property in basicProperties)
                {
                    if (!(base[property] is string) ||
                        (base[property] as string).Length == 0)
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        #endregion

        #region � Constructors �

        public FbDataConnectionProperties() 
            : base("FirebirdSql.Data.FirebirdClient")
        {
            System.Diagnostics.Trace.WriteLine("FbDataConnectionProperties()");
        }

        public FbDataConnectionProperties(string connectionString)
            : base("FirebirdSql.Data.FirebirdClient", connectionString)
        {
            System.Diagnostics.Trace.WriteLine("FbDataConnectionProperties(string)");
        }

        #endregion

        #region � Methods �

        public override void Parse(string s)
        {
            base.Parse(s);
        }

        public override string[] GetBasicProperties()
        {
            System.Diagnostics.Trace.WriteLine("FbDataConnectionProperties::GetBasicProperties()");

            return new string[] { "Data Source", "Database", "User ID", "Password" };
        }

        #endregion
    }
}
