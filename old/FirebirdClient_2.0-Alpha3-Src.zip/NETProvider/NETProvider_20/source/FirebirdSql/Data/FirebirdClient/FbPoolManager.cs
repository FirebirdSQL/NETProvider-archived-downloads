/*
 *	Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *	   The contents of this file are subject to the Initial 
 *	   Developer's Public License Version 1.0 (the "License"); 
 *	   you may not use this file except in compliance with the 
 *	   License. You may obtain a copy of the License at 
 *	   http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *	   Software distributed under the License is distributed on 
 *	   an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *	   express or implied. See the License for the specific 
 *	   language governing rights and limitations under the License.
 * 
 *	Copyright (c) 2002, 2005 Carlos Guzman Alvarez
 *	All Rights Reserved.
 */

using System;
using System.Collections;

namespace FirebirdSql.Data.FirebirdClient
{
    internal sealed class FbPoolManager
    {
        #region � Static Fields �

        private static readonly FbPoolManager instance = new FbPoolManager();

        #endregion

		#region � Static Properties �

		public static FbPoolManager Instance
		{
			get { return FbPoolManager.instance; }
		}

		#endregion

		#region � Fields �

		private Hashtable	pools;
        private Hashtable	handlers;
		private object		syncObject;

        #endregion

        #region � Properties �

        public int PoolsCount
        {
            get
            {
                if (this.pools != null)
                {
                    return this.pools.Count;
                }
                return 0;
            }
        }

        #endregion

        #region � Constructors �

        private FbPoolManager()
        {
            this.pools		= Hashtable.Synchronized(new Hashtable());
            this.handlers	= Hashtable.Synchronized(new Hashtable());
			this.syncObject	= new object();
        }

        #endregion

        #region � Methods �

		/// <summary>
		/// Gets a connection from the connection pool that matches the given connection string
		/// </summary>
		/// <param name="connectionString">A connection string</param>
		/// <returns>A <see cref="FbConnectionInternal" /> instance</returns>
		public FbConnectionInternal GetConnection(string connectionString)
		{
			lock (this.syncObject)
			{
				lock (this.pools.SyncRoot)
				{
					return this.GetOrCreatePool(connectionString).CheckOut();
				}
			}
		}

		/// <summary>
		/// Puts a connection back to the connection pool.
		/// </summary>
		/// <param name="connectionString">A connection string.</param>
		/// <param name="connectionInternal">A <see cref="FbConnectionInternal" /> instance.</param>
		public void PutConnection(string connectionString, FbConnectionInternal innerConnection)
		{
			lock (this.syncObject)
			{
				lock (this.pools.SyncRoot)
				{
					this.GetPool(connectionString).CheckIn(innerConnection);
				}
			}
		}

		/// <summary>
		/// Clears all existent connection pools.
		/// </summary>
        public void ClearAllPools()
        {
            lock (this.syncObject)
            {
                lock (this.pools.SyncRoot)
                {
                    FbConnectionPool[] tempPools = new FbConnectionPool[this.pools.Count];

                    this.pools.Values.CopyTo(tempPools, 0);

                    foreach (FbConnectionPool pool in tempPools)
                    {
                        // Clear pool
                        pool.Clear();
                    }

                    // Clear Hashtables
                    this.pools.Clear();
                    this.handlers.Clear();
                }
            }
        }

		/// <summary>
		/// Clears the connection pool that macthes the given connection string.
		/// </summary>
		/// <param name="connectionString">A connection string.</param>
        public void ClearPool(string connectionString)
        {
            lock (this.syncObject)
            {
                lock (this.pools.SyncRoot)
                {
                    int hashCode = connectionString.GetHashCode();

                    if (this.pools.ContainsKey(hashCode))
                    {
                        FbConnectionPool pool = (FbConnectionPool)this.pools[hashCode];

                        // Clear pool
                        pool.Clear();
                    }
                }
            }
        }

		/// <summary>
		/// Gets the number of connection on the connection pool that matches the given connection string.
		/// </summary>
		/// <param name="connectionString">A connection string.</param>
		/// <returns>The number of connections in the pool; or 0 if no pool exists for the given connection string.</returns>
		public int GetPooledConnectionCount(string connectionString)
		{
			FbConnectionPool pool = this.GetPool(connectionString);

			return (pool != null) ? pool.Count : 0;
		}

        #endregion

		#region � Private Methods �

        private FbConnectionPool GetPool(string connectionString)
        {
            FbConnectionPool pool = null;

			lock (this.syncObject)
			{
				lock (this.pools.SyncRoot)
				{
					if (this.pools.ContainsKey(connectionString.GetHashCode()))
					{
						pool = (FbConnectionPool)pools[connectionString.GetHashCode()];
					}
				}
			}

            return pool;
        }

        private FbConnectionPool GetOrCreatePool(string connectionString)
        {
            FbConnectionPool pool = null;

            lock (this.syncObject)
            {
				lock (this.pools.SyncRoot)
				{
					pool = this.GetPool(connectionString);

					if (pool == null)
					{
						int hashcode = connectionString.GetHashCode();

						// Create an empty pool	handler
						EmptyPoolEventHandler handler = new EmptyPoolEventHandler(this.OnEmptyPool);

						this.handlers.Add(hashcode, handler);

						// Create the new connection pool
						pool = new FbConnectionPool(connectionString);

						this.pools.Add(hashcode, pool);

						pool.EmptyPool += handler;
					}
				}
            }

            return pool;
        }

		#endregion

		#region � Event Handlers �

		private void OnEmptyPool(object sender, EventArgs e)
        {
            lock (this.pools.SyncRoot)
            {
                int hashCode = (int)sender;

                if (this.pools.ContainsKey(hashCode))
                {
                    FbConnectionPool pool = (FbConnectionPool)this.pools[hashCode];
                    EmptyPoolEventHandler handler = (EmptyPoolEventHandler)this.handlers[hashCode];

                    pool.EmptyPool -= handler;

                    this.pools.Remove(hashCode);
                    this.handlers.Remove(hashCode);

                    pool = null;
                    handler = null;
                }
            }
        }

        #endregion
    }
}
