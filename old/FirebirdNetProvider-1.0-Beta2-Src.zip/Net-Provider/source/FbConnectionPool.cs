//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author: Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Collections;
using System.Threading;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	internal class FbConnectionPool : MarshalByRefObject
	{
		#region FIELDS

		private static ConnectionPool pool = null;

		#endregion
    
		#region METHODS

		public static void Init()
		{
			if (pool ==  null)
			{
				pool = new ConnectionPool();
			}
		}

		public static FbIscConnection GetConnection(string connectionString)
		{
			Init();

			return ((FbIscConnection)pool.CheckOut(connectionString));
		}
    
		public static void FreeConnection(FbIscConnection c) 
		{
			pool.CheckIn(c);
		}

		#endregion
	}

	internal struct ConnectionData
	{
		public long created;
		public long	lifetime;
	}
	
	internal class ConnectionPool
	{
		#region FIELDS

		private Hashtable	locked	 = Hashtable.Synchronized(new Hashtable());
		private Hashtable	unlocked = Hashtable.Synchronized(new Hashtable());
		
		private Thread	cleanUpThread;

		#endregion

		#region CONSTRUCTORS

		public ConnectionPool()		
		{			
			cleanUpThread		= new Thread(new ThreadStart(RunCleanUp));
			cleanUpThread.Name	= "CleanUp Thread";			
			cleanUpThread.Start();
			cleanUpThread.IsBackground = true;
		}

		#endregion

		#region METHODS
		
		public Object CheckOut(string connectionString)
		{
			ConnectionData data;
			Object o = null;

			data.created  = System.DateTime.Now.Ticks;
			data.lifetime = 0;

			lock (unlocked.SyncRoot)
			{
				if (unlocked.Count > 0)
				{			
					IDictionaryEnumerator e = unlocked.GetEnumerator();
					while (e.MoveNext())
					{
						o = e.Key;
					
						if (Validate(o, connectionString))
						{
							if (((ConnectionData)e.Value).lifetime != 0)
							{
								if ((data.created - ((ConnectionData)e.Value).created) > ((ConnectionData)e.Value).lifetime)
								{
									unlocked.Remove(o);
									Expire(o);
									o = null;
								}
								else
								{
									unlocked.Remove(o);
									locked.Add(o, data);
									return(o);
								}
							}
							else
							{
								unlocked.Remove(o);
								locked.Add(o, data);
								return(o);
							}
						}
						else
						{						
							unlocked.Remove(o);
							Expire(o);
							o = null;
						}

						e = unlocked.GetEnumerator();
					}			
				}
			}

			o = Create(connectionString);
			
			data.lifetime = ((FbIscConnection)o).Lifetime * TimeSpan.TicksPerSecond;

			locked.Add(o, data);
			
			return(o);
		}	

		public void CheckIn(Object o)
		{
			ConnectionData data;

			lock (unlocked.SyncRoot)
			{
				data			= (ConnectionData)locked[o];
				data.created	= System.DateTime.Now.Ticks;

				locked.Remove(o);
				unlocked.Add(o, data);
			}
		}

		private void RunCleanUp()
		{		
			TimeSpan interval = new TimeSpan(0, 0, 10);

			while (true)
			{
				lock (this)
				{
					CleanUp(null);
				}

				Thread.Sleep(interval);
			}
		}

		private Object Create(string	connectionString)
		{
			try 
			{
				FbIscConnection connection = new FbIscConnection(connectionString);
				connection.Open();

				return connection;
			}
			catch (Exception ex) 
			{
				throw ex;
			}
		}
    
		private bool Validate(Object o, string connectionString)
		{
			try 
			{								
				return(((FbIscConnection)o).ConnectionString == connectionString &&
						((FbIscConnection)o).VerifyAttachedDB());
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void Expire(Object o)
		{
			try 
			{
				if (((FbIscConnection)o).VerifyAttachedDB())
				{
					((FbIscConnection)o).Close();
				}
			}
			catch (Exception)
			{
				throw new FbException("Error closing database connection.");
			}
		}
		
		private void CleanUp(object State)
		{
			long now = System.DateTime.Now.Ticks;
			Object o;			
			
			lock (unlocked.SyncRoot)
			{
				IDictionaryEnumerator e = unlocked.GetEnumerator();
				while (e.MoveNext())
				{
					o = e.Key;
					if (((ConnectionData)e.Value).lifetime != 0)
					{
						if ((now - ((ConnectionData)e.Value).created) > ((ConnectionData)e.Value).lifetime)
						{
							unlocked.Remove(o);
							Expire(o);
							o = null;

							// Rebuild Enumeration
							e = unlocked.GetEnumerator();
						}
					}
				}
			}
		}

		#endregion
	}
}