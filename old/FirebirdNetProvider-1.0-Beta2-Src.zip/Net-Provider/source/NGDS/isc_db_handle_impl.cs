//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.IO;
using System.Net.Sockets;
using System.Security.Principal;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="T:isc_db_handle_impl"]/*'/>
	internal class isc_db_handle_impl : isc_db_handle 
	{
		#region EVENTS 

		public event DbWarningMessageEventHandler DbWarningMessage;

		#endregion

		#region FIELDS

		private bool				invalid;
		private int					rdb_id;
		private ArrayList			rdb_transactions = new ArrayList();
		private ArrayList 			rdb_warnings 	 = new ArrayList();
		
		private ArrayList			rdb_sql_requests = new ArrayList();				
		private Socket				socket = null;
		private NetworkStream		networkStream = null;
		private XdrOutputStream		output;		
		private XdrInputStream		input;
		private int					op = -1;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Rdb_id"]/*'/>
		public int Rdb_id
		{
			get
			{
				CheckValidity();
				return rdb_id;
			}
			set
			{
				CheckValidity();
				rdb_id = value;
			}
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Transactions"]/*'/>
		public ArrayList Transactions
		{
			get { return rdb_transactions; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Output"]/*'/>
		public XdrOutputStream Output
		{
			get { return output; }
			set { output = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Input"]/*'/>
		public XdrInputStream Input
		{
			get { return input; }
			set { input = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:DbSocket"]/*'/>
		public Socket DbSocket
		{
			get { return socket; }
			set { socket = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:DbNetworkStream"]/*'/>
		public NetworkStream DbNetworkStream
		{
			get { return networkStream; }
			set { networkStream = value; }
		}	

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:IsValid"]/*'/>
		public bool IsValid
		{
			get { return !invalid; }
		}
		
		public ArrayList SqlRequest
		{
			get { return rdb_sql_requests; }
		}

		public int Op
		{
			get { return op; }
			set { op = value; }
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:HasTransactions"]/*'/>
		public bool HasTransactions()
		{
			CheckValidity();
			return rdb_transactions.Count == 0 ? false : true;
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:TransactionCount"]/*'/>
		public int TransactionCount()
		{
			CheckValidity();
			return rdb_transactions.Count;
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:AddTransaction(FirebirdSql.Data.NGDS.isc_tr_handle_impl)"]/*'/>
		public void AddTransaction(isc_tr_handle_impl tr)
		{
			CheckValidity();
			rdb_transactions.Add(tr);
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:RemoveTransaction(FirebirdSql.Data.NGDS.isc_tr_handle_impl)"]/*'/>
		public void RemoveTransaction(isc_tr_handle_impl tr)
		{
			CheckValidity();
			rdb_transactions.Remove(tr);
		}
		
		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:GetWarnings"]/*'/>
		public ArrayList GetWarnings() 
		{
			CheckValidity();
			lock (rdb_warnings) 
			{
				return new ArrayList(rdb_warnings);
			}
		}
		
		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:AddWarning(FirebirdSql.Data.INGDS.GDSException)"]/*'/>
		public void AddWarning(GDSException warning) 
		{
			CheckValidity();
			lock (rdb_warnings) 
			{
				rdb_warnings.Add(warning);
			}

			if (DbWarningMessage != null)
			{
				DbWarningMessage(this, new DbWarningMessageEventArgs(warning));
			}
		}
		
		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:ClearWarnings"]/*'/>
		public void ClearWarnings() 
		{
			CheckValidity();
			lock (rdb_warnings) 
			{
				rdb_warnings.Clear();
			}
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:CheckValidity"]/*'/>
		private void CheckValidity() 
		{
			if (invalid)
			{
				throw new InvalidOperationException("This database handle is invalid and cannot be used anymore.");
			}
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:Invalidate"]/*'/>
		internal void Invalidate()
		{
			try
			{
				input.Close();
				output.Close();				
				networkStream.Close();
				socket.Close();
			     
				input  = null;
				output = null;
				
				socket		  = null;
				networkStream = null;

				invalid = true;
			}
			catch(IOException ex)
			{
				throw ex;
			}
		}

		#endregion
	}
}