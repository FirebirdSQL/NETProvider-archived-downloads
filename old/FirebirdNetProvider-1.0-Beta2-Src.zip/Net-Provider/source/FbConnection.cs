//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;


namespace FirebirdSql.Data.Firebird
{	
	#region INFO_MESSAGE_EVENT_ARGS

	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="T:FirebirdSql.Data.Firebird.FbInfoMessageEventArgs"]/*'/>
	public sealed class FbInfoMessageEventArgs : EventArgs
	{
		private FbErrorCollection errors = new FbErrorCollection();
		private string			  message = "";

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:FirebirdSql.Data.Firebird.FbInfoMessageEventArgs.Errors"]/*'/>
		public FbErrorCollection Errors
		{
			get { return errors; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:FirebirdSql.Data.Firebird.FbInfoMessageEventArgs.Message"]/*'/>
		public string Message
		{
			get { return message; }
		}

		internal FbInfoMessageEventArgs(GDSException ex)
		{
			this.message = ex.Message;
			
			foreach (GDSError error in ex.Errors)
			{
				errors.Add(error.Message, error.ErrorCode);
			}
		}
	}

	#endregion

	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="D:FirebirdSql.Data.Firebird.FbInfoMessageEventHandler"]/*'/>
	public delegate void FbInfoMessageEventHandler(object sender, FbInfoMessageEventArgs e);
	
	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="T:FbConnection"]/*'/>
	#if (!_MONO)
	[ToolboxBitmap(typeof(FbConnection), "Resources.ToolboxBitmaps.FbConnection.bmp")]	
	#endif
	[DefaultEvent("InfoMessage")]
	public sealed class FbConnection : Component, IDbConnection, ICloneable
	{	
		#region EVENTS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="E:FirebirdSql.Data.Firebird.FbConnection.StateChange"]/*'/>
		public event StateChangeEventHandler StateChange;

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="E:FirebirdSql.Data.Firebird.FbConnection.InfoMessage"]/*'/>
		public event FbInfoMessageEventHandler InfoMessage;
		
		#endregion

		#region FIELDS

		private FbIscConnection iscConnection;
		private ConnectionState state;
		private bool			disposed			= false;		
		private string			connectionString	= String.Empty;
		private int				connectionTimeout	= 15;
		private FbDataReader	dataReader			= null;
		private string			database			= String.Empty;
		private string			dataSource			= String.Empty;
		private Encoding		encoding			= Encoding.Default;

		private FbTransaction	activeTxn			= null;

		private DbWarningMessageEventHandler dbWarningngHandler = null;

		#endregion
		
		#region PROPERTIES

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ConnectionString"]/*'/>
		public string ConnectionString
		{
			get { return connectionString; }
			set
			{ 
				if (state == ConnectionState.Closed)
				{
					connectionString = value;
				}
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ConnectionTimeout"]/*'/>
		public int ConnectionTimeout
		{
			get { return connectionTimeout; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get { return database; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:DataSource"]/*'/>
		public string DataSource
		{
			get { return dataSource; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ServerVersion"]/*'/>
		public string ServerVersion
		{
			get
			{
				if (this.State == ConnectionState.Closed)
				{
					throw new InvalidOperationException("The connection is closed.");
				}

				return IscConnection.DatabaseInfo.FirebirdVersion;
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:State"]/*'/>
		public ConnectionState State
		{
			get { return state; }
		}
		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Encoding"]/*'/>
		internal Encoding Encoding
		{
			get { return encoding; }
		}
		
		internal FbDataReader DataReader
		{
			get { return dataReader; }
			set { dataReader = value; }
		}

		internal FbIscConnection IscConnection
		{
			get { return iscConnection; }
			set { iscConnection = value; }
		}

		#endregion		

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbConnection()
		{
			state = ConnectionState.Closed;
		}
    		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		public FbConnection(string connString)
		{
			this.state				= ConnectionState.Closed;
			this.ConnectionString	= connString;			
		}		

		#endregion

		#region DESTRUCTORS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if (!disposed)
			{
				try
				{	
					if (disposing)
					{
						// release any managed resources
						Close();

						database	= null;
						encoding	= null;
					}

					// release any unmanaged resources
				}
				finally
				{
					base.Dispose(disposing);
				}

				disposed = true;
			}			
		}

		#endregion

		#region ICLONEABLE_METHODS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ICloneable#Clone"]/*'/>
		object ICloneable.Clone()
		{
			return new FbConnection(ConnectionString);
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		IDbTransaction IDbConnection.BeginTransaction()
		{
			return BeginTransaction();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		public FbTransaction BeginTransaction()
		{
			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException(" BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}
			
			try
			{
				activeTxn = new FbTransaction(this);
				activeTxn.BeginTransaction();				 
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return this.activeTxn;
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.String)"]/*'/>
		public FbTransaction BeginTransaction(string transactionName)
		{
			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException(" BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}
			
			try
			{
				activeTxn = new FbTransaction(this);
				activeTxn.BeginTransaction();
				activeTxn.Save(transactionName);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return this.activeTxn;
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		IDbTransaction IDbConnection.BeginTransaction(IsolationLevel level)
		{
			return BeginTransaction(level);
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level)
		{
			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			try
			{
				activeTxn = new FbTransaction(this, level);
				activeTxn.BeginTransaction();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return this.activeTxn;			
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel,System.String)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level, string transactionName)
		{
			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			try
			{
				activeTxn = new FbTransaction(this, level);
				activeTxn.BeginTransaction();
				activeTxn.Save(transactionName);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return this.activeTxn;			
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ChangeDatabase"]/*'/>
		public void ChangeDatabase(string db)
		{
			if (db == null || db.Trim().Length == 0)
			{
				throw new InvalidOperationException("Database name is not valid.");
			}

			if (this.DataReader != null)
			{
				throw new InvalidOperationException("ChangeDatabase requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			if (this.State == ConnectionState.Closed)
			{
				throw new InvalidOperationException("ChangeDatabase requires an open and available Connection.");
			}

			string oldDb = Database;

			try
			{
				/* Close current connection	*/
				Close();

				/* Set up the new Database	*/
				this.database = db;

				/* Open new connection	*/
				Open();
			}
			catch (FbException ex)
			{
				this.database = oldDb;
				throw ex;
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Open"]/*'/>
		public void Open()
		{
			if (state != ConnectionState.Closed)
			{
				throw new InvalidOperationException("Connection already Open.");
			}

			try
			{
				state = ConnectionState.Connecting;

				iscConnection = new FbIscConnection(connectionString);

				if (iscConnection.Pooling)
				{		
					// Use Connection Pooling
					iscConnection = FbConnectionPool.GetConnection(connectionString);
				}
				else
				{
					// Do not use Connection Pooling
					iscConnection.Pooled = false;
					iscConnection.Open();
				}

				database	= iscConnection.Database;
				dataSource	= iscConnection.DataSource;

				dbWarningngHandler = new DbWarningMessageEventHandler(OnDbWarningMessage);
				iscConnection.db.DbWarningMessage += dbWarningngHandler;
				
				// Set up the encoding field
				encoding = Encodings.GetFromFirebirdEncoding(iscConnection.Charset);

				state = ConnectionState.Open;
				
				if (StateChange != null)
				{
					StateChange(this, new StateChangeEventArgs(ConnectionState.Closed,state));
				}
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close()
		{
			if (state == ConnectionState.Open)
			{
				try
				{		
					lock (iscConnection)
					{
						iscConnection.db.DbWarningMessage -= dbWarningngHandler;

						if (activeTxn != null)
						{
							// Dispose Transaction
							activeTxn.Dispose();
							activeTxn = null;
						}

						if (iscConnection.Pooling)
						{
							IscConnection.ClearWarnings();
							FbConnectionPool.FreeConnection(IscConnection);
						}
						else
						{	
							IscConnection.Close();
							IscConnection = null;
						}
					}

					// Update state
					state = ConnectionState.Closed;

					// Raise event
					if (StateChange != null)
					{
						StateChange(this, new StateChangeEventArgs(ConnectionState.Open,state));
					}
				}
				catch(GDSException ex)
				{
					throw new FbException(ex);
				}
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:CreateCommand"]/*'/>
		IDbCommand IDbConnection.CreateCommand()
		{			
			return CreateCommand();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:CreateCommand"]/*'/>
		public FbCommand CreateCommand()
		{		
			FbCommand command = new FbCommand();

			command.Connection = this;
	
			return command;
		}

		private void OnDbWarningMessage(object sender, DbWarningMessageEventArgs e)
		{
			if (InfoMessage != null)
			{
				InfoMessage(this, new FbInfoMessageEventArgs(e.Exception));
			}
		}

		#endregion
	}
}
