//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Embedded
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class FesFactory : FactoryBase
	{
		#region Inner Classes
					
		private class FesFactoryHelper
		{
			internal static readonly FesFactory Instance = new FesFactory();

			// Explicit static constructor to tell C# compiler
			// not to mark type as beforefieldinit
			static FesFactoryHelper()
			{
			}
		}

		#endregion

		#region Static Properties

		public static FactoryBase Instance
		{
			get
			{
				return FesFactoryHelper.Instance;
			}
		}

		#endregion

		#region Constructors

		private FesFactory()
		{
		}

		#endregion

		#region Array Creation

		public override ArrayBase CreateArray(
			IDbAttachment	db,
			ITransaction	transaction,
			string			tableName, 
			string			fieldName)
		{
			return new FesArray(db, transaction, tableName, fieldName);
		}

		public override ArrayBase CreateArray(
			IDbAttachment	db,
			ITransaction	transaction,
			long			handle,
			string			tableName,
			string			fieldName)
		{
			return new FesArray(db, transaction, handle, tableName, fieldName);
		}

		#endregion

		#region Blob Creation

		public override BlobBase CreateBlob(
			IDbAttachment	db, 
			ITransaction	transaction)
		{
			return new FesBlob(db, transaction);
		}

		public override BlobBase CreateBlob(
			IDbAttachment	db, 
			ITransaction	transaction, 
			long			handle)
		{
			return new FesBlob(db, transaction, handle);
		}

		#endregion

		#region Connection Creation

		public override IDbAttachment CreateDbConnection(
			AttachmentParams parameters)
		{
			return new FesDbAttachment(parameters);
		}
				
		public override ISvcAttachment CreateSvcConnection(
			AttachmentParams parameters)
		{
			return new FesSvcAttachment(parameters);
		}

		#endregion

		#region Statement Creation

		public override StatementBase CreateStatement(IDbAttachment db)
		{
			return new FesStatement(db);
		}

		public override StatementBase CreateStatement(
			string			commandText, 
			IDbAttachment	db)
		{
			return new FesStatement(commandText, db);
		}

		public override StatementBase CreateStatement(
			string			commandText, 
			IDbAttachment	db, 
			ITransaction	transaction)
		{
			return new FesStatement(commandText, db, transaction);
		}

		#endregion

		#region Transaction Creation

		public override ITransaction CreateTransaction(
			IDbAttachment db)
		{
			return new FesTransaction(db);
		}

		public override ITransaction CreateTransaction(
			IDbAttachment	db, 
			IsolationLevel	isolationLevel)
		{
			return new FesTransaction(db, isolationLevel);
		}

		#endregion

		#region Status Vector Creation

		internal static int[] CreateStatusVector()
		{
			return new int[IscCodes.ISC_STATUS_LENGTH];
		}

		#endregion
	}
}
