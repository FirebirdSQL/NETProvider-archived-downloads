//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;

using Borland.Data.Schema;

namespace FirebirdSql.Data.Bdp
{
	public class FbMetaData : ISQLMetaData
	{
		#region Fields

		private FbConnection connection;

		#endregion

		#region Constructors

		public FbMetaData(FbConnection connection)
		{
			this.connection = connection;
		}

		#endregion

		#region ISQLMetaData Methods

		public void GetProperty(MetaDataProps metaProp, out object value)
		{
			throw new NotSupportedException();
		}

		public void SetProperty(MetaDataProps metaProp, object value)
		{
			throw new NotSupportedException();
		}

		public DataTable GetSchemaTable(
			IDataReader reader, IDbCommand command)
		{
			throw new NotSupportedException();
		}

		public DataTable GetIndices(
			string tableName, IndexType indexType)
		{
			throw new NotSupportedException();
		}

		public DataTable GetProcedureParams(
			string spName, string paramName)
		{
			throw new NotSupportedException();
		}

		public DataTable GetColumns(
			string tableName, string columnName, ColumnType colType)
		{
			throw new NotSupportedException();
		}

		public DataTable GetProcedures(
			string spName, ProcedureType procType)
		{
			throw new NotSupportedException();
		}

		public DataTable GetTables(
			string tableName, TableType tableType)
		{
			throw new NotSupportedException();
		}

		public DataTable GetObjectList(ObjectType type)
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}
