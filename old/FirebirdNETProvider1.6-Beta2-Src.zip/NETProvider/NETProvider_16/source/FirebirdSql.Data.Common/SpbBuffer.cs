//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class SpbBuffer : BufferBase
	{
		#region Constructors
		
		public SpbBuffer() : base()
		{
		}
		
		public SpbBuffer(bool isLittleEndian) : base(isLittleEndian)
		{
		}

		#endregion
		
		#region Methods

		public void Append(int type, byte content)
		{						
			this.Write((byte)type);
			this.Write(content);
		}

		public void Append(int type, int content)
		{						
			this.Write((byte)type);
			this.Write(content);			
		}

		public void Append(int type, string content)
		{			
			byte[] contents = System.Text.Encoding.Default.GetBytes(content);
			
			this.Write((byte)type);
			this.Write((short)contents.Length);
			this.Write(contents);
		}

		public void Append(byte type, string content)
		{			
			byte[] contents = System.Text.Encoding.Default.GetBytes(content);
			
			this.Write(type);
			this.Write((byte)contents.Length);
			this.Write(contents);
		}

		public void Append(int type, byte[] content)
		{						
			this.Write((byte)type);
			this.Write((short)content.Length);
			this.Write(content);
		}

		public void Append(byte type, byte[] content)
		{						
			this.Write(type);
			this.Write((byte)content.Length);
			this.Write(content);
		}
				
		#endregion
	}
}
