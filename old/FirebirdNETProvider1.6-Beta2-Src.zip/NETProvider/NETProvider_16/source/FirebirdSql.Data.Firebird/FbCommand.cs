//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Text;
using System.Text.RegularExpressions;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird
{		
	/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/overview/*'/>
	[ToolboxItem(true),
	ToolboxBitmap(typeof(FbCommand), "Resources.FbCommand.bmp")]
	public sealed class FbCommand : Component, IDbCommand, ICloneable
	{	
		#region Private static fields

		private static Regex namedRegex = new Regex(
			@"(('[^']*?\@[^']*')*[^'@]*?)*(?<param>@\w+)*([^'@]*?('[^']*?\@*[^']*'))*",
			RegexOptions.Compiled|RegexOptions.ExplicitCapture);


		#endregion
		
		#region Fields
		
		private FbConnection			connection;
		private FbTransaction			transaction;
		private FbParameterCollection	parameters;
		private UpdateRowSource			updatedRowSource;
		private CommandBehavior			commandBehavior;
		private StatementBase			statement;
		private bool					disposed;
		private int						actualCommand;
		private string[]				commands;
		private string					commandText;
		private CommandType				commandType;
		private bool					designTimeVisible;
		private int						commandTimeout;
		private StringCollection		namedParameters;
		private bool					returnsSet;
		private bool					implicitTransaction;

		#endregion

		#region Properties

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandText"]/*'/>
		[Category("Data"),
		DefaultValue(""),
		RefreshProperties(RefreshProperties.All)]
		#if (!MONO)
		[Editor(typeof(Design.FbCommandTextUIEditor), typeof(System.Drawing.Design.UITypeEditor))]
		#endif
		public string CommandText
		{
			get { return this.commandText; }
			set 
			{
				lock (this)
				{
					if (this.statement != null		&& 
						this.commandText != null	&&
						this.commandText != value	&& 
						this.commandText.Length != 0)
					{
						this.statement.Drop();
						this.statement	= null;
					}
			
					this.commandText	= value;
					this.actualCommand	= 0;
					this.commands		= null;
				}
			}
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandType"]/*'/>
		[Category("Data"),
		DefaultValue(CommandType.Text),
		RefreshProperties(RefreshProperties.All)]		
		public CommandType CommandType
		{
			get { return this.commandType; }
			set { this.commandType = value; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandTimeout"]/*'/>
		[ReadOnly(true),		
		DefaultValue(30)]		
		public int CommandTimeout
		{
			get { return this.commandTimeout; }
			set
			{
				if (value < 0) 
				{
					throw new ArgumentException("The property value assigned is less than 0.");
				}
				else
				{					
					throw new NotSupportedException();
				}
			}
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandPlan"]/*'/>
		[Browsable(false)]		
		public string CommandPlan
		{
			get 
			{
				if (this.statement != null)
				{
					return this.statement.GetExecutionPlan();
				}
				else
				{
					return String.Empty;
				}
			}
		}

		IDbConnection IDbCommand.Connection
		{
			get { return this.Connection; }
			set { this.Connection = (FbConnection)value; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="Connection"]/*'/>
		[Category("Behavior"), DefaultValue(null)]
		public FbConnection Connection
		{
			get { return this.connection; }
			set 
			{ 
				lock (this)
				{
					if (this.transaction != null &&
						!this.transaction.IsUpdated)
					{
						throw new InvalidOperationException("The Connection property was changed while a transaction was in progress.");
					}

					if (this.connection != null)
					{
						if (this.connection.DataReader != null)
						{
							throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");
						}
					
						if (this.connection.ActiveCommands != null)
						{
							this.connection.ActiveCommands.Remove(this);
						}
					}

					if (this.connection != value)
					{
						if (this.Transaction != null)
						{
							this.Transaction = null;
						}

						if (this.statement != null)
						{
							this.statement.Drop();
							this.statement = null;
						}
					}

					this.connection = value;

					// Add this command to the active command list
					if (this.connection != null &&
						this.connection.ActiveCommands != null &&
						!this.connection.ActiveCommands.Contains(this))
					{
						this.connection.ActiveCommands.Add(this);
					}
				}
			}
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="DesignTimeVisible"]/*'/>
		[Browsable(false),
		DesignOnly(true),
		DefaultValue(true)]
		public bool DesignTimeVisible
		{
			get { return this.designTimeVisible; }
			set { this.designTimeVisible = value; }
		}

		IDataParameterCollection IDbCommand.Parameters
		{
			get { return this.Parameters; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="Parameters"]/*'/>
		[Category("Data"),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public FbParameterCollection Parameters
		{
			get { return this.parameters; }
		}

		IDbTransaction IDbCommand.Transaction
		{
			get { return this.Transaction; }
			set { this.Transaction = (FbTransaction)value; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="Transaction"]/*'/>
		[Browsable(false),
		DataSysDescription("Tansaction context used by the command."),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]		
		public FbTransaction Transaction
		{
			get { return this.implicitTransaction ? null : this.transaction; }
			set
			{
				lock (this)
				{
					if (this.connection != null && 
						this.connection.DataReader != null)
					{
						throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");
					}

					this.RollbackImplicitTransaction();
					
					this.transaction = value;

					if (this.statement != null)						
					{
						if (this.transaction != null)
						{
							this.statement.Transaction = this.transaction.Transaction;
						}
						else
						{
							this.statement.Transaction = null;
						}
					}					
				}
			}
		}
		
		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="UpdatedRowSource"]/*'/>
		[Category("Behavior"), DefaultValue(UpdateRowSource.Both)]
		public UpdateRowSource UpdatedRowSource
		{
			get { return this.updatedRowSource; }
			set { this.updatedRowSource = value; }
		}

		#endregion

		#region Internal Properties
		
		internal CommandBehavior CommandBehavior
		{
			get { return this.commandBehavior; }
		}

		internal StatementBase Statement
		{
			get { return this.statement; }
			set { this.statement = value; }
		}

		internal int RecordsAffected
		{
			get 
			{ 
				if (this.statement != null)
				{
					return this.statement.RecordsAffected; 
				}
				return -1;
			}
		}

		internal bool IsDisposed
		{
			get { return this.disposed; }
		}

		internal FbTransaction ActiveTransaction
		{
			get { return this.transaction; }
		}

		#endregion

		#region Constructors

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor"]/*'/>
		public FbCommand() : base()
		{
			this.parameters			= new FbParameterCollection();
			this.updatedRowSource	= UpdateRowSource.Both;
			this.commandBehavior	= CommandBehavior.Default;
			this.actualCommand		= -1;
			this.commandText		= String.Empty;
			this.commandType		= CommandType.Text;		
			this.designTimeVisible	= true;
			this.commandTimeout		= 30;
			this.namedParameters	= new StringCollection();

			GC.SuppressFinalize(this);
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor(System.String)"]/*'/>
		public FbCommand(string cmdText) : this()
		{
			this.CommandText = cmdText;
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor(System.String,FbConnection)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection) : this()
		{
			this.CommandText = cmdText;
			this.Connection	 = connection;
		}
		
		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor(System.String,FbConnection,Transaction)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection, FbTransaction transaction) : this()
		{
			this.CommandText = cmdText;
			this.Connection  = connection;
			this.transaction = transaction;
		}				 

		#endregion

		#region IDisposable Methods

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			lock (this)
			{
				if (!this.disposed)
				{
					try
					{
						if (disposing)
						{
							// Clear active commands
							if (this.connection != null &&
								this.connection.ActiveCommands != null)
							{
								this.connection.ActiveCommands.Remove(this);
							}

							// release any managed resources
							if (this.statement != null)
							{
								this.statement.Drop();
								this.statement = null;
							}

							// Commit transaction if needed
							if (this.implicitTransaction &&
								this.transaction != null &&
								!this.transaction.IsUpdated)
							{
								try
								{
									this.RollbackImplicitTransaction();
								}
								catch
								{
								}
							}

							this.commandText			= String.Empty;
							this.actualCommand			= -1;
							this.implicitTransaction	= false;
							this.namedParameters		= null;
							this.commands				= null;
							this.connection				= null;
							this.transaction			= null;
							this.parameters				= null;
						}
					
						// release any unmanaged resources

						this.disposed = true;
					}
					finally 
					{
						base.Dispose(disposing);
					}
				}
			}
		}

		#endregion

		#region ICloneable Methods

		object ICloneable.Clone()
		{
			FbCommand command = new FbCommand();
			
			command.CommandText			= this.commandText;
			command.Connection			= this.connection;
			command.Transaction			= this.transaction;
			command.CommandType			= this.CommandType;
			command.UpdatedRowSource	= this.UpdatedRowSource;
			// command.CommandTimeout		= this.CommandTimeout;

			for (int i=0; i < this.Parameters.Count; i++)
			{
				command.Parameters.Add(((ICloneable)this.Parameters[i]).Clone());
			}

			return command;
		}

		#endregion

		#region Methods

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="Cancel"]/*'/>
		public void Cancel()
		{			
			throw new NotSupportedException();
		}
		
		IDbDataParameter IDbCommand.CreateParameter()
		{
			return CreateParameter();
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="CreateParameter"]/*'/>
		public FbParameter CreateParameter()
		{
			return new FbParameter();
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteNonQuery"]/*'/>
		public int ExecuteNonQuery()
		{
			lock (this)
			{
				this.checkCommand();

				try
				{
					this.actualCommand	= 0;
					this.returnsSet		= false;
				
					this.executeCommand(CommandBehavior.Default, false);

					this.InternalSetOutputParameters();

					this.CommitImplicitTransaction();
				}
				catch (IscException ex)
				{
					this.RollbackImplicitTransaction();

					throw new FbException(ex.Message, ex);
				}
				catch (Exception)
				{
					this.RollbackImplicitTransaction();

					throw;
				}
			}

			return this.statement.RecordsAffected;
		}
				
		IDataReader IDbCommand.ExecuteReader()
		{	
			return this.ExecuteReader();			
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteReader"]/*'/>
		public FbDataReader ExecuteReader()
		{	
			return this.ExecuteReader(CommandBehavior.Default);			
		}
		
		IDataReader IDbCommand.ExecuteReader(CommandBehavior behavior)
		{
			return this.ExecuteReader(behavior);
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteReader(System.Data.CommandBehavior)"]/*'/>
		public FbDataReader ExecuteReader(CommandBehavior behavior)
		{
			lock (this)
			{
				this.checkCommand();

				try
				{
					this.commandBehavior	= behavior;
					this.returnsSet			= true;

					this.executeCommand(behavior, true);	
				}
				catch (IscException ex)
				{
					this.RollbackImplicitTransaction();

					throw new FbException(ex.Message, ex);
				}
				catch (Exception)
				{
					this.RollbackImplicitTransaction();

					throw;
				}
			}

			return new FbDataReader(this, this.connection);
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteScalar"]/*'/>
		public object ExecuteScalar()
		{
			object val = null;

			lock (this)
			{
				this.checkCommand();

				try
				{
					this.actualCommand	= 0;
					if (this.CommandType == CommandType.StoredProcedure)
					{
						this.returnsSet	= false;
					}
					else
					{
						this.returnsSet	= true;
					}

					this.executeCommand(CommandBehavior.Default, false);

					// Gets only the values of the first row
					DbValue[] values;
					if ((values = this.statement.Fetch()) != null &&
						values.Length > 0)
					{
						val = values[0].Value;
					}

					this.InternalSetOutputParameters();

					this.CommitImplicitTransaction();
				}
				catch (IscException ex)
				{
					this.RollbackImplicitTransaction();

					throw new FbException(ex.Message, ex);
				}
				catch (Exception)
				{
					this.RollbackImplicitTransaction();

					throw;
				}
			}

			return val;
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="Prepare"]/*'/>
		public void Prepare()
		{
			lock (this)
			{
				this.checkCommand();

				try
				{
					this.returnsSet = false;

					this.splitBatchCommands(false);
					this.InternalPrepare();
				}
				catch (IscException ex)
				{
					this.RollbackImplicitTransaction();

					throw new FbException(ex.Message, ex);
				}
				catch (Exception)
				{
					this.RollbackImplicitTransaction();

					throw;
				}
			}
		}

		#endregion

		#region Internal Methods

		internal void InternalPrepare()
		{
			if (this.transaction == null)
			{
				this.implicitTransaction = true;

				this.transaction = new FbTransaction(this.connection);
				this.transaction.BeginTransaction();
			}

			if (this.commands == null)
			{
				this.splitBatchCommands(false);
			}

			if (this.statement == null)
			{
				if (this.commandType == CommandType.StoredProcedure)
				{
					this.commands[actualCommand] = this.buildSPCommandText();
				}

				this.statement = this.connection.Factory.CreateStatement(
					this.commands[actualCommand],
					this.connection.DbConnection.DB,
					this.transaction.Transaction);
			}
			else
			{
				if (this.implicitTransaction)
				{
					this.statement.Transaction = this.transaction.Transaction;
				}
			}

			if (!this.statement.IsPrepared)
			{
				this.parseNamedParameters();

				this.statement.Allocate();
				this.statement.Prepare();
				
				if (this.parameters.Count > 0)
				{
					// this.statement.DescribeParameters();

					RowDescriptor descriptor = this.buildParametersDescriptor();
					if (descriptor == null)
					{
						this.statement.DescribeParameters();
					}
					else
					{
						this.statement.Parameters = descriptor;
					}
				}
			}
			else
			{
				// Close statement for subsequently executions
				this.statement.Close();
			}
		}

		internal void InternalExecute()
		{
			if (this.parameters.Count > 0)
			{
				this.updateParameterValues();
			}

			this.statement.Execute();
		}

		internal bool NextResult()
		{
			bool returnValue = false;

			this.statement.Drop();
			this.statement = null;

			if ((this.commandBehavior & CommandBehavior.SingleResult) == CommandBehavior.SingleResult ||
				this.commandBehavior == System.Data.CommandBehavior.Default)
			{
				this.actualCommand++;

				if (this.actualCommand >= commands.Length)
				{
					this.actualCommand--;
				}
				else
				{
					string commandText = this.commands[actualCommand];
					if (commandText != null && commandText.Trim().Length > 0)
					{
						this.InternalPrepare();
						this.InternalExecute();

						returnValue = true;
					}
				}
			}		

			return returnValue;
		}
			
		internal void InternalSetOutputParameters()
		{
			if (this.CommandType == CommandType.StoredProcedure &&
				this.parameters.Count > 0						&&
				this.statement != null)
			{
				IEnumerator paramEnumerator = this.parameters.GetEnumerator();
				int i = 0;

				if (this.statement != null		&&
					this.statement.Rows != null &&
					this.statement.Rows.Length > 0)
				{
					DbValue[] values = (DbValue[])this.statement.Rows[0];

					if (values.Length > 0)
					{
						while (paramEnumerator.MoveNext())
						{
							FbParameter parameter = (FbParameter)paramEnumerator.Current;

							if (parameter.Direction == ParameterDirection.Output ||
								parameter.Direction == ParameterDirection.InputOutput ||
								parameter.Direction == ParameterDirection.ReturnValue)
							{
								parameter.Value = values[i].Value;
								i++;
							}
						}
					}
				}
			}
		}

		internal void CommitImplicitTransaction()
		{
			if (this.implicitTransaction &&
				this.transaction != null)
			{
				try
				{
					this.transaction.Commit();
				}
				catch (Exception ex)
				{
					this.RollbackImplicitTransaction();

					throw ex;
				}
				finally
				{
					this.implicitTransaction	= false;
					this.transaction			= null;
					if (this.statement != null)
					{
						this.statement.Transaction	= null;
					}
				}
			}
		}

		internal void RollbackImplicitTransaction()
		{
			if (this.implicitTransaction &&
				this.transaction != null)
			{
				try
				{
					this.transaction.Rollback();
				}
				catch (Exception)
				{
				}
				finally
				{
					this.implicitTransaction	= false;
					this.transaction			= null;
					if (this.statement != null)
					{
						this.statement.Transaction	= null;
					}
				}
			}
		}

		#endregion

		#region Input parameter descriptor generation methods

		private RowDescriptor buildParametersDescriptor()
		{
			short count	= this.validateInputParameters();

			if (count > 0)
			{
				if (this.namedParameters.Count > 0)
				{
					count = (short)this.namedParameters.Count;
					return this.buildNamedParametersDescriptor(count);
				}
				else
				{
					return this.buildPlaceHoldersDescriptor(count);
				}
			}

			return null;
		}

		private RowDescriptor buildNamedParametersDescriptor(short count)
		{
			RowDescriptor	descriptor	= new RowDescriptor(count);
			Charset			charset		= this.connection.Parameters.Charset;
			int				index		= 0;

			for (int i = 0; i < this.namedParameters.Count; i++)
			{
				string parameterName = null;
				
				index = -1;				

				if (this.namedParameters.Count != 0)
				{
					try
					{
						parameterName = this.namedParameters[i].Trim();
					}
					catch
					{
						if (i < this.parameters.Count )
						{
							parameterName = this.parameters[i].ParameterName;
						}
					}

					index = this.parameters.IndexOf(parameterName);
				}
				else
				{
					index = i;
				}

				if (!this.buildParameterDescriptor(descriptor, charset, i, index))
				{
					return null;
				}
			}

			return descriptor;
		}

		private RowDescriptor buildPlaceHoldersDescriptor(short count)
		{
			RowDescriptor	descriptor	= new RowDescriptor(count);
			Charset			charset		= this.connection.Parameters.Charset;
			int				index		= 0;

			for (int i = 0; i < this.parameters.Count; i++)
			{
				if (this.parameters[i].Direction == ParameterDirection.Input ||
					this.parameters[i].Direction == ParameterDirection.InputOutput)
				{
					if (this.buildParameterDescriptor(descriptor, charset, index, i))
					{
						index++;
					}
					else
					{
						return null;
					}					
				}
			}

			return descriptor;
		}

		private bool buildParameterDescriptor(
			RowDescriptor	descriptor,
			Charset			charset,
			int				dindex,
			int				pindex)
		{
			FbDbType type = this.parameters[pindex].FbDbType;

			// Set parameter Data Type
			descriptor.Fields[dindex].DataType = (short)TypeHelper.GetFbType(
				(DbDataType)type, 
				this.parameters[pindex].IsNullable);

			// Set parameter Sub Type
			switch (type)
			{
				case FbDbType.Binary:
					descriptor.Fields[dindex].SubType = 0;
					break;

				case FbDbType.Text:
					descriptor.Fields[dindex].SubType = 1;
					break;

				case FbDbType.Char:
				case FbDbType.VarChar:
					descriptor.Fields[dindex].SubType = (short)charset.ID;
					descriptor.Fields[dindex].Length = (short)charset.Encoding.GetMaxByteCount(
						this.parameters[pindex].Size);
					break;
			}

			// Set parameter length
			if (descriptor.Fields[dindex].Length == 0)
			{
				descriptor.Fields[dindex].Length = TypeHelper.GetSize(
					(DbDataType)type);
			}

			// Verify parameter
			if (descriptor.Fields[dindex].SqlType == 0 ||
				descriptor.Fields[dindex].Length == 0)
			{
				return false;
			}

			return true;
		}

		private short validateInputParameters()
		{
			short count = 0;

			for (int i = 0; i < this.parameters.Count; i++)
			{
				if (this.parameters[i].Direction == ParameterDirection.Input ||
					this.parameters[i].Direction == ParameterDirection.InputOutput)
				{
					FbDbType type = this.parameters[i].FbDbType;
					
					if (type == FbDbType.Array		||
						type == FbDbType.Decimal	||
						type == FbDbType.Numeric)
					{
						return -1;
					}
					else
					{
						count++;
					}
				}
			}

			return count;
		}

		#endregion

		#region Private Methods

		private void splitBatchCommands(bool batchAllowed)
		{
			if (this.commands == null)
			{
				if (batchAllowed)
				{
					MatchCollection matches = Regex.Matches(
						this.commandText,
						"([^';]+('.*'))*[^';]*(?=;*)");

					this.commands	= new string[matches.Count/2];
					int count		= 0;
					for (int i = 0; i < matches.Count; i++)
					{
						if (matches[i].Value != null &&
							matches[i].Value.Trim() != String.Empty)
						{
							this.commands[count] = matches[i].Value.Trim();
							count++;
						}
					}
				}
				else
				{
					this.commands = new string[]{this.commandText};
				}
			}
		}

		private void executeCommand(CommandBehavior behavior, bool split)
		{
			if ((behavior & CommandBehavior.SingleResult) == CommandBehavior.SingleResult)
			{
				split = false;
			}

			this.splitBatchCommands(split);
			this.InternalPrepare();

			if ((behavior & CommandBehavior.SequentialAccess) == CommandBehavior.SequentialAccess ||
				(behavior & CommandBehavior.SingleResult) == CommandBehavior.SingleResult ||
				(behavior & CommandBehavior.SingleRow) == CommandBehavior.SingleRow ||
				(behavior & CommandBehavior.CloseConnection) == CommandBehavior.CloseConnection ||
				behavior == CommandBehavior.Default)				
			{
				this.InternalExecute();
			}
		}

		private string buildSPCommandText()
		{
			string commandText = this.commands[actualCommand];

			if (commandText != null &&
				!commandText.Trim().ToLower().StartsWith("execute procedure ") &&
				!commandText.Trim().ToLower().StartsWith("select "))
			{
				StringBuilder paramsText = new StringBuilder();

				// Append the stored proc parameter name
				paramsText.Append(commandText);
				if (parameters.Count > 0)
				{
					paramsText.Append("(");
					for (int i = 0; i < this.parameters.Count; i++)
					{
						if (this.parameters[i].Direction == ParameterDirection.Input ||
							this.parameters[i].Direction == ParameterDirection.InputOutput)
						{
							// Append parameter name to parameter list
							paramsText.Append(this.parameters[i].ParameterName);
							if (i != parameters.Count - 1)
							{
								paramsText = paramsText.Append(",");
							}
						}
					}
					paramsText.Append(")");
					paramsText.Replace(",)", ")");
					paramsText.Replace("()", "");
				}
				
				if (returnsSet)
				{
					commandText = "select * from "  + paramsText.ToString();
				}
				else
				{
					commandText = "execute procedure " + paramsText.ToString();
				}
			}

			return commandText;
		}

		private void parseNamedParameters()
		{
			string sql = this.commands[actualCommand];

			this.namedParameters.Clear();
			
			if (sql.IndexOf("@") != -1)
			{
				MatchEvaluator me = new MatchEvaluator(matchEvaluator);

				sql = namedRegex.Replace(sql, me);
			}

			this.statement.CommandText = sql;
		}

		private string matchEvaluator(Match match)
		{
			string input = match.Value;

			if (match.Groups["param"].Success)
			{				
				Group g = match.Groups["param"];

				this.namedParameters.Add(g.Value);
								
				return Regex.Replace(input, g.Value, "?");
			}
			else
			{
				return match.Value;
			}
		}

		private void updateParameterValues()
		{
			RowDescriptor	gdsParams		= this.statement.Parameters;			
			string			parameterName	= String.Empty;
			int				index			= -1;
			
			if (gdsParams != null)
			{
				for (int i = 0; i < gdsParams.Count; i++)
				{
					index			= -1;
					parameterName	= null;

					if (this.namedParameters.Count != 0)
					{
						try
						{
							parameterName = this.namedParameters[i].Trim();
						}
						catch
						{
							if (i < this.parameters.Count)
							{
								parameterName = this.parameters[i].ParameterName;
							}
						}

						index = this.parameters.IndexOf(parameterName);
					}
					else
					{
						index = i;
					}

					if (index != -1)
					{
						if (this.parameters[index].Value == System.DBNull.Value)
						{
							if ((gdsParams.Fields[i].DataType & 1) == 0)
							{
								throw new InvalidOperationException("Input parameter value cannot be null.");
							}
							else
							{
								gdsParams.Fields[i].NullFlag	= -1;
								gdsParams.Fields[i].Value		= null;
							}
						}
						else
						{
							// Parameter value is not null
							gdsParams.Fields[i].NullFlag = 0;

							switch (gdsParams.Fields[i].SqlType)
							{
								case IscCodes.SQL_TEXT:
								case IscCodes.SQL_VARYING:
								case IscCodes.SQL_SHORT:
								case IscCodes.SQL_LONG:
								case IscCodes.SQL_QUAD:
								case IscCodes.SQL_INT64:
								case IscCodes.SQL_FLOAT:
								case IscCodes.SQL_DOUBLE:
								case IscCodes.SQL_D_FLOAT:
								case IscCodes.SQL_TYPE_DATE:
								case IscCodes.SQL_TYPE_TIME:
								case IscCodes.SQL_TIMESTAMP:
									gdsParams.Fields[i].Value = this.parameters[index].Value;
									break;

								case IscCodes.SQL_BLOB:
								{
									BlobBase blob = this.connection.Factory.CreateBlob(
										this.statement.DB,
										this.statement.Transaction);
									if (gdsParams.Fields[i].SubType == 1)
									{
										blob.Write(Convert.ToString(this.parameters[index].Value));
									}
									else
									{
										blob.Write((byte[])this.parameters[index].Value);
									}
									gdsParams.Fields[i].Value = blob.Id;
								}
									break;

								case IscCodes.SQL_ARRAY:
								{
									if (gdsParams.Fields[i].ArrayHandle == null)
									{
										gdsParams.Fields[i].ArrayHandle = 
											this.connection.Factory.CreateArray(
											this.statement.DB,
											this.statement.Transaction,
											gdsParams.Fields[i].Relation,
											gdsParams.Fields[i].Name);
									}
									else
									{
										gdsParams.Fields[i].ArrayHandle.DB			= this.statement.DB;
										gdsParams.Fields[i].ArrayHandle.Transaction = this.statement.Transaction;
									}
						
									gdsParams.Fields[i].ArrayHandle.Handle = 0;
									gdsParams.Fields[i].ArrayHandle.Write((System.Array)this.parameters[index].Value);
									gdsParams.Fields[i].Value = gdsParams.Fields[i].ArrayHandle.Handle;
								}
									break;

								default:
									throw new NotSupportedException("Unknown data type");
							}							
						}
					}
				}

				this.statement.Parameters = gdsParams;
			}
		}

		private void checkCommand()
		{
			if (this.transaction != null &&
				this.transaction.IsUpdated)
			{
				this.transaction = null;
			}

			if (this.connection == null || this.connection.State != ConnectionState.Open)
			{
				throw new InvalidOperationException("Connection must valid and open");
			}

			if (this.connection.DataReader != null)
			{
				throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");
			}

			if (this.connection.ActiveTransaction != null &&
				this.transaction == null)
			{
				throw new InvalidOperationException("Execute requires the Command object to have a Transaction object when the Connection object assigned to the command is in a pending local transaction.  The Transaction property of the Command has not been initialized.");
			}

			if (this.transaction != null	&&
				!this.transaction.IsUpdated &&
				!this.connection.Equals(transaction.Connection))
			{
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection.");
			}

			if (this.commandText == String.Empty || this.commandText == null)
			{
				throw new InvalidOperationException ("The command text for this Command has not been set.");
			}
		}

		#endregion
	}
}