//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2003-2004 Abel Eduardo Pereira.
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Isql
{
	#region Delegates

	/// <summary>
	/// The event handler type trigged after a SQL statement execution.
	/// </summary>
	public delegate void CommandExecutedEventHandler(object sender, CommandExecutedEventArgs e);

	#endregion

	/// <summary>
	/// Summary description for CommandExecutedEventArgs.
	/// </summary>
	public class CommandExecutedEventArgs
	{
		#region Fields

		private string				commandText;
		private FbDataReader		dataReader;
		private int					rowsAffected;

		#endregion

		#region Properties

		/// <summary>
		/// Returns the <see cref="SqlStatementType"/> of the current <see cref="CommandText"/>.
		/// </summary>
		public SqlStatementType StatementType 
		{
			get { return FbBatchExecution.GetStatementType(this.commandText); }
		}

		/// <summary>
		/// Returns the SQL statement that was executed.
		/// </summary>
		public string CommandText 
		{
			get { return this.commandText; }
		}

		/// <summary>
		/// Returns a <see cref="FbDataReader"/> instance case the executed SQL command returns data. If
		/// the executed SQL command does not returns data, (for instance: the case of an UPDATE statement), 
		/// the <b>DataReader</b> is setled to <b>null</b>.
		/// </summary>
		public FbDataReader DataReader
		{
			get { return this.dataReader; }
		}

		#endregion

		#region Constructors

		/// <summary>
		/// Creates an instance of CommandExecutedEventArgs class.
		/// </summary>
		/// <param name="dataReader"></param>
		/// <param name="commandText">The CommandText of the <see cref="FbCommand"/> that was executed.</param>
		/// <param name="rowsAffected"></param>
		public CommandExecutedEventArgs(
			FbDataReader		dataReader,
			string				commandText,
			int					rowsAffected)
		{
			this.dataReader		= dataReader;
			this.commandText	= commandText;
			this.rowsAffected	= rowsAffected;
		}

		#endregion

		#region Methods

		/// <summary>
		/// Overrided. Returns the SQL statement that was executed.
		/// </summary>
		/// <returns>The SQL statement that will be executed.</returns>
		public override string ToString() 
		{
			return this.commandText;
		}

		#endregion
	}
}
