//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2003-2004 Abel Eduardo Pereira.
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Collections.Specialized;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Isql
{
	#region Enumerations

	/// <summary>
	/// DSQL and ISQL statement types.
	/// </summary>
	public enum SqlStatementType 
	{
		/// <summary>
		/// Represents the SQL statement: <b>ALTER DATABASE</b>
		/// </summary>
		AlterDatabase = 0,

		/// <summary>
		/// Represents the SQL statement: <b>ALTER DOMAIN</b>
		/// </summary>
		AlterDomain,

		/// <summary>
		/// Represents the SQL statement: <b>ALTER EXCEPTION</b>
		/// </summary>
		AlterException,

		/// <summary>
		/// Represents the SQL statement: <b>ALTER INDEX</b>
		/// </summary>
		AlterIndex,

		/// <summary>
		/// Represents the SQL statement: <b>ALTER PROCEDURE</b>
		/// </summary>
		AlterProcedure,

		/// <summary>
		/// Represents the SQL statement: <b>ALTER TABLE</b>
		/// </summary>
		AlterTable,

		/// <summary>
		/// Represents the SQL statement: <b>ALTER TRIGGER</b>
		/// </summary>
		AlterTrigger,

		/// <summary>
		/// Represents the SQL statement: <b>CLOSE</b>
		/// </summary>
		Close,

		/// <summary>
		/// Represents the SQL statement: <b>COMMIT</b>
		/// </summary>
		Commit,

		/// <summary>
		/// Represents the SQL statement: <b>CONNECT</b>
		/// </summary>
		Connect,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE DATABASE</b>
		/// </summary>
		CreateDatabase,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE DOMAIN</b>
		/// </summary>
		CreateDomain,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE EXCEPTION</b>
		/// </summary>
		CreateException,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE GENERATOR</b>
		/// </summary>
		CreateGenerator,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE INDEX</b>
		/// </summary>
		CreateIndex,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE PROCEDURE</b>
		/// </summary>
		CreateProcedure,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE ROLE</b>
		/// </summary>
		CreateRole,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE SHADOW</b>
		/// </summary>
		CreateShadow,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE TABLE</b>
		/// </summary>
		CreateTable,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE TRIGGER</b>
		/// </summary>
		CreateTrigger,

		/// <summary>
		/// Represents the SQL statement: <b>CREATE VIEW</b>
		/// </summary>
		CreateView,

		/// <summary>
		/// Represents the SQL statement: <b>DECLARE CURSOR</b>
		/// </summary>
		DeclareCursor,

		/// <summary>
		/// Represents the SQL statement: <b>DECLARE EXTERNAL FUNCTION</b>
		/// </summary>
		DeclareExternalFunction,

		/// <summary>
		/// Represents the SQL statement: <b>DECLARE FILTER</b>
		/// </summary>
		DeclareFilter,

		/// <summary>
		/// Represents the SQL statement: <b>DECLARE STATEMENT</b>
		/// </summary>
		DeclareStatement,

		/// <summary>
		/// Represents the SQL statement: <b>DECLARE TABLE</b>
		/// </summary>
		DeclareTable,

		/// <summary>
		/// Represents the SQL statement: <b>DELETE</b>
		/// </summary>
		Delete,

		/// <summary>
		/// Represents the SQL statement: <b>DESCRIBE</b>
		/// </summary>
		Describe,

		/// <summary>
		/// Represents the SQL statement: <b>DISCONNECT</b>
		/// </summary>
		Disconnect,

		/// <summary>
		/// Represents the SQL statement: <b>DROP DATABASE</b>
		/// </summary>
		DropDatabase,

		/// <summary>
		/// Represents the SQL statement: <b>DROP DOMAIN</b>
		/// </summary>
		DropDomain,

		/// <summary>
		/// Represents the SQL statement: <b>DROP EXCEPTION</b>
		/// </summary>
		DropException,

		/// <summary>
		/// Represents the SQL statement: <b>DROP EXTERNAL FUNCTION</b>
		/// </summary>
		DropExternalFunction,

		/// <summary>
		/// Represents the SQL statement: <b>DROP FILTER</b>
		/// </summary>
		DropFilter,

		/// <summary>
		/// Represents the SQL statement: <b>DROP INDEX</b>
		/// </summary>
		DropIndex,

		/// <summary>
		/// Represents the SQL statement: <b>DROP PROCEDURE</b>
		/// </summary>
		DropProcedure,

		/// <summary>
		/// Represents the SQL statement: <b>DROP ROLE</b>
		/// </summary>
		DropRole,

		/// <summary>
		/// Represents the SQL statement: <b>DROP SHADOW</b>
		/// </summary>
		DropShadow,

		/// <summary>
		/// Represents the SQL statement: <b>DROP TABLE</b>
		/// </summary>
		DropTable,

		/// <summary>
		/// Represents the SQL statement: <b>DROP TRIGGER</b>
		/// </summary>
		DropTrigger,

		/// <summary>
		/// Represents the SQL statement: <b>DROP VIEW</b>
		/// </summary>
		DropView,

		/// <summary>
		/// Represents the SQL statement: <b>END DECLARE SECTION</b>
		/// </summary>
		EndDeclareSection,

		/// <summary>
		/// Represents the SQL statement: <b>EVENT INIT</b>
		/// </summary>
		EventInit,

		/// <summary>
		/// Represents the SQL statement: <b>EVENT WAIT</b>
		/// </summary>
		EventWait,

		/// <summary>
		/// Represents the SQL statement: <b>EXECUTE</b>
		/// </summary>
		Execute,

		/// <summary>
		/// Represents the SQL statement: <b>EXECUTE IMMEDIATE</b>
		/// </summary>
		ExecuteImmediate,

		/// <summary>
		/// Represents the SQL statement: <b>EXECUTE PROCEDURE</b>
		/// </summary>
		ExecuteProcedure,

		/// <summary>
		/// Represents the SQL statement: <b>FETCH</b>
		/// </summary>
		Fetch,

		/// <summary>
		/// Represents the SQL statement: <b>GRANT</b>
		/// </summary>
		Grant,

		/// <summary>
		/// Represents the SQL statement: <b>INSERT</b>
		/// </summary>
		Insert,

		/// <summary>
		/// Represents the SQL statement: <b>INSERT CURSOR</b>
		/// </summary>
		InsertCursor,

		/// <summary>
		/// Represents the SQL statement: <b>OPEN</b>
		/// </summary>
		Open,

		/// <summary>
		/// Represents the SQL statement: <b>PREPARE</b>
		/// </summary>
		Prepare,

		/// <summary>
		/// Represents the SQL statement: <b>REVOKE</b>
		/// </summary>
		Revoke,

		/// <summary>
		/// Represents the SQL statement: <b>ROLLBACK</b>
		/// </summary>
		Rollback,

		/// <summary>
		/// Represents the SQL statement: <b>SELECT</b>
		/// </summary>
		Select,

		/// <summary>
		/// Represents the SQL statement: <b>SET DATABASE</b>
		/// </summary>
		SetDatabase,

		/// <summary>
		/// Represents the SQL statement: <b>SET GENERATOR</b>
		/// </summary>
		SetGenerator,

		/// <summary>
		/// Represents the SQL statement: <b>SET NAMES</b>
		/// </summary>
		SetNames,

		/// <summary>
		/// Represents the SQL statement: <b>SET SQL DIALECT</b>
		/// </summary>
		SetSQLDialect,

		/// <summary>
		/// Represents the SQL statement: <b>SET STATISTICS</b>
		/// </summary>
		SetStatistics,

		/// <summary>
		/// Represents the SQL statement: <b>SET TRANSACTION</b>
		/// </summary>
		SetTransaction,

		/// <summary>
		/// Represents the SQL statement: <b>SHOW SQL DIALECT</b>
		/// </summary>
		ShowSQLDialect,

		/// <summary>
		/// Represents the SQL statement: <b>UPDATE</b>
		/// </summary>
		Update,

		/// <summary>
		/// Represents the SQL statement: <b>WHENEVER</b>
		/// </summary>
		Whenever
	}

	#endregion
 	
	/// <summary>
	/// Summary description for BatchExecution.
	/// </summary>
	public class FbBatchExecution
	{
		#region Events

		/// <summary>
		/// The event trigged before a SQL statement goes for execution.
		/// </summary>
		public event CommandExecutingEventHandler CommandExecuting;

		/// <summary>
		/// The event trigged after a SQL statement execution.
		/// </summary>
		public event CommandExecutedEventHandler CommandExecuted;

		#endregion

		#region Fields

		private StringCollection	sqlStatements = null;
		private FbConnection		sqlConnection = null;
		private FbTransaction		sqlTransaction = null;
		private FbConnectionString  connectionString = null;

		#endregion

		#region Properties

		/// <summary>
		/// Represents the list of SQL statements for batch execution.
		/// </summary>
		public StringCollection SqlStatements 
		{
			get { return this.sqlStatements; }
			set { this.sqlStatements = value; }
		}

		#endregion

		#region Constructors

		/// <summary>
		/// Creates an instance of FbBatchExecution engine.
		/// </summary>
		public FbBatchExecution()
		{
			sqlConnection = new FbConnection(); // do not specify the connection string
			connectionString = new FbConnectionString();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sqlConnection"></param>
		public FbBatchExecution(FbConnection sqlConnection)
		{
			if (sqlConnection == null)
			{
				this.sqlConnection = new FbConnection(); // do not specify the connection string
				this.connectionString = new FbConnectionString();
			}
			else
			{
				this.sqlConnection = sqlConnection;
				this.sqlTransaction = this.sqlConnection.BeginTransaction(); 
			}
		}

		#endregion

		#region Methods

		/// <summary>
		/// Starts the ordered execution of the SQL statements that are in <see cref="SqlStatements"/> collection.
		/// </summary>
		public virtual void Execute() 
		{
			if (this.SqlStatements.Count != 0) 
			{
				for (int i = 0; i < this.SqlStatements.Count; i++)
				{
					using (FbCommand atomicCommand = this.sqlConnection.CreateCommand()) 
					{
						int rowsAffected = -1;
						FbDataReader dataReader = null;
						atomicCommand.CommandText = this.SqlStatements[i];

						// raise the event
						OnCommandExecuting(atomicCommand);
						try 
						{
							// execute statement
							switch (FbBatchExecution.GetStatementType(atomicCommand.CommandText))
							{
								case SqlStatementType.AlterDatabase:
								case SqlStatementType.AlterDomain:
								case SqlStatementType.AlterException:
								case SqlStatementType.AlterIndex:
								case SqlStatementType.AlterProcedure:
								case SqlStatementType.AlterTable:
								case SqlStatementType.AlterTrigger:
								case SqlStatementType.Close:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.Commit:
									PerformCommit(atomicCommand.CommandText, this.sqlTransaction);
									break;
								case SqlStatementType.Connect:
									this.sqlConnection = performConnect(atomicCommand.CommandText);
									break;
								case SqlStatementType.CreateDatabase:
									this.sqlConnection = createDatabase(atomicCommand.CommandText);
									break;
								case SqlStatementType.CreateDomain:
								case SqlStatementType.CreateException:
								case SqlStatementType.CreateGenerator:
								case SqlStatementType.CreateIndex:
								case SqlStatementType.CreateProcedure:
								case SqlStatementType.CreateRole:
								case SqlStatementType.CreateShadow:
								case SqlStatementType.CreateTable:
								case SqlStatementType.CreateTrigger:
								case SqlStatementType.CreateView:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.DeclareCursor:
								case SqlStatementType.DeclareExternalFunction:
								case SqlStatementType.DeclareFilter:
								case SqlStatementType.DeclareStatement:
								case SqlStatementType.DeclareTable:
								case SqlStatementType.Delete:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.Describe:
									dataReader = atomicCommand.ExecuteReader();
									break;
								case SqlStatementType.Disconnect:
									disconnect(atomicCommand.CommandText);
									break;
								case SqlStatementType.DropDatabase:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									sqlTransaction.Commit();
									sqlConnection.Close();
									break;
								case SqlStatementType.DropDomain:
								case SqlStatementType.DropException:
								case SqlStatementType.DropExternalFunction:
								case SqlStatementType.DropFilter:
								case SqlStatementType.DropIndex:
								case SqlStatementType.DropProcedure:
								case SqlStatementType.DropRole:
								case SqlStatementType.DropShadow:
								case SqlStatementType.DropTable:
								case SqlStatementType.DropTrigger:
								case SqlStatementType.DropView:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.EventInit:
								case SqlStatementType.EventWait:
								case SqlStatementType.Execute:
								case SqlStatementType.ExecuteImmediate:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.ExecuteProcedure:
								case SqlStatementType.Fetch:
									dataReader = atomicCommand.ExecuteReader();
									break;
								case SqlStatementType.Grant:
								case SqlStatementType.Insert:
								case SqlStatementType.InsertCursor:
								case SqlStatementType.Open:
								case SqlStatementType.Prepare:
								case SqlStatementType.Revoke:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.Rollback:
									rollbackTransaction(sqlTransaction);
									break;
								case SqlStatementType.Select:
									dataReader = atomicCommand.ExecuteReader();
									break;
								case SqlStatementType.SetDatabase:
									sqlConnection = setDatabase(atomicCommand.CommandText);
									break;
								case SqlStatementType.SetGenerator:	  
								case SqlStatementType.SetNames:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.SetSQLDialect:
									sqlConnection = setSqlDialect(atomicCommand.CommandText);
									break;
								case SqlStatementType.SetStatistics:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
								case SqlStatementType.SetTransaction:
									sqlTransaction = setTransaction(atomicCommand.CommandText);
									break;
								case SqlStatementType.ShowSQLDialect:
									dataReader = atomicCommand.ExecuteReader();
									break;
								case SqlStatementType.Update:
								case SqlStatementType.Whenever:
									rowsAffected = atomicCommand.ExecuteNonQuery();
									break;
							}
						}
						catch (Exception e) 
						{
							#warning "the next 3 lines may be incorrect"
							sqlConnection.Close();
							sqlTransaction = null;
							sqlConnection = null;
							// wrap the exception in order to add the command index and rethrow
							throw new Exception("An exception was thrown when executing command index: " + i.ToString() + 
								" (zero-based).\nCommand is:\n" + atomicCommand.CommandText + "\nThe returned message was:\n" + 
								e.Message + "\nBatch execution aborted.");
						}
						// raise the event
						OnCommandExecuted(atomicCommand.CommandText, dataReader, rowsAffected);
					}
				}
				// commit root transaction
				sqlTransaction.Commit();
				sqlConnection.Close();
				sqlTransaction = null;
				sqlConnection = null;
			}
		}

		#endregion

		#region Protected Internal Methods

		/// <summary>
		/// Parses and commits the respective SQL based statement: 
		/// <c>COMMIT [WORK] [TRANSACTION name] [RELEASE] [RETAIN [SNAPSHOT]]</c>
		/// </summary>
		/// <param name="commitStatement">The commit statement text.</param>
		/// <param name="targetTransaction">The active SQL transaction.</param>
		/// <remarks>
		/// Ignores the transaction name. Implements only COMMIT and COMMIT RETAIN.
		/// </remarks>
		protected internal void PerformCommit(string commitStatement, FbTransaction targetTransaction)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Parses and executes the interactive SQL or standard SQL statement CONNECT.
		/// </summary>
		/// <param name="connectStatement">The connect statement.</param>
		/// <returns>An instance of <see cref="FbConnection"/>.</returns>
		protected internal FbConnection performConnect(string connectStatement)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Parses and executes the SQL, DSQL and isql statement CREATE DATABASE.
		/// </summary>
		/// <param name="createDbStatement">the create database statement.</param>
		/// <returns>An instance of <see cref="FbConnection"/>.</returns>
		protected internal FbConnection createDatabase(string createDbStatement)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="disconnectStatement"></param>
		protected internal void disconnect(string disconnectStatement)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sqlTransaction"></param>
		protected internal void rollbackTransaction(FbTransaction sqlTransaction)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		protected internal FbConnection setDatabase(string setDbStatement)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Changes the <see cref="FbConnection.ConnectionString"/> of the current (not open) Firebird connection.
		/// </summary>
		/// <param name="sqlDialectStatement">The SET SQL Dialect statement.</param>
		/// <returns>The <see cref="FbConnection"/> instance with the updated <see cref="FbConnection.ConnectionString"/>.</returns>
		/// <remarks>This method expects the FB Connection in Closed state.</remarks>
		protected internal FbConnection setSqlDialect(string sqlDialectStatement)
		{
			if (sqlConnection.State != ConnectionState.Closed)
			{
				throw new Exception("Attempting to set an SQL dialect for the database while the connection is not closed.");
			}
			if (connectionString == null)
			{
				throw new Exception("Cannot execute the statement SET SQL DIALECT because you already provied an instance of FbConnection");
			}
			try
			{
				connectionString.Load(sqlConnection.ConnectionString);
			}
			catch (Exception)
			{
				sqlConnection.ConnectionString = "";
			}

			StringParser parser	= new StringParser(sqlDialectStatement, false);
			parser.Token = " ";
			parser.ParseNext();										    
			if (parser.Result.ToUpper().CompareTo("SET") != 0)
				throw new Exception("Expected the keyword SET but something else was found.");
			parser.ParseNext();
			if (parser.Result.ToUpper().CompareTo("SQL") != 0)
				throw new Exception("Expected the keyword SQL but something else was found.");
			parser.ParseNext();
			if (parser.Result.ToUpper().CompareTo("DIALECT") != 0)
				throw new Exception("Expected the keyword DIALECT but something else was found.");
			parser.ParseNext();
			int i = int.Parse(parser.Result);
			if ((i < 0) || (i > 3))
				throw new Exception("Invalid sql dialect. Available dialects are: 1, 2 and 3");
			
			connectionString.Dialect = i;
			sqlConnection.ConnectionString = connectionString.ToString();
			return sqlConnection;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="setTransactionStatement"></param>
		/// <returns></returns>
		protected internal FbTransaction setTransaction(string setTransactionStatement)
		{
			throw new NotImplementedException();
		}

		#endregion

		#region Event Handlers

		/// <summary>
		/// The trigger function for <see cref="CommandExecuting"/>	event.
		/// </summary>
		/// <param name="sqlCommand">The SQL command that is going for execution.</param>
		protected virtual void OnCommandExecuting(FbCommand sqlCommand)
		{
			if (CommandExecuting != null)
			{
				CommandExecutingEventArgs e = new CommandExecutingEventArgs(sqlCommand);
				CommandExecuting(this, e);
			}
		}

		/// <summary>
		/// The trigger function for <see cref="CommandExecuted"/> event.
		/// </summary>
		/// <param name="commandText">The <see cref="FbCommand.CommandText"/> of the executed SQL command.</param>
		/// <param name="dataReader">The <see cref="FbDataReader"/> instance with the returned data. If the 
		/// command executed is not meant to return data (ex: UPDATE, INSERT...) this parameter must be 
		/// setled to <b>null</b>.</param>
		/// <param name="rowsAffected">The rows that were affected by the executed SQL command. If the executed 
		/// command is not meant to return this kind of information (ex: SELECT) this parameter must 
		/// be setled to <b>-1</b>.</param>
		protected virtual void OnCommandExecuted(string commandText, FbDataReader dataReader, int rowsAffected) 
		{
			if (CommandExecuted != null) 
			{
				CommandExecutedEventArgs e = new CommandExecutedEventArgs(dataReader, commandText, rowsAffected);
				CommandExecuted(this, e);
			}
		}

		#endregion

		#region Static Methods

		/// <summary>
		/// Determines the <see cref="SqlStatementType"/> of the provided SQL statement.
		/// </summary>
		/// <param name="sqlStatement">The string containing the SQL statement.</param>
		/// <returns>The <see cref="SqlStatementType"/> of the <b>sqlStatement</b>.</returns>
		/// <remarks>If the type of <b>sqlStatement</b> could not be determinated this 
		/// method will throw an exception.</remarks>
		public static SqlStatementType GetStatementType(string sqlStatement) 
		{
			switch (char.ToUpper(sqlStatement[0])) 
			{
				case 'A':
					if (StringParser.StartsWith(sqlStatement, "ALTER DATABASE", true))
						return SqlStatementType.AlterDatabase;
					if (StringParser.StartsWith(sqlStatement, "ALTER DOMAIN", true))
						return SqlStatementType.AlterDomain;
					if (StringParser.StartsWith(sqlStatement, "ALTER EXCEPTION", true))
						return SqlStatementType.AlterException;
					if (StringParser.StartsWith(sqlStatement, "ALTER INDEX", true))
						return SqlStatementType.AlterIndex;
					if (StringParser.StartsWith(sqlStatement, "ALTER PROCEDURE", true))
						return SqlStatementType.AlterProcedure;
					if (StringParser.StartsWith(sqlStatement, "ALTER TABLE", true))
						return SqlStatementType.AlterTable;
					if (StringParser.StartsWith(sqlStatement, "ALTER TRIGGER", true))
						return SqlStatementType.AlterTrigger;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'C':
				switch (char.ToUpper(sqlStatement[1])) 
				{
					case 'L':
						if (StringParser.StartsWith(sqlStatement, "CLOSE", true))
							return SqlStatementType.Close;
						throw new Exception("The type of the SQL statement could not be determinated.");

					case 'O':
						if (StringParser.StartsWith(sqlStatement, "COMMIT", true))
							return SqlStatementType.Commit;
						if (StringParser.StartsWith(sqlStatement, "CONNECT", true))
							return SqlStatementType.Connect;
						throw new Exception("The type of the SQL statement could not be determinated.");

					case 'R':
						if (StringParser.StartsWith(sqlStatement, "CREATE DATABASE", true))
							return SqlStatementType.CreateDatabase;
						if (StringParser.StartsWith(sqlStatement, "CREATE DOMAIN", true))
							return SqlStatementType.CreateDomain;
						if (StringParser.StartsWith(sqlStatement, "CREATE EXCEPTION", true))
							return SqlStatementType.CreateException;
						if (StringParser.StartsWith(sqlStatement, "CREATE GENERATOR", true))
							return SqlStatementType.CreateGenerator;
						if (StringParser.StartsWith(sqlStatement, "CREATE INDEX", true))
							return SqlStatementType.CreateIndex;
						if (StringParser.StartsWith(sqlStatement, "CREATE PROCEDURE", true))
							return SqlStatementType.CreateProcedure;
						if (StringParser.StartsWith(sqlStatement, "CREATE ROLE", true))
							return SqlStatementType.CreateRole;
						if (StringParser.StartsWith(sqlStatement, "CREATE SHADOW", true))
							return SqlStatementType.CreateShadow;
						if (StringParser.StartsWith(sqlStatement, "CREATE TABLE", true))
							return SqlStatementType.CreateTable;
						if (StringParser.StartsWith(sqlStatement, "CREATE TRIGGER", true))
							return SqlStatementType.CreateTrigger;
						if (StringParser.StartsWith(sqlStatement, "CREATE VIEW", true))
							return SqlStatementType.CreateView;
						throw new Exception("The type of the SQL statement could not be determinated.");

					default:
						throw new Exception("The type of the SQL statement could not be determinated.");
				}
					
				case 'D':
				switch (char.ToUpper(sqlStatement[1])) 
				{
					case 'E':
						if (StringParser.StartsWith(sqlStatement, "DECLARE CURSOR", true))
							return SqlStatementType.DeclareCursor;
						if (StringParser.StartsWith(sqlStatement, "DECLARE EXTERNAL FUNCTION", true))
							return SqlStatementType.DeclareExternalFunction;
						if (StringParser.StartsWith(sqlStatement, "DECLARE FILTER", true))
							return SqlStatementType.DeclareFilter;
						if (StringParser.StartsWith(sqlStatement, "DECLARE STATEMENT", true))
							return SqlStatementType.DeclareStatement;
						if (StringParser.StartsWith(sqlStatement, "DECLARE TABLE", true))
							return SqlStatementType.DeclareTable;
						if (StringParser.StartsWith(sqlStatement, "DELETE", true))
							return SqlStatementType.Delete;
						if (StringParser.StartsWith(sqlStatement, "DESCRIBE", true))
							return SqlStatementType.Describe;
						throw new Exception("The type of the SQL statement could not be determinated.");

					case 'I':
						if (StringParser.StartsWith(sqlStatement, "DISCONNECT", true))
							return SqlStatementType.Disconnect;
						throw new Exception("The type of the SQL statement could not be determinated.");

					case 'R':
						if (StringParser.StartsWith(sqlStatement, "DROP DATABASE", true))
							return SqlStatementType.DropDatabase;
						if (StringParser.StartsWith(sqlStatement, "DROP DOMAIN", true))
							return SqlStatementType.DropDomain;
						if (StringParser.StartsWith(sqlStatement, "DROP EXCEPTION", true))
							return SqlStatementType.DropException;
						if (StringParser.StartsWith(sqlStatement, "DROP EXTERNAL FUNCTION", true))
							return SqlStatementType.DropExternalFunction;
						if (StringParser.StartsWith(sqlStatement, "DROP FILTER", true))
							return SqlStatementType.DropFilter;
						if (StringParser.StartsWith(sqlStatement, "DROP INDEX", true))
							return SqlStatementType.DropIndex;
						if (StringParser.StartsWith(sqlStatement, "DROP PROCEDURE", true))
							return SqlStatementType.DropProcedure;
						if (StringParser.StartsWith(sqlStatement, "DROP ROLE", true))
							return SqlStatementType.DropRole;
						if (StringParser.StartsWith(sqlStatement, "DROP SHADOW", true))
							return SqlStatementType.DropShadow;
						if (StringParser.StartsWith(sqlStatement, "DROP TABLE", true))
							return SqlStatementType.DropTable;
						if (StringParser.StartsWith(sqlStatement, "DROP TRIGGER", true))
							return SqlStatementType.DropTrigger;
						if (StringParser.StartsWith(sqlStatement, "DROP VIEW", true))
							return SqlStatementType.DropView;
						throw new Exception("The type of the SQL statement could not be determinated.");

					default:
						throw new Exception("The type of the SQL statement could not be determinated.");
				}
				
				case 'E':
					if (StringParser.StartsWith(sqlStatement, "EXECUTE PROCEDURE", true))
						return SqlStatementType.ExecuteProcedure;
					if (StringParser.StartsWith(sqlStatement, "EXECUTE IMMEDIATE", true))
						return SqlStatementType.ExecuteImmediate;
					if (StringParser.StartsWith(sqlStatement, "EXECUTE", true))
						return SqlStatementType.Execute;
					if (StringParser.StartsWith(sqlStatement, "EVENT WAIT", true))
						return SqlStatementType.EventWait;
					if (StringParser.StartsWith(sqlStatement, "EVENT INIT", true))
						return SqlStatementType.EventInit;
					if (StringParser.StartsWith(sqlStatement, "END DECLARE SECTION", true))
						return SqlStatementType.EndDeclareSection;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'F':
					if (StringParser.StartsWith(sqlStatement, "FETCH", true))
						return SqlStatementType.Fetch;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'G':
					if (StringParser.StartsWith(sqlStatement, "GRANT", true))
						return SqlStatementType.Grant;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'I':
					if (StringParser.StartsWith(sqlStatement, "INSERT CURSOR", true))
						return SqlStatementType.InsertCursor;
					if (StringParser.StartsWith(sqlStatement, "INSERT", true))
						return SqlStatementType.Insert;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'O':
					if (StringParser.StartsWith(sqlStatement, "OPEN", true))
						return SqlStatementType.Open;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'P':
					if (StringParser.StartsWith(sqlStatement, "PREPARE", true))
						return SqlStatementType.Prepare;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'R':
					if (StringParser.StartsWith(sqlStatement, "REVOKE", true))
						return SqlStatementType.Revoke;
					if (StringParser.StartsWith(sqlStatement, "ROLLBACK", true))
						return SqlStatementType.Rollback;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'S':								
					if (StringParser.StartsWith(sqlStatement, "SELECT", true))
						return SqlStatementType.Select;
					if (StringParser.StartsWith(sqlStatement, "SET DATABASE", true))
						return SqlStatementType.SetDatabase;
					if (StringParser.StartsWith(sqlStatement, "SET GENERATOR", true))
						return SqlStatementType.SetGenerator;
					if (StringParser.StartsWith(sqlStatement, "SET NAMES", true))
						return SqlStatementType.SetGenerator;
					if (StringParser.StartsWith(sqlStatement, "SET SQL DIALECT", true))
						return SqlStatementType.SetSQLDialect;
					if (StringParser.StartsWith(sqlStatement, "SET STATISTICS", true))
						return SqlStatementType.SetStatistics;
					if (StringParser.StartsWith(sqlStatement, "SET TRANSACTION", true))
						return SqlStatementType.SetTransaction;
					if (StringParser.StartsWith(sqlStatement, "SHOW SQL DIALECT", true))
						return SqlStatementType.ShowSQLDialect;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'U':
					if (StringParser.StartsWith(sqlStatement, "UPDATE", true))
						return SqlStatementType.Update;
					throw new Exception("The type of the SQL statement could not be determinated.");

				case 'W':
					if (StringParser.StartsWith(sqlStatement, "WHENEVER", true))
						return SqlStatementType.Whenever;
					throw new Exception("The type of the SQL statement could not be determinated.");

				default:
					throw new Exception("The type of the SQL statement could not be determinated.");
			}
		}

		#endregion
	}
}