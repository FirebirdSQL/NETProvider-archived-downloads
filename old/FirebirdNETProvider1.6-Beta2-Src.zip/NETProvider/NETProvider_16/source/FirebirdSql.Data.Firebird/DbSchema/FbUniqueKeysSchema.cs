//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbUniqueKeysSchema : FbDbSchema
	{
		#region Constructors

		public FbUniqueKeysSchema() : base("PrimaryKeys", 2)
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
					"rel.rdb$relation_name AS TABLE_NAME, " +
					"rel.rdb$constraint_name AS UK_NAME, " +
					"seg.rdb$field_name AS COLUMN_NAME, " +
					"seg.rdb$field_position AS ORDINAL " +
				"FROM " + 
					"rdb$relation_constraints rel " +
					"left join rdb$indices idx ON rel.rdb$index_name = idx.rdb$index_name " +
					"left join rdb$index_segments seg ON idx.rdb$index_name = seg.rdb$index_name");

			where.Append("rel.rdb$constraint_type = 'UNIQUE'");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat(" AND rel.rdb$relation_name = @p{0}", index++);
				}

				if (restrictions.Length >= 2 && restrictions[1] != null)
				{
					where.AppendFormat(" AND rel.rdb$constraint_name = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rel.rdb$relation_name, rel.rdb$constraint_name, seg.rdb$field_position");

			return sql;
		}

		#endregion
	}
}