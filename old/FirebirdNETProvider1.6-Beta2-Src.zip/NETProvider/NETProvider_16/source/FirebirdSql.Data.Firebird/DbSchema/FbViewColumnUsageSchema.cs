//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbViewColumnUsage : FbDbSchema
	{
		#region Constructors

		public FbViewColumnUsage() : base("ViewColumnUsage", 2)
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
					"rel.rdb$relation_name AS VIEW_NAME, " +
					"rfr.rdb$field_name AS COLUMN_NAME, " +
					"fld.rdb$field_type AS COLUMN_DATA_TYPE, " +
					"fld.rdb$field_sub_type AS COLUMN_SUB_TYPE, " +
					"fld.rdb$field_length AS COLUMN_SIZE, " +
					"fld.rdb$field_precision AS NUMERIC_PRECISION, " +
					"fld.rdb$field_scale AS NUMERIC_SCALE, " +
					"rfr.rdb$field_position AS COLUMN_ORDINAL, " +
					"fld.rdb$default_source AS COLUMN_DEFAULT, " +
					"fld.rdb$null_flag AS IS_NULLABLE, " +
					"0 AS IS_READONLY, " +
					"rfr.rdb$description AS DESCRIPTION " +
				"FROM " +
					"rdb$relations rel " +
					"left join rdb$relation_fields rfr ON rel.rdb$relation_name = rfr.rdb$relation_name " +
					"left join rdb$fields fld ON rfr.rdb$field_source = fld.rdb$field_name ");

			where.Append("rel.rdb$view_source IS NOT NULL");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat(" AND rel.rdb$relation_name = @p{0}", index++);
				}

				if (restrictions.Length >= 2 && restrictions[1] != null)
				{
					where.AppendFormat(" AND rfr.rdb$field_name = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rel.rdb$relation_name, rfr.rdb$field_position");

			return sql;
		}

		#endregion
	}
}