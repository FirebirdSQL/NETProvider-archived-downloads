﻿/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2004, 2005 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

#if (!NETCF)

using System;
using System.Collections;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Text;

namespace FirebirdSql.Data.FirebirdClient
{
    public class FbConnectionStringBuilder : DbConnectionStringBuilder
    {
        #region · Properties ·

        public string UserID
        {
            get { return this.GetString("User ID"); }
            set { this["User ID"] = value; }
        }

        public string Password
        {
            get { return this.GetString("Password"); }
            set { this["Password"] = value; }
        }

        public string DataSource
        {
            get { return this.GetString("Data Source"); }
            set { this["Data Source"] = value; }
        }

        public string Database
        {
            get { return this.GetString("Database"); }
            set { this["Database"] = value; }
        }

        public int Port
        {
            get { return this.GetInt32("Port Number"); }
            set { this["Port Number"] = value; }
        }

        public int PacketSize
        {
            get { return this.GetInt32("Packet Size"); }
            set { this["Packet Size"] = value; }
        }

        public string Role
        {
            get { return this.GetString("Role Name"); }
            set { this["Role Name"] = value; }
        }

        public int Dialect
        {
            get { return this.GetInt32("Dialect"); }
            set { this["Dialect"] = value; }
        }

        public string Charset
        {
            get { return this.GetString("Character Set"); }
            set { this["Character Set"] = value; }
        }

        public int ConnectionTimeout
        {
            get { return this.GetInt32("Connection Timeout"); }
            set { this["Connection Timeout"] = value; }
        }

        public bool Pooling
        {
            get { return this.GetBoolean("Pooling"); }
            set { this["Pooling"] = value; }
        }

        public int ConnectionLifeTime
        {
            get { return this.GetInt32("Connection Lifetime"); }
            set { this["Connection Lifetime"] = value; }
        }

        public int MinPoolSize
        {
            get { return this.GetInt32("Min Pool Size"); }
            set { this["Min Pool Size"] = value; }
        }

        public int MaxPoolSize
        {
            get { return this.GetInt32("Max Pool Size"); }
            set { this["Max Pool Size"] = value; }
        }

        public int FetchSize
        {
            get { return this.GetInt32("Fetch Size"); }
            set { this["Fetch Size"] = value; }
        }

        public FbServerType ServerType
        {
            get { return (FbServerType)this.GetInt32("Server Type"); }
            set { this["Server Type"] = value; }
        }

        public IsolationLevel IsolationLevel
        {
            get { return (IsolationLevel)this.GetInt32("Isolation Level"); }
            set { this["Isolation Level"] = value; }
        }

        public bool ReturnRecordsAffected
        {
            get { return this.GetBoolean("records affected"); }
            set { this["records affected"] = value; }
        }

        #endregion

        #region · Constructors ·

        public FbConnectionStringBuilder()
        {
        }

        public FbConnectionStringBuilder(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        #endregion

        #region · Private methods ·

        private int GetInt32(string keyword)
        {
            return Convert.ToInt32(this[keyword]);
        }

        private string GetString(string keyword)
        {
            return Convert.ToString(this[keyword]);
        }

        private bool GetBoolean(string keyword)
        {
            return Convert.ToBoolean(this[keyword]);
        }

        #endregion
    }
}

#endif