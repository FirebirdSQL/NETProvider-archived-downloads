IN FbMembershipProvider1.5.sql;
IN FbRoleProvider1.5.sql;
IN FbProfileProvider1.5.sql;
IN FbSessionStateStore1.5.sql;
