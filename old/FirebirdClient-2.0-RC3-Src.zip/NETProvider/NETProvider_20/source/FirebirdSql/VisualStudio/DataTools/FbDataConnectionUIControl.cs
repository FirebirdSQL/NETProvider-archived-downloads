/*
 *  Visual Studio 2005 DDEX Provider for Firebird
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2005 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualStudio.Data;

namespace FirebirdSql.VisualStudio.DataTools
{
    public partial class FbDataConnectionUIControl : DataConnectionUIControl
    {
        #region � Constructors �

        public FbDataConnectionUIControl()
        {
            System.Diagnostics.Trace.WriteLine("FbDataConnectionUIControl()");
            InitializeComponent();
        }

        #endregion

        #region � Methods �

        public override void LoadProperties()
        {
            System.Diagnostics.Trace.WriteLine("FbDataConnectionUIControl::LoadProperties()");

            try
            {
                this.txtDataSource.Text = (string)ConnectionProperties["DataSource"];
                this.txtUserName.Text   = (string)ConnectionProperties["UserID"];
                this.txtDatabase.Text   = (string)ConnectionProperties["Database"];
                this.txtPassword.Text   = (string)ConnectionProperties["Password"];
                this.txtRole.Text       = (string)ConnectionProperties["Role"];
                this.txtPort.Text       = ConnectionProperties["Port"].ToString();
                this.cboCharset.Text    = (string)ConnectionProperties["Charset"];

                if (Convert.ToInt32(ConnectionProperties["ServerType"]) == 1)
                {
                    this.cboDialect.SelectedIndex = 0;
                }
                else
                {
                    this.cboDialect.SelectedIndex = 1;
                }
                if (Convert.ToInt32(ConnectionProperties["ServerType"]) == 0)
                {
                    this.cboServerType.SelectedIndex = 0;
                }
                else
                {
                    this.cboServerType.SelectedIndex = 1;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }
        }

        #endregion

        #region � Private Methods �

        private void SetProperty(string propertyName, object value)
        {
            ConnectionProperties[propertyName] = value;
        }

        #endregion

        #region � Event Handlers �

        private void SetProperty(object sender, EventArgs e)
        {
            if (sender.Equals(this.txtDataSource))
            {
                this.SetProperty("DataSource", this.txtDataSource.Text);
            } 
            else if (sender.Equals(this.txtDatabase))
            {
                this.SetProperty("Database", this.txtDatabase.Text);
            }
            else if (sender.Equals(this.txtUserName))
            {
                this.SetProperty("UserID", this.txtUserName.Text);
            }
            else if (sender.Equals(this.txtPassword))
            {
                this.SetProperty("Password", this.txtPassword.Text);
            }
            else if (sender.Equals(this.txtRole))
            {
                this.SetProperty("Role", this.txtRole.Text);
            }
            else if (sender.Equals(this.txtPort))
            {
                this.SetProperty("Port", Convert.ToInt32(this.txtPort.Text));
            }
            else if (sender.Equals(this.cboCharset))
            {
                this.SetProperty("Charset", this.cboCharset.Text);
            }
            else if (sender.Equals(this.cboDialect))
            {
                this.SetProperty("Dialect", Convert.ToInt32(this.cboDialect.Text));
            }
            else if (sender.Equals(this.cboServerType))
            {
                this.SetProperty("ServerType", Convert.ToInt32(this.cboServerType.SelectedIndex));
            }
        }

        private void FbDataConnectionUIControl_Load(object sender, EventArgs e)
        {
            this.txtPort.Text = "3050";
            this.cboCharset.SelectedIndex = 0;
            this.cboDialect.SelectedIndex = 1;
            this.cboServerType.SelectedIndex = 0;
        }

        private void cmdGetFile_Click(object sender, EventArgs e)
        {
            if (this.openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.txtDatabase.Text = this.openFileDialog.FileName;
            }
        }

        #endregion
    }
}
