SET SQL DIALECT 3;

SET NAMES NONE;

CREATE DATABASE '127.0.0.1:C:\MEMBERSHIP_PROVIDER.FDB'
USER 'SYSDBA' PASSWORD 'masterkey'
PAGE_SIZE 4096
DEFAULT CHARACTER SET UNICODE_FSS;

CREATE DOMAIN BOOL AS
SMALLINT
NOT NULL
CHECK (value = 1 or value = 0) 

CREATE TABLE Users
(
  PKID CHAR(16) CHARACTER SET OCTETS NOT NULL PRIMARY KEY,
  Username VARCHAR (255) NOT NULL,
  ApplicationName VARCHAR (255) NOT NULL,
  Email VARCHAR (128) NOT NULL,
  Comment VARCHAR (255),
  UserPassword VARCHAR (128) NOT NULL,
  PasswordQuestion VARCHAR (255),
  PasswordAnswer VARCHAR (255),
  IsApproved BOOLEAN, 
  LastActivityDate Timestamp,
  LastLoginDate Timestamp,
  LastPasswordChangedDate Timestamp,
  CreationDate Timestamp, 
  IsOnLine BOOLEAN,
  IsLockedOut BOOLEAN,
  LastLockedOutDate Timestamp,
  FailedPasswordAttemptCount Integer,
  FailedPasswordAttemptStart Timestamp,
  FailedPasswordAnswerCount Integer,
  FailedPasswordAnswerStart TimeStamp
)