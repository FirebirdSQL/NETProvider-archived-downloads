//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Text;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbclob.xml' path='doc/member[@name="T:FbClob"]/*'/>
	internal sealed class FbClob : Blob
	{
		#region CONSTRUCTORS
	
		/// <include file='xmldoc/fbclob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction,System.Int64)"]/*'/>
		public FbClob(FbConnection connection, FbTransaction transaction, long clobId):
				base(connection, transaction, clobId)
		{
		}

		/// <include file='xmldoc/fbclob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction)"]/*'/>
		public FbClob(FbConnection connection, FbTransaction transaction):
			base(connection, transaction)
		{
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbclob.xml' path='doc/member[@name="M:Read()"]/*'/>
		public string Read()
		{			
			StringBuilder data				 = new StringBuilder();
			isc_blob_handle_impl clob_handle = null;

			try
			{
				clob_handle = Open();
			
				while (!clob_handle.IsEof())
				{
					byte[] clobData = GetSegment(clob_handle);					

					data.Append(encoding.GetString(clobData));
				}
			}
			catch(GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
			finally
			{
				if (clob_handle != null)
				{
					Close(clob_handle);
				}
			}

			return data.ToString();
		}

		/// <include file='xmldoc/fbclob.xml' path='doc/member[@name="M:Write(System.String)"]/*'/>
		public long Write(string data)
		{
			long returnValue;
			isc_blob_handle_impl clob_handle = null;

			try
			{
				clob_handle = Create();

				byte[]	buffer	  = encoding.GetBytes(data);
				byte[]	tmpBuffer = null;

				int	length	= buffer.Length;
				int	offset	= 0;
				int	chunk	= length >= connection.IscConnection.PacketSize ? 
											connection.IscConnection.PacketSize : length;

				tmpBuffer = new byte[chunk];
				
				while (length > 0)
				{					
					if (chunk > length) 
					{
						chunk	  = (int)length;
						tmpBuffer = new byte[chunk];
					}					
					System.Array.Copy(buffer, offset, tmpBuffer, 0, chunk);					
					PutSegment(clob_handle, tmpBuffer);
					
					offset += chunk;					
					length -= chunk;
				}

				returnValue = clob_handle.blob_id;
			}
			catch(GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
			finally
			{
				if (clob_handle != null)
				{
					Close(clob_handle);
				}
			}

			return returnValue;
		}

		#endregion
	}
}
