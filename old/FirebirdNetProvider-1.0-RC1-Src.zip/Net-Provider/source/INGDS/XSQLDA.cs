//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="T:XSQLDA"]/*'/>
	internal class XSQLDA 
	{
		#region FIELDS

		/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="P:version"]/*'/>
		public int version;

		/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="P:sqln"]/*'/>
		public int sqln;

		/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="P:sqld"]/*'/>
		public int sqld;

		/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="P:sqln"]/*'/>
		public XSQLVAR[] sqlvar;
		
		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public XSQLDA() 
		{
			version = GdsCodes.SQLDA_VERSION1;
		}

		/// <include file='xmldoc/xsqlda.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public XSQLDA(int n) 
		{
			version = GdsCodes.SQLDA_VERSION1;
			sqln	= n;
			sqld	= n;
			sqlvar	= new XSQLVAR[n];
		}

		#endregion
	}
}
