//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="T:GDSException"]/*'/>
	internal class GDSException : Exception
	{	
		#region FIELDS
		
		private GDSErrorCollection errors = new GDSErrorCollection();

		private int		errorCode;
		private string	message;

		#endregion

		#region PROPERTIES
		
		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="P:Errors"]/*'/>
		public GDSErrorCollection Errors
		{
			get { return errors; }
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="P:Message"]/*'/>
		public new string Message
		{
			get { return message; }
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="P:ErrorCode"]/*'/>
		public int ErrorCode
		{
			get { return errorCode; }			
		}
	    
		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public GDSException() : base()
		{
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:#ctor(System.Int32)"]/*'/>
		public GDSException(int errorCode) : base()
		{
			this.Errors.Add(GdsCodes.isc_arg_gds, errorCode);
			BuildExceptionMessage();
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		public GDSException(string strParam)
		{			
			this.Errors.Add(GdsCodes.isc_arg_string, strParam);
			BuildExceptionMessage();
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:#ctor(System.Int32,System.String)"]/*'/>
		public GDSException(int type, string strParam) : base()
		{
			this.Errors.Add(type, strParam);
			BuildExceptionMessage();
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:#ctor(System.Int32,System.Int32)"]/*'/>
		public GDSException(int type, int errorCode) : base()
		{
			this.Errors.Add(type, errorCode);
			BuildExceptionMessage();
		}
	    
		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:#ctor(System.Int32,System.Int32,System.String)"]/*'/>
		public GDSException(int type, int errorCode, string strParam) : base()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(GdsCodes.isc_arg_string, strParam);			
			BuildExceptionMessage();
		}
		
		#endregion

		#region METHODS

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:IsWarning"]/*'/>
		public bool IsWarning() 
		{
			if (errors.Count > 0)
			{
				return errors[0].IsWarning();
			}
			else
			{
				return false;
			}
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:IsFatal"]/*'/>
		public bool IsFatal()
		{
			bool isFatal = false;

			for (int i=0; i < errors.Count; i++)
			{
				if (errors[0].IsFatal)
				{
					isFatal = true;
					break;
				}
			}

			return isFatal;			
		}

		/// <include file='xmldoc/gdsexception.xml' path='doc/member[@name="M:BuildExceptionMessage"]/*'/>
		public void BuildExceptionMessage()
		{
			StringBuilder	message = new StringBuilder();
			GDSMessage		gdsMessage = null;
			
			errorCode = errors.Count != 0 ? errors[0].ErrorCode : 0;

			for(int i = 0; i < errors.Count; i++)
			{				
				if (errors[i].Type == GdsCodes.isc_arg_gds || errors[i].Type == GdsCodes.isc_arg_warning)
				{
					gdsMessage = GDSExceptionHelper.GetMessage(errors[i].ErrorCode);

					// Add params if exist any
					int paramCount = gdsMessage.GetParamCount();
					for(int j = 1; j <= paramCount; j++)
					{
						if (errors[i+j].Type == GdsCodes.isc_arg_string)
						{
							gdsMessage.SetParameter(j, errors[i+j].StrParam);
						}
						else if (errors[i+j].Type == GdsCodes.isc_arg_number)
							{
								gdsMessage.SetParameter(j, errors[i+j].ErrorCode.ToString());
							}
					}

					errors[i].Message = gdsMessage.ToString();
					message.Append(errors[i].Message + "\n");

					i += paramCount;

					gdsMessage = null;
				}
			}

			this.message = message.ToString();
		}

		#endregion
	}
}