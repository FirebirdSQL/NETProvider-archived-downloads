using System;
using System.Text;
using System.Data;

using FirebirdSql.Data.Firebird;

class TestApp
{	
	static void Main(string[] args)
	{			
		string database = "C:\\ARCHIVOS DE PROGRAMA\\FIREBIRD\\EXAMPLES\\EMPLOYEE.GDB";

		if(args.Length != 0)
		{
			if(args[0] != null)
			{
				if(!args[0].EndsWith("\\"))
					args[0] = args[0] + "\\";
				database = args[0] + "EMPLOYEE.GDB";
			}
		}

		TestCommandBuilder(database);
		TestSchemaTable(database);		
		TestBatchQuerys(database);
		TestReader(database);
		TestAdapter(database);
		TestUpdate(database);
		
		Console.ReadLine();
	}

	static void TestSchemaTable(string database)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = 
				"Database=" + database + ";User=SYSDBA;Password=masterkey;Dialect=3;Server=localhost";
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
			
			FbCommand cmd = new FbCommand("select * from job", conn, txn);
	
			IDataReader reader = cmd.ExecuteReader();		
		
			DataTable schema = reader.GetSchemaTable();

			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Schema Table");

			DataRow[] currRows = schema.Select(null, null, DataViewRowState.CurrentRows);

			foreach (DataRow myRow in currRows)
			{
				foreach (DataColumn myCol in schema.Columns)
					Console.Write("\t{0}", myRow[myCol]);

				Console.WriteLine("\t" + myRow.RowState);
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");

			Console.WriteLine();
	
			txn.Rollback();
	
			reader.Close();
		
			conn.Close();		
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}
	}

	static void TestCommandBuilder(string database)
	{
		FbDataAdapter adapter = new FbDataAdapter();
		FbConnection conn	  = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = 
				"Database=" + database + ";User=SYSDBA;Password=masterkey;Dialect=3;Server=localhost;Port=3050";
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
	
			adapter.SelectCommand = new FbCommand("select * from employee order by emp_no", conn, txn);
	
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Command Builder");

			FbCommandBuilder cb = new FbCommandBuilder(adapter);
			Console.WriteLine(cb.GetInsertCommand().CommandText);
			Console.WriteLine();
			Console.WriteLine(cb.GetUpdateCommand().CommandText);
			Console.WriteLine();
			Console.WriteLine(cb.GetDeleteCommand().CommandText);

			Console.WriteLine();
			Console.WriteLine("------------------------");

			txn.Rollback();
			
			conn.Close();
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}
	}

	static void TestReader(string database)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = 
				"Database=" + database + ";User=SYSDBA;Password=masterkey;Dialect=3;Server=localhost;Port=3050";
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
			
			FbCommand cmd = new FbCommand("select * from employee", conn, txn);
			
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Data Reader");
			
			IDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				for(int i=0;i<reader.FieldCount;i++)
				{
					Console.WriteLine(reader.GetValue(i));
				}
			
				Console.WriteLine();
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");

			txn.Rollback();
	
			reader.Close();
		
			conn.Close();		
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}
	}

	static void TestUpdate(string database)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = 
				"Database=" + database + ";User=SYSDBA;Password=masterkey;Dialect=3;Server=localhost;Port=3050";
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
				
			FbCommand cmd = new FbCommand("update job set job_requirement = ? where job_title = ?", conn, txn);
						
			cmd.Parameters.Add("@job_requirement", "!!!just a test string!!!");
			cmd.Parameters.Add("@job_title", "Accountant");

			int ret = cmd.ExecuteNonQuery();

			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Update");

			Console.WriteLine("Records Updated: {0}", ret );

			Console.WriteLine();
			Console.WriteLine("------------------------");
											
			conn.Close();		
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}
	}
	static void TestBatchQuerys(string database)
	{
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = 
				"Database=" + database + ";User=SYSDBA;Password=masterkey;Dialect=3;Server=localhost;Port=3050";
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();
			
			string querys = "select * from employee order by emp_no;" +
							"select * from department order by dept_no";

			FbCommand cmd = new FbCommand(querys, conn, txn);
	
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Batch Querys");
			Console.WriteLine();
			Console.WriteLine("Employee Data");

			IDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{				
				for(int i=0;i<reader.FieldCount;i++)
				{
					Console.Write("{0}\t", reader.GetValue(i));
				}
			
				Console.WriteLine();
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");

			Console.WriteLine("Departaments Data");

			if(reader.NextResult())
			{
				while (reader.Read())
				{				
					for(int i=0;i<reader.FieldCount;i++)
					{
						Console.Write("{0}\t", reader.GetValue(i));
					}
				
					Console.WriteLine();
				}
			}

			Console.WriteLine();
			Console.WriteLine("------------------------");			

			txn.Rollback();
	
			reader.Close();
		
			conn.Close();		
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}
	}
	
	static void TestAdapter(string database)
	{
		FbDataAdapter adapter = new FbDataAdapter();
		FbConnection conn = new FbConnection();
		FbTransaction txn;

		try
		{
			conn.ConnectionString = 
				"Database=" + database + ";User=SYSDBA;Password=masterkey;Dialect=3;Server=localhost;Port=3050";
	
			conn.Open();
		
			txn = (FbTransaction)conn.BeginTransaction();

			adapter.SelectCommand = new FbCommand("select * from country", conn, txn);
			
			FbCommandBuilder cmdBuilder = new FbCommandBuilder(adapter);
			
			adapter.UpdateCommand = cmdBuilder.GetUpdateCommand();
			adapter.InsertCommand = cmdBuilder.GetInsertCommand();
			adapter.DeleteCommand = cmdBuilder.GetDeleteCommand();

			DataSet ds = new DataSet();
			adapter.Fill(ds, "Country");
	
			Console.WriteLine("------------------------");
			Console.WriteLine("Test - Data Adapter");
			printDataSet(ds);
			Console.WriteLine("------------------------");
	
			ds.Tables["Country"].Rows[1]["Currency"] = "Adap_Test";
			adapter.Update(ds, "Country");

			Console.WriteLine("------------------------");
			Console.WriteLine("Results of adapter.Update");
			printDataSet(ds);
			Console.WriteLine("------------------------");

			Console.WriteLine();			

			txn.Rollback();
	
			conn.Close();
		}
		catch(Exception ex)
		{
			conn.Close();
			Console.WriteLine("Exception message: {0}", ex.Message);
		}		
	}

	static void printDataSet(DataSet ds)
	{
		foreach (DataTable table in ds.Tables)
		{
			foreach (DataColumn col in table.Columns)
				Console.Write(col.ColumnName + "\t\t");
			Console.WriteLine();
			foreach (DataRow row in table.Rows)
			{
				for (int i = 0; i < table.Columns.Count; i++)
					Console.Write(row[i] + "\t\t");
				Console.WriteLine("");
			}
		}
	}
}
