//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.ComponentModel;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{	
	/// <summary>
	/// FbCommand States
	/// </summary>
	internal enum CommandState {Deallocated,Allocated,Preparing,Prepared,Executing,Executed};

	/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="T:FbCommand"]/*'/>
	public sealed class FbCommand : Component, IDbCommand, ICloneable
	{				
		#region FIELDS

		internal isc_stmt_handle_impl	stmt = null;
		
		private UpdateRowSource			updatedRowSource = UpdateRowSource.Both;
		private FbParameterCollection	parameters		 = new FbParameterCollection();
		private FbTransaction			txn				 = null;
		private CommandBehavior			commandBehavior	 = CommandBehavior.Default;
		private CommandType				cmdType			 = CommandType.Text;
		private CommandState			cmdState		 = CommandState.Deallocated;
		private int						actualCommand	 = -1;
		private bool					disposed		 = false;
		private FbConnection			connection;
		private string					cmdText;
		private string[]				commands;

		// Statement info
		private static byte[] stmtInfo  = new byte[]
		{
			GDSValues.isc_info_sql_records,
			GDSValues.isc_info_sql_stmt_type,
			GDSValues.isc_info_end
		};
		// Statement info size
		private static int INFO_SIZE = 128;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandText"]/*'/>
		public string CommandText
		{
			get 
			{ 
				return commands[actualCommand] == null ? "" : commands[actualCommand];
			}
			set 
			{ 				
				cmdText  = value;
				commands = cmdText.Split(';');
				this.actualCommand = 0;
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandType"]/*'/>
		public CommandType CommandType
		{
			get { return cmdType; }
			set { cmdType = value; }
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandTimeout"]/*'/>
		public int CommandTimeout
		{
			get  { return 0; }
			set  { if (value != 0) throw new NotSupportedException(); }
		}
		
		IDbConnection IDbCommand.Connection
		{
			get{ return Connection;  }
			set{ Connection = (FbConnection)value;}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Connection"]/*'/>
		public FbConnection Connection
		{
			get { return connection;  }
			set
			{
				if(Transaction != null)
				{
					if(Transaction.Transaction != null)
					{
						throw new ArgumentException("Transaction in progress.");
					}
				}

				/*
				 * The connection is associated with the transaction
				 * so set the transaction object to return a null reference 
				 * if the connection is reset.
				 */
				if (connection != value)
				{										
					if(Transaction != null)
					{
						Transaction.Rollback();
						Transaction = null;
					}

					if (stmt != null)
					{
						Close(false);
						stmt = null;
					}
				}

				connection = value;
				stmt = (isc_stmt_handle_impl)connection.gds.get_new_isc_stmt_handle();
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Parameters"]/*'/>
		public FbParameterCollection Parameters
		{
			get  { return parameters; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Parameters"]/*'/>
		IDataParameterCollection IDbCommand.Parameters
		{
			get  { return parameters; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Transaction"]/*'/>
		IDbTransaction IDbCommand.Transaction
		{
			get{ return Transaction; }
			set{ Transaction = (FbTransaction)value; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Transaction"]/*'/>
		public FbTransaction Transaction
		{
			get { return txn; }
			set 
			{ 
				if(Transaction != null)
				{
					if(Transaction.Transaction == null)
					{
						txn = value; 
					}
				}
				else
				{
					txn = value; 
				}
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:UpdatedRowSource"]/*'/>
		public UpdateRowSource UpdatedRowSource
		{
			get { return updatedRowSource;  }
			set { updatedRowSource = value; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:State"]/*'/>		
		internal CommandState State
		{
			get { return cmdState;  }
			set { cmdState = value; }
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:Statement"]/*'/>
		internal isc_stmt_handle_impl Statement
		{
			get{return stmt;}
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="P:CommandBehavior"]/*'/>
		internal CommandBehavior CommandBehavior
		{
			get{return commandBehavior;}
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbCommand()
		{
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		public FbCommand(string cmdText)
		{
			this.CommandText = cmdText;
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor(System.String,FirebirdSql.Data.Firebird.FbConnection)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection)
		{
			this.CommandText = cmdText;
			this.Connection	 = connection;
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:#ctor(System.String,FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection, FbTransaction txn)
		{
			this.CommandText = cmdText;
			this.Connection  = connection;
			this.Transaction = txn;
		}				 

		#endregion

		#region DESTRUCTORS

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Finalize"]/*'/>
		~FbCommand() 
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false)is optimal in terms of
			// readability and maintainability.
			Dispose (false);
		}		

		#endregion

		#region METHODS
		
		object ICloneable.Clone()
		{
			throw new NotImplementedException();
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if(!disposed)
			{
				try
				{
					if(disposing)
					{
						this.CommandText	= "";
						this.actualCommand	= -1;
						this.commands		= null;
						this.Parameters.Clear();
					}					

					disposed = true;
				}
				finally
				{
					base.Dispose(disposing);
				}
			}
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Cancel"]/*'/>
		public void Cancel()
		{			
			throw new NotSupportedException();
		}
		
		IDbDataParameter IDbCommand.CreateParameter()
		{
			return CreateParameter();
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:CreateParameter"]/*'/>
		public FbParameter CreateParameter()
		{
			return new FbParameter();
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteNonQuery"]/*'/>
		public int ExecuteNonQuery()
		{      
			if (connection == null || connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");

			if(!connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			try
			{
				if (cmdState == CommandState.Deallocated || cmdState == CommandState.Allocated)
					Prepare();

				Execute();
			}
			catch(GDSException ex)
			{
				if(connection.AutoCommit)
					this.txn.Rollback();

				throw new FbException(ex);
			}

			if(IsSelect())
				return -1;
			else
				return GetUpdateCount();
		}
				
		IDataReader IDbCommand.ExecuteReader()
		{	
			return ExecuteReader();			
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteReader"]/*'/>
		public FbDataReader ExecuteReader()
		{	
			return ExecuteReader(CommandBehavior.Default);			
		}
		
		IDataReader IDbCommand.ExecuteReader(CommandBehavior behavior)
		{
			return ExecuteReader(behavior);
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteReader(System.Data.CommandBehavior)"]/*'/>	
		public FbDataReader ExecuteReader(CommandBehavior behavior)
		{
			if (connection == null || connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");

			if(!connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			try
			{
				commandBehavior = behavior;

				if (cmdState == CommandState.Deallocated || cmdState == CommandState.Allocated)
					Prepare();
				
				Execute();								
			}
			catch(GDSException ex)
			{
				if(connection.AutoCommit)
					this.txn.Rollback();

				throw new FbException(ex);
			}

			return new FbDataReader(this);
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:ExecuteScalar"]/*'/>
		public object ExecuteScalar()
		{
			if (connection == null || connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");

			if(!connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			try
			{
				if (cmdState == CommandState.Deallocated || cmdState == CommandState.Allocated)
					Prepare();
				
				Execute();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return stmt.OutSqlda.sqlvar[0];				
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Prepare"]/*'/>	
		public void Prepare()
		{
			if (connection == null || connection.State != ConnectionState.Open)
				throw new InvalidOperationException("Connection must valid and open");			

			if(!connection.Equals(Transaction.Connection))
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection");

			try
			{
				if(txn == null)
					txn = new FbTransaction(this.connection);

				if(cmdState == CommandState.Deallocated)
					AllocateStatement();

				cmdState = CommandState.Preparing;

				XSQLDA output = connection.gds.isc_dsql_prepare(
													txn.Transaction, 
													stmt, 
													CommandText, 
													connection.Charset, 
													connection.Dialect);
							
				// sqln: number of fields allocated
				// sqld: actual number of fields
				if (output.sqld != output.sqln)
					throw new FbException("Invalid number of allocated columns in resultset.");
				
				connection.gds.isc_dsql_describe(stmt, GDSValues.SQLDA_VERSION1);
			
				XSQLDA input = connection.gds.isc_dsql_describe_bind(
											stmt, GDSValues.SQLDA_VERSION1);

				// sqln: number of fields allocated
				// sqld: actual number of fields
				if (input.sqld != input.sqln)
					throw new FbException("Invalid number of allocated columns in resultset.");
			
				cmdState = CommandState.Prepared;
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:NextResult"]/*'/>
		internal bool NextResult()
		{
			bool returnValue = false;

			actualCommand++;

			if(actualCommand>=commands.Length)
			{
				actualCommand--;
			}
			else
			{
				parameters.Clear();

				Close(true);

				Prepare();

				Execute();

				returnValue = true;
			}

			return returnValue;
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Execute"]/*'/>
		private void Execute()
		{
			try
			{
				cmdState = CommandState.Executing;

				connection.gds.isc_dsql_execute(txn.Transaction, stmt, 
					GDSValues.SQLDA_VERSION1, GetInSqlda());
				
				if(connection.AutoCommit)
					Transaction.Commit();

				cmdState = CommandState.Executed;
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:AllocateStatement"]/*'/>
		private void AllocateStatement()
		{
			try
			{
				if(stmt == null)
					stmt = (isc_stmt_handle_impl)connection.gds.get_new_isc_stmt_handle();
				connection.gds.isc_dsql_allocate_statement(connection.db, stmt);
			}
			catch(GDSException)
			{
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:Close"]/*'/>
		private void Close(bool deallocate)
		{
			if(stmt != null)
			{
				try
				{
					connection.gds.isc_dsql_free_statement(stmt, (deallocate) ? GDSValues.DSQL_drop : GDSValues.DSQL_close);

					cmdState = deallocate ? CommandState.Deallocated : CommandState.Allocated;				
				}
				catch(GDSException ex)
				{
					throw new FbException(ex);
				}
			}
		}

		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:GetInSqlda"]/*'/>		
		private XSQLDA GetInSqlda()
		{
			XSQLDA in_sqlda = stmt.InSqlda;
			IEnumerator paramEnumerator = Parameters.GetEnumerator();

			if(Parameters.Count != in_sqlda.sqlvar.Length)
			{
				throw new InvalidOperationException("Invalid number of parameters for command execution.");
			}
			
			int i = 0;
			while(paramEnumerator.MoveNext())
			{						
				switch (in_sqlda.sqlvar[i].sqltype & ~1)
				{
					case GDSValues.SQL_TEXT:
					case GDSValues.SQL_VARYING:							
						in_sqlda.sqlvar[i].sqldata = (string)(((FbParameter)paramEnumerator.Current).Value);
						break;

					case GDSValues.SQL_SHORT:
						in_sqlda.sqlvar[i].sqldata = Int16.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
						break;

					case GDSValues.SQL_LONG:
						in_sqlda.sqlvar[i].sqldata = Int32.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
						break;
			
					case GDSValues.SQL_FLOAT:
						in_sqlda.sqlvar[i].sqldata = float.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
						break;
								
					case GDSValues.SQL_DOUBLE:
					case GDSValues.SQL_D_FLOAT:
						in_sqlda.sqlvar[i].sqldata = Double.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
						break;
							
					case GDSValues.SQL_BLOB:
						if(in_sqlda.sqlvar[i].sqlsubtype == 1)
						{
							FbClob clob = new FbClob(Connection, Transaction);
							in_sqlda.sqlvar[i].sqldata = clob.Write(
									(((FbParameter)paramEnumerator.Current).Value).ToString());
						}
						else
						{
							FbBlob blob = new FbBlob(Connection, Transaction);
							in_sqlda.sqlvar[i].sqldata = blob.Write((byte[])
									((FbParameter)paramEnumerator.Current).Value);
						}
						
						break;
			
					case GDSValues.SQL_ARRAY:
						// TODO: Write array data
						break;

					case GDSValues.SQL_QUAD:
					case GDSValues.SQL_INT64:
						in_sqlda.sqlvar[i].sqldata = Int64.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
						break;
								
					case GDSValues.SQL_TIMESTAMP:
					case GDSValues.SQL_TYPE_TIME:			
					case GDSValues.SQL_TYPE_DATE:				
						in_sqlda.sqlvar[i].sqldata = DateTime.Parse((((FbParameter)paramEnumerator.Current).Value).ToString());
						break;
				
					default:
						throw new NotSupportedException("Unknown data type");
				}							

				if(in_sqlda.sqlvar[i].sqldata == System.DBNull.Value)
				{
					if((in_sqlda.sqlvar[i].sqltype & 1 ) == 0)
					{
						throw new InvalidOperationException("Parameter value cannot be null.");
					}
				}

				i++;
			}

			return in_sqlda;
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:IsSelect"]/*'/>
		private bool IsSelect()
		{
			return stmt.OutSqlda.sqld > 0  ? true : false;
		}
		
		/// <include file='xmldoc/fbcommand.xml' path='doc/member[@name="M:GetUpdateCount"]/*'/>
		private int GetUpdateCount()
		{
			SqlInfo info;

			try
			{				
				info = new SqlInfo(connection.gds.isc_dsql_sql_info(
													stmt, stmtInfo.Length, 
													stmtInfo, INFO_SIZE), 
													connection.gds);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return info.InsertCount		+
					info.UpdateCount	+
					info.DeleteCount;
		}

		#endregion
	}
}
