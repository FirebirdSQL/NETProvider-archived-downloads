//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="T:FbConnection"]/*'/>
	public sealed class FbConnection : Component, IDbConnection, ICloneable
	{	

		#region FIELDS

		internal IGDS			gds;		
		internal isc_db_handle	db;
		internal FbConnectionRequestInfo cri;

		private ConnectionState state;
		private string			connectionString = "";
		private string			database = "";
		private string			user	 = "";
		private string			password = "";
		private string			host	 = "";
		private string			port	 = "";
		private string			charset	 = "";
		private byte			dialect	 = 3;
		private bool			autoCommit = true;
		private int				connectionTimeout = 0;		

		private bool			disposed = false;

		private FbDataReader	dataReader = null;

		#endregion
		
		#region PROPERTIES

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Autocommit"]/*'/>
		public bool AutoCommit
		{
			get{ return autoCommit; }
			set{ autoCommit = value; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:State"]/*'/>
		public ConnectionState State
		{
			get { return state; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ConnectionString"]/*'/>
		public string ConnectionString
		{
			get{ return connectionString; }
			set
			{ 
				if(state == ConnectionState.Closed)
				{
					if(this.ParseConnectionString(value))
						connectionString = value;
					else
						throw new ArgumentException();
				}
			}			
		}
		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ConnectionTimeout"]/*'/>
		public int ConnectionTimeout
		{
			get{ return connectionTimeout; }
		}
		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get{ return database; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Dialect"]/*'/>
		internal byte Dialect
		{
			get{ return dialect; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Charset"]/*'/>
		internal string Charset
		{
			get{ return charset; }
		}

		internal FbDataReader DataReader
		{
			get{return dataReader;}
			set{dataReader=value;}
		}

		#endregion		

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbConnection()
		{			
			state = ConnectionState.Closed;
		}
    		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		public FbConnection(string connString)
		{
			state = ConnectionState.Closed;
			this.connectionString = connString;
		}		

		#endregion

		#region DESTRUCTORS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Finalize"]/*'/>
		~FbConnection() 
		{
			// Do not re-create Dispose clean-up code here.
			// Calling Dispose(false)is optimal in terms of
			// readability and maintainability.
			Dispose (false);
		}		

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if(!disposed)
			{
				try
				{	
					Close();

					if(disposing)
					{
						AutoCommit	= true;
						database	= "";
						charset		= "";
						user		= "";
						password	= "";

						cri			= null;
						
						db.ClearWarnings();

						gds			= null;
						db			= null;						
					}

					disposed = true;
				}
				finally
				{
					base.Dispose(disposing);
				}
			}
		}		

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ICloneable#Clone"]/*'/>
		object ICloneable.Clone()
		{
			throw new NotImplementedException();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		IDbTransaction IDbConnection.BeginTransaction()
		{
			return BeginTransaction();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		public FbTransaction BeginTransaction()
		{
			FbTransaction tr = null;

			try
			{
				tr = new FbTransaction(this);
				tr.BeginTransaction();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return tr;			
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		IDbTransaction IDbConnection.BeginTransaction(IsolationLevel level)
		{
			return BeginTransaction(level);
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level)
		{
			FbTransaction tr = null;

			try
			{
				tr = new FbTransaction(this, level);
				tr.BeginTransaction();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return tr;			
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ChangeDatabase"]/*'/>
		public void ChangeDatabase(string db)
		{	
			throw new NotImplementedException();		
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Open"]/*'/>
		public void Open()
		{
			if(state != ConnectionState.Closed)
				throw new InvalidOperationException("Connection already Open.");

			// Validate Connection String
			if (!this.ParseConnectionString(this.connectionString))
				throw new ArgumentException("Invalid connection String");

			try
			{
				state = ConnectionState.Connecting;

				// New instance of GDS class
				gds = GDSFactory.NewGDS();
				// New instance of RequestConnectionInfo class
				cri = new FbConnectionRequestInfo();
				// New instance for Database handler
				db	= gds.get_new_isc_db_handle();
				
				// DPB configuration
				cri.SetProperty(GDSValues.isc_dpb_dummy_packet_interval, new byte[] {120, 10, 0, 0});
				cri.SetProperty(GDSValues.isc_dpb_sql_dialect, new byte[] {dialect, 0, 0, 0});
				cri.SetProperty(GDSValues.isc_dpb_lc_ctype, charset);

				cri.SetUser(user);
				cri.SetPassword(password);

				// Connect to database
				gds.isc_attach_database(GetConnectString(), db, cri.Dpb);

				// Change State
				state = ConnectionState.Open;
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="Close"]/*'/>
		public void Close()
		{
			if(state == ConnectionState.Open)
			{
				try
				{	
					// Rollback all pending transactions
					if(db.HasTransactions())
					{						
						while ( db.HasTransactions() )
						{
							IEnumerator txnEnum = ((isc_db_handle_impl)db).Transactions.GetEnumerator();
							txnEnum.MoveNext();
							gds.isc_rollback_transaction((isc_tr_handle_impl)txnEnum.Current);
						}
						
					}
		
					// Disconnect
					gds.isc_detach_database(db);

					// Update state
					state = ConnectionState.Closed;
				}
				catch(GDSException ex)
				{
					throw new FbException(ex);
				}
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:CreateCommand"]/*'/>
		public IDbCommand CreateCommand()
		{			
			return new FbCommand();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ParseConnectionString"]/*'/>
		private bool ParseConnectionString(string connStr)
		{
			string db		= null;
			string user		= null;
			string password = null;
			string server	= null;
			string port     = null;
			string charset  = null;
			byte   dialect	= 3;

			bool returnVal = true;
			string[] elements = connStr.Split(';');			

			for(int i=0;i<elements.Length;i++)
			{
				string[] values = elements[i].Split('=');

				switch(values[0].ToUpper())
				{
					case "DATABASE":
						db = values[1];
						break;

					case "USER":
						user = values[1];
						break;

					case "PASSWORD":
						password = values[1];
						break;

					case "SERVER":
						server = values[1];
						break;

					case "PORT":
						port = values[1];
						break;

					case "DIALECT":
						dialect = System.Convert.ToByte(values[1]);
						break;

					case "CHARSET":
						charset = values[1];
						break;

					default:
						break;
				}
			}

			if(database==null || user ==null || password==null || host==null)
			{
				returnVal = false;
			}
			else
			{
				this.database	= db;
				this.user		= user;
				this.password	= password;
				this.host		= server;
				if(port == null)
					this.port	= "3050";
				else
					this.port	= port;
				this.dialect	= dialect;
				if(charset == null)
					this.charset = "NONE";
				else
					this.charset = charset;
			}

			return returnVal;
		}
		
		private string GetConnectString()
		{
			string fileString = host + "/" + port + ":" + database;

			return fileString;
		}

		#endregion
	}
}
