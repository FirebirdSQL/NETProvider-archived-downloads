//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbcatalogfunctions.xml' path='doc/member[@name="T:FbCatalogFunctions"]/*'/>
	internal class FbCatalogFunctions
	{		
		/// <include file='xmldoc/fbcatalogfunctions.xml' path='doc/member[@name="M:GetPrimaryKey(FirebirdSql.Data.Firebird.FbConnection,System.String,System.String,System.String,System.String)"]/*'/>
		public static IDataReader GetPrimaryKey(FbConnection connection, 
												string tableCat,
												string tableSchema,
												string tableName,
												string columnName)
		{			
			StringBuilder sql = new StringBuilder();

			sql.Append(
				"select NULL as table_cat, NULL as table_schem,\n"	+
				"\trel.rdb$relation_name as table_name,\n"			+
				"\tseg.rdb$field_name as column_name,\n"			+
				"\tseg.rdb$field_position as key_seq,\n"			+
				"\tidx.rdb$index_name as pk_name\n"					+
				"from rdb$relation_constraints rel, rdb$indices idx, rdb$index_segments seg\n" +
				" where rel.rdb$constraint_type = 'PRIMARY KEY'\n"	+
				" and rel.rdb$index_name = idx.rdb$index_name\n"	+
				" and idx.rdb$index_name = seg.rdb$index_name\n");
				
			if(tableName != null)
				if(tableName.Length != 0)
					sql.AppendFormat(" and rel.rdb$relation_name = '{0}'", tableName);

			if(columnName != null)
				if(columnName.Length != 0)
					sql.AppendFormat(" and seg.rdb$field_name = '{0}'", columnName);

			sql.Append(" order by rel.rdb$relation_name, idx.rdb$index_name, seg.rdb$field_position");

			try
			{		
				FbCommand command = new FbCommand(sql.ToString(), connection);

				// Begin transaction
				command.Transaction = connection.BeginTransaction();

				// Prepare the SQL command
				command.Prepare();
				
				// Exec command and returns the Reader
				return command.ExecuteReader();
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}		
		
		/// <include file='xmldoc/fbcatalogfunctions.xml' path='doc/member[@name="M:GetUniqueColumns(FirebirdSql.Data.Firebird.FbConnection,System.String,System.String,System.String,System.String)"]/*'/>
		public static IDataReader GetUniqueColumns(FbConnection connection, 
												string tableCat,
												string tableSchema,
												string tableName,
												string columnName)
		{			
			StringBuilder sql = new StringBuilder();

			sql.Append(
				"select NULL as table_cat, NULL as table_schem,\n"	+
				"\trel.rdb$relation_name as table_name,\n"			+
				"\tseg.rdb$field_name as column_name,\n"			+
				"\tseg.rdb$field_position as key_seq,\n"			+
				"\tidx.rdb$index_name as pk_name\n"					+
				"from rdb$relation_constraints rel, rdb$indices idx, rdb$index_segments seg\n" +
				" where rel.rdb$constraint_type = 'UNIQUE'\n"	+
				" and rel.rdb$index_name = idx.rdb$index_name\n"	+
				" and idx.rdb$index_name = seg.rdb$index_name\n");
				
			if(tableName != null)
				if(tableName.Length != 0)
					sql.AppendFormat(" and rel.rdb$relation_name = '{0}'", tableName);

			if(columnName != null)
				if(columnName.Length != 0)
					sql.AppendFormat(" and seg.rdb$field_name = '{0}'", columnName);

			sql.Append(" order by rel.rdb$relation_name, idx.rdb$index_name, seg.rdb$field_position");

			try
			{		
				FbCommand command = new FbCommand(sql.ToString(), connection);

				// Begin transaction
				command.Transaction = connection.BeginTransaction();

				// Prepare the SQL command
				command.Prepare();
				
				// Exec command and returns the Reader
				return command.ExecuteReader();
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbcatalogfunctions.xml' path='doc/member[@name="M:GetSchemaColumns(FirebirdSql.Data.Firebird.FbConnection,System.String,System.String,System.String,System.String)"]/*'/>
		public static IDataReader GetSchemaColumns(FbConnection connection, 
												string tableCat,
												string tableSchema,
												string tableName,
												string columnName)
		{
			StringBuilder sql = new StringBuilder();
			
			sql.Append("select NULL as table_cat,NULL as table_schem,\n"	+
				"rfr.rdb$relation_name     as table_name,\n"				+
				"rfr.rdb$field_name        as colum_name,\n"				+
				"rfr.rdb$field_position    as column_ordinal,\n"			+
				"fld.rdb$field_length      as column_size,\n"				+
				"fld.rdb$field_precision   as numeric_precision,\n"			+
				"fld.rdb$field_scale       as numeric_scale,\n"				+
				"fld.rdb$field_type        as data_type,\n"					+
				"fld.rdb$field_sub_type    as data_sub_type,\n"				+
				"rfr.rdb$null_flag         as nullable,\n"					+
				"rfr.rdb$update_flag       as isreadonly,\n"				+
				"rfr.rdb$default_value     as column_def\n"					+
				"from rdb$relation_fields rfr, rdb$fields fld\n"			+
				"where rfr.rdb$field_source = fld.rdb$field_name"			);
				
			if (tableName != null)
				if (tableName.Length != 0)				
					sql.AppendFormat(" and rfr.rdb$relation_name = '{0}'", tableName);
	
			if (columnName != null)
				if (columnName.Length != 0)
					sql.AppendFormat(" and rfr.rdb$field_name = '{0}'", columnName);

			sql.Append(" order by rfr.rdb$relation_name, rfr.rdb$field_position");
						
			try
			{				
				FbCommand command = new FbCommand(sql.ToString(), connection);

				// Begin transaction
				command.Transaction = connection.BeginTransaction();

				// Prepare the SQL command
				command.Prepare();

				// Commit transaction
				command.Transaction.Commit();
				
				// Exec command and returns the Reader
				return command.ExecuteReader();
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbcatalogfunctions.xml' path='doc/member[@name="M:GetColumnPrivileges(FirebirdSql.Data.Firebird.FbConnection,System.String,System.String,System.String,System.String)"]/*'/>
		public static IDataReader GetColumnPrivileges(FbConnection connection, 
														string tableCat,
														string tableSchema,
														string tableName,
														string columnName)
		{
			StringBuilder sql = new StringBuilder();

			sql.Append(
				"select NULL as table_cat,"				+
				"NULL as table_schem,"					+
				"tbl.rdb$relation_name as table_name,"	+
				"usp.rdb$field_name as column_name,"	+
				"usp.rdb$grantor as grantor,"			+
				"usp.rdb$user as grantee,"				+
				"usp.rdb$privilege as privilege,"		+
				"usp.rdb$grant_option as isgrantable "	+
				"from rdb$relations tbl, rdb$user_privileges usp\n"	+
				" where tbl.rdb$relation_name = usp.rdb$relation_name\n");
				
			if(tableName != null)
				if(tableName.Length != 0)
					sql.AppendFormat(" and tbl.rdb$relation_name = '{0}'", tableName);

			if (columnName != null)
				if (columnName.Length != 0)
					sql.AppendFormat(" and tbl.rdb$relation_name = '{0}'", columnName);

			sql.Append(" order by tbl.rdb$relation_name, usp.rdb$field_name, usp.rdb$privilege");
									
			try
			{				
				FbCommand command = new FbCommand(sql.ToString(), connection);

				// Begin transaction
				command.Transaction = connection.BeginTransaction();

				// Prepare the SQL command
				command.Prepare();

				// Commit transaction
				command.Transaction.Commit();
				
				// Exec command and returns the Reader
				return command.ExecuteReader();
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbcatalogfunctions.xml' path='doc/member[@name="M:GetTablePrivileges(FirebirdSql.Data.Firebird.FbConnection,System.String,System.String,System.String)"]/*'/>
		public static IDataReader GetTablePrivileges(FbConnection connection, 
														string tableCat,
														string tableSchema,
														string tableName)
		{
			StringBuilder sql = new StringBuilder();

			sql.Append(
				"select NULL as table_cat,"				+
				"NULL as table_schem,"					+
				"tbl.rdb$relation_name as table_name,"	+
				"usp.rdb$grantor as grantor,"			+
				"usp.rdb$user as grantee,"				+
				"usp.rdb$privilege as privilege,"		+
				"'YES' as isgrantable, "				+
				"usp.rdb$grant_option as GRANT_OPTION "	+
				"from rdb$relations tbl, rdb$user_privileges usp\n" +
				" where tbl.rdb$relation_name = usp.rdb$relation_name\n");

			if (tableName != null)
				if (tableName.Length != 0)
					sql.AppendFormat(" and tbl.rdb$relation_name = '{0}'", tableName);
					
			sql.Append(" order by tbl.rdb$relation_name, usp.rdb$privilege, usp.rdb$user");	
									
			try
			{				
				FbCommand command = new FbCommand(sql.ToString(), connection);

				// Begin transaction
				command.Transaction = connection.BeginTransaction();

				// Prepare the SQL command
				command.Prepare();

				// Commit transaction
				command.Transaction.Commit();
				
				// Exec command and returns the Reader
				return command.ExecuteReader();
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}
	}
}
