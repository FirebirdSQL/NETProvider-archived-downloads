//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Security.Permissions;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbclientpermissionattribute.xml' path='doc/member[@name="T:FbClientPermissionAttribute"]/*'/>
	[AttributeUsage(AttributeTargets.Assembly    | 
					AttributeTargets.Class 	     | 
					AttributeTargets.Struct      | 
					AttributeTargets.Constructor |
					AttributeTargets.Method)]
	public sealed class FbClientPermissionAttribute : DBDataPermissionAttribute
	{
		/// <include file='xmldoc/fbclientpermissionattribute.xml' path='doc/member[@name="F:action"]/*'/>
		private SecurityAction action;

		/// <include file='xmldoc/fbclientpermissionattribute.xml' path='doc/member[@name="M:#ctor(System.Security.Permissions.SecurityAction)"]/*'/>
		public FbClientPermissionAttribute(SecurityAction action):base(action)
		{
			this.action = action;
		}

		/// <include file='xmldoc/fbclientpermissionattribute.xml' path='doc/member[@name="M:CreatePermission"]/*'/>
		public override IPermission CreatePermission()
		{
			throw new NotImplementedException ();
		}
	}
}
