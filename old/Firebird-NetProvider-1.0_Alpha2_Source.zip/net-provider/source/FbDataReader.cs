//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Text;
using System.Collections;
using System.Globalization;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;
using FirebirdSql.Logging;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="T:FbDataReader"]/*'/>
	public sealed class FbDataReader : IDataReader
	{		
		#region FIELDS
		
		private bool		open = true;

		private DataTable	schemaTable;

		private static int  STARTPOS  = -1;
		private int			position  = STARTPOS;
						
		FbCommand			command;
		object[]			row;		

		private Log4CSharp log = null;

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbCommand)"]/*'/>
		internal FbDataReader(FbCommand command)
		{
			command.Connection.DataReader = this;

			this.command	 = command;
			this.schemaTable = null;

			#if(_DEBUG)
				log = new Log4CSharp(GetType(), "fbprov.log", Mode.APPEND);
			#endif
		}

		#endregion

		#region IDISPOSABLE_METHODS
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:Dispose"]/*'/>
		public void Dispose()
		{
		}

		#endregion

		#region IDATAREADER_PROPERTIES_METHODS

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:Depth"]/*'/>
		public int Depth 
		{
			get { return 0; }
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:IsClosed"]/*'/>
		public bool IsClosed
		{
			get  { return !open; }
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:RecordsAffected"]/*'/>
		public int RecordsAffected 
		{
			/*
			 * RecordsAffected is only applicable to batch statements
			 * that include inserts/updates/deletes. 
			 */
			get { return -1; }
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close()
		{
			if(!open)
				return;

			if((command.CommandBehavior & CommandBehavior.CloseConnection) == CommandBehavior.CloseConnection)
			{
				command.Connection.Close();
			}

			command.Connection.DataReader = null;

			open	= false;
			row		= null;
			command = null;
			position= STARTPOS;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:NextResult"]/*'/>
		public bool NextResult()
		{
			bool returnValue = this.command.NextResult();

			if( returnValue )
			{
				position  = STARTPOS;
				row = null;
			}

			return returnValue;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:Read"]/*'/>
		public bool Read()
		{
			if(log!=null) log.Debug("read");

			try
			{
				row = command.Connection.gds.isc_dsql_fetch(
												command.Statement,
												GDSValues.SQLDA_VERSION1,
												command.Statement.OutSqlda);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			if (row == null)
				return false;
			else
			{
				position++;
				return true;
			}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetSchemaTable"]/*'/>
		public DataTable GetSchemaTable()
		{
			if(log!=null) log.Debug("GetSchemaTable");

			if(schemaTable != null)
				return schemaTable;

			XSQLVAR[]	sqlvar		= command.Statement.OutSqlda.sqlvar;			
			DataRow		schemaRow;

			schemaTable = this.GetSchemaTableStructure();

			for (int i=0;i<sqlvar.Length;i++)
			{
				schemaRow = schemaTable.NewRow();

				schemaRow["ColumnName"]		= sqlvar[i].aliasname;
				schemaRow["ColumnOrdinal"]	= GetOrdinal(sqlvar[i].aliasname);
				schemaRow["ColumnSize"]		= sqlvar[i].sqllen;				
				if(IsNumeric(i))
				{
					schemaRow["NumericPrecision"]= sqlvar[i].sqllen;
					schemaRow["NumericScale"]	 = sqlvar[i].sqlscale;
				}
				else
				{
					schemaRow["NumericPrecision"]= System.DBNull.Value;
					schemaRow["NumericScale"]	 = System.DBNull.Value;
				}
				schemaRow["DataType"]		= FbField.GetSystemTypeFromFbType(sqlvar[i].sqltype,
				                                                         	  sqlvar[i].sqlscale,
				                                                         	  sqlvar[i].sqlsubtype);
				schemaRow["ProviderType"]	= sqlvar[i].sqltype;
				schemaRow["IsLong"]			= IsLong(i);
				schemaRow["AllowDBNull"]	= AllowDBNull(i);
				schemaRow["IsReadOnly"]		= IsReadOnly(i);
				schemaRow["IsUnique"]		= IsUnique(i);				
				schemaRow["IsKeyColumn"]	= IsKey(i);				
				schemaRow["IsAutoIncrement"]= false;
				schemaRow["BaseSchemaName"]	= null;
				schemaRow["BaseCatalogName"]= null;
				schemaRow["BaseTableName"]	= sqlvar[i].relname;
				schemaRow["BaseColumnName"]	= sqlvar[i].aliasname;

				schemaTable.Rows.Add(schemaRow);
			}

			return schemaTable;
		}

		#endregion

		#region IDATARECORD_PROPERTIES_METHODS
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:FieldCount"]/*'/>
		public int FieldCount
		{
			get{ return command.Statement.OutSqlda.sqld; }
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetName(System.Int32)"]/*'/>
		public String GetName(int i)
		{
			return command.Statement.OutSqlda.sqlvar[i].aliasname;			
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDataTypeName(System.Int32)"]/*'/>
		public String GetDataTypeName(int i)
		{
			if(log!=null) log.Debug("GetDataTypeName");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return FbField.GetFbTypeName(
						command.Statement.OutSqlda.sqlvar[i].sqltype,
						command.Statement.OutSqlda.sqlvar[i].sqlscale,
						command.Statement.OutSqlda.sqlvar[i].sqlsubtype);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetFieldType(System.Int32)"]/*'/>
		public Type GetFieldType(int i)
		{			
			if(log!=null) log.Debug("GetFieldType");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return FbField.GetSystemTypeFromFbType(
						command.Statement.OutSqlda.sqlvar[i].sqltype,
						command.Statement.OutSqlda.sqlvar[i].sqlscale,
						command.Statement.OutSqlda.sqlvar[i].sqlsubtype);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetValue(System.Int32)"]/*'/>
		public Object GetValue(int i)
		{
			if(log!=null) log.Debug("GetValue");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			if(row[i] == null)
				return System.DBNull.Value;

			switch (command.Statement.OutSqlda.sqlvar[i].sqltype & ~1)
			{
				case GDSValues.SQL_TEXT:
				case GDSValues.SQL_VARYING:
					// Char
					// Varchar
					return GetString(i);

				case GDSValues.SQL_SHORT:
					// Short/Smallint
					if(command.Statement.OutSqlda.sqlvar[i].sqlscale < 0)
						return GetDecimal(i);
					else
						return GetInt16(i);

				case GDSValues.SQL_LONG:
					// Long
					if(command.Statement.OutSqlda.sqlvar[i].sqlscale < 0)
						return GetDecimal(i);
					else
						return GetInt32(i);
				
				case GDSValues.SQL_FLOAT:
					// Float
					return GetFloat(i);
									
				case GDSValues.SQL_DOUBLE:
				case GDSValues.SQL_D_FLOAT:
					// Doble
					return GetDouble(i);
								
				case GDSValues.SQL_BLOB:
					// Blob binary
					if (command.Statement.OutSqlda.sqlvar[i].sqlsubtype == 1)
						return GetClobData((long)row[i]);
					else
						return GetBlobData((long)row[i]);
				
				case GDSValues.SQL_ARRAY:
					// Array
					return row[i];

				case GDSValues.SQL_QUAD:
				case GDSValues.SQL_INT64:
					if(command.Statement.OutSqlda.sqlvar[i].sqlscale < 0)
						return GetDecimal(i);
					else
						return GetInt64(i);
									
				case GDSValues.SQL_TIMESTAMP:
				case GDSValues.SQL_TYPE_TIME:			
				case GDSValues.SQL_TYPE_DATE:				
					// Timestamp, Time and Date
					return GetDateTime(i);
					
				default:
					throw new NotSupportedException("Unknown data type");
			}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetValues(System.Object[])"]/*'/>
		public int GetValues(object[] values)
		{
			if(log!=null) log.Debug("GetValues");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			for(int i=0;i<FieldCount;i++)
			{
				values[i] = this.GetValue(i);
			}

			return row.Length;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetOrdinal(System.String)"]/*'/>
		public int GetOrdinal(string name)
		{
			if(log!=null) log.Debug("GetOrdinal");

			if(IsClosed)
				throw new InvalidOperationException("Reader closed");

			XSQLDA sqlda = command.Statement.OutSqlda;

			for (int i=0;i<FieldCount;i++)
			{
				if (0 == _cultureAwareCompare(name, sqlda.sqlvar[i].sqlname))
				{
					return i;
				}
			}
						
			throw new IndexOutOfRangeException("Could not find specified column in results");
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:Item(System.Int32)"]/*'/>
		public object this [ int i ]
		{
			get { 
				if(i < 0 || i >= FieldCount)
					throw new InvalidOperationException("Invalid column number");

				return row[i]; 
				}
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="P:Item(System.String)"]/*'/>
		public object this [ String name ]
		{			
			get { return this[GetOrdinal(name)]; }
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetBoolean(System.Int32)"]/*'/>
		public bool GetBoolean(int i)
		{
			if(log!=null) log.Debug("GetBoolean");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return (bool)row[i];
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetByte(System.Int32)"]/*'/>
		public byte GetByte(int i)
		{
			if(log!=null) log.Debug("GetByte");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return (byte)row[i];
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetBytes(System.Int32,System.Int64,System.Byte[],System.Int32,System.Int32)"]/*'/>
		public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
		{
			if(log!=null) log.Debug("GetBytes");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			throw new NotSupportedException("GetBytes not supported.");
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetChar(System.Int32)"]/*'/>
		public char GetChar(int i)
		{
			if(log!=null) log.Debug("GetChar");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");
			
			return Char.Parse(row[i].ToString());
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetChars(System.Int32,System.Int64,System.Char[],System.Int32,System.Int32)"]/*'/>
		public long GetChars(int i, long fieldOffset, char[] buffer, int bufferoffset, int length)
		{
			if(log!=null) log.Debug("GetChars");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			throw new NotSupportedException("GetChars not supported.");
		}
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetGuid(System.Int32)"]/*'/>
		public Guid GetGuid(int i)
		{
			if(log!=null) log.Debug("GetGuid");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return (Guid)row[i];
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetInt16(System.Int32)"]/*'/>
		public Int16 GetInt16(int i)
		{
			if(log!=null) log.Debug("GetInt16");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return Int16.Parse(row[i].ToString());
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetInt32(System.Int32)"]/*'/>
		public Int32 GetInt32(int i)
		{
			if(log!=null) log.Debug("GetInt32");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return Int32.Parse(row[i].ToString());
		}
		
		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetInt64(System.Int32)"]/*'/>
		public Int64 GetInt64(int i)
		{
			if(log!=null) log.Debug("GetInt64");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return Int64.Parse(row[i].ToString());
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetFloat(System.Int32)"]/*'/>
		public float GetFloat(int i)
		{
			if(log!=null) log.Debug("GetFloat");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return float.Parse(row[i].ToString());
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDouble(System.Int32)"]/*'/>
		public double GetDouble(int i)
		{
			if(log!=null) log.Debug("GetDouble");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return Double.Parse(row[i].ToString());
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetString(System.Int32)"]/*'/>
		public String GetString(int i)
		{
			if(log!=null) log.Debug("GetString");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			if(!IsDBNull(i))
				return Encoding.Default.GetString((byte[])row[i]);
			else
				return null;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDecimal(System.Int32)"]/*'/>
		public Decimal GetDecimal(int i)
		{
			long	divisor = 1;
			decimal returnValue;

			if(log!=null) log.Debug("GetDecimal");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			if(command.Statement.OutSqlda.sqlvar[i].sqlscale<0)
			{
				int exp = command.Statement.OutSqlda.sqlvar[i].sqlscale*(-1);
				divisor = (long)System.Math.Pow(10, exp);
			}
			
			switch (command.Statement.OutSqlda.sqlvar[i].sqltype & ~1)
			{
				case GDSValues.SQL_SHORT:
					// Short/Smallint
					returnValue = Int16.Parse(row[i].ToString())/divisor;
					break;

				case GDSValues.SQL_LONG:
					// Long
					returnValue = Int32.Parse(row[i].ToString())/divisor;
					break;
											
				case GDSValues.SQL_DOUBLE:
					// Double
					returnValue = Decimal.Parse(row[i].ToString());
					break;					

				case GDSValues.SQL_QUAD:
				case GDSValues.SQL_INT64:
					// BigInt
					returnValue = Int64.Parse(row[i].ToString())/divisor;
					break;

				default:
					returnValue = Decimal.Parse(row[i].ToString());					
					break;
			}

			return returnValue;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetDateTime(System.Int32)"]/*'/>
		public DateTime GetDateTime(int i)
		{
			if(log!=null) log.Debug("GetDateTime");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return DateTime.Parse(row[i].ToString());
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetData(System.Int32)"]/*'/>
		public IDataReader GetData(int i)
		{
			if(log!=null) log.Debug("GetData");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			throw new NotSupportedException("GetData not supported.");
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsDBNull(System.Int32)"]/*'/>
		public bool IsDBNull(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");

			if(position == STARTPOS)
				throw new InvalidOperationException("There are no data to read.");

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			// return row[i] == null;
			return command.Statement.OutSqlda.sqlvar[i].sqlind == -1 ? true : false;
		}

		#endregion

		#region SPECIFIC_METHODS

		private int _cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB, CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.IgnoreCase);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetClob(System.Int64)"]/*'/>
		private string GetClobData(long clob_id)
		{
			FbClob clob = new FbClob(command.Connection, command.Transaction, clob_id);			

			return clob.Read();
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetBlob(System.Int64)"]/*'/>
		private object[] GetBlobData(long blob_id)
		{
			FbBlob blob = new FbBlob(command.Connection, command.Transaction, blob_id);

			return blob.Read();
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsNumeric(System.Int32)"]/*'/>
		private bool IsNumeric(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");

			XSQLDA sqlda = command.Statement.OutSqlda;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return FbField.IsNumeric(command.Statement.OutSqlda.sqlvar[i].sqltype);			
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsLong(System.Int32)"]/*'/>
		private bool IsLong(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");

			XSQLDA sqlda = command.Statement.OutSqlda;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");

			return FbField.IsLong(command.Statement.OutSqlda.sqlvar[i].sqltype);			
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsKey(System.Int32)"]/*'/>
		private bool IsKey(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return FbField.IsKey(
					command.Connection,
					null, null,
					sqlvar[i].relname,
					sqlvar[i].aliasname);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsUnique(System.Int32)"]/*'/>
		private bool IsUnique(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return FbField.IsUnique(
				command.Connection,
				null, null,
				sqlvar[i].relname,
				sqlvar[i].aliasname);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:IsReadOnly(System.Int32)"]/*'/>
		private bool IsReadOnly(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return FbField.IsReadOnly(
				command.Connection,
				null, null,
				sqlvar[i].relname,
				sqlvar[i].aliasname);
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:AllowDBNull(System.Int32)"]/*'/>
		private bool AllowDBNull(int i)
		{	
			if(log!=null) log.Debug("IsDbNull");
			
			XSQLVAR[] sqlvar = command.Statement.OutSqlda.sqlvar;

			if(i < 0 || i >= FieldCount)
				throw new InvalidOperationException("Invalid column number");			

			return (sqlvar[i].sqltype & 1) == 1 ? true : false;
		}

		/// <include file='xmldoc/fbdatareader.xml' path='doc/member[@name="M:GetSchemaTableStructure"]/*'/>
		private DataTable GetSchemaTableStructure()
		{
			DataTable  schemaStruct = new DataTable("Schema");			

			// Schema table structure
			schemaStruct.Columns.Add("ColumnName", System.Type.GetType("System.String"));
			schemaStruct.Columns.Add("ColumnOrdinal", System.Type.GetType("System.Int32"));
			schemaStruct.Columns.Add("ColumnSize", System.Type.GetType("System.Int32"));
			schemaStruct.Columns.Add("NumericPrecision", System.Type.GetType("System.Int32"));
			schemaStruct.Columns.Add("NumericScale", System.Type.GetType("System.Int32"));
			schemaStruct.Columns.Add("DataType", System.Type.GetType("System.Type"));
			schemaStruct.Columns.Add("ProviderType", System.Type.GetType("System.Int32"));			
			schemaStruct.Columns.Add("IsLong", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("AllowDBNull", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("IsReadOnly", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("IsRowVersion", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("IsUnique", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("IsKeyColumn", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("IsAutoIncrement", System.Type.GetType("System.Boolean"));
			schemaStruct.Columns.Add("BaseSchemaName", System.Type.GetType("System.String"));
			schemaStruct.Columns.Add("BaseCatalogName", System.Type.GetType("System.String"));
			schemaStruct.Columns.Add("BaseTableName", System.Type.GetType("System.String"));
			schemaStruct.Columns.Add("BaseColumnName", System.Type.GetType("System.String"));
			
			return schemaStruct;
		}

		#endregion
	}
}
