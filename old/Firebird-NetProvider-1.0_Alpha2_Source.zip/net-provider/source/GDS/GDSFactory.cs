//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// The class <code>GDSFactory</code> exists to provide a way
	/// to obtain objects implementing GDS and Clumplet.
	/// </summary>
	internal class GDSFactory 
	{
		#region METHODS

		/// <summary>
		/// Creates a new instance of the GDS Implementation
		/// </summary>
		/// <returns>A new GDS instance</returns>
		public static IGDS NewGDS() 
		{
			return new GDS();
		}

		/// <summary>
		/// Creates a new instance of the Clumplet Implementation
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="content">Contents</param>
		/// <returns>A new Clumplet instance</returns>
		public static IClumplet NewClumplet(int type, string content) 
		{
			return GDS.NewClumplet(type, content);
		}

		/// <summary>
		/// Creates a new instance of the Clumplet Implementation
		/// </summary>
		/// <param name="type">Type</param>
		/// <returns>A new Clumplet instance</returns>
		public static IClumplet NewClumplet(int type)
		{
			return GDS.NewClumplet(type);
		}
		
		/// <summary>
		/// Creates a new instance of the Clumplet Implementation
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="c">Clumplet instance</param>
		/// <returns>A new Clumplet instance</returns>
		public static IClumplet NewClumplet(int type, int c)
		{
			return GDS.NewClumplet(type, c);
		}

		/// <summary>
		/// Creates a new instance of the Clumplet Implementation
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="content">Contents</param>
		/// <returns>A new Clumplet instance</returns>
		public static IClumplet NewClumplet(int type, byte[] content) 
		{
			return GDS.NewClumplet(type, content);
		}

		/// <summary>
		/// Clone a clumplet instance
		/// </summary>
		/// <param name="c">Clumplet instance to clone</param>
		/// <returns>A new Clumplet instance</returns>
		public static IClumplet CloneClumplet(IClumplet c) 
		{
			return GDS.CloneClumplet(c);
		}

		#endregion
	}
}
