//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Resources;
using System.Text;
using System.Threading;
using System.Reflection;
using System.Collections;

using FirebirdSql.Logging;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// This class is supposed to return messages for the specified error code.
	/// It loads all messages during the class initialization and keeps messages
	/// in the static <code>java.util.Properties</code> variable.
	/// </summary>
	internal class GDSExceptionHelper 
	{
		#region FIELDS

		private static Logger log;

		private static string MESSAGES = "isc_error_msg";
		private static ResourceManager rm;

		private static bool initialized = false;
		#endregion
		
		#region CONSTRUCTORS

		public GDSExceptionHelper()
		{
			log = LoggerFactory.GetLogger(this.GetType(), false);			
		}

		#endregion

		#region METHODS

		/// <summary>
		/// This method initializes the messages map.
		/// </summary>
		private static void Init()
		{			
			try 
			{												
				rm = new ResourceManager(MESSAGES,
									Assembly.GetExecutingAssembly());
			} 
			catch (Exception ex)
			{				
				if (log!=null) log.info("Exception in init of GDSExceptionHelper", ex);
			} 
			finally 
			{
				initialized = true;
			}
		}
		
		/// <summary>
		/// This method returns a message for the specified error code.
		/// </summary>
		/// <param name="code">Firebird error code</param>
		/// <returns>instance of <code>GDSExceptionHelper.GDSMesssage</code> class</returns>
		public static GDSMessage GetMessage(int code)
		{
			string message = null;

			if (!initialized) 
				Init();

			try
			{
				message = rm.GetString(code.ToString());			
			}
			catch(Exception ex)
			{		
				if (log!=null) log.info("Exception in GetMessage", ex);
			}
			finally
			{
				if(message==null)
					message = "No message for code " + code.ToString() + " found.";
			}

			return new GDSMessage(message);
		}
		#endregion
	}
	
	/// <summary>
	/// This class wraps message template obtained from isc_error_msg.properties
	/// file and allows to set parameters to the message.
	/// </summary>
	internal class GDSMessage 
	{
		#region FIELDS

		private string format;
		private ArrayList parameters = new ArrayList();

		#endregion

		#region METHODS

		/// <summary>
		/// Constructs an instance of GDSMessage for the specified template.
		/// </summary>
		/// <param name="format">Formato del mensaje</param>
		public GDSMessage(string format)
		{
			this.format = format;
		}

		/// <summary>
		/// Returns the number of parameters for the message template.
		/// </summary>
		/// <returns></returns>
		public int GetParamCount() 
		{
			int count = 0;

			if(format==null)
				format="";

			for(int i = 0; i < format.Length; i++)
				if (format[i] == '{') 
					count++;

			return count;
		}
			
		/// <summary>
		/// Sets the parameter value
		/// </summary>
		/// <param name="position">the parameter number, 0 - first parameter.</param>
		/// <param name="text">value of parameter</param>
		public void SetParameter(int position, string text) 
		{
			parameters.Add(text);
		}
			
		/// <summary>
		/// Substs the parameters in the format string and retuns the message as a string.
		/// </summary>
		/// <returns>The message as a string</returns>
		public override string ToString() 
		{
			StringBuilder message = new StringBuilder();
			
			if(parameters.Count == GetParamCount())
				message.AppendFormat(format, parameters.ToArray());
			else
				message.Append(format);

			return message.ToString();
		}

		#endregion
	}
}
