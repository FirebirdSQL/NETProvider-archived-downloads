//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.INGDS
{	
	/// <summary>
	/// The class <code>SqlInfo</code> interprets return info from the server
	/// into update, insert, and delete counts.
	/// </summary>
	internal class SqlInfo 
	{
		#region FIELDS
		private int statementType;
		private int insertCount;
		private int updateCount;
		private int deleteCount;
		private int selectCount;
		#endregion

		#region PROPERTIES
		/// <summary>
		/// Gets a value that represents the Statement Type
		/// </summary>		
		public int StatementType
		{
			get{return statementType;}
		}

		/// <summary>
		/// Gets a value that represents the number of inserts
		/// </summary>
		public int InsertCount
		{
			get{return insertCount;}
		}

		/// <summary>
		/// Gets a value that represents the number of updates
		/// </summary>
		public int UpdateCount
		{
			get{return updateCount;}
		}

		/// <summary>
		/// Gets a value that represents the number of deletes
		/// </summary>
		public int DeleteCount
		{
			get{return deleteCount;}
		}

		/// <summary>
		/// Gets a value that represents the number of rows ????
		/// </summary>		
		public int SelectCount
		{
			get{return selectCount;}
		}
		#endregion

		#region CONSTRUCTORS
		
		/// <summary>
		/// Initializes a new instance of the SqlInfo class
		/// </summary>
		/// <param name="buffer">Buffer with the information</param>
		/// <param name="gds">And GDSImpl object</param>
		public SqlInfo(byte[] buffer, IGDS gds) 
		{
			int pos = 0;
			int length;
			int type;
			while ((type = buffer[pos++]) != GDSValues.isc_info_end) 
			{
				length = gds.isc_vax_integer(buffer, pos, 2);
				pos += 2;
				switch (type) 
				{
					case GDSValues.isc_info_sql_records:
						int l;
						int t;
						while ((t = buffer[pos++]) != GDSValues.isc_info_end) 
						{
							l = gds.isc_vax_integer(buffer, pos, 2);
							pos += 2;
							switch (t) 
							{
								case GDSValues.isc_info_req_insert_count:
									insertCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								case GDSValues.isc_info_req_update_count:
									updateCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								case GDSValues.isc_info_req_delete_count:
									deleteCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								case GDSValues.isc_info_req_select_count:
									selectCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								default:
									break;
							}
							pos += l;
						}
						break;
					
					case GDSValues.isc_info_sql_stmt_type:
						statementType = gds.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;
					
					default:
						pos += length;
						break;
				}
			}
		}
		
		#endregion 
	}
}
