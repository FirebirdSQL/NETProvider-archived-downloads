//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// The class <code>XSQLDA</code> is a c# mapping of the XSQLDA server 
	/// data structure used to represent one row for input and output.
	/// </summary>
	///
	internal class XSQLDA 
	{
		#region FIELDS
		/// <summary>
		/// Version
		/// </summary>
		public int version;
		/// <summary>
		/// Number of retrieved fields 
		/// </summary>
		public int sqln;
		/// <summary>
		/// Number of real fields
		/// </summary>
		public int sqld;
		/// <summary>
		/// Fields information
		/// </summary>
		public XSQLVAR[] sqlvar;
		#endregion

		#region CONSTRUCTORS
		/// <summary>
		/// Constructor
		/// </summary>
		public XSQLDA() 
		{
			version = GDSValues.SQLDA_VERSION1;
		}

		/// <summary>
		/// Initializes a new instance of the XSQLDA class
		/// </summary>
		/// <param name="n">Number of fields</param>
		/// <seealso cref="XSQLVAR"/>
		public XSQLDA(int n) 
		{
			version = GDSValues.SQLDA_VERSION1;
			sqln	= n;
			sqld	= n;
			sqlvar	= new XSQLVAR[n];
		}
		#endregion
	}
}
