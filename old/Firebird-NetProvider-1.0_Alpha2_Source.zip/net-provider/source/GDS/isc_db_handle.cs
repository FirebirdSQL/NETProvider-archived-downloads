//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.Security.Principal;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// The interface <code>isc_db_handle</code> represents a socket connection
	/// to the database server.
	/// </summary>
	internal interface isc_db_handle 
	{
		/// <summary>
		/// Not supported.
		/// </summary>
		GenericIdentity Subject
		{
			get;
		}

		/// <summary>
		/// Checks if have transactions opened
		/// </summary>		
		bool HasTransactions();		

		/// <summary>
		/// Gets the number of transactions opened
		/// </summary>		
		int TransactionsOpened();

		/// <summary>		
		/// Get list of warnings that were returned by the server.
		/// </summary>
		/// <returns>
		/// Instance of ArraytList containing instances of 
		/// - GDSException. Representing server warnings 
		/// (method GDSException#isWarning()} returns <code>true</code>).
		/// </returns>
		ArrayList GetWarnings();

		/// <summary>
		/// Clear warning list associated with this connection.
		/// </summary>		 
		void ClearWarnings();		
	}
}
