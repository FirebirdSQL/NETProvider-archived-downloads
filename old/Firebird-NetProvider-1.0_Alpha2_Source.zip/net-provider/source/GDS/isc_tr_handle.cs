//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.INGDS
{
	/// <summary>
	/// Transaction States
	/// </summary>
	internal class isc_tr_values
	{
		public static int NOTRANSACTION			= 0;
		public static int TRANSACTIONSTARTING	= 1;
		public static int TRANSACTIONSTARTED	= 2;
		public static int TRANSACTIONPREPARING	= 3;
		public static int TRANSACTIONPREPARED	= 4;
		public static int TRANSACTIONCOMMITTING	= 5;
		public static int TRANSACTIONROLLINGBACK = 6;
	}

	/// <summary>
	/// The interface <code>isc_tr_handle</code> represents a transaction handle.
	/// </summary>
	internal interface isc_tr_handle
	{	
		/// <summary>
		/// Gets or Sets a value representing the database handler associated 
		/// with the transaction
		/// </summary>
		isc_db_handle DbHandle
		{
			get;
			set;
		}

		/// <summary>
		/// Gets a value representing the Transaction state.
		/// </summary>
		int State
		{
			get;
		}
	}
}
