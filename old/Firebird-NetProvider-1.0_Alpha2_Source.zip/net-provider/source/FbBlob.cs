//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbblob.xml' path='doc/member[@name="T:FbBlob"]/*'/>
	internal sealed class FbBlob : Blob
	{
		#region CONSTRUCTORS
	
		/// <include file='xmldoc/fbblob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction,System.Int64)"]/*'/>
		public FbBlob(IDbConnection connection, IDbTransaction transaction, long blobId):
				base(connection,transaction,blobId)
		{
		}

		/// <include file='xmldoc/fbblob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction)"]/*'/>
		public FbBlob(IDbConnection connection, IDbTransaction transaction):
			base(connection,transaction)
		{
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbblob.xml' path='doc/member[@name="M:Read(System.Int64)"]/*'/>
		public object[] Read()
		{
			ArrayList data					 = new ArrayList();
			isc_blob_handle_impl blob_handle = null;
						
			try
			{
				blob_handle = Open();
			
				while (!blob_handle.IsEof())
				{
					byte[] blobData = GetSegment(blob_handle);					

					data.Add (blobData);
				}

				Close(blob_handle);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
			finally
			{
				if(blob_handle != null)
					Close(blob_handle);
			}

			return data.ToArray();
		}

		/// <include file='xmldoc/fbblob.xml' path='doc/member[@name="M:Write(System.String)"]/*'/>
		public long Write(byte[] data)
		{
			long returnValue;
			isc_blob_handle_impl blob_handle = null;

			try
			{
				blob_handle = Create();
				
				byte[]	tmpBuffer = null;

				int	length	= data.Length;
				int	offset	= 0;
				int	chunk	= length >= this.MaxSegmentSize ? this.MaxSegmentSize : length;

				tmpBuffer = new byte[chunk];
				
				while (length > 0)
				{					
					if (chunk > length) 
					{
						chunk	  = (int)length;
						tmpBuffer = new byte[chunk];
					}					
					System.Array.Copy(data, offset, tmpBuffer, 0, chunk);					
					PutSegment(blob_handle, tmpBuffer);
					
					offset += chunk;					
					length -= chunk;
				}

				returnValue = blob_handle.blob_id;
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
			finally
			{
				if(blob_handle != null)
					Close(blob_handle);
			}

			return returnValue;
		}

		#endregion
	}
}
