//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{	
	/// <summary>
	/// Implementation of <code>isc_blob_handle</code> interface. 
	/// <seealso cref="isc_blob_handle"/>
	/// </summary>
	internal class isc_blob_handle_impl : isc_blob_handle 
	{
		#region FIELDS

		internal isc_db_handle_impl	 db;
		internal isc_tr_handle_impl	 tr;
		// internal isc_blob_handle_impl next;

		internal int	rbl_id;
		internal long	blob_id;		
		internal int	rbl_flags;

		#endregion

		#region PROPERTIES

		/// <summary>
		/// Gets a value indicating the Blob ID
		/// </summary>
		public long BlobId
		{
			get{return blob_id;}
			set{blob_id=value;}			
		}

		#endregion

		#region CONSTRUCTORS

		/// <summary>
		/// Initializrs a new instance of isc_blob_handle_impl class.
		/// </summary>
		internal isc_blob_handle_impl() 
		{
		}

		#endregion

		#region METHODS

		/// <summary>
		/// Checks if exist more data for the blob.
		/// </summary>
		/// <returns>True if exist more data or false if no</returns>
		public bool IsEof()
		{
			return (rbl_flags & GDSValues.RBL_eof_pending) != 0;
		}

		#endregion
	}
}
