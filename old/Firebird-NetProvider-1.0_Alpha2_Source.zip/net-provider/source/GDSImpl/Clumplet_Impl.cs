//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Runtime.Serialization;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <summary>
	/// Implementation of <code>IClumplet</code> interface.	
	/// </summary>
	/// <remarks>
	/// Format of a clumplet:
	///		type	 - 1 byte
	///		length	 - 1 byte
	///		contents - length bytes.
	/// </remarks>
	[Serializable()]
	internal class ClumpletImpl : IClumplet, IXdrable 
	{
		#region FIELDS

		/// <summary>
		/// Clumplet Type
		/// </summary>
		internal int			type;
		/// <summary>
		/// Clumplet Contents
		/// </summary>
		internal byte[]			content;
		/// <summary>
		/// Next Clumplet
		/// </summary>
		internal ClumpletImpl	next;

		#endregion

		#region PROPERTIES

		/// <summary>
		/// Clumplet Length
		/// </summary>
		public int Length
		{
			get
			{
				if (next == null)
				{
					return content.Length + 2;
				}
				else
				{
					return content.Length + 2 + next.Length;
				}
			}
		}

		#endregion

		#region CONSTRUCTORS

		/// <summary>
		/// Constructor - Internal, don't allow instances
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="content">Contents</param>
		internal ClumpletImpl(int type, byte[] content) 
		{
			this.type = type;
			this.content = content;
		}

		/// <summary>
		/// Constructor - Internal, don't allow instances
		/// </summary>
		/// <param name="c">Clumplet instance</param>
		internal ClumpletImpl(ClumpletImpl c) 
		{
			this.type = c.type;
			this.content = c.content;
			if (c.next != null) 
			{
				this.next = new ClumpletImpl(c.next);
			}
		}

		#endregion

		#region METHODS
		
		/// <summary>
		/// Append a clumplet
		/// </summary>
		/// <param name="c">Clumplet instance</param>
		/// <remarks>
		/// not a very safe implementation, only works for one unchained clumplet.
		/// </remarks>
		public void Append(IClumplet c) 
		{
			ClumpletImpl ci = (ClumpletImpl)c;
			if (this.type == ci.type) 
			{
				this.content = ci.content;
			}
			else if (next == null) 
			{
				next = ci;
			}
			else 
			{
				next.Append(c);
			}
		}

		/// <summary>
		/// Find a clumplet
		/// </summary>
		/// <param name="type">Clumplet Type</param>
		/// <returns>The contents of the Clumplet</returns>
		public byte[] Find(int type)
		{
			if (type == this.type) 
			{
				return content;        
			}
			if (next == null) 
			{
				return null;        
			}

			return next.Find(type);
		}
		
		/// <summary>
		/// Write the contents of the Clumplet on the Stream
		/// </summary>
		/// <param name="output"></param>
		/// <remarks>IXdrable</remarks>
		public void write(XdrOutputStream output)
		{
			output.Write((byte)type);
			output.Write((byte)content.Length);
			output.Write(content);
			if (next != null) 
			{
				next.write(output);
			}
		}
		
		/// <summary>		
		/// </summary>
		/// <param name="input"></param>
		/// <param name="length"></param>
		/// <remarks>IXdrable</remarks>
		public void read(XdrInputStream input, int length) 
		{
		}

		/// <summary>
		/// Make a comparision with other Clumplet
		/// </summary>
		/// <param name="o">Clumplet instance</param>
		/// <returns>True if object are equal or false if not</returns>
		public override bool Equals(object o) 
		{
			if ((o == null) || !(o is ClumpletImpl))
			{
				return false;
			}
			ClumpletImpl c = (ClumpletImpl)o;
			if (type != c.type || !Array.Equals(content, c.content)) 
			{				
				return false;	// these have different contents
			}
			if (next != null) 
			{
				return next.Equals(c.next);	// we have next, compare with c.next
			}
			return (c.next == null);	// contents the same, we have no next, == if c has no next.
		}

		/// <summary>
		/// Gets the hash of the Clumplet
		/// </summary>
		/// <returns>The hash code</returns>
		public override int GetHashCode() 
		{
			int arrayhash = type;
			for (int i = 0; i< content.Length; i++) 
			{
				arrayhash ^= ((int)content[i])<<(8 * (i % 4));
			}
			if (next != null) 
			{
				arrayhash ^= next.GetHashCode();
			}
			return arrayhash;
		}

		#endregion
	}
}
