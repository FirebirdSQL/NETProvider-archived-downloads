//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.Net.Sockets;
using System.Security.Principal;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <summary>
	/// Implementatio of <code>isc_db_handle</code> interface
	/// <seealso cref="isc_db_handle"/>
	/// </summary>
	internal class isc_db_handle_impl : isc_db_handle 
	{
		#region FIELDS

		private int				rdb_id;
		private GenericIdentity subject;
		private ArrayList		rdb_transactions = new ArrayList();
		private ArrayList 		rdb_warnings 	 = new ArrayList();
		
		internal ArrayList		rdb_sql_requests = new ArrayList();		
		internal TcpClient		socket = null;
		internal NetworkStream	networkStream = null;
		internal XdrOutputStream output;		
		internal XdrInputStream input;
		internal int			op = -1;

		#endregion

		#region PROPERTIES

		/// <summary>
		/// Gets a value representing the Database handler ID
		/// </summary>
		public int Rdb_id
		{
			get{return rdb_id;}
			set{rdb_id=value;}
		}

		/// <summary>
		/// Not supported.
		/// </summary>
		public GenericIdentity Subject
		{
			get{return subject;}
			set{subject=value;}
		}

		public ArrayList Transactions
		{
			get{ return rdb_transactions; }
		}

		#endregion

		#region CONSTRUCTORS

		/// <summary>
		/// Initializes a new instance of isc_db_handle_impl class.
		/// </summary>
		public isc_db_handle_impl() 
		{
		}

		#endregion

		#region METHODS

		/// <summary>
		/// Checks if exist opened transactions.
		/// </summary>
		/// <returns>True if are transactions opened or false if not</returns>
		public bool HasTransactions()
		{
			return rdb_transactions.Count == 0 ? false : true;
		}

		/// <summary>
		/// Gets a value representing the number of opened transactions
		/// </summary>
		/// <returns>The number of opened transaction</returns>
		public int TransactionsOpened()
		{
			return rdb_transactions.Count;
		}

		/// <summary>
		/// Adds a transacion handler
		/// </summary>
		/// <param name="tr">Transaction handler</param>
		public void AddTransaction(isc_tr_handle_impl tr)
		{
			rdb_transactions.Add(tr);
		}

		/// <summary>
		/// Removes a tranbsaction handler
		/// </summary>
		/// <param name="tr">Transaction handler</param>
		public void RemoveTransaction(isc_tr_handle_impl tr)
		{
			rdb_transactions.Remove(tr);
		}
		
		/// <summary>
		/// Get server Warnings
		/// </summary>
		/// <returns>An ArrayList object with the server Warnings</returns>
		public ArrayList GetWarnings() 
		{
			lock(rdb_warnings) 
			{
				return new ArrayList(rdb_warnings);
			}
		}
		
		/// <summary>
		/// Adds a warning
		/// </summary>
		/// <param name="warning">An GDSException object representing the Warning</param>
		public void AddWarning(GDSException warning) 
		{
			lock(rdb_warnings) 
			{
				rdb_warnings.Add(warning);
			}
		}
		
		/// <summary>
		/// Clear all server warnings
		/// </summary>
		public void ClearWarnings() 
		{
			lock(rdb_warnings) 
			{
				rdb_warnings.Clear();
			}
		}
		
		#endregion
	}
}
