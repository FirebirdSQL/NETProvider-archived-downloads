//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Globalization;
using System.Net;
using System.Net.Sockets;

using FirebirdSql.Logging;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <summary>
	/// Implementation of IGDS interface
	/// <seealso cref="IGDS"/>
	/// </summary>
	internal class GDS : GDSValues, IGDS
	{
		#region CONSTANTS

		// Operation (packet) types

		internal const int op_void                = 0;    // Packet has been voided
		internal const int op_connect             = 1;    // Connect to remote server
		internal const int op_exit                = 2;    // Remote end has exitted
		internal const int op_accept              = 3;    // Server accepts connection
		internal const int op_reject              = 4;    // Server rejects connection
		internal const int op_protocol            = 5;    // Protocol selection
		internal const int op_disconnect          = 6;    // Connect is going away
		internal const int op_credit              = 7;    // Grant (buffer) credits
		internal const int op_continuation        = 8;    // Continuation packet
		internal const int op_response            = 9;    // Generic response block

		// Page server operations

		internal const int op_open_file           = 10;   // Open file for page service
		internal const int op_create_file         = 11;   // Create file for page service
		internal const int op_close_file          = 12;   // Close file for page service
		internal const int op_read_page           = 13;   // optionally lock and read page
		internal const int op_write_page          = 14;   // write page and optionally release lock
		internal const int op_lock                = 15;   // sieze lock
		internal const int op_convert_lock        = 16;   // convert existing lock
		internal const int op_release_lock        = 17;   // release existing lock
		internal const int op_blocking            = 18;   // blocking lock message

		// Full context server operations

		internal const int op_attach              = 19;   // Attach database
		internal const int op_create              = 20;   // Create database
		internal const int op_detach              = 21;   // Detach database
		internal const int op_compile             = 22;   // Request based operations
		internal const int op_start               = 23;
		internal const int op_start_and_send      = 24;
		internal const int op_send                = 25;
		internal const int op_receive             = 26;
		internal const int op_unwind              = 27;
		internal const int op_release             = 28;

		internal const int op_transaction         = 29;   // Transaction operations
		internal const int op_commit              = 30;
		internal const int op_rollback            = 31;
		internal const int op_prepare             = 32;
		internal const int op_reconnect           = 33;

		internal const int op_create_blob         = 34;   // Blob operations //
		internal const int op_open_blob           = 35;
		internal const int op_get_segment         = 36;
		internal const int op_put_segment         = 37;
		internal const int op_cancel_blob         = 38;
		internal const int op_close_blob          = 39;

		internal const int op_info_database       = 40;   // Information services
		internal const int op_info_request        = 41;
		internal const int op_info_transaction    = 42;
		internal const int op_info_blob           = 43;

		internal const int op_batch_segments      = 44;   // Put a bunch of blob segments

		internal const int op_mgr_set_affinity    = 45;   // Establish server affinity
		internal const int op_mgr_clear_affinity  = 46;   // Break server affinity
		internal const int op_mgr_report          = 47;   // Report on server

		internal const int op_que_events          = 48;   // Que event notification request
		internal const int op_cancel_events       = 49;   // Cancel event notification request
		internal const int op_commit_retaining    = 50;   // Commit retaining (what else)
		internal const int op_prepare2            = 51;   // Message form of prepare
		internal const int op_event               = 52;   // Completed event request (asynchronous)
		internal const int op_connect_request     = 53;   // Request to establish connection
		internal const int op_aux_connect         = 54;   // Establish auxiliary connection
		internal const int op_ddl                 = 55;   // DDL call
		internal const int op_open_blob2          = 56;
		internal const int op_create_blob2        = 57;
		internal const int op_get_slice           = 58;
		internal const int op_put_slice           = 59;
		internal const int op_slice               = 60;   // Successful response to internal const int op_get_slice
		internal const int op_seek_blob           = 61;   // Blob seek operation

		// DSQL operations //

		internal const int op_allocate_statement  = 62;   // allocate a statment handle
		internal const int op_execute             = 63;   // execute a prepared statement
		internal const int op_exec_immediate      = 64;   // execute a statement
		internal const int op_fetch               = 65;   // fetch a record
		internal const int op_fetch_response      = 66;   // response for record fetch
		internal const int op_free_statement      = 67;   // free a statement
		internal const int op_prepare_statement   = 68;   // prepare a statement
		internal const int op_set_cursor          = 69;   // set a cursor name
		internal const int op_info_sql            = 70;

		internal const int op_dummy               = 71;   // dummy packet to detect loss of client

		internal const int op_response_piggyback  = 72;   // response block for piggybacked messages
		internal const int op_start_and_receive   = 73;
		internal const int op_start_send_and_receive  = 74;

		internal const int op_exec_immediate2     = 75;   // execute an immediate statement with msgs
		internal const int op_execute2            = 76;   // execute a statement with msgs
		internal const int op_insert              = 77;
		internal const int op_sql_response        = 78;   // response from execute; exec immed; insert

		internal const int op_transact            = 79;
		internal const int op_transact_response   = 80;
		internal const int op_drop_database       = 81;

		internal const int op_service_attach      = 82;
		internal const int op_service_detach      = 83;
		internal const int op_service_info        = 84;
		internal const int op_service_start       = 85;

		internal const int op_rollback_retaining  = 86;


		// Temporal response packet data
		/*    
		 * private int resp_object;
		 * private long resp_blob_id;
		 * private byte[] resp_data;
		 */
		
		//8192;//4096; //max size for response for ??
		internal const int MAX_BUFFER_SIZE = 1024;
		// Max number of rows in a fetch batch
		internal const int MAX_FETCH_ROWS = 200;

		#endregion

		#region FIELDS

		// Log
		private Log4CSharp log = null;

		#endregion

		#region CONSTRUCTORS
	    
		/// <summary>
		/// Initializes a new instance of class GDSImpl
		/// </summary>
		public GDS() 
		{			
			#if(_DEBUG)			
				log = new Log4CSharp(GetType(), "fbprov.log", Mode.APPEND);		
			#endif			
		}

		#endregion

		#region DATABASE_METHODS

		/// <summary>
		/// <code>isc_create_database</code> creates a database
		/// based on the file name and Clumplet of database properties
		/// supplied.  The supplied db handle is attached to the
		/// newly created database. 
		/// </summary>
		/// <param name="file_name">
		///		a <code>string</code> the file name,
		///		including host and port, for the database.
		///		The expected format is host:port:path_to_file.
		///		The value for host is localhost if not supplied.
		///		The value for port is 3050 if not supplied.
		///	</param>
		/// <param name="db_handle">
		///		An <code>isc_db_handle</code> The db handle to
		///		attach to the new database.
		///</param>
		///<param name="c">
		///		a <code>Clumplet</code> The parameters for the new database
		///		and the attachment to it.  See docs for dpb (database
		///		parameter block.)
		///	</param>
		/// <exception cref="GDSException">GDSException if an error occurs</exception>
		public void isc_create_database(string file_name,
									isc_db_handle db_handle,
									IClumplet c)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}

			lock(db) 
			{
				DbAttachInfo dbai = new DbAttachInfo(file_name);
				connect(db, dbai);
				try 
				{
					if (log != null) log.Debug("op_create ");

					db.output.WriteInt(op_create);
					db.output.WriteInt(0);           // packet->p_atch->p_atch_database
					db.output.WriteString(dbai.FileName);
					db.output.WriteTyped(isc_dpb_version1, (IXdrable)c);
					db.output.Flush();

					if (log != null) log.Debug("sent");

					try 
					{
						Response r = ReceiveResponse(db);
						db.Rdb_id = r.resp_object;
					} 
					catch (GDSException g) 
					{
						Disconnect(db);
						throw g;
					}
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_write_err);
				}
			}
		}

		public void isc_attach_database(string host,
										int port,
										string file_name,
										isc_db_handle db_handle,
										IClumplet dpb)
		{
			try
			{
				DbAttachInfo dbai = new DbAttachInfo(host, port, file_name);
				isc_attach_database(dbai, db_handle, dpb);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		public void isc_attach_database(string connectstring,
									isc_db_handle db_handle,
									IClumplet dpb)
		{
			try
			{
				DbAttachInfo dbai = new DbAttachInfo(connectstring);
				isc_attach_database(dbai, db_handle, dpb);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <summary>
		/// Attaches to an existing database.
		/// </summary>
		/// <param name="dbai"></param>
		/// <param name="db_handle">
		///		An <code>isc_db_handle</code> The db handle to
		///		attach to the database.
		/// </param>
		/// <param name="dpb"></param>
		public void isc_attach_database(DbAttachInfo dbai,
									isc_db_handle db_handle,
									IClumplet dpb)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}

			lock(db) 
			{
				if (log != null) log.Debug("op_attach ");
				connect(db, dbai);					
				try
				{
					db.output.WriteInt(op_attach);
					db.output.WriteInt(0);                // packet->p_atch->p_atch_database
					db.output.WriteString(dbai.FileName);
					db.output.WriteTyped(isc_dpb_version1, (IXdrable)dpb);
					db.output.Flush();
					if (log != null) log.Debug("sent");

					try 
					{
						Response r = ReceiveResponse(db);
						db.Rdb_id = r.resp_object;						
					}
					catch (GDSException ge) 
					{
						Disconnect(db);
						throw ge;
					}
				} 
				catch (IOException)
				{
					throw new GDSException(isc_net_write_err);
				}
			}
		}

		/// <summary>
		/// Reports requested information about a previously attached database.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="item_length"></param>
		/// <param name="items"></param>
		/// <param name="buffer_length"></param>
		/// <param name="buffer"></param>
		public void isc_database_info(isc_db_handle db_handle,
									int item_length,
									byte[] items,
									int buffer_length,
									byte[] buffer) 
		{
			throw new GDSException(isc_wish_list);
		}

		/// <summary>
		/// Detaches from a database previously connected with 
		/// <code>isc_attach_database()</code>.
		/// <seealso cref="isc_attach_database"/>
		/// </summary>
		/// <param name="db_handle"></param>
		public void isc_detach_database(isc_db_handle db_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}

			lock(db) 
			{
				if (db_handle.HasTransactions()) 
				{
					throw new GDSException(isc_open_trans, db.TransactionsOpened());
				}
	        
				try 
				{
					if (log != null) log.Debug("op_detach ");
					db.output.WriteInt(op_detach);
					db.output.WriteInt(db.Rdb_id);
					db.output.Flush();            
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_network_error);
				}
			}
		}

		/// <summary>
		/// Deletes a currently attached database and all of its supporting files, 
		/// such as secondary database files, write-ahead log files, and shadow 
		/// files.
		/// </summary>
		/// <param name="db_handle"></param>
		public void isc_drop_database(isc_db_handle db_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}

			lock(db) 
			{				
				try 
				{
					if (log != null) log.Debug("op_drop_database ");
					db.output.WriteInt(op_drop_database);
					db.output.WriteInt(db.Rdb_id);
					db.output.Flush();            
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_network_error);
				}
			}
		}

		/// <summary>
		/// Dynamically builds or expands a database parameter buffer (DPB) 
		/// to include database	parameters.
		/// </summary>
		/// <param name="dpb"></param>
		/// <param name="dpb_length"></param>
		/// <param name="param"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public byte[] isc_expand_dpb(byte[] dpb, int dpb_length,
									int param, object[] parameters)
		{
			return dpb;
		}

		#endregion

		#region TRANSACTION_METHODS		

		/// <summary>
		/// Starts a new transaction against one or more databases.
		/// </summary>
		/// <param name="tr_handle"></param>
		/// <param name="db_handle"></param>
		/// <param name="tpb"></param>
		public void isc_start_transaction(isc_tr_handle tr_handle,
											isc_db_handle db_handle,
											ArrayList tpb /*int tpb_length,
											byte[] tpb*/)
		{                               

			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (tr_handle == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}

			if (db_handle == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}
			
			lock(db) 
			{
				if (tr.State != isc_tr_values.NOTRANSACTION) 
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONSTARTING;

				try {
					if (log != null) log.Debug("op_transaction ");
					db.output.WriteInt(op_transaction);
					db.output.WriteInt(db.Rdb_id);
					db.output.WriteSet(isc_tpb_version3, tpb);					
					db.output.Flush();            
					if (log != null) log.Debug("sent");					
					Response r = ReceiveResponse(db);
					tr.TransactionId = r.resp_object;
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_network_error);
				}
				
				tr.DbHandle = db;
				tr.State    = isc_tr_values.TRANSACTIONSTARTED;				
			}
		}

		/// <summary>
		/// Commits a specified active transaction.
		/// </summary>
		/// <remarks>
		/// <code>isc_commit_transaction()</code> closes record streams, 
		/// frees system resources, and sets the transaction handle to zero 
		/// for the specified transaction.
		/// </remarks>
		/// <param name="tr_handle"></param>
		public void isc_commit_transaction(isc_tr_handle tr_handle)
		{
			if (tr_handle == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}

			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock(db) 
			{
				if (tr.State != isc_tr_values.TRANSACTIONSTARTED && tr.State != isc_tr_values.TRANSACTIONPREPARED)
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONCOMMITTING;

				try 
				{
					if (log != null) log.Debug("op_commit ");
					if (log != null) log.Debug("tr.rtr_id: " + tr.TransactionId);
					db.output.WriteInt(op_commit);
					db.output.WriteInt(tr.TransactionId);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
				
				tr.State = isc_tr_values.NOTRANSACTION;
				tr.UnsetDbHandle();
			}
		}

		/// <summary>
		/// Commits an active transaction and retains the 
		/// transaction context after a commit.
		/// </summary>
		/// <remarks>
		/// <code>isc_commit_retaining()</code> commits an active transaction 
		/// and immediately clones itself. 
		/// </remarks>
		/// <param name="tr_handle"></param>
		public void isc_commit_retaining(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock(db) 
			{
				if (tr.State != isc_tr_values.TRANSACTIONSTARTED && tr.State != isc_tr_values.TRANSACTIONPREPARED)
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONCOMMITTING;

				try 
				{
					if (log != null) log.Debug("op_commit_retaining ");
					db.output.WriteInt(op_commit_retaining);
					db.output.WriteInt(tr.TransactionId);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
				tr.State = isc_tr_values.TRANSACTIONSTARTED;
			}
		}

		/// <summary>
		/// Executes the first phase of a two-phase commit 
		/// against multiple databases.
		/// </summary>
		/// <param name="tr_handle"></param>
		public void isc_prepare_transaction(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
						
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock(db) 
			{
				if (tr.State != isc_tr_values.TRANSACTIONSTARTED) 
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONPREPARING;
				try 
				{
					if (log != null) log.Debug("op_prepare ");
					db.output.WriteInt(op_prepare);
					db.output.WriteInt(tr.TransactionId);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException)
				{
					throw new GDSException(isc_net_read_err);
				}
				tr.State = isc_tr_values.TRANSACTIONPREPARED;
			}
		}

		/// <summary>
		/// Performs the first phase of a two-phase commit for 
		/// multi-database transactions.
		/// </summary>
		/// <param name="tr_handle"></param>
		/// <param name="bytes"></param>
		public void isc_prepare_transaction2(isc_tr_handle tr_handle,
											byte[] bytes)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock(db) 
			{
				if (tr.State != isc_tr_values.TRANSACTIONSTARTED) 
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONPREPARING;
				try 
				{
					if (log != null) log.Debug("op_prepare2 ");
					db.output.WriteInt(op_prepare2);
					db.output.WriteInt(tr.TransactionId);
					db.output.WriteBuffer(bytes, bytes.Length);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}

				tr.State = isc_tr_values.TRANSACTIONPREPARED;
			}
		}

		/// <summary>
		/// Undoes changes made by a transaction, and restores the database 
		/// to its state prior to the start of the specified transaction.		
		/// </summary>
		/// <remarks>
		/// isc_rollback_transaction() rolls back a specified transaction, 
		/// closes record streams, frees system resources, and sets the 
		/// transaction handle to zero. It is typically used to undo all database 
		/// changes made by a transaction when an error occurs.
		/// </remarks>
		/// <param name="tr_handle"></param>
		public void isc_rollback_transaction(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock(db)
			{
				if (tr.State != isc_tr_values.TRANSACTIONSTARTED && tr.State != isc_tr_values.TRANSACTIONPREPARED)
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONROLLINGBACK;

				try 
				{
					if (log != null) log.Debug("op_rollback ");
					db.output.WriteInt(op_rollback);
					db.output.WriteInt(tr.TransactionId);
					db.output.Flush();            
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}

				tr.State = isc_tr_values.NOTRANSACTION;
				tr.UnsetDbHandle();
			}
		}

		/// <summary>
		/// Undoes changes made by a transaction and retains the transaction 
		/// context after the rollback.
		/// </summary>
		/// <param name="tr_handle"></param>
		public void isc_rollback_retaining(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock(db) 
			{
				if (tr.State != isc_tr_values.TRANSACTIONSTARTED && tr.State != isc_tr_values.TRANSACTIONPREPARED)
				{
					throw new GDSException(isc_tra_state);
				}
				tr.State = isc_tr_values.TRANSACTIONROLLINGBACK;

				try 
				{
					if (log != null) log.Debug("op_rollback_retaining ");
					db.output.WriteInt(op_rollback_retaining);
					db.output.WriteInt(tr.TransactionId);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
				tr.State = isc_tr_values.TRANSACTIONSTARTED;
			}
		}

		#endregion

		#region DYNAMIC_SQL_METHODS		

		/// <summary>
		/// Allocates a statement handle for subsequent use with other 
		/// API dynamic SQL (DSQL) calls.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="stmt_handle"></param>
		public void isc_dsql_allocate_statement(isc_db_handle db_handle,
											isc_stmt_handle stmt_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;

			if (db_handle == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}

			if (stmt_handle == null) 
			{
				throw new GDSException(isc_bad_req_handle);
			}

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_allocate_statement ");
					db.output.WriteInt(op_allocate_statement);
					db.output.WriteInt(db.Rdb_id);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					Response r  = ReceiveResponse(db);
					stmt.rsr_id = r.resp_object;
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}

				stmt.rsr_rdb = db;
				db.rdb_sql_requests.Add(stmt);
				stmt.allRowsFetched = false;
			}
		}

		/// <summary>
		/// Allocates a statement handle for subsequent use with other 
		/// API dynamic SQL (DSQL) calls.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="stmt_handle"></param>
		public void isc_dsql_alloc_statement2(isc_db_handle db_handle,
											isc_stmt_handle stmt_handle)
		{
			throw new GDSException(isc_wish_list);
		}

		/// <summary>
		/// Provides information about columns retrieved by the execution 
		/// of a DSQL SELECT or EXECUTE PROCEDURE statement.
		/// </summary>
		/// <param name="stmt_handle"></param>
		/// <param name="da_version"></param>
		/// <returns></returns>
		public XSQLDA isc_dsql_describe(isc_stmt_handle stmt_handle,
									int da_version)
		{

			byte[] describe_select_info = new byte[] { isc_info_sql_select,
													isc_info_sql_describe_vars,
													isc_info_sql_sqlda_seq,
													isc_info_sql_type,
													isc_info_sql_sub_type,
													isc_info_sql_scale,
													isc_info_sql_length,
													isc_info_sql_field,
													isc_info_sql_relation,
													isc_info_sql_owner,
													isc_info_sql_alias,
													isc_info_sql_describe_end};

			try
			{
				byte[] buffer = isc_dsql_sql_info(stmt_handle, 
										describe_select_info.Length, 
										describe_select_info, MAX_BUFFER_SIZE);

				return ParseSqlInfo(stmt_handle, buffer, describe_select_info);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
		
		/// <summary>
		/// Provides information about dynamic input parameters required 
		/// by a previously prepared DSQL statement.
		/// </summary>
		/// <param name="stmt_handle"></param>
		/// <param name="da_version"></param>
		/// <returns></returns>
		public XSQLDA isc_dsql_describe_bind(isc_stmt_handle stmt_handle,
											int da_version) 
		{
			byte[] describe_bind_info = new byte[] { isc_info_sql_bind,
													isc_info_sql_describe_vars,
													isc_info_sql_sqlda_seq,
													isc_info_sql_type,
													isc_info_sql_sub_type,
													isc_info_sql_scale,
													isc_info_sql_length,
													isc_info_sql_field,
													isc_info_sql_relation,
													isc_info_sql_owner,
													isc_info_sql_alias,
													isc_info_sql_describe_end };

			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;

			try
			{		        
				byte[] buffer = isc_dsql_sql_info(stmt_handle,
								describe_bind_info.Length, describe_bind_info,
								MAX_BUFFER_SIZE);
		        
				stmt.in_sqlda = ParseSqlInfo(stmt_handle, buffer, describe_bind_info);
			}
			catch(GDSException ge)
			{
				throw ge;
			}

			return stmt.in_sqlda;
		}

		/// <summary>
		/// Executes a previously prepared DSQL statement.
		/// </summary>
		/// <param name="tr_handle"></param>
		/// <param name="stmt_handle"></param>
		/// <param name="da_version"></param>
		/// <param name="xsqlda"></param>
		/// <remarks>
		/// isc_dsql_execute() executes a DSQL statement previously 
		/// prepared with <code>isc_dsql_prepare()</code>. 
		/// <code>isc_dsql_execute()</code> can be used to execute two 
		/// types of statements:
		/// <list type="bullet">
		///		<item>
		///			Statements that may return more than one row of data.
		///		</item>
		///		<item>
		///			Statements that need to be executed more than once.
		///		</item>
		/// </list>
		/// </remarks>
		public void isc_dsql_execute(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									int da_version,
									XSQLDA xsqlda)
		{
			try
			{
				isc_dsql_execute2(tr_handle, stmt_handle, da_version,
					xsqlda, null);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
		
		/// <summary>
		/// Executes a previously prepared DSQL statement.
		/// </summary>
		/// <param name="tr_handle"></param>
		/// <param name="stmt_handle"></param>
		/// <param name="da_version"></param>
		/// <param name="in_xsqlda"></param>
		/// <param name="out_xsqlda"></param>
		/// <remarks>
		/// <code>isc_dsql_execute2()</code> executes a previously prepared DSQL statement 
		/// that has input parameters and returns results, such as 
		/// EXECUTE PROCEDURE and SELECT.
		/// </remarks>
		public void isc_dsql_execute2(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									int da_version,
									XSQLDA in_xsqlda,
									XSQLDA out_xsqlda)
		{
			isc_tr_handle_impl	 tr		= (isc_tr_handle_impl) tr_handle;
			isc_stmt_handle_impl stmt	= (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl	 db		= stmt.rsr_rdb;

			stmt.ClearRows();
	        
			// Test Handles needed here
			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug((out_xsqlda == null) ? "op_execute " : "op_execute2 ");
					
					if (!IsSQLDataOK(in_xsqlda)) 
					{
						throw new GDSException(isc_dsql_sqlda_value_err);
					}
	                
					db.output.WriteInt((out_xsqlda == null) ? op_execute : op_execute2);
					db.output.WriteInt(stmt.rsr_id);
					db.output.WriteInt(tr.TransactionId);

					WriteBLR(db, in_xsqlda);
					db.output.WriteInt(0);  //message number = in_message_type
					db.output.WriteInt(((in_xsqlda == null) ? 0 : 1));  //stmt->rsr_bind_format

					if (in_xsqlda != null) 
					{
						WriteSQLData(db, in_xsqlda);
					}

					if (out_xsqlda != null) 
					{
						WriteBLR(db, out_xsqlda);
						db.output.WriteInt(0); //out_message_number = out_message_type
					}
					db.output.Flush();            
					if (log != null) log.Debug("sent");

					if (NextOperation(db) == op_sql_response) 
					{
						//this would be an Execute procedure
						stmt.rows.Add(ReceiveSqlResponse(db, out_xsqlda));
						stmt.allRowsFetched = true;
						stmt.isSingletonResult = true;
					}
					else 
					{
						stmt.isSingletonResult = false;
					}

					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		/// <summary>
		/// Prepares and executes just once a DSQL statement that does not 
		/// return data. There is a special case of 
		/// <code>isc_dsql_execute_immediate()</code> for creating databases.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="tr_handle"></param>
		/// <param name="statement"></param>
		/// <param name="dialect"></param>
		/// <param name="xsqlda"></param>
		/// <remarks>
		/// Note In the special case where the statement is CREATE DATABASE, 
		/// there is no transaction, so db_handle and trans_handle must be 
		/// pointers to handles whose value is NULL. When 
		/// <code>isc_dsql_execute_immediate()</code> returns, db_handle is a 
		/// valid handle, just as though you had made a call to 
		/// <code>isc_attach_database().</code>
		/// </remarks>
		public void isc_dsql_execute_immediate(isc_db_handle db_handle,
											isc_tr_handle tr_handle,
											string statement,
											int dialect,
											XSQLDA xsqlda)
		{
			try
			{
				isc_dsql_exec_immed2(db_handle, tr_handle, statement, dialect, xsqlda, null);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
	    
		public void isc_dsql_execute_immediate(isc_db_handle db_handle,
											isc_tr_handle tr_handle,
											string statement,
											string encoding,
											int dialect,
											XSQLDA xsqlda)
		{
			try
			{
				isc_dsql_exec_immed2(db_handle, tr_handle, statement, encoding, dialect, 
										xsqlda, null);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
		
		public void isc_dsql_exec_immed2(isc_db_handle db_handle,
										isc_tr_handle tr_handle,
										string statement,
										int dialect,
										XSQLDA in_xsqlda,
										XSQLDA out_xsqlda)
		{
			try
			{
				isc_dsql_exec_immed2(db_handle, tr_handle, statement, "NONE", dialect, 
										in_xsqlda, out_xsqlda);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <summary>
		/// Prepares and executes just once, a DSQL statement that returns no more than 
		/// one row of data.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="tr_handle"></param>
		/// <param name="statement"></param>
		/// <param name="encoding"></param>
		/// <param name="dialect"></param>		
		/// <param name="in_xsqlda"></param>
		/// <param name="out_xsqlda"></param>
		public void isc_dsql_exec_immed2(isc_db_handle db_handle,
										isc_tr_handle tr_handle,
										string statement,
										string encoding,
										int dialect,
										XSQLDA in_xsqlda,
										XSQLDA out_xsqlda)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			// Test Handles
			lock(db) 
			{
				try 
				{
					if (!IsSQLDataOK(in_xsqlda)) 
					{
						throw new GDSException(isc_dsql_sqlda_value_err);
					}
	                
					if (in_xsqlda == null && out_xsqlda == null) 
					{
						if (log != null) log.Debug("op_exec_immediate ");
						db.output.WriteInt(op_exec_immediate);
					} 
					else 
					{
						if (log != null) log.Debug("op_exec_immediate2 ");
						db.output.WriteInt(op_exec_immediate2);

						WriteBLR(db, in_xsqlda);
						db.output.WriteInt(0);
						db.output.WriteInt(((in_xsqlda == null) ? 0 : 1));

						if (in_xsqlda != null) 
						{
							WriteSQLData(db, in_xsqlda);
						}

						WriteBLR(db, out_xsqlda);
						db.output.WriteInt(0);
					}

					db.output.WriteInt(tr.TransactionId);
					db.output.WriteInt(0);
					db.output.WriteInt(dialect);
					db.output.WriteString(statement, encoding);
					db.output.WriteString("");
					db.output.WriteInt(0);
					db.output.Flush();            
					
					if (log != null) log.Debug("sent");

					if (NextOperation(db) == op_sql_response) 
					{
						ReceiveSqlResponse(db, out_xsqlda);
					}

					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		/// <summary>
		/// Retrieves data returned by a previously prepared and executed 
		/// DSQL statement.
		/// </summary>
		/// <param name="stmt_handle"></param>
		/// <param name="da_version"></param>
		/// <param name="xsqlda"></param>
		/// <returns></returns>
		public object[] isc_dsql_fetch(isc_stmt_handle stmt_handle,
								int da_version,
								XSQLDA xsqlda)
		{

			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl db = stmt.rsr_rdb;

			if (stmt_handle == null) 
			{
				throw new GDSException(isc_bad_req_handle);
			}

			if (xsqlda == null) 
			{
				throw new GDSException(isc_dsql_sqlda_err);
			}

			if (!stmt.allRowsFetched && stmt.rows.Count == 0) 
			{
				//Fetch next batch of rows
				lock(db) 
				{
					try 
					{						
						if (log != null) log.Debug("op_fetch ");
						db.output.WriteInt(op_fetch);
						db.output.WriteInt(stmt.rsr_id);
						WriteBLR(db, xsqlda);
						db.output.WriteInt(0);              // p_sqldata_message_number
						db.output.WriteInt(MAX_FETCH_ROWS); // p_sqldata_messages
						db.output.Flush();
						if (log != null) log.Debug("sent");

						if (NextOperation(db) == op_fetch_response) 
						{
							int sqldata_status;
							int sqldata_messages;
							do 
							{
								int op = ReadOperation(db);
								sqldata_status = db.input.ReadInt();
								sqldata_messages = db.input.ReadInt();

								if (sqldata_messages > 0 && sqldata_status == 0) 
								{
									stmt.rows.Add(ReadSQLData(db, xsqlda));
								}

							} while (sqldata_messages > 0 && sqldata_status == 0);

							if (sqldata_status == 100) 
							{
								if (log != null) log.Debug("all rows successfully fetched");
								stmt.allRowsFetched = true;
							}

						}
						else 
						{
							ReceiveResponse(db);
						}
					} 
					catch (IOException) 
					{
						throw new GDSException(isc_net_read_err);
					}
				}
			}

			if (stmt.rows.Count > 0) 
			{
				//Return next row from cache.
				object[] row = (object[])stmt.rows[0];
				stmt.rows.RemoveAt(0);
				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					xsqlda.sqlvar[i].sqldata = row[i];					
					xsqlda.sqlvar[i].sqlind = (row[i] == null ? -1 : 0);
				}
				for (int i = xsqlda.sqld; i< xsqlda.sqln; i++) 
				{
					//is this really necessary?
					xsqlda.sqlvar[i].sqldata = null;
				}
				return row;
			}
			else 
			{
				for (int i = 0; i< xsqlda.sqln; i++) 
				{
					xsqlda.sqlvar[i].sqldata = null;
				}
				return null; //no rows fetched
			}
		}

		/// <summary>
		/// Frees a statement handle and all resources allocated for it, or closes a cursor associated
		/// with the statement referenced by a statement handle.
		/// </summary>
		/// <param name="stmt_handle"></param>
		/// <param name="option"></param>
		/// <remarks>
		/// <code>isc_dsql_free_statement()</code> either frees a statement 
		/// handle and all resources allocated for it 
		/// (option = <code>DSQL_drop</code>), or closes a cursor 
		/// associated with the statement (option = <code>>DSQL_close</code>).
		/// Note <code>isc_dsql_free_statement()</code> does nothing if it is 
		/// called with an option value other than <code>DSQL_drop</code>
		///  or <code>DSQL_close</code>.
		///  </remarks>
		public void isc_dsql_free_statement(isc_stmt_handle stmt_handle,
										int option)
		{
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl db = stmt.rsr_rdb;

			if (stmt_handle == null) 
			{
				throw new GDSException(isc_bad_req_handle);
			}

			//Does not seem to be possible or necessary to close
			//an execute procedure statement.
			if (stmt.isSingletonResult && option == DSQL_close) 
			{
				return;        
			}
	        
			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_free_statement ");
					db.output.WriteInt(op_free_statement);
					db.output.WriteInt(stmt.rsr_id);
					db.output.WriteInt(option);
					db.output.Flush();
					if (log != null) log.Debug("sent");

					ReceiveResponse(db);
					if (option == DSQL_drop) 
					{
						stmt.in_sqlda = null;
						stmt.out_sqlda = null;
					}
					stmt.ClearRows();
					db.rdb_sql_requests.Remove(stmt);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		public XSQLDA isc_dsql_prepare(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									string statement,
									int dialect/*,
									xsqlda*/)
		{
			try
			{
				return isc_dsql_prepare(tr_handle, stmt_handle, statement, "NONE", dialect);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <summary>
		/// Prepares a DSQL statement for repeated execution.
		/// </summary>
		/// <param name="tr_handle"></param>
		/// <param name="stmt_handle"></param>
		/// <param name="statement"></param>
		/// <param name="encoding"></param>
		/// <param name="dialect"></param>
		/// <returns></returns>
		public XSQLDA isc_dsql_prepare(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									string statement,
									string encoding,
									int dialect/*,
									xsqlda*/) 
		{
			isc_tr_handle_impl tr	  = (isc_tr_handle_impl) tr_handle;
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl db	  = stmt.rsr_rdb;

			if (tr_handle == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}

			if (stmt_handle == null) 
			{
				throw new GDSException(isc_bad_req_handle);
			}

			//reinitialize stmt SQLDA members.

			stmt.in_sqlda  = null;
			stmt.out_sqlda = null;

			byte[] sql_prepare_info = new byte[] { isc_info_sql_select,
												isc_info_sql_describe_vars,
												isc_info_sql_sqlda_seq,
												isc_info_sql_type,
												isc_info_sql_sub_type,
												isc_info_sql_scale,
												isc_info_sql_length,
												isc_info_sql_field,
												isc_info_sql_relation,
												isc_info_sql_owner,
												isc_info_sql_alias,
												isc_info_sql_describe_end};

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_prepare_statement {0}", statement);
					db.output.WriteInt(op_prepare_statement);
					db.output.WriteInt(tr.TransactionId);
					db.output.WriteInt(stmt.rsr_id);
					db.output.WriteInt(dialect);
					db.output.WriteString(statement, encoding);
					db.output.WriteBuffer(sql_prepare_info, sql_prepare_info.Length);
					db.output.WriteInt(MAX_BUFFER_SIZE);
					db.output.Flush();            

					if (log != null) log.Debug("sent");

					Response r = ReceiveResponse(db);
					stmt.out_sqlda = ParseSqlInfo(stmt_handle, r.resp_data, sql_prepare_info);
					return stmt.out_sqlda;
				} 
				catch (IOException)
				{
					throw new GDSException(isc_net_read_err);
				}				
			}
		}

		/// <summary>
		/// Defines a cursor name and associates it with a DSQL statement.
		/// </summary>
		/// <param name="stmt_handle"></param>
		/// <param name="cursor_name"></param>
		/// <param name="type"></param>
		public void isc_dsql_set_cursor_name(isc_stmt_handle stmt_handle,
											string cursor_name,
											int type)
		{
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl db = stmt.rsr_rdb;

			if (stmt_handle == null) 
			{
				throw new GDSException(isc_bad_req_handle);
			}

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_set_cursor ");
					db.output.WriteInt(op_set_cursor);
					db.output.WriteInt(stmt.rsr_id);

					byte[] buffer = new byte[cursor_name.Length + 1];
					System.Array.Copy(Encoding.Default.GetBytes(cursor_name), 0,
										buffer, 0, cursor_name.Length);
					buffer[cursor_name.Length] = (byte) 0;

					db.output.WriteBuffer(buffer, buffer.Length);
					db.output.WriteInt(0);
					db.output.Flush();
					if (log != null) log.Debug("sent");

					ReceiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}
		
		/// <summary>
		/// Returns requested information about a prepared DSQL statement.
		/// </summary>
		/// <param name="stmt_handle"></param>
		/// <param name="item_length"></param>
		/// <param name="items"></param>
		/// <param name="buffer_length"></param>
		/// <returns></returns>
		/// <remarks>
		/// <code>isc_dsql_sql_info()</code> returns requested information 
		/// about a statement prepared with a  call to <code>isc_dsql_prepare()</code>. 
		/// The main application need for this function is to determine
		/// the statement type of an unknown prepared statement, for example, 
		/// a statement entered by the user at run time.
		/// Requested information can include the:
		/// <list type="bullet">
		///		<item>
		///		Statement type
		///		</item>
		///		<item>
		///		Number of input parameters required by the statement
		///		</item>
		///		<item>
		///		Number of output values returned by the statement		
		///		</item>
		///		<item>
		///		Detailed information regarding each input parameter or 
		///		output value, including its datatype, scale, and length
		///		</item>
		///		<item>
		///		The query plan prepared by the optimizer
		///		</item>
		/// </list>
		/// </remarks>							 
		public byte[] isc_dsql_sql_info(isc_stmt_handle stmt_handle,
									int item_length,
									byte[] items,
									int buffer_length/*,
									byte[] buffer*/)
		{
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl db = stmt.rsr_rdb;

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_info_sql ");
					db.output.WriteInt(op_info_sql);
					db.output.WriteInt(stmt.rsr_id);
					db.output.WriteInt(0);
					db.output.WriteBuffer(items, item_length);
					db.output.WriteInt(buffer_length);
					db.output.Flush();
					if (log != null) log.Debug("sent");
					Response r = ReceiveResponse(db);
					return r.resp_data;
				} 
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		/// <summary>
		/// Reverses the byte order of an integer.
		/// </summary>
		/// <param name="buffer"></param>
		/// <param name="pos"></param>
		/// <param name="length"></param>
		/// <returns></returns>
		public int isc_vax_integer(byte[] buffer, int pos, int length) 
		{
			int value;
			int shift;

			value = shift = 0;

			int i = pos;
			while (--length >= 0) 
			{
				value += (buffer[i++] & 0xff) << shift;
				shift += 8;
			}
			
			return value;
		}

		#endregion

		#region BLOB_METHODS

		/// <summary>
		/// Creates and opens the Blob for write access, and optionally 
		/// specifies the filters to be used to translate the Blob from 
		/// one subtype to another.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="tr_handle"></param>
		/// <param name="blob_handle"></param>
		/// <param name="bpb"></param>
		public void isc_create_blob2(isc_db_handle db_handle,
							isc_tr_handle tr_handle,
							isc_blob_handle blob_handle, //contains blob_id
							IClumplet bpb)
		{
			try
			{
				OpenOrCreateBlob(db_handle, tr_handle, blob_handle, bpb, (bpb == null)? op_create_blob: op_create_blob2);
				((isc_blob_handle_impl)blob_handle).rbl_flags |= RBL_create;
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <summary>
		/// Opens an existing Blob for retrieval and optional filtering.
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="tr_handle"></param>
		/// <param name="blob_handle"></param>
		/// <param name="bpb"></param>
		public void isc_open_blob2(isc_db_handle db_handle,
							isc_tr_handle tr_handle,
							isc_blob_handle blob_handle, //contains blob_id
							IClumplet bpb)
		{
			try
			{
				OpenOrCreateBlob(db_handle, tr_handle, blob_handle, bpb, (bpb == null)? op_open_blob: op_open_blob2);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <summary>
		/// <seealso cref="isc_create_blob2"/>
		/// <seealso cref="isc_open_blob2"/>
		/// </summary>
		/// <param name="db_handle"></param>
		/// <param name="tr_handle"></param>
		/// <param name="blob_handle"></param>
		/// <param name="bpb"></param>
		/// <param name="op"></param>
		private void OpenOrCreateBlob(isc_db_handle db_handle,
							isc_tr_handle tr_handle,
							isc_blob_handle blob_handle,		//contains blob_id
							IClumplet bpb,
							int op)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_blob_handle_impl blob = (isc_blob_handle_impl) blob_handle;

			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
			if (blob == null) 
			{
				throw new GDSException(isc_bad_segstr_handle);
			}

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug((bpb == null)? "op_open/create_blob ": "op_open/create_blob2 ");
					if (log != null) log.Debug("op: " + op);
					db.output.WriteInt(op);
					if (bpb != null) 
					{
						db.output.WriteTyped(isc_bpb_version1, (IXdrable)bpb);
					}
					db.output.WriteInt(tr.TransactionId);	// ??really a short?
					if (log != null) log.Debug("sending blob_id: " + blob.blob_id);
					db.output.WriteLong(blob.blob_id);
					db.output.Flush();            

					if (log != null) log.Debug("sent");
					Response r = ReceiveResponse(db);
					blob.db = db;
					blob.tr = tr;
					blob.rbl_id = r.resp_object;
					blob.blob_id = r.resp_blob_id;
					tr.AddBlob(blob);
				}
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		/// <summary>
		/// Reads a segment from an open Blob.
		/// </summary>
		/// <param name="blob_handle"></param>
		/// <param name="requested"></param>
		/// <returns></returns>
		public byte[] isc_get_segment(isc_blob_handle blob_handle,
									int requested)
		{
			isc_blob_handle_impl blob = (isc_blob_handle_impl) blob_handle;
			isc_db_handle_impl db = blob.db;
			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}
			isc_tr_handle_impl tr = blob.tr;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_get_segment ");
					db.output.WriteInt(op_get_segment);
					db.output.WriteInt(blob.rbl_id);	// short???
					db.output.WriteInt((requested + 2 < short.MaxValue) ? requested+2 : short.MaxValue);
					if (log != null) log.Debug("trying to read bytes: " +((requested + 2 < short.MaxValue) ? requested+2: short.MaxValue));
					db.output.WriteInt(0);				// writeBuffer for put segment;
					db.output.Flush();            
					if (log != null) log.Debug("sent");
					Response resp = ReceiveResponse(db);
					blob.rbl_flags &= ~RBL_segment;
					if (resp.resp_object == 1) 
					{
						blob.rbl_flags |= RBL_segment;
					}
					else if (resp.resp_object == 2) {
						blob.rbl_flags |= RBL_eof_pending;
					}
					byte[] buffer = resp.resp_data;
					if (buffer.Length == 0) 
					{
						// previous segment was last, this has no data
						return buffer;
					}
					int len = 0;
					int srcpos = 0;
					int destpos = 0;
					while (srcpos < buffer.Length) 
					{
						len = isc_vax_integer(buffer, srcpos, 2);
						srcpos += 2;
						System.Array.Copy(buffer, srcpos, buffer, destpos, len);
						srcpos += len;
						destpos += len;
					}
					byte[] result = new byte[destpos];
					System.Array.Copy(buffer, 0, result, 0, destpos);
					return result;
				}
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		/// <summary>
		/// Writes a Blob segment.
		/// </summary>
		/// <param name="blob_handle"></param>
		/// <param name="buffer"></param>
		public void isc_put_segment(isc_blob_handle blob_handle, byte[] buffer)
		{
			isc_blob_handle_impl blob = (isc_blob_handle_impl) blob_handle;
			isc_db_handle_impl db = blob.db;
			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}
			isc_tr_handle_impl tr = blob.tr;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}

			lock(db) 
			{
				try 
				{
					if (log != null) log.Debug("op_batch_segments ");
					db.output.WriteInt(op_batch_segments);
					if (log != null) log.Debug("blob.rbl_id:  " + blob.rbl_id);
					db.output.WriteInt(blob.rbl_id); //short???
					if (log != null) log.Debug("buffer.Length " + buffer.Length);
					db.output.WriteBlobBuffer(buffer);
					if (log != null) log.Debug("sent");
					db.output.Flush();            
					Response resp = ReceiveResponse(db);
				}
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		/// <summary>
		/// Closes an open Blob, which involves flushing any remaining segments, 
		/// releasing system resources associated with Blob update or retrieval,
		/// and setting the Blob handle to zero.
		/// </summary>
		/// <param name="blob_handle"></param>
		public void isc_close_blob(isc_blob_handle blob_handle)
		{
			isc_blob_handle_impl blob = (isc_blob_handle_impl) blob_handle;
			isc_db_handle_impl db = blob.db;
			if (db == null) 
			{
				throw new GDSException(isc_bad_db_handle);
			}
			isc_tr_handle_impl tr = blob.tr;
			if (tr == null) 
			{
				throw new GDSException(isc_bad_trans_handle);
			}
			ReleaseObject(db, op_close_blob, blob.rbl_id);
			tr.RemoveBlob(blob);
		}

		#endregion

		#region ERROR_INFO_METHODS

		/// <summary>
		/// Translates an InterBase error code in the error status vector to 
		/// an SQL error code number.
		/// </summary>
		/// <param name="errcode"></param>
		/// <returns></returns>
		private int isc_sql_code(int errcode)
		{
			ushort	code;
			/* SQL code -999 (GENERIC_SQLCODE) is generic, meaning "no other sql code
			 * known".  Now scan the status vector, seeing if there is ANY sqlcode
			 * reported.  Make note of the first error in the status vector who's 
			 * SQLCODE is NOT -999, that will be the return code if there is no specific
			 * sqlerr reported. */
			int	sqlCode = GDSValues.GENERIC_SQLCODE;	/* error of last resort */
						 
			ushort fac	  = (ushort)SqlCode.GetFacility(errcode);
			ushort class_ = (ushort)SqlCode.GetClass(errcode);

			code = (ushort)SqlCode.GetCode(errcode);

			if ((code < SqlCode.SqlCodes.Length / 2) &&
				(SqlCode.SqlCodes[code] != GDSValues.GENERIC_SQLCODE))
			{
				sqlCode = SqlCode.SqlCodes[code];				
			}

			return sqlCode;
		}

		#endregion

		#region HANDLE_DECLARATION_METHODS

		public isc_db_handle get_new_isc_db_handle() 
		{
			return new isc_db_handle_impl();
		}

		public isc_tr_handle get_new_isc_tr_handle() 
		{
			return new isc_tr_handle_impl();
		}

		public isc_stmt_handle get_new_isc_stmt_handle() 
		{
			return new isc_stmt_handle_impl();
		}

		public isc_blob_handle get_new_isc_blob_handle() 
		{
			return new isc_blob_handle_impl();
		}

		public static IClumplet NewClumplet(int type, string content) 
		{
			return new ClumpletImpl(type, Encoding.Default.GetBytes(content));
		}

		public static IClumplet NewClumplet(int type)
		{
			return new ClumpletImpl(type, new byte[] {});
		}

		public static IClumplet NewClumplet(int type, int c)
		{
			return new ClumpletImpl(type, new byte[] {(byte)(c>>24), (byte)(c>>16), (byte)(c>>8), (byte)c});
		}

		public static IClumplet NewClumplet(int type, byte[] content) 
		{
			return new ClumpletImpl(type, content);
		}

		public static IClumplet CloneClumplet(IClumplet c) 
		{
			if (c == null) 
			{
				return null;
			}
			return new ClumpletImpl((ClumpletImpl)c);
		}

		#endregion

		#region MISC_METHODS

		/// <summary>
		/// Connects to the server
		/// </summary>
		/// <param name="db"></param>
		/// <param name="dbai"></param>
		private void connect(isc_db_handle_impl db,
								DbAttachInfo dbai) 
		{
			try 
			{
				try 
				{
					db.socket = new TcpClient(dbai.Server, dbai.Port);
					db.networkStream = db.socket.GetStream();
					if (log != null) log.Debug("Got socket");
				} 
				catch (SocketException ex2) 
				{
					string message = "Cannot resolve host " + dbai.Server;
					if (log != null) log.Error(message, ex2);
					throw new GDSException(isc_arg_gds, isc_network_error, dbai.Server);
				}								
				
				db.output = new XdrOutputStream(new BufferedStream((System.IO.Stream)db.networkStream));
				db.input  = new XdrInputStream(new BufferedStream((System.IO.Stream)db.networkStream));				

				// Here we identify the user to the engine.  This may or may not be used 
				// as login info to a database.				
				string user = Environment.UserName;
				if (log != null) log.Debug("user.name: " + user);
				string host = System.Net.Dns.GetHostName();
				if (log != null) log.Debug("host: " + host);
				
				int n = 0;
				byte[] user_id = new byte[200];
				user_id[n++] = 1;		// CNCT_user
				user_id[n++] = (byte) user.Length;

				System.Array.Copy(Encoding.Default.GetBytes(user), 0, user_id, n, user.Length);
				n += user.Length;

				user_id[n++] = 4;		// CNCT_host
				user_id[n++] = (byte) host.Length;
				System.Array.Copy(Encoding.Default.GetBytes(host), 0, user_id, n, host.Length);
				n += host.Length;
	            
				user_id[n++] = 6;		// CNCT_user_verification
				user_id[n++] = 0;

				if (log != null) log.Debug("op_connect ");
				db.output.WriteInt(op_connect);
				db.output.WriteInt(op_attach);
				db.output.WriteInt(2);						// CONNECT_VERSION2
				db.output.WriteInt(1);						// arch_generic

				db.output.WriteString(dbai.FileName);		// p_cnct_file
				db.output.WriteInt(1);						// p_cnct_count
				db.output.WriteBuffer(user_id, n);			// p_cnct_user_id

				db.output.WriteInt(10);						// PROTOCOL_VERSION10
				db.output.WriteInt(1);						// arch_generic
				db.output.WriteInt(2);						// ptype_rpc
				db.output.WriteInt(3);						// ptype_batch_send
				db.output.WriteInt(2);
			
				db.output.Flush();				
				if (log != null) log.Debug("sent");

				if (log != null) log.Debug("op_accept ");
				if (ReadOperation(db) == op_accept) 
				{
					db.input.ReadInt();                   // Protocol version number
					db.input.ReadInt();                   // Architecture for protocol
					db.input.ReadInt();                   // Minimum type
					if (log != null) log.Debug("received");
				} 
				else 
				{
					Disconnect(db);
					if (log != null) log.Debug("not received");
					throw new GDSException(isc_connect_reject);
				}
			} 
			catch (IOException ex) 
			{
				if (log != null) log.InfoEx("IOException while trying to connect to db:", ex);
				throw new GDSException(isc_arg_gds, isc_network_error, dbai.Server);
			}
		}

		/// <summary>
		/// Disconnect to the server
		/// </summary>
		/// <param name="db"></param>
		private void Disconnect(isc_db_handle_impl db)
		{
			try
			{
				db.socket.Close();
			}
			catch(IOException ioe)
			{
				throw new GDSException(isc_arg_gds, isc_net_read_err, ioe.Message);
			}
		}

		private object[] ReceiveSqlResponse(isc_db_handle_impl db,
										XSQLDA xsqlda)
		{
			try 
			{
				if (log != null) log.Debug("op_sql_response ");
				if (ReadOperation(db) == op_sql_response) 
				{
					int messages = db.input.ReadInt();
					if (log != null) log.Debug("received");
					if (messages > 0) 
					{
						return ReadSQLData(db, xsqlda);
					}
					else 
					{
						return null;
					}
				} 
				else 
				{
					if (log != null) log.Debug("not received");
					throw new GDSException(isc_net_read_err);
				}
			} 
			catch (IOException ex) 
			{
				if (log != null) log.WarnEx("IOException in receiveSQLResponse", ex);
				// ex.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GDSException(isc_arg_gds, isc_net_read_err, ex.Message);
			}
		}

		private Response ReceiveResponse(isc_db_handle_impl db)
		{
			try 
			{
				if (log != null) log.Debug("op_response ");
				int op = ReadOperation(db);
				if (op == op_response) 
				{
					Response r = new Response();

					r.resp_object = db.input.ReadInt();
					if (log != null) log.Debug("op_response resp_object: " + r.resp_object);
					r.resp_blob_id = db.input.ReadLong();
					if (log != null) log.Debug("op_response resp_blob_id: " + r.resp_blob_id);
					r.resp_data = db.input.ReadBuffer();
					if (log != null) log.Debug("op_response resp_data size: " + r.resp_data.Length);										
					for (int i = 0; i < ((r.resp_data.Length< 16) ? r.resp_data.Length: 16) ; i++) 
					{
					    if (log != null) log.Debug("byte: " + r.resp_data[i]);
					}
					ReadStatusVector(db);
					if (log != null) log.Debug("received");
					if (log != null) CheckAllRead(db.input);//DEBUG
					return r;
				} 
				else 
				{
					if (log != null) log.Debug("not received: op is " + op);
					if (log != null) CheckAllRead(db.input);
					return null;
				}
			} 
			catch (IOException ex) 
			{
				if (log != null) log.WarnEx("IOException in ReceiveResponse", ex);
				// ex.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GDSException(isc_arg_gds, isc_net_read_err, ex.Message);
			}
		}

		private int NextOperation(isc_db_handle_impl db)
		{
			do 
			{
				/* loop as long as we are receiving dummy packets, just
					throwing them away--note that if we are a server we won't
					be receiving them, but it is better to check for them at
					this level rather than try to catch them in all places where
					this routine is called */
			
				db.op = db.input.ReadInt();				
				if (log != null)
				{
					if (db.op == op_dummy) 
					{
						log.Debug("op_dummy received");
					}
				}
			} while (db.op == op_dummy);

			return db.op;
		}

		private int ReadOperation(isc_db_handle_impl db)
		{
			int op = (db.op >= 0) ? db.op : NextOperation(db);
			db.op = -1;
			return op;
		}

		private void ReadStatusVector(isc_db_handle_impl db)
		{
			try 
			{
				GDSException head = null;
				GDSException tail = null;
				while (true) 
				{
					int arg = db.input.ReadInt();
					switch (arg) 
					{
						case isc_arg_end:
							if (head != null && !head.IsWarning()) 
								throw head;
							else
								if (head != null && head.IsWarning()) 
									db.AddWarning(head);
		
							return;
						
						case isc_arg_interpreted:						
						case isc_arg_string:							
							GDSException ts = new GDSException(arg, db.input.ReadString());
							if (log != null) log.Debug("readStatusVector string: " + ts.Message);
							if (head == null) 
							{
								head = ts;
								tail = ts;
							}
							else 
							{
								tail.Next = ts;
								tail = ts;
							}
							break;
						
						case isc_arg_number:
							{
								int arg_value = db.input.ReadInt();
								if (log != null)log.Debug("readStatusVector int: " + arg_value);
								GDSException td = new GDSException(arg, arg_value);								
								if (head == null) 
								{
									head = td;
									tail = td;
								}
								else 
								{
									tail.Next = td;
									tail = td;
								}
								break;
							}
						
						default:
							int e = db.input.ReadInt();
							if (log != null)log.Debug("readStatusVector int: " + e);
							if (e != 0) 
							{
								GDSException td = new GDSException(arg, e);
								if (head == null) 
								{
									head = td;
									tail = td;
								}
								else 
								{
									tail.Next = td;
									tail = td;
								}
							}
							break;
					}
				}
			}
			catch (IOException ioe) 
			{
				// ioe.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GDSException(isc_arg_gds, isc_net_read_err, ioe.Message);
			}
		}

		private void WriteBLR(isc_db_handle_impl db,
								XSQLDA xsqlda)
		{
			int blr_len = 0;
			byte[] blr = null;

			if (xsqlda != null) 
			{
				// Determine the BLR length
				blr_len = 8;
				int par_count = 0;
				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					int dtype = xsqlda.sqlvar[i].sqltype & ~1;
					if (dtype == SQL_VARYING || dtype == SQL_TEXT) 
					{
						blr_len += 3;
					} 
					else if (dtype == SQL_SHORT || dtype == SQL_LONG ||
								dtype == SQL_INT64 ||
								dtype == SQL_QUAD ||
								dtype == SQL_BLOB || dtype == SQL_ARRAY) {
							blr_len += 2;
						} 
						else 
						{
							blr_len++;
						}
					blr_len += 2;
					par_count += 2;
				}

				blr = new byte[blr_len];

				int n = 0;
				blr[n++] = 5;                   // blr_version5
				blr[n++] = 2;                   // blr_begin
				blr[n++] = 4;                   // blr_message
				blr[n++] = 0;

				blr[n++] = (byte) (par_count & 255);
				blr[n++] = (byte) (par_count >> 8);

				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					int dtype = xsqlda.sqlvar[i].sqltype & ~1;
					int len = xsqlda.sqlvar[i].sqllen;
					if (dtype == SQL_VARYING) {
						blr[n++] = 37;              // blr_varying
						blr[n++] = (byte) (len & 255);
						blr[n++] = (byte) (len >> 8);
					} else if (dtype == SQL_TEXT) {
						blr[n++] = 14;              // blr_text
						blr[n++] = (byte) (len & 255);
						blr[n++] = (byte) (len >> 8);
					} else if (dtype == SQL_DOUBLE) {
						blr[n++] = 27;              // blr_double
					} else if (dtype == SQL_FLOAT) {
						blr[n++] = 10;              // blr_float
					} else if (dtype == SQL_D_FLOAT) {
						blr[n++] = 11;              // blr_d_float
					} else if (dtype == SQL_TYPE_DATE) {
						blr[n++] = 12;              // blr_sql_date
					} else if (dtype == SQL_TYPE_TIME) {
						blr[n++] = 13;              // blr_sql_time
					} else if (dtype == SQL_TIMESTAMP) {
						blr[n++] = 35;              // blr_timestamp
					} else if (dtype == SQL_BLOB) {
						blr[n++] = 9;               // blr_quad
						blr[n++] = 0;
					} else if (dtype == SQL_ARRAY) {
						blr[n++] = 9;               // blr_quad
						blr[n++] = 0;
					} else if (dtype == SQL_LONG) {
						blr[n++] = 8;               // blr_long
						blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
					} else if (dtype == SQL_SHORT) {
						blr[n++] = 7;               // blr_short
						blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
					} else if (dtype == SQL_INT64) {
						blr[n++] = 16;              // blr_int64
						blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
					} else if (dtype == SQL_QUAD) {
						blr[n++] = 9;               // blr_quad
						blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
					} else {
	//                    return error_dsql_804 (gds__dsql_sqlda_value_err);
					}

					blr[n++] = 7;               // blr_short
					blr[n++] = 0;
				}

				blr[n++] = (byte) 255;          // blr_end
				blr[n++] = 76;                  // blr_eoc
			}

			try 
			{
				db.output.WriteBuffer(blr, blr_len);
			} 
			catch (IOException) 
			{
				throw new GDSException(isc_net_write_err);
			}

		}

		private bool IsSQLDataOK(XSQLDA xsqlda) 
		{
			if (xsqlda != null) 
			{
				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					if ((xsqlda.sqlvar[i].sqlind != -1) &&
						(xsqlda.sqlvar[i].sqldata == null)) 
					{
						return false;
					}
				}
			}
			return true;
		}

		private void WriteSQLData(isc_db_handle_impl db,
									XSQLDA xsqlda)
		{
			// This only works if not (port->port_flags & PORT_symmetric)

			for (int i = 0; i < xsqlda.sqld; i++) 
			{
				WriteSQLDatum(db, xsqlda.sqlvar[i]);
			}
		}

		private void WriteSQLDatum(isc_db_handle_impl db,
									XSQLVAR xsqlvar)
		{			
			if (log != null) 
			{
				if (db.output == null) 
				{
					log.Debug("db.output null in writeSQLDatum");
				}
				if (xsqlvar.sqldata == null) 
				{
					log.Debug("sqldata null in writeSQLDatum: " + xsqlvar);
				}
			}

			FixNull(xsqlvar);

			if (log != null) 
			{
				if (xsqlvar.sqldata == null) 
				{
					log.Debug("sqldata still null in writeSQLDatum: " + xsqlvar);
				}
			}

			try 
			{
				object sqldata = xsqlvar.sqldata;

				switch (xsqlvar.sqltype & ~1) 
				{
					case SQL_TEXT:						
						if(((string)sqldata).Length != xsqlvar.sqllen)
						{
							throw new GDSException(isc_rec_size_err);
						}						
						db.output.WriteOpaque(
								Encoding.Default.GetBytes((string)sqldata),
								xsqlvar.sqllen);
						break;

					case SQL_VARYING:						
						if(((string)sqldata).Length > xsqlvar.sqllen)
						{
							throw new GDSException(isc_rec_size_err);
						}
						db.output.WriteInt(((string)sqldata).Length);						
						db.output.WriteOpaque(
								Encoding.Default.GetBytes((string)sqldata),
								((string)sqldata).Length);
						break;
					
					case SQL_SHORT:
						db.output.WriteShort((short) sqldata);
						break;
					
					case SQL_LONG:
						db.output.WriteInt((int) sqldata);
						break;
					
					case SQL_FLOAT:
						db.output.WriteFloat((float) sqldata);
						break;
					
					case SQL_DOUBLE:
						db.output.WriteDouble((double) sqldata);
						break;
	
					case SQL_TIMESTAMP:
						db.output.WriteInt(EncodeDate((System.DateTime) sqldata));
						db.output.WriteInt(EncodeTime((System.DateTime) sqldata));
						break;

					case SQL_BLOB:						
						db.output.WriteLong((long)sqldata);
						break;

					case SQL_ARRAY:
						db.output.WriteLong((long) sqldata);
						break;
					
					case SQL_QUAD:
						db.output.WriteLong((long) sqldata);
						break;
					
					case SQL_TYPE_TIME:
						db.output.WriteInt(EncodeTime((System.DateTime) sqldata));
						break;
					
					case SQL_TYPE_DATE:
						db.output.WriteInt(EncodeDate((System.DateTime) sqldata));
						break;
					
					case SQL_INT64:
						db.output.WriteLong((long) sqldata);
						break;
					
					default:
						throw new GDSException("Unknown sql data type: " + xsqlvar.sqltype);
				}

				db.output.WriteInt(xsqlvar.sqlind);

			} 
			catch (IOException) 
			{
				throw new GDSException(isc_net_write_err);
			}
		}

		private void FixNull(XSQLVAR xsqlvar)
		{
			if ((xsqlvar.sqlind == -1) && (xsqlvar.sqldata == null)) 
			{
				switch (xsqlvar.sqltype & ~1) 
				{
					case SQL_TEXT:
						xsqlvar.sqldata = new byte[xsqlvar.sqllen];
						break;
					
					case SQL_VARYING:
						xsqlvar.sqldata = new byte[0];
						break;
					
					case SQL_SHORT:
						xsqlvar.sqldata = (short) 0;
						break;
					
					case SQL_LONG:
						xsqlvar.sqldata = (int) 0;
						break;
					
					case SQL_FLOAT:
						xsqlvar.sqldata = (float) 0;
						break;
					
					case SQL_DOUBLE:
						xsqlvar.sqldata = (double) 0;
						break;

					case SQL_TIMESTAMP:
						xsqlvar.sqldata  = new System.DateTime(0 * 10000L + 621355968000000000);
						break;
					
					case SQL_BLOB:					
					case SQL_ARRAY:
					case SQL_QUAD:
					case SQL_INT64:
						xsqlvar.sqldata = (long) 0;
						break;
					
					case SQL_TYPE_TIME:
						xsqlvar.sqldata = new System.DateTime(0 * 10000L + 621355968000000000);
						break;

					case SQL_TYPE_DATE:
						xsqlvar.sqldata = new System.DateTime(0 * 10000L + 621355968000000000);
						break;

					default:
						throw new GDSException("Unknown sql data type: " + xsqlvar.sqltype);
				}
			}
		}

		private string FillString(string s, int len) 
		{
			if (s.Length < len) 
			{
				StringBuilder sb = new StringBuilder();
				sb.EnsureCapacity(len);
				sb.Append(s);
				for (int i = 0; i < (len - s.Length); i++) 
				{
					sb.Append(' ');
				}
				s = sb.ToString();
			}
			return s;
		}

		private int EncodeTime(System.DateTime d) 
		{
			GregorianCalendar calendar = new GregorianCalendar();			

			// TODO: Faltan los milisegundos
			long millisInDay = 
				calendar.GetHour(d) * 60 * 60 * 1000 + 
				calendar.GetMinute(d) * 60 * 1000 + 
				calendar.GetSecond(d) * 1000;				
			
			int iTime = (int) (millisInDay * 10);

			return iTime;
		}

		private int EncodeDate(System.DateTime d) 
		{			
			int day, month, year;
			int c, ya;

			GregorianCalendar calendar = new GregorianCalendar();

			day		= calendar.GetDayOfMonth(d);
			month	= calendar.GetMonth(d);
			year	= calendar.GetYear(d);

			if (month > 2) 
			{
				month -= 3;
			} else 
			{
				month += 9;
				year -= 1;
			}

			c = year / 100;
			ya = year - 100 * c;

			return ((146097 * c) / 4		+
					(1461 * ya) / 4			+
					(153 * month + 2) / 5	+
					day + 1721119 - 2400001);
		}


		//Now returns results in object[] and in xsqlda.data
		//Nulls are represented by null values in object array,
		//but by sqlind = -1 in xsqlda.
		private object[] ReadSQLData(isc_db_handle_impl db,
									XSQLDA xsqlda)
		{
			// This only works if not (port->port_flags & PORT_symmetric)
			object[] row = new object[xsqlda.sqld];
			for (int i = 0; i < xsqlda.sqld; i++) 
			{
				row[i] = ReadSQLDatum(db, xsqlda.sqlvar[i]);
			}
			return row;
		}

		private object ReadSQLDatum(isc_db_handle_impl db,
									XSQLVAR xsqlvar) 
		{
			try 
			{
				switch (xsqlvar.sqltype & ~1) 
				{
					case SQL_TEXT:
						xsqlvar.sqldata = db.input.ReadOpaque(xsqlvar.sqllen);
						break;
					
					case SQL_VARYING:
						xsqlvar.sqldata = db.input.ReadOpaque(db.input.ReadInt());
						break;
					
					case SQL_SHORT:
						xsqlvar.sqldata = (short)db.input.ReadInt();
						break;
					
					case SQL_LONG:
						xsqlvar.sqldata = db.input.ReadInt();
						break;
					
					case SQL_FLOAT:
						xsqlvar.sqldata = (float)db.input.ReadSingle();
						break;
					
					case SQL_DOUBLE:	
						xsqlvar.sqldata = (double)db.input.ReadDouble();
						break;
		
					case SQL_TIMESTAMP:
						DateTime date = DecodeDate(db.input.ReadInt());
						DateTime time = DecodeTime(db.input.ReadInt());

						xsqlvar.sqldata = new System.DateTime(
										date.Year, date.Month, date.Day,
										time.Hour,time.Minute, time.Second, time.Millisecond);
						break;
					
					case SQL_BLOB:
						xsqlvar.sqldata = db.input.ReadLong();
						break;
					
					case SQL_ARRAY:
						xsqlvar.sqldata = db.input.ReadLong();
						break;
					
					case SQL_QUAD:
						xsqlvar.sqldata = db.input.ReadLong();
						break;
					
					case SQL_TYPE_TIME:
						xsqlvar.sqldata = DecodeTime(db.input.ReadInt());
						break;
					
					case SQL_TYPE_DATE:
						xsqlvar.sqldata = DecodeDate(db.input.ReadInt());
						break;
					
					case SQL_INT64:
						xsqlvar.sqldata = db.input.ReadLong();
						break;
				}

				xsqlvar.sqlind = db.input.ReadInt();

				if (xsqlvar.sqlind == 0) 
				{
					return xsqlvar.sqldata;
				}
				else if (xsqlvar.sqlind == -1) {
					return null;
				}
				else {
					throw new GDSException("invalid sqlind value: " + xsqlvar.sqlind);
				}

			} 
			catch (IOException) 
			{
				throw new GDSException(isc_net_read_err);
			}
		}

		private System.DateTime DecodeTime(int sql_time) 
		{
			return new System.DateTime((sql_time / 10000) * 1000 * 10000L + 621355968000000000);
		}

		private System.DateTime DecodeDate(int sql_date) 
		{
			int year, month, day, century;

			sql_date	-= 1721119 - 2400001;
			century		= (4 * sql_date - 1) / 146097;
			sql_date	= 4 * sql_date - 1 - 146097 * century;
			day			= sql_date / 4;

			sql_date	= (4 * day + 3) / 1461;
			day			= 4 * day + 3 - 1461 * sql_date;
			day			= (day + 4) / 4;

			month	= (5 * day - 3) / 153;
			day		= 5 * day - 3 - 153 * month;
			day		= (day + 5) / 5;

			year	= 100 * century + sql_date;

			if (month < 10) 
			{
				month += 3;
			} 
			else 
			{
				month -= 9;
				year += 1;
			}

			DateTime date = new System.DateTime(year, month, day);		

			return date.Date;
		}

		private XSQLDA ParseSqlInfo(isc_stmt_handle stmt_handle,
									byte[] info,
									byte[] items) 
		{   
			if (log != null) log.Debug("parseSqlInfo started");

			XSQLDA xsqlda = new XSQLDA();
			int lastindex = 0;
			while ((lastindex = ParseTruncSqlInfo(info, xsqlda, lastindex)) > 0) 
			{
				lastindex--;               // Is this OK ?
				byte[] new_items = new byte[4 + items.Length];
				new_items[0] = isc_info_sql_sqlda_start;
				new_items[1] = 2;
				new_items[2] = (byte) (lastindex & 255);
				new_items[3] = (byte) (lastindex >> 8);				
				Array.Copy(items, 0, new_items, 4, items.Length);
				info = isc_dsql_sql_info(stmt_handle, new_items.Length, new_items, info.Length);
			}
			if (log != null) log.Debug("parseSqlInfo ended");

			return xsqlda;
		}
	    
	    
		private int ParseTruncSqlInfo(byte[] info,
									XSQLDA xsqlda,
									int lastindex)
		{
			byte item;
			int index = 0;
			if (log != null) log.Debug("parseSqlInfo: first 2 bytes are " + isc_vax_integer(info, 0, 2) + " or: " + info[0] + ", " + info[1]);

			int i = 2;

			int len = isc_vax_integer(info, i, 2);
			i += 2;
			int n = isc_vax_integer(info, i, len);
			i += len;
			if (xsqlda.sqlvar == null) 
			{
				xsqlda.sqld = xsqlda.sqln = n;
				xsqlda.sqlvar = new XSQLVAR[xsqlda.sqln];
			}
			if (log != null) log.Debug("xsqlda.sqln read as " + xsqlda.sqln);

			while (info[i] != isc_info_end) 
			{
				while ((item = info[i++]) != isc_info_sql_describe_end) 
				{
					switch (item) 
					{
						case isc_info_sql_sqlda_seq:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							index = isc_vax_integer(info, i, len);
							i += len;
							xsqlda.sqlvar[index - 1] = new XSQLVAR();
							break;
						
						case isc_info_sql_type:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqltype = isc_vax_integer (info, i, len);
							i += len;
							break;

						case isc_info_sql_sub_type:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqlsubtype = isc_vax_integer (info, i, len);
							i += len;
							break;
						
						case isc_info_sql_scale:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqlscale = isc_vax_integer (info, i, len);
							i += len;
							break;
						
						case isc_info_sql_length:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqllen = isc_vax_integer (info, i, len);
							i += len;
							break;

						case isc_info_sql_field:
							len = isc_vax_integer(info, i, 2);
							i += 2;							
							xsqlda.sqlvar[index - 1].sqlname = 
										Encoding.Default.GetString(info,i,len);
							i += len;
							break;							
						
						case isc_info_sql_relation:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].relname = 
										Encoding.Default.GetString(info,i,len);
							i += len;
							break;
						
						case isc_info_sql_owner:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].ownname = 
												Encoding.Default.GetString(info,i,len);
							i += len;
							break;

						case isc_info_sql_alias:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].aliasname = 
												Encoding.Default.GetString(info,i,len);
							i += len;
							break;

						/*						
						case isc_info_sql_null_ind:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqlind = isc_vax_integer (info, i, len);
							i += len;
							break;
						*/

						case isc_info_truncated:
							return lastindex;
							//throw new GDSException(isc_dsql_sqlda_err);						

						default:
							throw new GDSException(isc_dsql_sqlda_err);
					}
				}
				lastindex = index;
			}
			return 0;
		}

		//DEBUG
		private void CheckAllRead(BinaryReader input)
		{
			try 
			{
				int i = (int)input.PeekChar();
				if (i > 0) 
				{
					if (log != null) log.Debug("Extra bytes in packet read: " + i);
					byte[] b = new byte[i];					
					input.Read(b, 0, i);					
					for (int j = 0; j < ((b.Length < 16) ? b.Length : 16) ; j++) 
					{
						if (log != null) 
							log.Debug("byte: " + b[j]);
					}
				}
			}
			catch (IOException e) 
			{
				throw new GDSException("IOException in checkAllRead: " + e);
			}
		}

		private void ReleaseObject(isc_db_handle_impl db, int op, int id)
		{
			lock(db) 
			{
				try 
				{
					db.output.WriteInt(op);
					db.output.WriteInt(id);
					db.output.Flush();            
					ReceiveResponse(db);
				}
				catch (IOException) 
				{
					throw new GDSException(isc_net_read_err);
				}
			}
		}

		#endregion

		#region INNER_CLASSES		

		internal class DbAttachInfo 
		{
			private string	server	= "localhost";
			private int		port	= 3050;
			private string	fileName;			

			public string Server
			{
				get{return server;}
			}

			public int Port
			{
				get{return port;}
			}

			public string FileName
			{
				get{return fileName;}
			}

			public DbAttachInfo(string connectInfo)
			{
				if (connectInfo == null) 
				{
					throw new GDSException("Connection string missing");
				}

				// allows standard syntax //host:port/....
				// and old fb syntax host/port:....
				connectInfo = connectInfo.Trim();
				char hostSepChar;
				char portSepChar;
				if (connectInfo.StartsWith("//"))
				{
					connectInfo = connectInfo.Substring(2);
					hostSepChar = '/';
					portSepChar = ':';
				}
				else 
				{
					hostSepChar = ':';
					portSepChar = '/';
				}

				int sep = connectInfo.IndexOf(hostSepChar);
				if (sep == 0 || sep == connectInfo.Length - 1) 
				{
					throw new GDSException("Bad connection string: '"+hostSepChar+"' at beginning or end of:" + connectInfo +  isc_bad_db_format);
				}
				else if (sep > 0) {
					server = connectInfo.Substring(0, sep);
					fileName = connectInfo.Substring(sep + 1);
					int portSep = server.IndexOf(portSepChar);
					if (portSep == 0 || portSep == server.Length - 1) 
					{
						throw new GDSException("Bad server string: '"+portSepChar+"' at beginning or end of: " + server +  isc_bad_db_format);
					}
					else if (portSep > 0) {
						port = int.Parse(server.Substring(portSep + 1));							
						server = server.Substring(0, portSep);
					}
				}
				else if (sep == -1) 
				{
					fileName = connectInfo;
				}
			}

			public DbAttachInfo(string server, int port, string fileName)
			{
				if (fileName == null || fileName.Equals("")) 
				{
					throw new GDSException("null filename in DbAttachInfo");
				}
				if (server != null) 
				{
					this.server = server;
				}
				if (!port.Equals(null)) 
				{
					this.port = port;
				}
				this.fileName = fileName;
			}
		}
			
		internal class Response 
		{
			public int	  resp_object;
			public long	  resp_blob_id;
			public byte[] resp_data;
		}

		#endregion
	}
}
