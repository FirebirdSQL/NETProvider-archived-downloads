//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Copyright (C) 2002 Carlos Guzmn lvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Resources;
using System.Text;
using System.Reflection;
using System.Threading;
using System.Collections;

using FirebirdSql.Logging;

namespace FirebirdSql.Data.NGDS
{
	/// <summary>
	/// This class allows to get information about encodings of the Firebird Server in C#
	/// </summary>
	internal class Encodings
	{
		private static Logger log;
		
		private static string ENCODINGS		= "isc_encodings";
		private static ResourceManager		rm;
		
		private static bool initialized		= false;

		/// <summary>
		/// Initializes a new instance of Encodings class
		/// </summary>
		public Encodings()
		{
			log = LoggerFactory.GetLogger(this.GetType(), false);
		}

		/// <summary>
		/// This method initializes the encodings map.
		/// </summary>
		private static void Init()
		{			
			try 
			{				
				rm = new ResourceManager(ENCODINGS,
									Assembly.GetExecutingAssembly());				
			} 
			catch (Exception ex)
			{
				if (log!=null) log.info("Exception in init of GDSExceptionHelper", ex);
			} 
			finally 
			{
				initialized = true;
			}
		}

		/// <summary>
		/// Returns .Net encoding from a Firebird Encoding
		/// </summary>
		/// <param name="fbencoding">The name of the Firebird Server encoding</param>
		/// <returns>The equivalent encoding in C#</returns>
		public static Encoding GetFromFirebirdEncoding(string fbencoding)
		{
			string encoding = null;
			
			if (!initialized) 
				Init();
			
			try
			{
				switch(fbencoding)
				{
					case "NONE":
						return Encoding.Default;						

					default:
						encoding = rm.GetString(fbencoding);
						break;
				}
			}
			catch(Exception ex)
			{			
				if (log!=null) log.info("Exception in GetFromFirebirdEncoding", ex);
				encoding = "Default";
			}
			
			return Encoding.GetEncoding(encoding);
		}
	}
}
