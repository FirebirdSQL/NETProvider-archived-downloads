using System;
using System.Data;
using System.Text;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/blob.xml' path='doc/member[@name="T:Blob"]/*'/>
	internal class Blob
	{
		#region FIELDS

		protected FbConnection  connection;
		protected FbTransaction txn = null;

		//must be less than 1024 * 32: 1-24 * 32 -  is ok.		
		protected int maxSegmentSize = 1024*4;

		protected long blob_id;

		protected Encoding encoding;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="P:MaxSegmentSize"]/*'/>
		public virtual int MaxSegmentSize
		{
			get{return maxSegmentSize;}
			set{maxSegmentSize = value;}
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="P:BlobId"]/*'/>
		public long BlobId
		{
			get{return blob_id;}
			set{blob_id = value;}
		}

		#endregion

		#region CONSTRUCTORS
	
		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction,System.Int64)"]/*'/>
		public Blob(IDbConnection connection, IDbTransaction transaction, long blob_id)
		{
			this.connection = (FbConnection)connection;
			this.txn		= (FbTransaction)transaction;
			this.BlobId		= blob_id;

			this.encoding	= Encodings.GetFromFirebirdEncoding(this.connection.Charset);
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction)"]/*'/>
		public Blob(IDbConnection connection, IDbTransaction transaction)
		{
			this.connection = (FbConnection)connection;
			this.txn		= (FbTransaction)transaction;
			
			this.encoding	= Encodings.GetFromFirebirdEncoding(this.connection.Charset);
		}		
		#endregion

		#region METHODS

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:Create()"]/*'/>
		protected virtual isc_blob_handle_impl Create()
		{
			 isc_blob_handle_impl blob_handle = null;

			try
			{
				blob_handle = 
					(isc_blob_handle_impl)connection.gds.get_new_isc_blob_handle ();
				
				connection.gds.isc_create_blob2(connection.db, txn.Transaction,blob_handle,
												null);
			}
			catch(GDSException ex)
			{
				throw ex;
			}

			return blob_handle;
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:Open"]/*'/>
		protected virtual isc_blob_handle_impl Open()
		{
			isc_blob_handle_impl blob_handle = null;

			try
			{
				blob_handle = 
					(isc_blob_handle_impl)connection.gds.get_new_isc_blob_handle ();

				blob_handle.BlobId = BlobId;

				connection.gds.isc_open_blob2(connection.db, txn.Transaction, blob_handle, 
											  null);
			}
			catch(GDSException ex)
			{
				throw ex;
			}

			return blob_handle;
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:GetSegment(FirebirdSql.Data.INGDS.isc_blob_handle)"]/*'/>
		protected virtual byte[] GetSegment(isc_blob_handle_impl blob_handle)
		{
			try
			{
				return connection.gds.isc_get_segment(blob_handle, MaxSegmentSize);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:PutSegment(FirebirdSql.Data.INGDS.isc_blob_handle,byte[])"]/*'/>
		protected virtual void PutSegment(isc_blob_handle_impl blob_handle, byte[] data)
		{
			try
			{
				connection.gds.isc_put_segment(blob_handle, data);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:Close(FirebirdSql.Data.INGDS.isc_blob_handle)"]/*'/>
		protected virtual void Close(isc_blob_handle_impl blob_handle)
		{
			try
			{
				connection.gds.isc_close_blob(blob_handle);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}		

		#endregion
	}
}
