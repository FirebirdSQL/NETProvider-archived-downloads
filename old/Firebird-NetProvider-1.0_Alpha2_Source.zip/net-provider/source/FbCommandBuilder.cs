//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Data.Common;
using System.Text;
using System.ComponentModel;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="T:FbCommandBuilder"]/*'/>
	public sealed class FbCommandBuilder : Component
	{
		#region FIELDS

		private Builder			builder = new Builder();

		private FbDataAdapter	dataAdapter;
		private string			quotePrefix = "";
		private string			quoteSufix  = "\"";

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="P:DataAdapter"]/*'/>
		public IDbDataAdapter DataAdapter
		{
			get{return dataAdapter;}
			set{					
				dataAdapter = (FbDataAdapter)value;
				builder.DataAdapter = this.dataAdapter;				
				}
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="P:QuotePrefix"]/*'/>
		public string QuotePrefix
		{
			get{return quotePrefix;}
			set{
				quotePrefix = value;
				builder.QuotePrefix = quotePrefix;
				}
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="P:QuoteSufix"]/*'/>
		public string QuoteSufix
		{
			get{return quoteSufix;}
			set{
				quoteSufix = value;
				builder.QuoteSufix = quoteSufix;
				}
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbCommandBuilder()
		{			
			builder.QuotePrefix = quotePrefix;
			builder.QuoteSufix  = quoteSufix;
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:#ctor(System.Data.IDbDataAdapter)"]/*'/>
		public FbCommandBuilder(IDbDataAdapter adapter)
		{
			this.DataAdapter = adapter;
			builder.QuotePrefix = quotePrefix;
			builder.QuoteSufix  = quoteSufix;
		}

		#endregion

		#region METHODS
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:DeriveParameters(System.Data.IDbCommand)"]/*'/>
		public void DeriveParameters(IDbCommand command)
		{
			// TODO: Implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:GetInsertCommand"]/*'/>
		public FbCommand GetInsertCommand()
		{			
			return builder.BuildInsert();
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:GetUpdateCommand"]/*'/>
		public FbCommand GetUpdateCommand()
		{			
			return builder.BuildUpdate();
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:GetDeleteCommand"]/*'/>
		public FbCommand GetDeleteCommand()
		{			
			return builder.BuildDelete();
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:RefreshSchema"]/*'/>
		public void RefreshSchema()
		{
			// TODO: Implementar
			throw new NotImplementedException ();
		}

		#endregion
	}

	/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="T:Builder"]/*'/>
	internal class Builder
	{
		#region FIELDS
		
		FbDataAdapter dataAdapter;

		private string insert = "INSERT INTO {0} ({1}) VALUES ({2})";
		private string update = "UPDATE {0} SET {1} WHERE {2}";
		private string delete = "DELETE FROM {0} WHERE {1}";

		private string quotePrefix = "";
		private string quoteSufix  = "\"";

		private string whereClausule = "{0} = ?";

		private string[] primaryKey;
		
		#endregion		

		#region PROPERTIES
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="P:Builder.DataAdapter"]/*'/>
		public IDbDataAdapter DataAdapter
		{
			get{return dataAdapter;}
			set{
					dataAdapter = (FbDataAdapter)value;
					try
					{
						this.dataAdapter.SelectCommand.Prepare();
						this.primaryKey = this.GetPrimaryKey();
					}
					catch(FbException ex)
					{
						throw ex;
					}				
				}
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="P:Builder.QuotePrefix"]/*'/>
		public string QuotePrefix
		{
			get{return quotePrefix;}
			set{quotePrefix = value;}
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="P:Builder.QuoteSufix"]/*'/>
		public string QuoteSufix
		{
			get{return quoteSufix;}
			set{quoteSufix = value;}
		}

		#endregion
		
		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.#ctor"]/*'/>
		public Builder()
		{
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.#ctor(FirebirdSql.Data.Firebird.FbDataAdapter)"]/*'/>
		public Builder(FbDataAdapter dataAdapter)
		{
			this.DataAdapter = dataAdapter;
		}

		#endregion
		
		#region METHODS

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.BuildInsert"]/*'/>
		public FbCommand BuildInsert()
		{
			FbCommand		cmd = new FbCommand();
			StringBuilder	sql = new StringBuilder();
			XSQLVAR[]		sqlvar = dataAdapter.SelectCommand.Statement.OutSqlda.sqlvar;
			string			fields = "";
			string			values = "";

			for (int i=0;i<sqlvar.Length;i++)
			{
				// Build Field name and append it to the string
				fields += quoteSufix + sqlvar[i].sqlname + quoteSufix;
				if(i != (sqlvar.Length - 1))
					fields += ",";

				// Build value name and append it to the string
				values += "?";

				if(i != (sqlvar.Length - 1))
					values += ",";

				cmd.Parameters.Add("@p" + i.ToString(),
					FbField.GetFbType(sqlvar[i].sqltype,sqlvar[i].sqlscale,sqlvar[i].sqlsubtype),
					sqlvar[i].sqlname);
			}

			sql.AppendFormat(insert, sqlvar[0].relname, fields, values);
			
			cmd.CommandText = sql.ToString();			

			cmd.UpdatedRowSource = UpdateRowSource.Both;

			cmd.Connection	= dataAdapter.SelectCommand.Connection;
			cmd.Transaction = dataAdapter.SelectCommand.Transaction;

			return cmd;
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.BuildUpdate"]/*'/>
		public FbCommand BuildUpdate()
		{
			FbCommand		cmd = new FbCommand();
			StringBuilder	sql = new StringBuilder();
			XSQLVAR[]		sqlvar = dataAdapter.SelectCommand.Statement.OutSqlda.sqlvar;
			string			sets   = "";

			for (int i=0;i<sqlvar.Length;i++)
			{
				// Build Field name and append it to the string
				sets += quoteSufix + sqlvar[i].sqlname + quoteSufix;
				sets += " = " + "?";
				if(i != (sqlvar.Length - 1))
					sets += ",";

				cmd.Parameters.Add("@p" + i.ToString(),
					FbField.GetFbType(sqlvar[i].sqltype,sqlvar[i].sqlscale,sqlvar[i].sqlsubtype),
					sqlvar[i].sqlname);
			}

			sql.AppendFormat(update, sqlvar[0].relname, sets, BuildWhere(cmd));
			
			cmd.CommandText = sql.ToString();

			cmd.UpdatedRowSource = UpdateRowSource.Both;

			cmd.Connection	= dataAdapter.SelectCommand.Connection;
			cmd.Transaction = dataAdapter.SelectCommand.Transaction;

			return cmd;
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.BuildDelete"]/*'/>
		public FbCommand BuildDelete()
		{
			FbCommand		cmd = new FbCommand();
			StringBuilder	sql = new StringBuilder();
			XSQLVAR[]		sqlvar = dataAdapter.SelectCommand.Statement.OutSqlda.sqlvar;

			sql.AppendFormat(delete, sqlvar[0].relname, BuildWhere(cmd));
			
			cmd.CommandText = sql.ToString();

			cmd.UpdatedRowSource = UpdateRowSource.Both;

			cmd.Connection	= dataAdapter.SelectCommand.Connection;
			cmd.Transaction = dataAdapter.SelectCommand.Transaction;

			return cmd;
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.BuildWhere"]/*'/>
		private string BuildWhere(FbCommand cmd)
		{
			StringBuilder where = new StringBuilder("");
			int index;

			index = cmd.Parameters.Count;

			for (int i=0;i<primaryKey.Length;i++)
			{			
				// Build where condition name and append it to the string
				where.AppendFormat(
						this.whereClausule,
						quoteSufix + primaryKey[i] + quoteSufix );
				
				if(i != (primaryKey.Length - 1))
					where.Append(" AND ");

				index++;

				cmd.Parameters.Add("@p" + index.ToString(),
								GetPkColumnType(primaryKey[i]),
								primaryKey[i]).SourceVersion = DataRowVersion.Original;
			}

			return where.ToString();
		}

		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.GetPrimaryKey"]/*'/>
		private string[] GetPrimaryKey()
		{
			FbCommand selectCommand = dataAdapter.SelectCommand;
			string[] pk;
			string	 temp;
			 
			FbDataReader reader = 
					(FbDataReader) FbCatalogFunctions.GetPrimaryKey(
							(FbConnection)selectCommand.Connection,
							null, null,
							selectCommand.Statement.OutSqlda.sqlvar[0].relname,
							null);

			temp = "";
			while (reader.Read())
			{
				// 3 = Field Name
				temp += ((string)reader.GetValue(3)).Trim() + ";";
			}
			
			temp = temp.Remove(temp.Length-1, 1);
            pk = temp.Split(';');

			return pk;
		}
		
		/// <include file='xmldoc/fbcommandbuilder.xml' path='doc/member[@name="M:Builder.GetPkColumnType(System.String)"]/*'/>
		private FbType GetPkColumnType(string columnName)
		{
			// TODO: Use DbSchema instead of this
			XSQLVAR[] sqlvar = dataAdapter.SelectCommand.Statement.OutSqlda.sqlvar;			
			
			for (int i=0;i<sqlvar.Length;i++)
			{
				if(sqlvar[i].sqlname == columnName )
				{
					return FbField.GetFbType(sqlvar[i].sqltype,
											sqlvar[i].sqlscale,
											sqlvar[i].sqltype);
				}
			}

			throw new FbException("Column unknown");
		}
		
		#endregion
	}
}
