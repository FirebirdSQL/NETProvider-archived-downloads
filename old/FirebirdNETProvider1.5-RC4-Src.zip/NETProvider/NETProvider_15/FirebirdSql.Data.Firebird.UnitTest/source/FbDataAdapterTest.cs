//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using NUnit.Framework;
using System;
using System.Data;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbDataAdapterTest : BaseTest 
	{
		public FbDataAdapterTest() : base(true)
		{		
		}
	
		[Test]
		public void FillTest()
		{
			FbCommand		command = new FbCommand("select * from TEST", Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");
			
			Console.WriteLine();
			Console.WriteLine("DataAdapter - Fill Method - Test");

			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
				{
					Console.Write(col.ColumnName + "\t\t");
				}
				
				Console.WriteLine();
				
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
					{
						Console.Write(row[i] + "\t\t");
					}

					Console.WriteLine("");
				}
			}

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}

		[Test]
		public void FillMultipleTest()
		{
			FbCommand		command = new FbCommand("select * from TEST", Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds1 = new DataSet();
			DataSet ds2 = new DataSet();
			
			adapter.Fill(ds1, "TEST");
			adapter.Fill(ds2, "TEST");
			
			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}

		[Test]
		public void InsertTest()
		{
			FbCommand command		= new FbCommand("select * from TEST", Connection, Transaction);
			FbDataAdapter adapter	= new FbDataAdapter(command);
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			DataRow newRow = ds.Tables["TEST"].NewRow();

			newRow["INT_FIELD"]			= 101;
			newRow["CHAR_FIELD"]		= "ONE THOUSAND";
			newRow["VARCHAR_FIELD"]		= ":;,.{}`+^*[]\\!|@#$%&/()?_-<>";
			newRow["BIGINT_FIELD"]		= 100000;
			newRow["SMALLINT_FIELD"]	= 100;
			newRow["DOUBLE_FIELD"]		= 100.01;
			newRow["NUMERIC_FIELD"]		= 100.01;
			newRow["DECIMAL_FIELD"]		= 100.01;
			newRow["DATE_FIELD"]		= new DateTime(100, 10, 10);
			newRow["TIME_FIELD"]		= new DateTime(100, 10, 10, 10, 10, 10, 10);
			newRow["TIMESTAMP_FIELD"]	= new DateTime(100, 10, 10, 10, 10, 10, 10);
			newRow["CLOB_FIELD"]		= "ONE THOUSAND";

			ds.Tables["TEST"].Rows.Add(newRow);

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}

		[Test]
		public void UpdateCharTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["CHAR_FIELD"] = "ONE THOUSAND";

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT char_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);			
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			string val = (string)command.ExecuteScalar();

			Assertion.AssertEquals("char_field has not correct value", "ONE THOUSAND", val.Trim());
		}

		[Test]
		public void UpdateVarCharTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["VARCHAR_FIELD"]	= "ONE VAR THOUSAND";

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT varchar_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);			
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			string val = (string)command.ExecuteScalar();

			Assertion.AssertEquals("varchar_field has not correct value", "ONE VAR THOUSAND", val.Trim());
		}

		[Test]
		public void UpdateSmallIntTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["SMALLINT_FIELD"] = System.Int16.MaxValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT smallint_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);			
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			short val = (short)command.ExecuteScalar();

			Assertion.AssertEquals("smallint_field has not correct value", System.Int16.MaxValue, val);
		}

		[Test]
		public void UpdateBigIntTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["BIGINT_FIELD"]	= System.Int32.MaxValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT bigint_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);			
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			long val = (long)command.ExecuteScalar();

			Assertion.AssertEquals("bigint_field has not correct value", System.Int32.MaxValue, val);
		}

		[Test]
		public void UpdateDoubleTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["DOUBLE_FIELD"]	= System.Int32.MaxValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT double_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			double val = (double)command.ExecuteScalar();

			Assertion.AssertEquals("double_field has not correct value", System.Int32.MaxValue, val);
		}

		[Test]
		public void UpdateNumericTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["NUMERIC_FIELD"]	= System.Int32.MaxValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT numeric_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			decimal val = (decimal)command.ExecuteScalar();

			Assertion.AssertEquals("numeric_field has not correct value", System.Int32.MaxValue, val);
		}

		[Test]
		public void UpdateDecimalTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["DECIMAL_FIELD"]	= System.Int32.MaxValue;
			
			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT decimal_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			decimal val = (decimal)command.ExecuteScalar();

			Assertion.AssertEquals("decimal_field has not correct value", System.Int32.MaxValue, val);
		}

		[Test]
		public void UpdateDateTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			DateTime dtValue = DateTime.Now;

			ds.Tables["TEST"].Rows[0]["DATE_FIELD"] = dtValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT date_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			DateTime val = (DateTime)command.ExecuteScalar();

			Assertion.AssertEquals("date_field has not correct day", dtValue.Day, val.Day);
			Assertion.AssertEquals("date_field has not correct month", dtValue.Month, val.Month);
			Assertion.AssertEquals("date_field has not correct year", dtValue.Year, val.Year);
		}

		[Test]
		public void UpdateTimeTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			DateTime dtValue = DateTime.Now;

			ds.Tables["TEST"].Rows[0]["TIME_FIELD"] = dtValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT time_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			DateTime val = (DateTime)command.ExecuteScalar();

			Assertion.AssertEquals("time_field has not correct hour", dtValue.Hour, val.Hour);
			Assertion.AssertEquals("time_field has not correct minute", dtValue.Minute, val.Minute);
			Assertion.AssertEquals("time_field has not correct second", dtValue.Second, val.Second);
		}

		[Test]
		public void UpdateTimeStampTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			DateTime dtValue = DateTime.Now;

			ds.Tables["TEST"].Rows[0]["TIMESTAMP_FIELD"] = dtValue;

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();

			Transaction.Commit();

			Transaction = Connection.BeginTransaction();

			sql		= "SELECT timestamp_field FROM TEST WHERE int_field = @int_field";
			command = new FbCommand(sql, Connection, Transaction);
			command.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;

			DateTime val = (DateTime)command.ExecuteScalar();

			Assertion.AssertEquals("timestamp_field has not correct day", dtValue.Day, val.Day);
			Assertion.AssertEquals("timestamp_field has not correct month", dtValue.Month, val.Month);
			Assertion.AssertEquals("timestamp_field has not correct year", dtValue.Year, val.Year);
			Assertion.AssertEquals("timestamp_field has not correct hour", dtValue.Hour, val.Hour);
			Assertion.AssertEquals("timestamp_field has not correct minute", dtValue.Minute, val.Minute);
			Assertion.AssertEquals("timestamp_field has not correct second", dtValue.Second, val.Second);
		}

		[Test]
		public void UpdateClobTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 1;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0]["CLOB_FIELD"] = "ONE THOUSAND";

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}
	
		[Test]
		public void DeleteTest()
		{
			string			sql		= "select * from TEST where INT_FIELD = ?";
			FbCommand		command = new FbCommand(sql, Connection, Transaction);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@INT_FIELD", FbDbType.Integer, 4, "INT_FIELD").Value = 10;
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");

			ds.Tables["TEST"].Rows[0].Delete();

			adapter.Update(ds, "TEST");

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}
	}
}
