//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Collections;

using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird
{	
	internal class FbDbConnection : MarshalByRefObject
	{
		#region FIELDS

		private GdsDbAttachment	db;
		private GdsAttachParams	parameters;
		private long			created;
		private long			lifetime;
		private bool			pooled;
		private string			connectionString;
		
		#endregion

		#region PROPERTIES

		public GdsDbAttachment DB
		{
			get { return this.db; }
		}

		public long Lifetime
		{
			get { return this.lifetime; }
		}
		public long Created
		{
			get { return this.created; }
			set { this.created = value; }
		}
		
		public bool Pooled
		{
			get { return this.pooled; }
			set { this.pooled = value; }
		}

		public GdsAttachParams Parameters
		{
			get { return this.parameters; }
		}

		public string ConnectionString
		{
			get { return this.connectionString; }
		}

		#endregion

		#region CONSTRUCTORS

		public FbDbConnection(string connectionString)
		{
			this.connectionString	= connectionString;
			this.parameters			= new GdsAttachParams(connectionString);
			this.lifetime			= this.parameters.LifeTime;
		}

		public FbDbConnection(string connectionString, GdsAttachParams parameters)
		{
			this.connectionString	= connectionString;
			this.parameters			= parameters;
			this.lifetime			= parameters.LifeTime;
		}

		#endregion

		#region METHODS

		public void Connect()
		{							
			try
			{
				this.db = new GdsDbAttachment(this.parameters);
				this.db.Attach();
			}
			catch (GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}
		
		public void Disconnect()
		{	
			try
			{
				this.db.Detach();
			}
			catch (GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		public void CancelEvents()
		{
			try
			{
				if (this.db.EventsAtt != null)
				{
					this.db.EventsAtt.Detach();
					this.db.EventsAtt = null;
				}
			}
			catch (GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		public bool Verify()
		{
			int INFO_SIZE = 16;
			
			byte[] buffer = new byte[INFO_SIZE];
			
			// Do not actually ask for any information
			byte[] databaseInfo  = new byte[]
			{
				GdsCodes.isc_info_end
			};

			try 
			{
				this.db.GetDatabaseInfo(databaseInfo, INFO_SIZE, buffer);

				return true;
			}
			catch
			{
				return false;
			}
		}

		#endregion
	}
}
