using System;
using System.IO;
using System.Text;
using System.Net;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsDpbBuffer : BinaryWriter
	{		
		#region FIELDS
		
		public int Length
		{
			get { return GetContents().Length; }
		}
		
		#endregion
		
		#region CONSTRUCTORS
		
		public GdsDpbBuffer() : base(new MemoryStream())
		{
		}
		
		#endregion			
		
		#region METHODS
				
		public void Append(int type)
		{
			Write((byte)type);
		}

		public void Append(int type, byte content)
		{						
			Write((byte)type);
			Write((byte)1);
			Write(content);
		}

		public void Append(int type, short content)
		{						
			Write((byte)type);
			Write((byte)2);
			Write((short)IPAddress.NetworkToHostOrder(content));
		}

		public void Append(int type, int content)
		{
			Write((byte)type);
			Write((byte)4);
			Write((int)IPAddress.NetworkToHostOrder(content));
		}

		public void Append(int type, byte[] content)
		{						
			Write((byte)type);
			Write((byte)content.Length);
			Write(content);
		}

		public void Append(int type, string content)
		{
			Append(type, Encoding.Default.GetBytes(content));
		}

		public byte[] GetContents()
		{
			return ((MemoryStream)(BaseStream)).ToArray();
		}
				
		#endregion
	}
}
