//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Net;
using System.IO;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsInetReader : BinaryReader
	{
		#region FIELDS

		private byte[]		pad;
		private Encoding	encoding;

		#endregion

		#region CONTRUCTORS

		public GdsInetReader(Stream input, Encoding encoding) : base(input)
		{
			this.pad		= new byte[4];
			this.encoding	= encoding;
		}

		#endregion

		#region METHODS
		
		public object ReadValue(GdsField field)
		{
			object fieldValue = null;
			switch (field.SqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:
					fieldValue = field.Encoding.GetString(ReadOpaque(field.SqlLen));
					break;
					
				case GdsCodes.SQL_VARYING:
					fieldValue = field.Encoding.GetString(ReadOpaque(ReadInt()));
					break;
					
				case GdsCodes.SQL_SHORT:
					fieldValue = (short)ReadInt();
					if (field.SqlScale < 0)
					{
						fieldValue = GdsDecodeType.DecodeDecimal(
							fieldValue,
							field.SqlScale,
							field.SqlType);
					}
					break;
					
				case GdsCodes.SQL_LONG:
					fieldValue = ReadInt();
					if (field.SqlScale < 0)
					{
						fieldValue = GdsDecodeType.DecodeDecimal(
							fieldValue,
							field.SqlScale,
							field.SqlType);
					}
					break;
					
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					fieldValue = ReadLong();
					if (field.SqlScale < 0)
					{
						fieldValue = GdsDecodeType.DecodeDecimal(
							fieldValue,
							field.SqlScale,
							field.SqlType);
					}
					break;

				case GdsCodes.SQL_FLOAT:
					fieldValue = ReadSingle();
					break;
					
				case GdsCodes.SQL_DOUBLE:	
					fieldValue = ReadDouble();
					break;
		
				case GdsCodes.SQL_TIMESTAMP:
					DateTime date = GdsDecodeType.DecodeDate(ReadInt());
					DateTime time = GdsDecodeType.DecodeTime(ReadInt());

					fieldValue = new System.DateTime(
						date.Year, date.Month, date.Day,
						time.Hour,time.Minute, time.Second, time.Millisecond);
					break;
										
				case GdsCodes.SQL_TYPE_TIME:
					fieldValue = GdsDecodeType.DecodeTime(ReadInt());
					break;
					
				case GdsCodes.SQL_TYPE_DATE:
					fieldValue = GdsDecodeType.DecodeDate(ReadInt());
					break;
					
				case GdsCodes.SQL_BLOB:
				case GdsCodes.SQL_ARRAY:
					fieldValue = ReadLong();
					break;
			}

			int sqlInd = ReadInt();

			if (sqlInd == 0) 
			{
				return fieldValue;
			}
			else if (sqlInd == -1) 
			{
				return null;
			}
			else 
			{
				throw new GdsException("invalid sqlind value: " + sqlInd);
			}
		}

		public byte[] ReadOpaque(int len)
		{
			byte[] buffer = new byte[len];

			int readed = 0;
			while (readed < len)
			{
				readed += Read(buffer, readed, len-readed);
			}
			Read(pad, 0, ((4 - len) & 3));

			return buffer;
		}

		public byte[] ReadBuffer()
		{
			int 	len 	= this.ReadInt();
			byte[] 	buffer 	= new byte[len];
			
			int readed = 0;
			while (readed < len)
			{				
				readed += Read(buffer, readed, len - readed);
			}
			Read(pad, 0, ((4 - len) & 3));
			
			return buffer;
		}

		public byte[] ReadSlice(GdsArrayDesc desc)
		{			
			int realLength 		= ReadInt();
			int totalElements	= (realLength + ((4 - desc.Length) & 3)) / desc.Length;
			int	currentElement	= 0;
			int readed 			= 0;
			
			// Skip Length bytes
			int skip = ReadInt();
			
			if (desc.DataType == GdsCodes.blr_short)
			{
				realLength = realLength * desc.Length;
			}

			byte[] slice = new byte[realLength];
			
			while (readed < realLength)
			{
				switch (desc.DataType)
				{
					case GdsCodes.blr_text:
					case GdsCodes.blr_text2:
					case GdsCodes.blr_cstring:
					case GdsCodes.blr_cstring2:
					{												
						// Skip fill bytes
						if (((4 - desc.Length) & 3) != 0)
						{
							readed += Read(slice, readed, desc.Length);
							Read(pad, 0, ((4 - desc.Length) & 3));
						}
						else
						{
							readed += Read(slice, readed, realLength);	
						}
					}
					break;

					case GdsCodes.blr_varying:
					case GdsCodes.blr_varying2:
					{						
						byte[] tmp = ReadBytes(4);												
						tmp.CopyTo(slice, readed);
						readed += 4;
						
						int itemLength = BitConverter.ToInt32(tmp, 0);						
						itemLength = IPAddress.HostToNetworkOrder(itemLength);
						
						if (itemLength != 0)
						{
							readed += Read(slice, readed, itemLength);
							
							// Skip fill bytes
							if (((4 - itemLength) & 3) != 0)
							{
								Read(pad, 0, ((4 - itemLength) & 3));
							}
						}
						currentElement++;
						
						if (currentElement == totalElements)
						{
							readed = realLength;
						}
					}
					break;
									
					default:
						readed += Read(slice, readed, realLength - readed);
						break;
				}
			}
						
			return slice;
		}

		public override string ReadString()
		{
			int len = this.ReadInt();
			byte[] buffer = new byte[len];
						
			Read(buffer, 0, len);
			Read(pad, 0, ((4 - len) & 3));
			
			return encoding.GetString(buffer);
		}

		public short ReadShort()
		{
			return IPAddress.HostToNetworkOrder(base.ReadInt16());
		}

		public int ReadInt()
		{
			return IPAddress.HostToNetworkOrder(base.ReadInt32());
		}

		public long ReadLong()
		{
			return IPAddress.HostToNetworkOrder(base.ReadInt64());
		}

		public override float ReadSingle()
		{			
			FloatLayout floatValue = new FloatLayout();
			floatValue.i0 = IPAddress.HostToNetworkOrder(base.ReadInt32());

			return floatValue.f;
		}
		
		public override double ReadDouble()
		{			
			DoubleLayout doubleValue = new DoubleLayout();
			int temp;			

			doubleValue.d = base.ReadDouble();
			doubleValue.i0 = IPAddress.HostToNetworkOrder(doubleValue.i0);
			doubleValue.i4 = IPAddress.HostToNetworkOrder(doubleValue.i4);

			temp = doubleValue.i0;
			doubleValue.i0 = doubleValue.i4;
			doubleValue.i4 = temp;

			return doubleValue.d;
		}

		#endregion
	}
}
