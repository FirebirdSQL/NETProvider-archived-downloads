//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Collections;
using FirebirdSql.Data.Firebird;
using FirebirdSql.Data.Firebird.Isql;
using NUnit.Framework;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbDatabaseSchemaTest : BaseTest 
	{
		FbConnection  connection;

		public FbDatabaseSchemaTest() : base()
		{
		}

		[SetUp]
		public void Setup()
		{		
			connection = new FbConnection(this.GetConnectionString());
			connection.Open();
		}
		
		[TearDown]
		public void TearDown()
		{
			connection.Close();
		}

		[Test]
		public void CharacterSets()
		{
			DataTable characterSets = connection.GetDbSchemaTable(
				FbDbSchemaType.Character_Sets, null);
		}
		
		[Test]
		public void CheckConstraints()
		{
			DataTable checkConstraints = connection.GetDbSchemaTable(
				FbDbSchemaType.Check_Constraints, null);
		}

		[Test]
		public void CheckConstraintsByTable()
		{
			DataTable checkConstraintsByTable = connection.GetDbSchemaTable(
				FbDbSchemaType.Check_Constraints_By_Table, null);
		}

		[Test]
		public void Collations()
		{
			DataTable collations = connection.GetDbSchemaTable(
				FbDbSchemaType.Collations, null);
		}

		[Test]
		public void Columns()
		{
			DataTable columns = connection.GetDbSchemaTable(
				FbDbSchemaType.Columns, null);
		}

		[Test]
		public void ColumnPrivileges()
		{
			DataTable columnPrivileges = connection.GetDbSchemaTable(
				FbDbSchemaType.Column_Privileges, null);
		}

		[Test]
		public void Domains()
		{
			DataTable domains = connection.GetDbSchemaTable(
				FbDbSchemaType.Domains, null);
		}

		[Test]
		public void ForeignKeys()
		{
			DataTable foreignKeys = connection.GetDbSchemaTable(
				FbDbSchemaType.Foreign_Keys, null);
		}

		[Test]
		public void Functions()
		{
			DataTable functions = connection.GetDbSchemaTable(
				FbDbSchemaType.Functions, null);
		}

		[Test]
		public void Generators()
		{
			DataTable generators = connection.GetDbSchemaTable(
				FbDbSchemaType.Generators, null);
		}

		[Test]
		public void Indexes()
		{
			DataTable indexes = connection.GetDbSchemaTable(
				FbDbSchemaType.Indexes, null);
		}

		[Test]
		public void PrimaryKeys()
		{
			DataTable primaryKeys = connection.GetDbSchemaTable(
				FbDbSchemaType.Primary_Keys, null);
		}

		[Test]
		public void ProcedureParameters()
		{
			DataTable procedureParameters = connection.GetDbSchemaTable(
				FbDbSchemaType.Procedure_Parameters, null);
		}

		[Test]
		public void ProcedurePrivileges()
		{
			DataTable procedurePrivileges = connection.GetDbSchemaTable(
				FbDbSchemaType.Procedure_Privileges, null);
		}

		[Test]
		public void Procedures()
		{
			DataTable procedures = connection.GetDbSchemaTable(
				FbDbSchemaType.Procedures, null);
		}

		[Test]
		public void ProviderTypes()
		{
			DataTable providerTypes = connection.GetDbSchemaTable(
				FbDbSchemaType.Provider_Types, null);
		}

		[Test]
		public void Roles()
		{
			DataTable roles = connection.GetDbSchemaTable(
				FbDbSchemaType.Roles, null);
		}

		[Test]
		[Ignore("Not implemented.")]
		public void Statistics()
		{
			DataTable statistics = connection.GetDbSchemaTable(
				FbDbSchemaType.Statistics, null);
		}

		[Test]
		public void Tables()
		{
			DataTable tables = connection.GetDbSchemaTable(
				FbDbSchemaType.Tables, null);
		}

		[Test]
		public void TableConstraint()
		{
			DataTable tableConstraint = connection.GetDbSchemaTable(
				FbDbSchemaType.Table_Constraint, null);
		}

		[Test]
		public void TablePrivileges()
		{
			DataTable tablePrivileges = connection.GetDbSchemaTable(
				FbDbSchemaType.Table_Privileges, null);
		}

		[Test]
		[Ignore("Not implemented.")]
		public void TableStatistics()
		{
			DataTable table_Statistics = connection.GetDbSchemaTable(
				FbDbSchemaType.Table_Statistics, null);
		}

		[Test]
		public void Triggers()
		{
			DataTable triggers = connection.GetDbSchemaTable(
				FbDbSchemaType.Triggers, null);
		}

		[Test]
		[Ignore("Not implemented.")]
		public void UsagePrivileges()
		{
			DataTable usagePrivileges = connection.GetDbSchemaTable(
				FbDbSchemaType.Usage_Privileges, null);
		}

		[Test]
		public void ViewColumnUsage()
		{
			DataTable viewColumnUsage = connection.GetDbSchemaTable(
				FbDbSchemaType.View_Column_Usage, null);
		}

		[Test]
		public void Views()
		{
			DataTable views = connection.GetDbSchemaTable(
				FbDbSchemaType.Views, null);
		}

		[Test]
		public void ViewPrivileges()
		{
			DataTable viewPrivileges = connection.GetDbSchemaTable(
				FbDbSchemaType.View_Privileges, null);
		}
	}
}
