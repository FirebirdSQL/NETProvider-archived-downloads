//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Configuration;

namespace FirebirdSql.Data.Firebird.Tests
{
	public class BaseTest
	{
		#region FIELDS

		private string 	server;
		private string 	port;
		private string 	database;
		private string 	user;
		private string 	password;
		private string 	charset;
		private string 	role;
		private string 	dialect;
		private string	pooling;
		private string	lifetime;
		private string	packetSize;
		private string	isqlScript;

		#endregion

		#region PROPERTIES

		public string Server
		{
			get { return this.server; }
		}

		public string Port
		{
			get { return this.port; }
		}		

		public string Database
		{
			get { return this.database; }
		}
		
		public string User
		{
			get { return this.user; }
		}		
		
		public string Password
		{
			get { return this.password; }
		}
		
		public string Charset
		{
			get { return this.charset; }
		}

		public string Role
		{
			get { return this.role; }
		}

		public string Dialect
		{
			get { return this.dialect; }
		}

		public string Lifetime
		{
			get { return this.lifetime; }
		}

		public string Pooling
		{
			get { return this.pooling; }
		}

		public string PacketSize
		{
			get { return this.packetSize; }
		}

		public string IsqlScript
		{
			get { return this.isqlScript; }
		}

		#endregion

		#region CONSTRUCTORS
				
		public BaseTest()
		{
			this.server   = ConfigurationSettings.AppSettings["Server"];
			this.port 	 = ConfigurationSettings.AppSettings["Port"];
			this.database = ConfigurationSettings.AppSettings["Database"];
			this.user 	 = ConfigurationSettings.AppSettings["User"];
			this.password = ConfigurationSettings.AppSettings["Password"];
			this.role	 = ConfigurationSettings.AppSettings["Role"];
			this.charset  = ConfigurationSettings.AppSettings["Charset"];			
			this.dialect  = ConfigurationSettings.AppSettings["Dialect"];
			this.lifetime = ConfigurationSettings.AppSettings["Connection lifetime"];
			this.pooling  = ConfigurationSettings.AppSettings["Pooling"];
			this.packetSize = ConfigurationSettings.AppSettings["Packet Size"];
			this.isqlScript = ConfigurationSettings.AppSettings["Isql Script"];
		}

		#endregion

		#region METHODS

		public string GetConnectionString()
		{
			return "Database=" + this.Database	+ ";" + 
					"User="		+ this.User		+ ";" + 
					"Password=" + this.Password	+ ";" + 
					"Server="	+ this.Server	+ ";" + 
					"Port="		+ this.Port		+ ";" + 
					"Dialect="	+ this.Dialect	+ ";" + 
					"Charset="	+ this.Charset	+ ";" +
					"Role="		+ this.Role		+ ";" +
					"Connection Lifetime=" + this.Lifetime + ";" +
					"Pooling="	+ this.Pooling	+ ";" +
					"PacketSize=" + this.PacketSize;
		}

		#endregion
	}
}
