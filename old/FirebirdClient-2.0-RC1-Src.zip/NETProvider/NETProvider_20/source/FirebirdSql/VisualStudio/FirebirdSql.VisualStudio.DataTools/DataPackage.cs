﻿/*
 *  Visual Studio 2005 DDEX Provider for Firebird
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2005 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.ComponentModel.Design;
using System.Globalization;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;

namespace FirebirdSql.VisualStudio.DataTools
{
    [Guid("8d9358ba-ccc9-4169-9fd6-a52b8aee2d50")]
    [DefaultRegistryRoot("Software\\Microsoft\\VisualStudio\\8.0")]
    [ProvideLoadKey("Standard", "1.0", "DDEX Provider for Firebird", "..", 106)]
    [InstalledProductRegistration(true, "#100", "#102", "1.0", IconResourceID = 400)]
    [ProvideService(typeof(FbDataProviderObjectFactory), ServiceName = "Firebird Provider Object Factory")]
    public sealed class DataPackage : Package, IVsInstalledProduct
    {
        #region · Constructors ·

        public DataPackage()
        {
#if (ENABLE_TRACE)
            System.Diagnostics.Trace.Listeners.Add(new System.Diagnostics.TextWriterTraceListener("C:\\FirebirdDDEXProviderLog.txt"));
#endif

            System.Diagnostics.Trace.WriteLine("DataPackage()");
        }

        #endregion

        #region · IVsInstalledProduct Members ·

        public int IdBmpSplash(out uint pIdBmp)
        {
            pIdBmp = 0;

            return VSConstants.S_OK;
        }

        public int IdIcoLogoForAboutbox(out uint pIdIco)
        {
            pIdIco = 400;

            return VSConstants.S_OK;
        }

        public int OfficialName(out string pbstrName)
        {
            pbstrName = "FirebirdClient Visual Studio 2005 Integration";

            return VSConstants.S_OK;
        }

        public int ProductDetails(out string pbstrProductDetails)
        {
            pbstrProductDetails = "DDEX provider for Firebird";

            return VSConstants.S_OK;
        }

        public int ProductID(out string pbstrPID)
        {
            pbstrPID = "v1.0.0.0";

            return VSConstants.S_OK;
        }

        #endregion

        #region · Protected Methods ·

        protected override void Initialize()
        {
            System.Diagnostics.Trace.WriteLine("DataPackage::Initialize()");

            ((IServiceContainer)this).AddService(typeof(FbDataProviderObjectFactory), new ServiceCreatorCallback(this.CreateService), true);
            base.Initialize();
        }

        #endregion

        #region · Private Methods ·

        private object CreateService(IServiceContainer container, Type serviceType)
        {
            System.Diagnostics.Trace.WriteLine(String.Format("DataPackage::CreateService({0})", serviceType.FullName));

            if (serviceType == typeof(FbDataProviderObjectFactory))
            {
                return new FbDataProviderObjectFactory();
            }

            return null;
        }

        #endregion
    }
}