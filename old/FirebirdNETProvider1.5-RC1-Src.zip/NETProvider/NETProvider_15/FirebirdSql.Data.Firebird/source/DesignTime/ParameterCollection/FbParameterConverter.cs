//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Globalization;
using System.Reflection;

namespace FirebirdSql.Data.Firebird.Design
{
	internal class FbParameterConverter : TypeConverter
	{
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType) 
		{
			if (destinationType == typeof(InstanceDescriptor)) 
			{
				return true;
			}

			return base.CanConvertTo(context, destinationType);
		}
		
		public override object ConvertTo(ITypeDescriptorContext context, 
			CultureInfo culture, object value, Type destinationType) 
		{
			if (destinationType == typeof(InstanceDescriptor) && 
				value is FbParameter) 
			{
				FbParameter param = (FbParameter)value;

				ConstructorInfo ctor = typeof(FbParameter).GetConstructor(
					new Type[] {typeof(string)	, typeof(FbDbType), 
								typeof(int)		, typeof(ParameterDirection),
								typeof(bool)	, typeof(byte),
								typeof(byte)	, typeof(string),
								typeof(DataRowVersion), typeof(object)
							   });
				
				if (ctor != null)
				{
					return new InstanceDescriptor(ctor, 
						new object[] {
										param.ParameterName	, param.FbDbType,
										param.Size			, param.Direction,
										param.IsNullable	, param.Precision,
										param.Scale			, param.SourceColumn,
										param.SourceVersion	, param.Value
									 });
				}
			}

			return base.ConvertTo(context, culture, value, destinationType);      
		}
	}
}
