//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbDbSchemaFactory
	{
		public static IDbSchema GetSchema(FbDbSchemaType schema)
		{
			IDbSchema returnSchema = null;

			switch(schema)
			{
				case FbDbSchemaType.Character_Sets:
					returnSchema = new FbCharacterSetsSchema();
					break;

				case FbDbSchemaType.Check_Constraints:
					returnSchema = new FbCheckConstraintsSchema();
					break;

				case FbDbSchemaType.Check_Constraints_By_Table:
					returnSchema = new FbChecksByTableSchema();
					break;

				case FbDbSchemaType.Collations:
					returnSchema = new FbCollationsSchema();
					break;

				case FbDbSchemaType.Columns:
					returnSchema = new FbColumnsSchema();
					break;

				case FbDbSchemaType.Column_Privileges:
					returnSchema = new FbColumnPrivilegesSchema();
					break;

				case FbDbSchemaType.Domains:
					returnSchema = new FbDomainsSchema();
					break;

				case FbDbSchemaType.Foreign_Keys:
					returnSchema = new FbForeignKeysSchema();
					break;

				case FbDbSchemaType.Functions:
					returnSchema = new FbFunctionsSchema();
					break;

				case FbDbSchemaType.Generators:
					returnSchema = new FbGeneratorsSchema();
					break;

				case FbDbSchemaType.Indexes:
					returnSchema = new FbIndexesSchema();
					break;

				case FbDbSchemaType.Primary_Keys: 
					returnSchema = new FbPrimaryKeysSchema();
					break;

				case FbDbSchemaType.Procedures:
					returnSchema = new FbProceduresSchema();
					break;

				case FbDbSchemaType.Procedure_Parameters: 
					returnSchema = new FbProcedureParametersSchema();
					break;

				case FbDbSchemaType.Procedure_Privileges:
					returnSchema = new FbProcedurePrivilegesSchema();
					break;

				case FbDbSchemaType.Provider_Types:
					returnSchema = new FbProviderTypesSchema();
					break;

				case FbDbSchemaType.Roles:
					returnSchema = new FbRolesSchema();
					break;

				case FbDbSchemaType.Statistics: 
					break;

				case FbDbSchemaType.Tables: 
					returnSchema = new FbTablesSchema();
					break;

				case FbDbSchemaType.Table_Constraint:
					returnSchema = new FbTableConstraintsSchema();
					break;

				case FbDbSchemaType.Table_Privileges:
					returnSchema = new FbTablePrivilegesSchema();					
					break;

				case FbDbSchemaType.Table_Statistics:
					break;

				case FbDbSchemaType.Triggers: 
					returnSchema = new FbTriggersSchema();
					break;

				case FbDbSchemaType.View_Column_Usage:
					returnSchema = new FbViewColumnUsage();
					break;

				case FbDbSchemaType.Views:
					returnSchema = new FbViewsSchema();
					break;

				case FbDbSchemaType.View_Privileges:
					returnSchema = new FbViewPrivilegesSchema();
					break;
			}

			return returnSchema;
		}
	}
}