//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbCharacterSetsSchema : FbAbstractDbSchema
	{
		#region CONSTRUCTORS

		public FbCharacterSetsSchema() : base("CharacterSets")
		{
		}

		#endregion

		#region ADD_METHODS

		public override void AddTables()
		{
			AddTable("rdb$character_sets");
		}

		public override void AddRestrictionColumns()
		{
			AddRestrictionColumn("rdb$character_set_name", "CHARACTER_SET_NAME", null);			
			AddRestrictionColumn("rdb$character_set_id"	 , "CHARACTER_SET_ID", null);
		}

		public override void AddDataColumns()
		{
			AddDataColumn("rdb$default_collate_name", "DEFAULT_COLLATION");
			AddDataColumn("rdb$bytes_per_character"	, "BYTES_PER_CHARACTER");
			AddDataColumn("rdb$description"			, "DESCRIPTION");
		}

		public override void AddJoins()
		{
		}

		public override void AddOrderByColumns()
		{
			AddOrderBy("rdb$character_set_name");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region PARSE_METHODS

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}