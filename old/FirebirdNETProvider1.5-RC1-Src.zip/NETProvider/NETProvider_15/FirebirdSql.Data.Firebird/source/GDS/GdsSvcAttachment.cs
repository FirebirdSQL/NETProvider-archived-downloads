//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;

using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsSvcAttachment : GdsAttachment
	{
		#region FIELDS

		private string			service;
		private GdsSpbBuffer	spb;

		#endregion

		#region CONSTRUCTORS

		public GdsSvcAttachment(GdsAttachParams parameters) : base(parameters)
		{
		}

		#endregion

		#region METHODS

		public void Attach(string service, GdsSpbBuffer spb)
		{
			this.service	= service;
			this.spb		= spb;
			Attach();
		}

		public override void Detach()
		{
			lock (this) 
			{	        
				try 
				{
					Send.WriteInt(GdsCodes.op_service_detach);
					Send.WriteInt(Handle);
					Send.Flush();            
					
					GdsResponse r = ReceiveResponse();
				} 
				catch (IOException) 
				{
					throw new GdsException(GdsCodes.isc_network_error);
				}
				finally
				{
					try 
					{
						Disconnect();
					}
					catch (IOException) 
					{
						throw new GdsException(GdsCodes.isc_network_error);
					} 
				}
			}
		}				

		public void Start(GdsSpbBuffer	spb)
		{
			lock (this) 
			{
				try 
				{
					Send.WriteInt(GdsCodes.op_service_start);
					Send.WriteInt(Handle);
					Send.WriteInt(0);
					Send.WriteBuffer(spb.ToArray(), spb.Length);
					Send.Flush();

					try 
					{
						GdsResponse r = ReceiveResponse();
					} 
					catch (GdsException g) 
					{
						throw g;
					}
				} 
				catch (IOException)
				{
					throw new GdsException(GdsCodes.isc_net_write_err);
				}
			}
		}

		public void Query(GdsSpbBuffer	spb		,
			int 		request_length	,
			byte[] 		request_buffer	,
			int 		buffer_length	,
			byte[] 		buffer)
		{
			lock (this) 
			{			
				try 
				{					
					Send.WriteInt(GdsCodes.op_service_info);		//	operation
					Send.WriteInt(Handle);							//	db_handle
					Send.WriteInt(0);								//	incarnation					
					Send.WriteTyped(GdsCodes.isc_spb_version, 
									spb.ToArray());					//	spb
					Send.WriteBuffer(request_buffer, 
									request_length);				//	request buffer
					Send.WriteInt(buffer_length);					//	result buffer length

					Send.Flush();

					GdsResponse r = ReceiveResponse();

					System.Array.Copy(r.Data, 0, buffer, 0, buffer_length);
				}
				catch (IOException) 
				{
					throw new GdsException(GdsCodes.isc_network_error);
				}
			}
		}

		public override void Attach()
		{
			lock (this) 
			{
				try 
				{
					Connect();
					
					Send.WriteInt(GdsCodes.op_service_attach);
					Send.WriteInt(0);
					Send.WriteString(service);
					Send.WriteTyped(GdsCodes.isc_spb_version, 
									spb.ToArray());
					Send.Flush();

					try 
					{
						GdsResponse r = ReceiveResponse();
						Handle = r.ObjectHandle;
					} 
					catch (GdsException g) 
					{
						Disconnect();
						throw g;
					}
				} 
				catch (IOException)
				{
					Disconnect();
					throw new GdsException(GdsCodes.isc_net_write_err);
				}
			}
		}

		public override void SendWarning(GdsException ex)
		{
		}
		
		#endregion
	}
}
