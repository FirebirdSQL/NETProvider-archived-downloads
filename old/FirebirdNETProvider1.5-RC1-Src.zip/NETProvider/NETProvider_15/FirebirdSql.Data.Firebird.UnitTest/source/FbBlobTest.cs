//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using NUnit.Framework;
using System;
using System.Collections;
using System.Security.Cryptography;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbBlobTest : BaseTest 
	{
		public FbBlobTest() : base(false)
		{		
		}
		
		[Test]
		public void BinaryBlobTest()
		{
			int id_value = System.DateTime.Now.Millisecond;
			
			string selectText = "SELECT blob_field FROM TEST WHERE int_field = " + id_value.ToString();
			string insertText = "INSERT INTO TEST (int_field, blob_field) values(@int_field, @blob_field)";
			
			Console.WriteLine("\r\n\r\nBinary Blob Test");
			
			Console.WriteLine("Generating an array of temp data");
			// Generate an array of temp data
			byte[] insert_values = new byte[100000*4];
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
			rng.GetBytes(insert_values);
			
			Console.WriteLine("Executing insert command");

			// Execute insert command
			FbTransaction transaction = Connection.BeginTransaction();

			FbCommand insert = new FbCommand(insertText, Connection, transaction);
			insert.Parameters.Add("@int_field", FbDbType.Integer).Value = id_value;
			insert.Parameters.Add("@blob_field", FbDbType.Binary).Value = insert_values;
			insert.ExecuteNonQuery();

			transaction.Commit();

			Console.WriteLine("Checking inserted values");

			// Check that inserted values are correct
			FbCommand select = new FbCommand(selectText, Connection);
			byte[] select_values = (byte[])select.ExecuteScalar();			

			for (int i = 0; i < insert_values.Length; i++)
			{
				if (insert_values[i] != select_values[i])
				{
					throw new Exception("differences at index " + i.ToString());
				}
			}

			Console.WriteLine("Finishing test");
		}

		[Test]
		public void ReaderGetBytes()
		{
			int id_value = System.DateTime.Now.Millisecond + 20000;
			
			string selectText = "SELECT blob_field FROM TEST WHERE int_field = " + id_value.ToString();
			string insertText = "INSERT INTO TEST (int_field, blob_field) values(@int_field, @blob_field)";
			
			Console.WriteLine("\r\n\r\nFbDataReader.GetBytes with Binary Blob Test");
			
			Console.WriteLine("Generating an array of temp data");
			// Generate an array of temp data
			byte[] insert_values = new byte[100000*4];
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
			rng.GetBytes(insert_values);
			
			Console.WriteLine("Executing insert command");

			// Execute insert command
			FbTransaction transaction = Connection.BeginTransaction();

			FbCommand insert = new FbCommand(insertText, Connection, transaction);
			insert.Parameters.Add("@int_field", FbDbType.Integer).Value = id_value;
			insert.Parameters.Add("@blob_field", FbDbType.Binary).Value = insert_values;
			insert.ExecuteNonQuery();

			transaction.Commit();

			Console.WriteLine("Checking inserted values");

			// Check that inserted values are correct
			FbCommand select = new FbCommand(selectText, Connection);

			FbDataReader reader = select.ExecuteReader();

			int		index		= 0;
			int		segmentSize	= 1000;
			byte[]	select_values = new byte[100000*4];
			while (reader.Read())
			{
				while (index < 400000)
				{
					reader.GetBytes(0, index, select_values, index, segmentSize);

					index += segmentSize;
				}
			}

			for (int i = 0; i < insert_values.Length; i++)
			{
				if (insert_values[i] != select_values[i])
				{
					throw new Exception("differences at index " + i.ToString());
				}
			}
		}
	}
}
