//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Collections;
using FirebirdSql.Data.Firebird;
using FirebirdSql.Data.Firebird.Isql;
using NUnit.Framework;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbDatabaseSchemaTest : BaseTest 
	{
		public FbDatabaseSchemaTest() : base(false)
		{
		}

		[Test]
		public void CharacterSets()
		{
			DataTable characterSets = Connection.GetDbSchemaTable(
				FbDbSchemaType.Character_Sets, null);
		}
		
		[Test]
		public void CheckConstraints()
		{
			DataTable checkConstraints = Connection.GetDbSchemaTable(
				FbDbSchemaType.Check_Constraints, null);
		}

		[Test]
		public void CheckConstraintsByTable()
		{
			DataTable checkConstraintsByTable = Connection.GetDbSchemaTable(
				FbDbSchemaType.Check_Constraints_By_Table, null);
		}

		[Test]
		public void Collations()
		{
			DataTable collations = Connection.GetDbSchemaTable(
				FbDbSchemaType.Collations, null);
		}

		[Test]
		public void Columns()
		{
			DataTable columns = Connection.GetDbSchemaTable(
				FbDbSchemaType.Columns, null);
		}

		[Test]
		public void ColumnPrivileges()
		{
			DataTable columnPrivileges = Connection.GetDbSchemaTable(
				FbDbSchemaType.Column_Privileges, null);
		}

		[Test]
		public void Domains()
		{
			DataTable domains = Connection.GetDbSchemaTable(
				FbDbSchemaType.Domains, null);
		}

		[Test]
		public void ForeignKeys()
		{
			DataTable foreignKeys = Connection.GetDbSchemaTable(
				FbDbSchemaType.Foreign_Keys, null);
		}

		[Test]
		public void Functions()
		{
			DataTable functions = Connection.GetDbSchemaTable(
				FbDbSchemaType.Functions, null);
		}

		[Test]
		public void Generators()
		{
			DataTable generators = Connection.GetDbSchemaTable(
				FbDbSchemaType.Generators, null);
		}

		[Test]
		public void Indexes()
		{
			DataTable indexes = Connection.GetDbSchemaTable(
				FbDbSchemaType.Indexes, null);
		}

		[Test]
		public void PrimaryKeys()
		{
			DataTable primaryKeys = Connection.GetDbSchemaTable(
				FbDbSchemaType.Primary_Keys, null);
		}

		[Test]
		public void ProcedureParameters()
		{
			DataTable procedureParameters = Connection.GetDbSchemaTable(
				FbDbSchemaType.Procedure_Parameters, null);
		}

		[Test]
		public void ProcedurePrivileges()
		{
			DataTable procedurePrivileges = Connection.GetDbSchemaTable(
				FbDbSchemaType.Procedure_Privileges, null);
		}

		[Test]
		public void Procedures()
		{
			DataTable procedures = Connection.GetDbSchemaTable(
				FbDbSchemaType.Procedures, null);
		}

		[Test]
		public void ProviderTypes()
		{
			DataTable providerTypes = Connection.GetDbSchemaTable(
				FbDbSchemaType.Provider_Types, null);
		}

		[Test]
		public void Roles()
		{
			DataTable roles = Connection.GetDbSchemaTable(
				FbDbSchemaType.Roles, null);
		}

		[Test]
		[Ignore("Not implemented.")]
		public void Statistics()
		{
			DataTable statistics = Connection.GetDbSchemaTable(
				FbDbSchemaType.Statistics, null);
		}

		[Test]
		public void Tables()
		{
			DataTable tables = Connection.GetDbSchemaTable(
				FbDbSchemaType.Tables, null);
		}

		[Test]
		public void TableConstraint()
		{
			DataTable tableConstraint = Connection.GetDbSchemaTable(
				FbDbSchemaType.Table_Constraint, null);
		}

		[Test]
		public void TablePrivileges()
		{
			DataTable tablePrivileges = Connection.GetDbSchemaTable(
				FbDbSchemaType.Table_Privileges, null);
		}

		[Test]
		[Ignore("Not implemented.")]
		public void TableStatistics()
		{
			DataTable table_Statistics = Connection.GetDbSchemaTable(
				FbDbSchemaType.Table_Statistics, null);
		}

		[Test]
		public void Triggers()
		{
			DataTable triggers = Connection.GetDbSchemaTable(
				FbDbSchemaType.Triggers, null);
		}

		[Test]
		[Ignore("Not implemented.")]
		public void UsagePrivileges()
		{
			DataTable usagePrivileges = Connection.GetDbSchemaTable(
				FbDbSchemaType.Usage_Privileges, null);
		}

		[Test]
		public void ViewColumnUsage()
		{
			DataTable viewColumnUsage = Connection.GetDbSchemaTable(
				FbDbSchemaType.View_Column_Usage, null);
		}

		[Test]
		public void Views()
		{
			DataTable views = Connection.GetDbSchemaTable(
				FbDbSchemaType.Views, null);
		}

		[Test]
		public void ViewPrivileges()
		{
			DataTable viewPrivileges = Connection.GetDbSchemaTable(
				FbDbSchemaType.View_Privileges, null);
		}
	}
}
