//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbPrimaryKeysSchema : FbAbstractDbSchema
	{
		#region CONSTRUCTORS

		public FbPrimaryKeysSchema() : base("PrimaryKeys")
		{
		}

		#endregion

		#region ADD_METHODS

		public override void AddTables()
		{
			AddTable("rdb$relation_constraints rel");
		}

		public override void AddRestrictionColumns()
		{
			AddRestrictionColumn("rel.rdb$relation_name"	, "TABLE_NAME", null);
			AddRestrictionColumn("rel.rdb$constraint_name"	, "PK_NAME", null);
		}

		public override void AddDataColumns()
		{
			AddDataColumn("rel.rdb$deferrable"			, "DEFERRABLE");
			AddDataColumn("rel.rdb$initially_deferred"	, "INITIALLY_DEFERRED");
			AddDataColumn("rfr.rdb$field_name"			, "FIELD_NAME");
		}

		public override void AddJoins()
		{
			AddJoin("left join", "rdb$indices idx"			, "rel.rdb$index_name = idx.rdb$index_name");
			AddJoin("left join", "rdb$index_segments seg"	, "idx.rdb$index_name = seg.rdb$index_name");
			AddJoin("left join", "rdb$relation_fields rfr"	, "rel.rdb$relation_name = rfr.rdb$relation_name AND seg.rdb$field_name = rfr.rdb$field_name");
		}

		public override void AddOrderByColumns()
		{
			AddOrderBy("rel.rdb$relation_name");
		}

		public override void AddWhereFilters()
		{
			AddWhereFilter("rel.rdb$constraint_type = 'PRIMARY KEY'");
		}

		#endregion

		#region PARSE_METHODS

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}