//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;

using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Design
{
	internal class ParameterCollectionEditor : System.ComponentModel.Design.CollectionEditor
	{
		#region Fields

		private FbParameterCollection parameters;

		#endregion

		#region Constructors

		public ParameterCollectionEditor(Type type) : base(type)
		{
			parameters = null;
		}

		#endregion

		#region Methods

		public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
		{
			this.parameters = (FbParameterCollection)value;
			return base.EditValue(context, provider, value);
		}

		#endregion

		#region Protected Methods

		protected override object CreateInstance(Type type)
		{
			FbParameter parameter = (FbParameter)base.CreateInstance(type);
			
			parameter.ParameterName = this.generateParameterName("Parameter");

			return parameter;
		}

		#endregion

		#region Private Methods

		private string generateParameterName(string prefix)
		{
			string	parameterName	= String.Empty;
			int		index			= parameters.Count + 1;
			bool	valid			= false;
			
			while (!valid)
			{
				parameterName = prefix + index.ToString();
				if (parameters.IndexOf(parameterName) == -1)
				{
					valid = true;
				}
				index++;
			}

			return parameterName;
		}

		#endregion
	}
}
