//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Firebird.Gds
{
	[Serializable]
	internal class GdsErrorCollection : ArrayList
	{
		#region PROPERTIES

		public GdsError this[string errorMessage] 
		{
			get { return (GdsError)this[IndexOf(errorMessage)]; }
			set { this[IndexOf(errorMessage)] = (GdsError)value; }
		}

		public new GdsError this[int errorIndex] 
		{
			get { return (GdsError)base[errorIndex]; }
			set { base[errorIndex] = (GdsError)value; }
		}

		#endregion

		#region METHODS
	
		public bool Contains(string errorMessage)
		{
			return(-1 != IndexOf(errorMessage));
		}
		
		public int IndexOf(string errorMessage)
		{
			int index = 0;

			foreach (GdsError item in this)
			{
				if (cultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		public void RemoveAt(string errorMessage)
		{
			RemoveAt(IndexOf(errorMessage));
		}

		internal GdsError Add(GdsError error)
		{
			base.Add(error);

			return error;
		}
		
		internal GdsError Add(int errorCode)
		{
			GdsError error = new GdsError(errorCode);			

			return Add(error);
		}

		internal GdsError Add(string message)
		{
			GdsError error = new GdsError(message);			

			return Add(error);
		}

		internal GdsError Add(int type, string strParam)
		{
			GdsError error = new GdsError(type, strParam);			

			return Add(error);
		}

		internal GdsError Add(int type, int errorCode)
		{
			GdsError error = new GdsError(type, errorCode);			

			return Add(error);
		}

		internal GdsError Add(int type, int errorCode, string strParam)
		{
			GdsError error = new GdsError(type, errorCode, strParam);

			return Add(error);
		}

		private bool cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(
				strA, 
				strB, 
				CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | 
				CompareOptions.IgnoreCase) == 0 ? true : false;
		}

		#endregion
	}
}
