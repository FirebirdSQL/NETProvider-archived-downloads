//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird.Gds
{
	[Serializable]
	internal class GdsError
	{
		#region FIELDS

		private string	message;
		private int		type;
		private int		errorCode;
		private string	strParam;
		private bool	isFatal;
		
		#endregion

		#region PROPERTIES
		
		public string Message
		{
			get { return message; }
			set { message = value; }
		}

		public int ErrorCode
		{
			get { return errorCode; }
		}

		public string StrParam
		{
			get
			{
				if ((type == GdsCodes.isc_arg_interpreted) || (type == GdsCodes.isc_arg_string))
				{
					return strParam;
				}
				else
				{
					if (type == GdsCodes.isc_arg_number)
					{
						return errorCode.ToString();
					}				
					else
					{
						return String.Empty;
					}
				}
			}
		}

		public int Type
		{
			get { return type; }
		}

		public bool IsFatal
		{
			get { return isFatal; }
		}

		#endregion

		#region CONSTRUCTORS

		internal GdsError(int errorCode)
		{						
			this.errorCode	= errorCode;
			this.isFatal = CheckIfIsFatal();
		}

		internal GdsError(string strParam)
		{
			this.strParam	= strParam;
		}

		internal GdsError(int type, string strParam)
		{
			this.type		= type;
			this.strParam	= strParam;
		}

		internal GdsError(int type, int errorCode)
		{
			this.type		= type;
			this.errorCode	= errorCode;

			if (type == GdsCodes.isc_arg_number)
			{
				this.isFatal = CheckIfIsFatal();
			}
		}

		internal GdsError(int type, int errorCode, string strParam)
		{
			this.type		= type;
			this.errorCode	= errorCode;
			this.strParam	= strParam;

			if (type == GdsCodes.isc_arg_number)
			{
				this.isFatal = CheckIfIsFatal();
			}
		}

		#endregion

		#region METHODS

		public bool IsWarning() 
		{
			return (Type == GdsCodes.isc_arg_warning);
		}

		private bool CheckIfIsFatal()
		{
			/*
			for (int i = 0; i < GdsCodes.FATAL_ERRORS.Length 
				&& ErrorCode >= GdsCodes.FATAL_ERRORS[i]; i++)
			{
				if (ErrorCode == GdsCodes.FATAL_ERRORS[i]) 
				{
					return true;
				}
            
			}
			*/
			return false;
		}

		#endregion
	}
}
