//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fberror.xml' path='doc/member[@name="T:FbError"]/*'/>	
	[Serializable]
	public sealed class FbError
	{
		#region FIELDS

		private byte	classError = 0;
		private int		lineNumber = 0;
		private string	message;
		private int		number;
		
		#endregion

		#region PROPERTIES
		
		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="P:Class"]/*'/>
		public byte Class
		{
			get { return classError; }
		}
		
		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="P:LineNumber"]/*'/>
		public int LineNumber
		{
			get { return lineNumber; }
		}

		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="P:Message"]/*'/>
		public string Message
		{
			get { return message; }
		}

		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="P:Number"]/*'/>
		public int Number
		{
			get { return number; }
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="M:#ctor"]/*'/>
		internal FbError()
		{
		}
		
		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="M:#ctor(System.String,System.Int32)"]/*'/>
		internal FbError(string message,int number)
		{			
			this.number		= number;
			this.message	= message;
		}

		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="M:#ctor(System.Byte,System.String,System.Int32)"]/*'/>
		internal FbError(byte classError, string message, int number)
		{			
			this.classError = classError;
			this.number		= number;
			this.message	= message;
		}

		/// <include file='xmldoc/fberror.xml' path='doc/member[@name="M:#ctor(System.Byte,System.Int32,System.String,System.Int32)"]/*'/>
		internal FbError(byte classError, int line, string message, int number)
		{			
			this.classError = classError;
			this.lineNumber = line;
			this.number		= number;
			this.message	= message;
		}

		#endregion
	}
}
