//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/overview/*'/>
	[Serializable]	
	public enum FbDbType
	{
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Array"]/*'/>
		Array			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="BigInt"]/*'/>
		BigInt			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Binary"]/*'/>
		Binary			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Char"]/*'/>
		Char			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Date"]/*'/>
		Date			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Decimal"]/*'/>
		Decimal			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Double"]/*'/>
		Double			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Float"]/*'/>
		Float			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Integer"]/*'/>
		Integer			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Numeric"]/*'/>
		Numeric			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="SmallInt"]/*'/>
		SmallInt		,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Text"]/*'/>
		Text			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="Time"]/*'/>
		Time			,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="TimeStamp"]/*'/>
		TimeStamp		,
		/// <include file='Doc/en_EN/FbDbType.xml' path='doc/enum[@name="FbDbType"]/field[@name="VarChar"]/*'/>
		VarChar
	}
}
