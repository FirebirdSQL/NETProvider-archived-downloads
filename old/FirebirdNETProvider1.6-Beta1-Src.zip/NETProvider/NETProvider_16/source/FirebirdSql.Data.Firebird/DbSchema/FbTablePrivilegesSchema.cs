//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbTablePrivilegesSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbTablePrivilegesSchema() : base("Table_Privileges")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$user_privileges");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"rdb$relation_name", "TABLE_NAME", null);
			
			this.AddRestrictionColumn(
				"rdb$user", "GRANTEE", null);

			this.AddRestrictionColumn(
				"rdb$grantor", "GRANTOR", null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("rdb$privilege"		, "PRIVILEGE");
			this.AddDataColumn("rdb$grant_option"	, "WITH_GRANT");
		}

		public override void AddJoins()
		{
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("rdb$relation_name");
		}

		public override void AddWhereFilters()
		{
			this.AddWhereFilter("rdb$object_type = 0");
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}