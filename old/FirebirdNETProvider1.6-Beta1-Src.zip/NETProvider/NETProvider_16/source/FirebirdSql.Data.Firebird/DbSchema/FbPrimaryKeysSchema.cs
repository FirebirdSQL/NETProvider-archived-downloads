//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbPrimaryKeysSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbPrimaryKeysSchema() : base("PrimaryKeys")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$relation_constraints rel");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"rel.rdb$relation_name", 
				"TABLE_NAME", 
				null);

			this.AddRestrictionColumn(
				"rel.rdb$constraint_name", 
				"PK_NAME", 
				null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("rel.rdb$deferrable", "DEFERRABLE");
			this.AddDataColumn(
				"rel.rdb$initially_deferred", "INITIALLY_DEFERRED");
			this.AddDataColumn("rfr.rdb$field_name", "FIELD_NAME");
		}

		public override void AddJoins()
		{
			this.AddJoin(
				"left join", 
				"rdb$indices idx", 
				"rel.rdb$index_name = idx.rdb$index_name");
			
			this.AddJoin(
				"left join", 
				"rdb$index_segments seg", 
				"idx.rdb$index_name = seg.rdb$index_name");
			
			this.AddJoin(
				"left join", 
				"rdb$relation_fields rfr", 
				"rel.rdb$relation_name = rfr.rdb$relation_name AND seg.rdb$field_name = rfr.rdb$field_name");
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("rel.rdb$relation_name");
		}

		public override void AddWhereFilters()
		{
			this.AddWhereFilter("rel.rdb$constraint_type = 'PRIMARY KEY'");
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}