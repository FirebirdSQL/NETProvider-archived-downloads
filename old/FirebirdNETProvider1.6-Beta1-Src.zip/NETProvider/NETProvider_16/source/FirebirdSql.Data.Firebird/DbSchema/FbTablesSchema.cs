//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbTablesSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbTablesSchema() : base("Tables")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$relations");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"rdb$relation_name", "TABLE_NAME", null);
			
			this.AddRestrictionColumn(
				"rdb$view_blr", "TABLE_TYPE", null);
			
			this.AddRestrictionColumn(
				"rdb$system_flag", "SYSTEM_TABLE", null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("rdb$owner_name"	, "OWNER_NAME");
			this.AddDataColumn("rdb$description", "DESCRIPTION");
		}

		public override void AddJoins()
		{
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("rdb$system_flag");
			this.AddOrderBy("rdb$owner_name");
			this.AddOrderBy("rdb$relation_name");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}