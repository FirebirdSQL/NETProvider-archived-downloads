//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbTriggersSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbTriggersSchema() : base("Triggers")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$triggers");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"rdb$trigger_name", "TRIGGER_NAME", null);

			this.AddRestrictionColumn(
				"rdb$relation_name", "TABLE_NAME", null);
			
			this.AddRestrictionColumn(
				"rdb$system_flag", "SYSTEM_TRIGGER", null);
			
			this.AddRestrictionColumn(
				"rdb$trigger_type", "TRIGGER_TYPE", null);
		
			this.AddRestrictionColumn(
				"rdb$trigger_inactive", "TRIGGER_INACTIVE", null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("rdb$trigger_sequence"	, "SEQUENCE");
			this.AddDataColumn("rdb$trigger_source"		, "SOURCE");
			this.AddDataColumn("rdb$description"		, "DESCRIPTION");
		}

		public override void AddJoins()
		{
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("rdb$relation_name");
			this.AddOrderBy("rdb$trigger_name");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}