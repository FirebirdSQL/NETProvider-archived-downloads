//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/overview/*'/>
	[Flags]
	[Serializable]
	public enum FbTransactionOptions : int
	{
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Consistency"]/*'/>
		Consistency		= 1,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Concurrency"]/*'/>
		Concurrency		= 2,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Shared"]/*'/>
		Shared			= 4,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Protected"]/*'/>
		Protected		= 8,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Exclusive"]/*'/>
		Exclusive		= 16,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Wait"]/*'/>
		Wait				= 32,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="NoWait"]/*'/>
		NoWait			= 64,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Read"]/*'/>
		Read			= 128,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Write"]/*'/>
		Write			= 256,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="LockRead"]/*'/>
		LockRead		= 512,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="LockWrite"]/*'/>
		LockWrite		= 1024,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="ReadCommitted"]/*'/>
		ReadCommitted	= 2048,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="Autocommit"]/*'/>
		Autocommit		= 4096,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="RecVersion"]/*'/>
		RecVersion		= 8192,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="NoRecVersion"]/*'/>
		NoRecVersion	= 16384,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="RestartRequests"]/*'/>
		RestartRequests	= 32768,
		/// <include file='Doc/en_EN/FbTransactionOptions.xml' path='doc/enum[@name="FbTransactionOptions"]/field[@name="NoAutoUndo"]/*'/>
		NoAutoUndo		= 65536
	}
}
