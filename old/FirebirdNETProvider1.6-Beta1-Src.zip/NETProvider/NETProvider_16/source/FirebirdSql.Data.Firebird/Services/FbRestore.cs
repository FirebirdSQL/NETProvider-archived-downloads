//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird.Services
{
	#region Enumerations

	/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/overview/*'/>
	[Flags]
	public enum FbRestoreFlags
	{
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="DeactivateIndexes"]/*'/>
		DeactivateIndexes			= 0x0100,
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="NoShadow"]/*'/>
		NoShadow					= 0x0200,
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="NoValidity"]/*'/>
		NoValidity					= 0x0400,
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="IndividualCommit"]/*'/>
		IndividualCommit			= 0x0800,
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="Replace"]/*'/>
		Replace						= 0x1000,
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="Create"]/*'/>
		Create						= 0x2000,
		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/enum[@name="FbRestoreFlags"]/field[@name="UseAllSpace"]/*'/>
		UseAllSpace					= 0x4000
	}

	#endregion

	/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/overview/*'/>
	public sealed class FbRestore : FbService
	{
		#region Fields

		private ArrayList			backupFiles;
		private bool				verbose;
		private int					pageBuffers;
		private int					pageSize;
		private FbRestoreFlags		options;
		
		#endregion

		#region Properties

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/property[@name="BackupFiles"]/*'/>
		public ArrayList BackupFiles
		{
			get { return this.backupFiles; }
			set { this.backupFiles = value; }
		}

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/property[@name="Verbose"]/*'/>
		public bool	Verbose
		{
			get { return this.verbose; }
			set { this.verbose = value; }
		}

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/property[@name="PageBuffers"]/*'/>
		public int PageBuffers
		{
			get { return this.pageBuffers; }
			set { this.pageBuffers = value; }
		}

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/property[@name="PageSize"]/*'/>
		public int PageSize
		{
			get { return this.pageSize; }
			set
			{
				if (this.pageSize != 1024 && 
					this.pageSize != 2048 && 
					this.pageSize != 4096 &&
					this.pageSize != 8192 && 
					this.pageSize != 16384)
				{
					throw new InvalidOperationException("Invalid page size.");
				}
				this.pageSize = value;
			}
		}

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/property[@name="Options"]/*'/>
		public FbRestoreFlags Options
		{
			get { return this.options; }
			set { this.options = value; }
		}

		#endregion

		#region Constructors

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/constructor[@name="ctor"]/*'/>
		public FbRestore() : base()
		{
			this.backupFiles	= new ArrayList();
			this.verbose		= false;
			this.pageSize		= 4096;
			this.pageBuffers	= 2048;
		}

		#endregion

		#region Methods

		/// <include file='Doc/en_EN/FbRestore.xml' path='doc/class[@name="FbRestore"]/method[@name="Start"]/*'/>
		public void Start()
		{
			// Configure Spb
			this.StartSpb = new SpbBuffer();
			this.StartSpb.Append(IscCodes.isc_action_svc_restore);			
			foreach(FbBackupFile bkpFile in backupFiles)
			{
				this.StartSpb.Append(
					IscCodes.isc_spb_bkp_file, 
					bkpFile.BackupFile);
			}
			this.StartSpb.Append(
				IscCodes.isc_spb_dbname, 
				this.Parameters.Database);
			if (this.verbose)
			{
				this.StartSpb.Append(IscCodes.isc_spb_verbose);
			}
			this.StartSpb.Append(IscCodes.isc_spb_res_buffers, this.pageBuffers);
			this.StartSpb.Append(IscCodes.isc_spb_res_page_size, this.pageSize);
			this.StartSpb.Append(IscCodes.isc_spb_options, (int)this.options);
			
			// Start execution
			this.startTask();			
		}
				
		#endregion		
	}
}
