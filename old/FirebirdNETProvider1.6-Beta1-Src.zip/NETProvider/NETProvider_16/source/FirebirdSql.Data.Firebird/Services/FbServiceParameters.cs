//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace FirebirdSql.Data.Firebird.Services
{
	/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/class[@name="FbServiceParameters"]/overview/*'/>
	public sealed class FbServiceParameters
	{
		#region Fields

		private string	userName;
		private string	userPassword;
		private string	dataSource;
		private int		port;
		private byte	dialect;
		private string	database;
		private string	role;
		private int		packetSize;
		private int		serverType;

		#endregion

		#region Properties

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="UserName"]/*'/>
		public string UserName
		{
			get { return this.userName; }
			set { this.userName = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="UserPassword"]/*'/>
		public string UserPassword
		{
			get { return this.userPassword; }
			set { this.userPassword = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="DataSource"]/*'/>
		public string DataSource
		{
			get { return this.dataSource; }
			set { this.dataSource = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="Port"]/*'/>
		public int Port
		{
			get { return this.port; }
			set { this.port = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="Dialect"]/*'/>
		public byte	Dialect
		{
			get { return this.dialect; }
			set { this.dialect = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="Database"]/*'/>
		public string Database
		{
			get { return this.database; }
			set { this.database = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="PacketSize"]/*'/>
		public int PacketSize
		{
			get { return this.packetSize; }
			set { this.packetSize = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="Role"]/*'/>
		public string Role
		{
			get { return this.role; }
			set { this.role = value; }
		}

		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/property[@name="ServerType"]/*'/>
		public int ServerType
		{
			get { return this.serverType; }
			set { this.serverType = value; }
		}

		#endregion

		#region Constructors
		
		/// <include file='Doc/en_EN/FbServiceParameters.xml' path='doc/constructor[@name="ctor"]/*'/>
		public FbServiceParameters()
		{
			this.userName		= String.Empty;
			this.userPassword	= String.Empty;
			this.database		= String.Empty;
			this.role			= String.Empty;		
			this.dataSource		= "localhost";
			this.port			= 3050;
			this.dialect		= 3;
			this.packetSize		= 8192;
		}
		
		#endregion
	}
}
