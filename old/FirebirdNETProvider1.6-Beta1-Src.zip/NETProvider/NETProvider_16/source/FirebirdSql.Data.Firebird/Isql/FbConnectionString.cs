//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2003-2004 Abel Eduardo Pereira.
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Isql
{
	/// <summary>
	/// Encapsulates the Firebird connection string
	/// </summary>
	public class FbConnectionString: Object 
	{
		#region Private fields...
		private string user = "SYSDBA";
		private string password = "masterkey";
		private string database = "";
		private string dataSource = "localhost";
		private int port = 3050;
		private int dialect = 3;
		private string charset = "NONE";
		private string role = "";
		private int connectionLifetime = 15;
		private bool polling = true;
		private int packetSize = 8192;
		#endregion

		// expects a field in the format: <string>=<string>
		private void ParseConnectionField(string unknownField) 
		{
			int i = 0;
			int len = unknownField.Length;

			while ((i < len) && (unknownField[i] != '=')) 
				i++;

			string s = unknownField.Substring(0, i);
			string val = unknownField.Substring(i + 1);
			
			if (s.Equals("User")) 
			{
				this.User = val;
				return;
			}
			if (s.Equals("Password")) 
			{
				this.Password = val;
				return;
			}
			if (s.Equals("Database")) 
			{
				this.Database = val;
				return;
			}
			if (s.Equals("DataSource") || s.Equals("Server") ) 
			{
				this.DataSource = val;
				return;
			}
			if (s.Equals("Port")) 
			{
				this.Port = int.Parse(val);
				return;
			}
			if (s.Equals("Dialect")) 
			{
				this.Dialect = int.Parse(val);
				return;
			}
			if (s.Equals("Charset")) 
			{
				this.Charset = val;
				return;
			}
			if (s.Equals("Role")) 
			{
				this.Role = val;
				return;
			}
			if (s.Equals("User")) 
			{
				this.User = val;
				return;
			}
			if (s.Equals("Connection lifetime")) 
			{
				this.ConnectionLifetime = int.Parse(val);
				return;
			}
			if (s.Equals("Polling")) 
			{
				this.Polling = bool.Parse(val);
				return;
			}
			if (s.Equals("Packet Size")) 
			{
				this.PacketSize = int.Parse(val);
				return;
			}

			throw new Exception("No connection parameter was found on string to parse.");
		}

		/// <summary>
		/// Builds the Firebird connection string from the data on the fields. This method is invoked by ToString(). 
		/// </summary>
		/// <returns>The Firebird connection string.</returns>
		protected virtual string ConnectionStringFromFields() 
		{
			return "User=" + this.User + ";" + "Password=" + this.Password + ";" +
				"Database=" + this.Database + ";" +	"DataSource=" + this.DataSource + ";" +
				"Port=" + this.Port.ToString() + ";" + "Dialect=" + this.Dialect.ToString() + ";" +
				"Charset=" +this.Charset + ";" + "Role=" + this.Role + ";" +
				"Connection lifetime=" + this.ConnectionLifetime + ";" +
				"Polling=" + this.Polling.ToString() + ";" +
				"Packet Size=" + this.PacketSize.ToString() + ";";	
		}

		/// <summary>
		/// Parses the <c>connectionString</c> and loads its tokens into the instance properties. 
		/// </summary>
		/// <param name="connectionString">The well formed Firebird connection string.</param>
		protected void ConnectionStringToFields(string connectionString) 
		{
			int len = connectionString.Length;
			int index = 0;
			int mark = 0;

			while (index < len) 
			{
				while (index < len) 
				{
					if (connectionString[index] == ';') 
					{
						ParseConnectionField(connectionString.Substring(mark, index - mark));
						mark = index + 1;
						break;
					}
					else index++;
				}
				index++;
			}
		}

		/// <summary>
		/// Parsed and loads a connection string object.
		/// </summary>
		/// <param name="connectionString">A valid Firebird connection string.</param>
		public void Load(string connectionString)
		{
			ConnectionStringToFields(connectionString);
		}
		// constructors:
		/// <summary>
		/// 
		/// </summary>
		public FbConnectionString() 
		{

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="connectionString">The Firebird connection string used in <see cref="FbConnection"/>.</param>
		public FbConnectionString(string connectionString) 
		{
			this.ConnectionStringToFields(connectionString);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="user">The username used to establish a connection to the Firebird server.</param>
		/// <param name="password">The user password used to establish a connection to the Firebird server.</param>
		/// <param name="database">The database that you wish to establish the connection.</param>
		public FbConnectionString(string user, string password, string database) 
		{
			this.User = user;
			this.Password = password;
			this.Database = database;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="user">The username used to establish a connection to the Firebird server.</param>
		/// <param name="password">The user password used to establish a connection to the Firebird server.</param>
		/// <param name="database">The database that you wish to establish the connection.</param>
		/// <param name="dataSource">The host where the Firebird database server is located. </param>
		/// <param name="port">The service port of the Firebird database server.</param>
		public FbConnectionString(string user, string password, string database, string dataSource, int port) 
		{
			this.User = user;
			this.Password = password;
			this.Database = database;
			this.DataSource = dataSource;
			this.Port = port;
		}

		/// <summary>
		/// Loads instance properties from a XML document containing the connection string representation.
		/// </summary>
		/// <param name="alias">The alias of the connection string.</param>
		/// <param name="xmlDocument">The XML document filename.</param>
		/// <example>
		/// <code>
		/// &lt;?xml version="1.0" encoding="utf-8" ?&gt;
		///	&lt;profile Alias="sapiens"&gt;
		///		&lt;User&gt;SYSDBA&lt;/User&gt;
		///		&lt;Password&gt;masterkey&lt;/Password&gt;
		///		&lt;Database&gt;d:\databases\WEBRESOURCES.FDB&lt;/Database&gt;
		///		&lt;DataSource&gt;localhost&lt;/DataSource&gt;
		///		&lt;Port&gt;3050&lt;/Port&gt;
		///		&lt;Dialect&gt;3&lt;/Dialect&gt;
		///		&lt;Charset&gt;NONE&lt;/Charset&gt;
		///		&lt;Role&gt;&lt;/Role&gt;
		///		&lt;ConnectionLifetime&gt;15&lt;/ConnectionLifetime&gt;
		///		&lt;Polling&gt;true&lt;/Polling&gt;
		///		&lt;PacketSize&gt;8192&lt;/PacketSize&gt;
		///	&lt;/profile&gt;
		/// </code>
		/// </example>
		public virtual void FromXML(string alias, string xmlDocument) 
		{

			DataSet ds = new DataSet();
			ds.ReadXml(xmlDocument);
			DataRow[] rows;
			try 
			{
				rows = ds.Tables[0].Select("Alias='"+alias+"'");	
			}
			catch (Exception) 
			{
				throw new Exception("The profile \""+alias+"\" was not found in XML document:\n" + xmlDocument);  
			}
			this.User = (string) rows[0]["User"];
			this.Password = (string) rows[0]["Password"];
			this.Database = (string) rows[0]["Database"];
			this.DataSource = (string) rows[0]["DataSource"];
			this.Port = int.Parse((string) rows[0]["Port"]);
			this.Dialect = int.Parse((string) rows[0]["Dialect"]);
			this.Charset = (string) rows[0]["Charset"];	
			this.Role = (string) rows[0]["Role"];
			this.ConnectionLifetime = int.Parse((string) rows[0]["ConnectionLifetime"]);
			this.Polling = bool.Parse((string) rows[0]["Polling"]);
			this.PacketSize = int.Parse((string) rows[0]["PacketSize"]);
		}

		/// <summary>
		/// Overrided method, returns the Firebird connection string.
		/// </summary>
		/// <returns>The Firebird connection string.</returns>
		public override string ToString() 
		{
			return ConnectionStringFromFields();
		}

		/// <summary>
		/// Firebird User account for login. Default value: SYSDBA
		/// </summary>
		public virtual string User 
		{
			get 
			{
				return this.user;
			}
			set 
			{
				this.user = value;
			}
		}

		/// <summary>
		/// Password for the Firebird user account. Default value: masterkey
		/// </summary>
		public virtual string Password 
		{
			get 
			{
				return this.password;
			} 
			set 
			{
				this.password = value;
			}
		}

		/// <summary>
		/// Database path to establish the connection. Default value: an empty string.
		/// </summary>
		public virtual string Database 
		{
			get 
			{
				return this.database;
			}
			set 
			{
				this.database = value;
			}
		}

		/// <summary>
		/// Server name for establish the connection. Default value: localhost
		/// </summary>
		public virtual string DataSource 
		{
			get 
			{
				return this.dataSource;
			}
			set 
			{
				this.dataSource = value;
			}
		}

		/// <summary>
		/// Port number in the server for establish the connection. Default value: 3050
		/// </summary>
		public virtual int Port 
		{
			get 
			{
				return this.port;
			}
			set 
			{
				this.port = value;
			}
		}

		/// <summary>
		/// Database dialect. Default value: 3
		/// </summary>
		public virtual int Dialect 
		{
			get 
			{
				return this.dialect;
			}
			set 
			{
				this.dialect = value;
			}
		}

		/// <summary>
		/// Database Character Set. Default value: NONE
		/// </summary>
		public virtual string Charset 
		{
			get 
			{
				return this.charset;
			}
			set 
			{
				this.charset = value;
			}
		}

		/// <summary>
		/// User Role. Default value: an empty string.
		/// </summary>
		public virtual string Role 
		{
			get 
			{
				return this.role;
			}
			set 
			{
				this.role = value; 
			}
		}

		/// <summary>
		/// When a connection is returned to the pool, its creation time is compared with the current time, and the connection is destroyed if that time span (in seconds) exceeds the value specified by connection lifetime. Default value: 0
		/// </summary>
		public virtual int ConnectionLifetime 
		{
			get 
			{
				return this.connectionLifetime;
			}
			set 
			{
				this.connectionLifetime = value;
			}
		}

		/// <summary>
		/// When true, the FbConnection object is drawn from the appropriate pool, or if necessary, is created and added to the appropriate pool. Default value: true
		/// </summary>
		public virtual bool Polling 
		{
			get 
			{
				return this.polling;
			}
			set 
			{
				this.polling = value;
			}
		}

		/// <summary>
		/// Size (in bytes) of network packets used to communicate with an instance of Firebird Server. Default value: 8192
		/// </summary>
		public virtual int PacketSize 
		{
			get 
			{
				return this.packetSize;
			}
			set 
			{
				this.packetSize = value;
			}
		}
	}
}
