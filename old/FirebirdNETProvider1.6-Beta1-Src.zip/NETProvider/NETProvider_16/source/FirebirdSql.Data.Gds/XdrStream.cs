//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Text;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Gds
{
	internal class XdrStream : Stream, IDisposable
	{
		#region Static Fields

		private static byte[] fill;
		private static byte[] pad;

		#endregion

		#region Static Properties

		internal static byte[] Fill
		{
			get
			{
				if (fill == null)
				{
					fill = new byte[32767];
					for (int i = 0; i < fill.Length; i++)
					{
						fill[i] = 32;
					}
				}

				return fill;
			}
		}

		private static byte[] Pad
		{
			get
			{
				if (pad == null)
				{
					pad	= new byte[]{0,0,0,0};
				}

				return pad;
			}
		}

		#endregion

		#region Fields

		private byte[]		buffer;
		private Charset		charset;
		private Encoding	encoding;
		private Stream		innerStream;
		private bool		disposed;

		#endregion

		#region Stream Properties

		public override bool CanWrite
		{
			get { return this.innerStream.CanWrite; }
		}

		public override bool CanRead
		{
			get { return this.innerStream.CanRead; }
		}

		public override bool CanSeek
		{
			get { return this.innerStream.CanSeek; }
		}

		public override long Position
		{
			get { return this.innerStream.Position; }
			set { this.innerStream.Position = value; }
		}

		public override long Length
		{
			get { return this.innerStream.Length; }
		}

		#endregion

		#region Constructors

		public XdrStream() : this(new MemoryStream(), Charset.DefaultCharset)
		{
		}

		public XdrStream(Charset charset) : this(new MemoryStream(), charset)
		{
		}

		public XdrStream(byte[] buffer) : this(buffer, Charset.DefaultCharset)
		{
		}

		public XdrStream(byte[] buffer, Charset charset) : this(new MemoryStream(buffer), charset)
		{
		}

		public XdrStream(Stream innerStream, Charset charset) : base()
		{
			this.buffer			= new byte[8]{0,0,0,0,0,0,0,0};
			this.innerStream	= innerStream;
			this.charset		= charset;
			this.encoding		= charset.Encoding;
		}

		#endregion

		#region Finalizer

		~XdrStream()
		{
			this.Dispose(false);
		}

		#endregion

        #region IDisposable Methods

		void IDisposable.Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposed)
			{
				if (disposing)
				{
					if (this.innerStream != null)
					{
						((IDisposable)this.innerStream).Dispose();
					}
					this.encoding		= null;
					this.innerStream	= null;
				}

				this.disposed = true;
			}
		}

		#endregion

		#region Stream methods

		public override void Close()
		{
			((IDisposable)this).Dispose();
		}

		public override void Flush()
		{
			this.checkDisposed();

			this.innerStream.Flush();
		}

		public override void SetLength(long length)
		{
			this.checkDisposed();

			this.innerStream.SetLength(length);
		}

		public override long Seek(long offset, System.IO.SeekOrigin loc)
		{
			this.checkDisposed();

			return this.innerStream.Seek(offset, loc);
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			this.checkDisposed();

			if (this.CanRead)
			{
				return this.innerStream.Read(buffer, offset, count);
			}
			
			throw new InvalidOperationException("Read operations are not allowed by this stream");
		}

		public override void WriteByte(byte value)
		{
			this.checkDisposed();

			this.innerStream.WriteByte(value);
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			this.checkDisposed();

			if (this.CanWrite)
			{
				this.innerStream.Write(buffer, offset, count);
			}
			else
			{
				throw new InvalidOperationException("Write operations are not allowed by this stream");
			}
		}

		public byte[] ToArray()
		{
			this.checkDisposed();

			if (this.innerStream is MemoryStream)
			{
				return ((MemoryStream)this.innerStream).ToArray();
			}
			
			throw new InvalidOperationException();
		}

		#endregion

		#region Xdr Read Methods

		public byte[] ReadOpaque(int length)
		{
			byte[]	buffer = new byte[length];
			int		readed = 0;

			while (readed < length)
			{
				readed += this.Read(buffer, readed, length-readed);
			}

			int padLength = ((4 - length) & 3);
			if (padLength > 0)
			{
				this.Read(Pad, 0, padLength);
			}

			return buffer;
		}

		public byte[] ReadBuffer()
		{	
			return this.ReadOpaque(this.ReadInt32());
		}

		public string ReadString()
		{
			return this.ReadString(this.encoding);
		}

		public string ReadString(int length)
		{		
			return this.ReadString(this.encoding, length);
		}

		public string ReadString(Encoding encoding)
		{
			return this.ReadString(encoding, this.ReadInt32());
		}

		public string ReadString(Encoding encoding, int length)
		{		
			return encoding.GetString(this.ReadOpaque(length));
		}

		public short ReadInt16()
		{
			return Convert.ToInt16(this.ReadInt32());
		}

		public int ReadInt32()
		{
			this.Read(buffer, 0, 4);
			
			return IPAddress.HostToNetworkOrder(BitConverter.ToInt32(buffer, 0));
		}

		public long ReadInt64()
		{
			this.Read(buffer, 0, 8);
			
			return IPAddress.HostToNetworkOrder(BitConverter.ToInt64(buffer, 0));
		}

		public float ReadSingle()
		{			
			FloatLayout layout = new FloatLayout();
			
			layout.i0 = this.ReadInt32();

			return layout.f;
		}
		
		public double ReadDouble()
		{			
			DoubleLayout layout = new DoubleLayout();
		
			layout.i4 = this.ReadInt32();
			layout.i0 = this.ReadInt32();

			return layout.d;
		}

		public DateTime ReadDateTime()
		{
			DateTime date = this.ReadDate();
			DateTime time = this.ReadTime();

			return new System.DateTime(
				date.Year, date.Month, date.Day,
				time.Hour,time.Minute, time.Second, time.Millisecond);
		}

		public DateTime ReadDate()
		{
			return TypeDecoder.DecodeDate(this.ReadInt32());
		}

		public DateTime ReadTime()
		{
			return TypeDecoder.DecodeTime(this.ReadInt32());
		}

		public decimal ReadDecimal(int type, int scale)
		{
			decimal value = 0;

			switch (type)
			{
				case IscCodes.SQL_SHORT:
					value = TypeDecoder.DecodeDecimal(
						this.ReadInt16(),
						scale,
						type);	
					break;
					
				case IscCodes.SQL_LONG:
					value = TypeDecoder.DecodeDecimal(
						this.ReadInt32(),
						scale,
						type);
					break;
					
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					value = TypeDecoder.DecodeDecimal(
						this.ReadInt64(),
						scale,
						type);
					break;

				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					value = Convert.ToDecimal(this.ReadDouble());
					break;
			}

			return value;
		}

		public object ReadValue(DbField field)
		{
			object fieldValue = null;

			switch (field.DbDataType)
			{
				case DbDataType.Char:
				{
					string s = this.ReadString(
						field.Charset.Encoding, 
						field.Length);

					if ((field.Length % field.Charset.BytesPerCharacter) == 0 &&
						s.Length > field.CharCount)
					{
						fieldValue = s.Substring(0, field.CharCount);
					}
					else
					{
						fieldValue = s;
					}
				}
				break;
					
				case DbDataType.VarChar:
					fieldValue = this.ReadString(field.Charset.Encoding).TrimEnd();
					break;
					
				case DbDataType.SmallInt:
					fieldValue = this.ReadInt16();
					break;
					
				case DbDataType.Integer:
					fieldValue = this.ReadInt32();
					break;
					
				case DbDataType.Array:
				case DbDataType.Binary:
				case DbDataType.Text:
				case DbDataType.BigInt:
					fieldValue = this.ReadInt64();
					break;

				case DbDataType.Decimal:
				case DbDataType.Numeric:
					fieldValue = this.ReadDecimal(
						field.SqlType, 
						field.NumericScale);
					break;

				case DbDataType.Float:
					fieldValue = this.ReadSingle();
					break;
					
				case DbDataType.Double:
					fieldValue = this.ReadDouble();
					break;
		
				case DbDataType.Date:
					fieldValue = this.ReadDate();
					break;
					
				case DbDataType.Time:
					fieldValue = this.ReadTime();
					break;

				case DbDataType.TimeStamp:
					fieldValue = this.ReadDateTime();
					break;															
			}

			int sqlInd = this.ReadInt32();

			if (sqlInd == 0) 
			{
				return fieldValue;
			}
			else if (sqlInd == -1) 
			{
				return null;
			}
			else 
			{
				throw new IscException("invalid sqlind value: " + sqlInd);
			}
		}

		#endregion

		#region Xdr Write Methods

		public void WriteOpaque(byte[] buffer, int length)
		{
			if (buffer != null && length > 0) 
			{
				this.Write(buffer, 0, buffer.Length);
				this.Write(Fill, 0, length - buffer.Length);
				this.Write(Pad, 0, ((4 - length) & 3));
			}
		}

		public void WriteBuffer(byte[] buffer)
		{
			this.WriteBuffer(
				buffer, 
				buffer == null ? 0 : buffer.Length);
		}

		public void WriteBuffer(byte[] buffer, int length)
		{
			this.Write(length);
			if (buffer != null && length > 0) 
			{
				this.Write(buffer, 0, length);
				this.Write(Pad, 0, ((4 - length) & 3));
			}
		}

		public void WriteBlobBuffer(byte[] buffer)
		{
			int length = buffer.Length ; // 2 for short for buffer length
			
			if (length > short.MaxValue) 
			{
				throw(new IOException()); //Need a value???
			}
			this.Write(length + 2);
			this.Write(length + 2);	//bizarre but true! three copies of the length
			this.WriteByte((byte)((length >> 0) & 0xff));
			this.WriteByte((byte)((length >> 8) & 0xff));
			this.Write(buffer, 0, length);

			this.Write(Pad, 0, ((4 - length + 2) & 3));
		}

		public void WriteTyped(int type, byte[] buffer)
		{
			int length;

			if (buffer == null) 
			{
				this.Write(1);
				this.WriteByte((byte)type);
				length = 1;
			}
			else 
			{
				length = buffer.Length + 1;
				this.Write(length);
				this.WriteByte((byte)type);
				this.Write(buffer, 0, buffer.Length);
			}
			this.Write(Pad, 0, ((4 - length) & 3));
		}

		public void Write(string value)
		{	        				        
			this.WriteBuffer(
				this.encoding.GetBytes(value), 
				this.encoding.GetByteCount(value));
		}

		public void Write(short value)
		{
			this.Write((int)value);
		}

		public void Write(int value)
		{
			this.Write(BitConverter.GetBytes(IPAddress.NetworkToHostOrder(value)), 0, 4);
		}

		public void Write(long value)
		{
			this.Write(BitConverter.GetBytes(IPAddress.NetworkToHostOrder(value)), 0, 8);
		}

		public void Write(float value)
		{
			FloatLayout layout = new FloatLayout();			

			layout.f = value;
			layout.i0 = IPAddress.NetworkToHostOrder(layout.i0);

			this.Write(BitConverter.GetBytes(layout.f), 0, 4);
		}

		public void Write(double value)
		{
			DoubleLayout layout = new DoubleLayout();
			int temp;

			layout.d = value;
			layout.i0 = IPAddress.NetworkToHostOrder(layout.i0);
			layout.i4 = IPAddress.NetworkToHostOrder(layout.i4);

			temp = layout.i0;
			layout.i0 = layout.i4;
			layout.i4 = temp;

			this.Write(BitConverter.GetBytes(layout.d), 0, 8);
		}

		public void Write(decimal value, int type, int scale)
		{			
			switch (type)
			{
				case IscCodes.SQL_SHORT:
					this.Write(Convert.ToInt16(
						TypeEncoder.EncodeDecimal(value,scale,type)));
					break;

				case IscCodes.SQL_LONG:
					this.Write(Convert.ToInt32(
						TypeEncoder.EncodeDecimal(value, scale, type)));
					break;

				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					this.Write(Convert.ToInt64(
						TypeEncoder.EncodeDecimal(value, scale, type)));
					break;

				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					this.Write(Convert.ToDouble(value));
					break;
			}
		}

		public void Write(DateTime value)
		{
			this.WriteDate(value);
			this.WriteTime(value);
		}

		public void WriteDate(DateTime value)
		{
			this.Write(TypeEncoder.EncodeDate(Convert.ToDateTime(value)));
		}
		
		public void WriteTime(DateTime value)
		{
			this.Write(TypeEncoder.EncodeTime(Convert.ToDateTime(value)));
		}

		public void Write(RowDescriptor descriptor)
		{
			for (int i = 0; i < descriptor.Fields.Length; i++) 
			{
				this.Write(descriptor.Fields[i]);
			}
		}

		public void Write(DbField param)
		{
			param.FixNull();
			
			try 
			{
				object sqldata = param.Value;
				switch (param.DbDataType) 
				{
					case DbDataType.Char:
					{
						string svalue = sqldata.ToString();

						if ((param.Length % param.Charset.BytesPerCharacter) == 0 &&
							svalue.Length > param.CharCount)
						{ 	 
							throw new IscException(335544321); 	 
						}

						this.WriteOpaque(
							param.Charset.Encoding.GetBytes(svalue), 
							param.Length);
					}
					break;

					case DbDataType.VarChar:
					{
						string svalue = sqldata.ToString().TrimEnd();

						if ((param.Length % param.Charset.BytesPerCharacter) == 0 &&
							svalue.Length > param.CharCount)
						{ 	 
							throw new IscException(335544321); 	 
						}
					
						byte[] data = param.Charset.Encoding.GetBytes(svalue);

						this.WriteBuffer(data, data.Length);
					}
					break;
									
					case DbDataType.SmallInt:
						this.Write(Convert.ToInt16(sqldata));
						break;

					case DbDataType.Integer:
						this.Write(Convert.ToInt32(sqldata));
						break;

					case DbDataType.BigInt:
					case DbDataType.Array:
					case DbDataType.Binary:
						this.Write(Convert.ToInt64(sqldata));
						break;
					
					case DbDataType.Decimal:
					case DbDataType.Numeric:
						this.Write(
							Convert.ToDecimal(sqldata),
							param.SqlType,
							param.NumericScale);
						break;

					case DbDataType.Float:
						this.Write(Convert.ToSingle(sqldata));
						break;
				
					case DbDataType.Double:
						this.Write(Convert.ToDouble(sqldata));
						break;

					case DbDataType.Date:
						this.WriteDate(Convert.ToDateTime(sqldata));
						break;

					case DbDataType.Time:
						this.WriteTime(Convert.ToDateTime(sqldata));
						break;

					case DbDataType.TimeStamp:
						this.Write(Convert.ToDateTime(sqldata));
						break;

					default:
						throw new IscException("Unknown sql data type: " + param.DataType);
				}

				this.Write(param.NullFlag);
			} 
			catch (IOException) 
			{
				throw new IscException(IscCodes.isc_net_write_err);
			}
		}

		#endregion

		#region Private Methods

		private void checkDisposed()
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException("The XdrStream is closed.");
			}
		}

		#endregion
	}
}
