//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.IO;
using System.Text;
using System.Collections;
using System.Threading;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Gds
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class GdsDbAttachment : GdsAttachment, IDbAttachment
	{
		#region Events

		public event WarningMessageEventHandler DbWarningMessage;

		#endregion

		#region Fields

		private int	transactionCount;

		#endregion

		#region Properties

		public int TransactionCount
		{
			get { return this.transactionCount; }
			set { this.transactionCount = value; }
		}

		#endregion

		#region Constructors

		public GdsDbAttachment(AttachmentParams parameters) : base(parameters)
		{
		}

		#endregion

		#region Database Methods

		public void CreateDatabase(AttachmentParams parameters, DpbBuffer c)
		{
			lock (this) 
			{
				try 
				{
					this.Connect();
					this.Send.Write(IscCodes.op_create);
					this.Send.Write(0);		// packet->p_atch->p_atch_database
					this.Send.Write(this.Parameters.Database);
					this.Send.WriteBuffer(c.ToArray());
					this.Send.Flush();

					try 
					{
						GdsResponse r = this.ReceiveResponse();
						this.Handle = r.ObjectHandle;

						this.Detach();
					} 
					catch (IscException g) 
					{
						try
						{
							this.Disconnect();
						}
						catch (Exception)
						{
						}

						throw g;
					}
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_write_err);
				}
			}
		}

		public void DropDatabase()
		{
			lock (this) 
			{				
				try 
				{
					this.Send.Write(IscCodes.op_drop_database);
					this.Send.Write(this.Handle);
					this.Send.Flush();

					GdsResponse r = this.ReceiveResponse();

					this.Disconnect();
				} 
				catch (IOException) 
				{
					try
					{
						this.Detach();
					}
					catch {}

					throw new IscException(IscCodes.isc_network_error);
				}
			}
		}

		#endregion

		#region Methods

		public void Attach()
		{
			lock (this)
			{
				this.Connect();

				this.identify();
				try
				{
					DpbBuffer dpb = this.Parameters.BuildDpb(
						this.IsLittleEndian);

					this.Send.Write(IscCodes.op_attach);
					this.Send.Write(0);
					this.Send.Write(this.Parameters.Database);
					this.Send.WriteBuffer(dpb.ToArray());
					this.Send.Flush();
					
					try 
					{
						GdsResponse r = this.ReceiveResponse();
						this.Handle = r.ObjectHandle;
					}
					catch (IscException ge) 
					{
						try
						{
							this.Disconnect();
						}
						catch (Exception)
						{
						}
						throw ge;
					}
				} 
				catch (IOException)
				{
					throw new IscException(IscCodes.isc_net_write_err);
				}
			}			
		}

		public void Detach()
		{
			lock (this) 
			{
				if (this.TransactionCount > 0) 
				{
					throw new IscException(
						IscCodes.isc_open_trans, this.TransactionCount);
				}
	        
				try 
				{
					this.Send.Write(IscCodes.op_detach);
					this.Send.Write(this.Handle);
					this.Send.Flush();

					GdsResponse r = this.ReceiveResponse();

					this.transactionCount = 0;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_network_error);
				}
				finally
				{
					try 
					{
						this.Disconnect();
					}
					catch (IOException) 
					{
						throw new IscException(IscCodes.isc_network_error);
					} 
				}
			}			
		}

		/// <summary>
		/// isc_database_info
		/// </summary>
		public void GetDatabaseInfo(
			byte[] items, int buffer_length, byte[] buffer)
		{		
			lock (this) 
			{			
				try 
				{					
					// see src/remote/protocol.h for packet definition (p_info struct)					
					this.Send.Write(IscCodes.op_info_database);	//	operation
					this.Send.Write(this.Handle);				//	db_handle
					this.Send.Write(0);							//	incarnation
					this.Send.WriteBuffer(items, items.Length);	//	items
					this.Send.Write(buffer_length);				//	result buffer length

					this.Send.Flush();

					GdsResponse r = this.ReceiveResponse();

					// System.Array.Copy(r.Data, 0, buffer, 0, buffer_length);
					Buffer.BlockCopy(r.Data, 0, buffer, 0, buffer_length);
				}
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_network_error);
				}
			}
		}

		public override void SendWarning(IscException warning) 
		{
			if (this.DbWarningMessage != null)
			{
				this.DbWarningMessage(this, new WarningMessageEventArgs(warning));
			}
		}

		#endregion

		#region Private Methods

		private void identify()
		{
			try
			{
				// Here we identify the user to the engine.  
				// This may or may not be used as login info to a database.				
				byte[] user = Encoding.Default.GetBytes(System.Environment.UserName);
				byte[] host = Encoding.Default.GetBytes(System.Net.Dns.GetHostName());
				
				int n = 0;
				byte[] user_id = new byte[200];
						
				user_id[n++] = 1;		// CNCT_user
				user_id[n++] = (byte)user.Length;
				Buffer.BlockCopy(user, 0, user_id, n, user.Length);
				n += user.Length;
						
				user_id[n++] = 4;		// CNCT_host
				user_id[n++] = (byte)host.Length;
				Buffer.BlockCopy(host, 0, user_id, n, host.Length);
				n += host.Length;
			    
				user_id[n++] = 6;		// CNCT_user_verification
				user_id[n++] = 0;

				this.Send.Write(IscCodes.op_connect);
				this.Send.Write(IscCodes.op_attach);
				this.Send.Write(IscCodes.CONNECT_VERSION2);	// CONNECT_VERSION2
				this.Send.Write(1);							// arch_generic

				this.Send.Write(this.Parameters.Database);	// p_cnct_file
				this.Send.Write(1);							// p_cnct_count
				this.Send.WriteBuffer(user_id, n);			// p_cnct_user_id
				
				this.Send.Write(IscCodes.PROTOCOL_VERSION10);
				this.Send.Write(1);							// arch_generic
				this.Send.Write(2);							// ptype_rpc
				this.Send.Write(3);							// ptype_batch_send
				this.Send.Write(2);
			
				this.Send.Flush();				
				
				if (this.ReadOperation() == IscCodes.op_accept) 
				{
					this.Receive.ReadInt32();
					this.Receive.ReadInt32();
					this.Receive.ReadInt32();
				} 
				else 
				{
					try
					{					
						this.Detach();
					}
					catch (Exception)
					{
					}
					finally
					{
						throw new IscException(IscCodes.isc_connect_reject);
					}
				}
			} 
			catch (IOException)
			{
				throw new IscException(IscCodes.isc_arg_gds, IscCodes.isc_network_error, Parameters.DataSource);
			}
		}

		#endregion
	}
}