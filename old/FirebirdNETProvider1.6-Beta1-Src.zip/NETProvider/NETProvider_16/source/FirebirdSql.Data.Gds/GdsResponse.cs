//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Gds
{
	internal sealed class GdsResponse
	{
		#region Fields

		private int		objectHandle;
		private long	blobId;
		private byte[]	data;

		#endregion

		#region Properties

		public int ObjectHandle
		{
			get { return objectHandle; }
		}

		public long BlobId
		{
			get { return blobId; }
		}

		public byte[] Data
		{
			get { return data; }
		}

		#endregion

		#region Constructors

		public GdsResponse()
		{
		}
		
		public GdsResponse(int objectHandle, long blobId, byte[] data)
		{
			this.objectHandle	= objectHandle;
			this.blobId			= blobId;
			this.data			= data;
		}

		#endregion
	}
}
