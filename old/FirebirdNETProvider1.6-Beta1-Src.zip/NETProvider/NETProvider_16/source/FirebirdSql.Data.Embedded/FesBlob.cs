//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Embedded
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class FesBlob : BlobBase
	{
		#region Fields

		private FesDbAttachment	db;

		#endregion

		#region Properties

		public override IDbAttachment DB
		{
			get { return this.db; }
		}

		#endregion

		#region Constructors

		public FesBlob(
			IDbAttachment	db, 
			ITransaction	transaction) : this(db, transaction, 0)
		{
		}
	
		public FesBlob(
			IDbAttachment	db, 
			ITransaction	transaction, 
			long			blobId) : base(db)
		{
			if (!(db is FesDbAttachment))
			{
				throw new ArgumentException("Specified argument is not of FesDbAttachment type.");
			}
			if (!(transaction is FesTransaction))
			{
				throw new ArgumentException("Specified argument is not of FesTransaction type.");
			}
			this.db				= (FesDbAttachment)db;
			this.transaction	= (FesTransaction)transaction;
			this.position		= 0;
			this.blobHandle		= 0;
			this.blobId			= blobId;
		}

		#endregion

		#region Protected Methods

		protected override void Create()
		{
			lock (this.db) 
			{
				int[] statusVector = FesFactory.CreateStatusVector();

				int dbHandle = this.db.Handle;
				int trHandle = this.transaction.Handle;

				int status = FbClient.isc_create_blob2(
					statusVector,
					ref dbHandle,
					ref trHandle,
					ref this.blobHandle,
					ref this.blobId,					
					0,
					new byte[0]);

				this.db.ParseStatusVector(statusVector);

				this.RblAddValue(IscCodes.RBL_create);
			}
		}

		protected override void Open()
		{
			lock (this.db) 
			{
				int[] statusVector = FesFactory.CreateStatusVector();

				int dbHandle = this.db.Handle;
				int trHandle = this.transaction.Handle;

				int status = FbClient.isc_open_blob2(
					statusVector,
					ref dbHandle,
					ref trHandle,
					ref this.blobHandle,
					ref this.blobId,
					0,
					new byte[0]);

				this.db.ParseStatusVector(statusVector);
			}
		}

		protected override byte[] GetSegment()
		{
			short requested = (short)this.SegmentSize;

			lock (this.db) 
			{
				int[] statusVector = FesFactory.CreateStatusVector();

				int dbHandle = this.db.Handle;
				int trHandle = this.transaction.Handle;

				byte[] segment = new byte[requested];

				short segmentLength = requested;

				int status = FbClient.isc_get_segment(
					statusVector,
					ref this.blobHandle,
					ref segmentLength,
					ref requested,
					segment);

				this.RblRemoveValue(IscCodes.RBL_segment);
				if (statusVector[1] == IscCodes.isc_segstr_eof)
				{
					segment = new byte[0];
					this.RblAddValue(IscCodes.RBL_eof_pending);
				}
				else
				{
					if (segmentLength != requested)
					{
						// Store real data in a temp buffer
						byte[] temp = new byte[segmentLength];
						Buffer.BlockCopy(segment, 0, temp, 0, temp.Length);

						// Resize segment buffer and copy readed data
						segment = new byte[segmentLength];
						Buffer.BlockCopy(temp, 0, segment, 0, segment.Length);
					}

					this.RblAddValue(IscCodes.RBL_segment);

					this.db.ParseStatusVector(statusVector);
				}				

				return segment;
			}
		}

		protected override void PutSegment(byte[] buffer)
		{
			lock (this.db) 
			{
				int[] statusVector = FesFactory.CreateStatusVector();

				int dbHandle	= this.db.Handle;
				int trHandle	= this.transaction.Handle;

				int status = FbClient.isc_put_segment(
					statusVector,
					ref this.blobHandle,
					(short)buffer.Length,
					buffer);

				this.db.ParseStatusVector(statusVector);
			}
		}

		protected override void Seek(int position)
		{
			throw new NotSupportedException();
		}

		protected override void GetBlobInfo()
		{
			throw new NotSupportedException();
		}

		protected override void Close()
		{	
			lock (this.db)
			{
				int[] statusVector = FesFactory.CreateStatusVector();

				int status = FbClient.isc_close_blob(
					statusVector,
					ref this.blobHandle);

				this.db.ParseStatusVector(statusVector);
			}
		}		

		protected override void Cancel()
		{	
			lock (this.db)
			{
				int[] statusVector = FesFactory.CreateStatusVector();

				int status = FbClient.isc_cancel_blob(
					statusVector,
					ref this.blobHandle);

				this.db.ParseStatusVector(statusVector);
			}
		}		

		#endregion
	}
}
