//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;

namespace FirebirdSql.Data.Embedded
{
	[StructLayout(LayoutKind.Sequential)]
	internal struct XSQLDA
	{
		public short		version;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=8)] 
		public string		sqldaid;
		public int			sqldabc;
		public short		sqln;
		public short		sqld;

		public static int ComputeLength(int n)
		{
			return (Marshal.SizeOf(typeof(XSQLDA)) + n * Marshal.SizeOf(typeof(XSQLVAR)));
		}
	}

	[StructLayout(LayoutKind.Sequential)] 
	internal struct XSQLVAR
	{
		public short	sqltype;	
		public short	sqlscale;
		public short	sqlsubtype;	
		public short	sqllen;
		public IntPtr	sqldata;
		public IntPtr	sqlind;
		public short	sqlname_length;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] 
		public string	sqlname;
		public short	relname_length;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] 
		public string	relname;
		public short	ownername_length;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] 
		public string	ownername;
		public short	aliasname_length;
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] 
		public string	aliasname;
	}
}
