//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class CharsetCollection : ArrayList
	{
		#region Properties

		public new Charset this[int index]
		{
			get { return (Charset)base[index]; }
			set { base[index] = (Charset)value; }
		}

		public Charset this[string name] 
		{
			get { return (Charset)this[IndexOf(name)]; }
			set { this[IndexOf(name)] = (Charset)value; }
		}

		#endregion

		#region Methods

		public bool Contains(string name)
		{
			return (-1 != this.IndexOf(name));
		}

		public int IndexOf(string name)
		{
			int index = 0;

			foreach (Charset item in this)
			{
				if (this.cultureAwareCompare(item.Name, name))
				{
					return index;
				}
				index++;
			}

			return -1;
		}

		public int IndexOf(int id)
		{
			int index = 0;

			foreach (Charset item in this)
			{
				if (item.ID == id)
				{
					return index;
				}
				index++;
			}

			return -1;
		}

		public void RemoveAt(string charset)
		{
			RemoveAt(this.IndexOf(charset));
		}

		public Charset Add(Charset charset)
		{
			base.Add(charset);

			return charset;
		}

		public Charset Add(
			int id, 
			string charset, 
			int bytesPerCharacter,
			string systemCharset)
		{
			Charset charSet = new Charset(
				id, 
				charset, 
				bytesPerCharacter, 
				systemCharset);

			base.Add(charSet);

			return charSet;
		}

		public Charset Add(
			int id, 
			string charset, 
			int bytesPerCharacter, 
			int cp)
		{
			Charset charSet = new Charset(
				id, 
				charset, 
				bytesPerCharacter, 
				cp);

			base.Add(charSet);

			return charSet;
		}

		public Charset Add(
			int id, 
			string charset, 
			int bytesPerCharacter,
			Encoding encoding)
		{
			Charset charSet = new Charset(
				id, 
				charset, 
				bytesPerCharacter,
				encoding);

			base.Add(charSet);

			return charSet;
		}

		private bool cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(
				strA, 
				strB,
				CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth |
				CompareOptions.IgnoreCase) == 0 ? true : false;
		}

		#endregion
	}
}
