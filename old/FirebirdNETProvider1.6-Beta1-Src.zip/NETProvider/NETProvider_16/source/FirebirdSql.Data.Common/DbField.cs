//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class DbField
	{
		#region Fields

		private DbDataType	dbDataType;
		private short		dataType;	
		private short		numericScale;
		private short		subType;	
		private short		length;	
		private object		fvalue;
		private short		nullFlag;
		private string		name;
		private string		relation;
		private string		owner;
		private string		alias;
		private Charset		charset;
		private	int			charCount;
		private ArrayBase	arrayHandle;

		#endregion

		#region Properties

		public DbDataType DbDataType
		{
			get { return this.dbDataType; }
		}

		public int SqlType
		{
			get { return this.dataType & ~1; }
		}

		public short DataType
		{
			get { return this.dataType; }
			set 
			{ 
				this.dataType	= value; 
				if (this.dataType != 0)
				{
					this.dbDataType = this.getDbDataType();
				}
			}
		}

		public short NumericScale
		{
			get { return this.numericScale; }
			set { this.numericScale = value; }
		}

		public short SubType
		{
			get { return this.subType; }
			set 
			{ 
				if (this.IsCharacter())
				{
					// Bits 0-7 of sqlsubtype is charset_id (127 is a special value -
					// current attachment charset).
					// Bits 8-17 hold collation_id for this value.
					byte[] cs = BitConverter.GetBytes(value);

					int index = Charset.SupportedCharsets.IndexOf(cs[0]);
					if (index != -1)
					{
						this.charset = Charset.SupportedCharsets[index];
					}
					else
					{
						this.charset = Charset.SupportedCharsets[0];
					}
				}
								
				this.subType = value;
			}
		}

		public short Length
		{
			get { return this.length; }
			set 
			{ 
				this.length = value; 
				if (this.IsCharacter())
				{
					this.charCount = this.length / this.charset.BytesPerCharacter;
				}
			}
		}

		public object Value
		{
			get { return this.fvalue; }
			set { this.fvalue = value; }
		}

		public short NullFlag
		{
			get { return this.nullFlag; }
			set { this.nullFlag = value; }
		}

		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		public string Relation
		{
			get { return this.relation; }
			set { this.relation = value; }
		}

		public string Owner
		{
			get { return this.owner; }
			set { this.owner = value; }
		}

		public string Alias
		{
			get { return this.alias; }
			set { this.alias = value; }
		}

		public Charset Charset
		{
			get { return this.charset; }
		}

		public int CharCount
		{
			get { return this.charCount; }
			set { this.charCount = value; }
		}

		public ArrayBase ArrayHandle
		{
			get
			{
				if (this.IsArray())
				{
					return this.arrayHandle;
				}
				else
				{
					throw new IscException("Field is not an array type");
				}
			}

			set
			{
				if (this.IsArray())
				{
					this.arrayHandle = value;
				}
				else
				{
					throw new IscException("Field is not an array type");
				}
			}
		}

		#endregion

		#region Constructors
		
		public DbField() 
		{
			this.charCount	= -1;
			this.name		= String.Empty;
			this.relation	= String.Empty;
			this.owner		= String.Empty;
			this.alias		= String.Empty;
		}

		#endregion

		#region Methods

		public void FixNull()
		{
			if (this.NullFlag == -1 && 
				(this.Value == null || this.Value == DBNull.Value))
			{
				switch (this.SqlType) 
				{
					case IscCodes.SQL_TEXT:
					case IscCodes.SQL_VARYING:
						this.Value = String.Empty;
						break;
					
					case IscCodes.SQL_SHORT:
						this.Value = (short)0;
						break;
					
					case IscCodes.SQL_LONG:
						this.Value = (int)0;
						break;
					
					case IscCodes.SQL_FLOAT:
						this.Value = (float)0;
						break;
					
					case IscCodes.SQL_DOUBLE:
						this.Value = (double)0;
						break;
					
					case IscCodes.SQL_BLOB:
					case IscCodes.SQL_ARRAY:
					case IscCodes.SQL_INT64:
					case IscCodes.SQL_QUAD:					
						this.Value = (long)0;
						break;

					case IscCodes.SQL_TYPE_DATE:
					case IscCodes.SQL_TYPE_TIME:
					case IscCodes.SQL_TIMESTAMP:
						this.Value = new System.DateTime(0 * 10000L + 621355968000000000);
						break;

					default:
						throw new IscException("Unknown sql data type: " + this.DataType);
				}
			}
		}

		public string GetDataTypeName()
		{			 
			switch (this.SqlType)
			{
				case IscCodes.SQL_TEXT:
					return "CHAR";
				
				case IscCodes.SQL_VARYING:
					return "VARCHAR";
				
				case IscCodes.SQL_SHORT:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "SMALLINT";
					}

				case IscCodes.SQL_LONG:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "INTEGER";
					}
				
				case IscCodes.SQL_FLOAT:
					return "FLOAT";
				
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "DOUBLE";
					}
								
				case IscCodes.SQL_BLOB:
					if (this.subType == 1)
					{
						return "BLOB SUB_TYPE 1";
					}
					else
					{
						return "BLOB";
					}
				
				case IscCodes.SQL_ARRAY:
					return "ARRAY";

				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "BIGINT";
					}
				
				case IscCodes.SQL_TIMESTAMP:
					return "TIMESTAMP";

				case IscCodes.SQL_TYPE_TIME:			
					return "TIME";

				case IscCodes.SQL_TYPE_DATE:
					return "DATE";

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public Type GetSystemType()
		{
			switch (this.SqlType)
			{
				case IscCodes.SQL_TEXT:
					return Type.GetType("System.String");
				
				case IscCodes.SQL_VARYING:
					return Type.GetType("System.String");
				
				case IscCodes.SQL_SHORT:
					if (this.numericScale < 0)
					{												
						return Type.GetType("System.Decimal");												
					}
					else
					{
						return Type.GetType("System.Int16");
					}

				case IscCodes.SQL_LONG:
					if (this.numericScale < 0)
					{
						return Type.GetType("System.Decimal");
					}
					else
					{
						return Type.GetType("System.Int32");
					}
				
				case IscCodes.SQL_FLOAT:
					return Type.GetType("System.Double");
				
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					if (this.numericScale < 0)
					{
						return Type.GetType("System.Decimal");
					}
					else
					{
						return Type.GetType("System.Double");
					}
								
				case IscCodes.SQL_BLOB:
					if (this.subType == 1)
					{
						return Type.GetType("System.String");
					}
					else
					{
						return Type.GetType("System.Array");
					}
				
				case IscCodes.SQL_ARRAY:
					return Type.GetType("System.Array");

				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					if (this.numericScale < 0)
					{
						return Type.GetType("System.Decimal");
					}
					else
					{
						return Type.GetType("System.Int64");
					}
				
				case IscCodes.SQL_TIMESTAMP:
				case IscCodes.SQL_TYPE_TIME:			
				case IscCodes.SQL_TYPE_DATE:
					return Type.GetType("System.DateTime");

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public bool IsNumeric()
		{
			switch (this.SqlType)
			{
				case IscCodes.SQL_SHORT:
				case IscCodes.SQL_LONG:
				case IscCodes.SQL_FLOAT:
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					return true;

				case IscCodes.SQL_TEXT:				
				case IscCodes.SQL_VARYING:
				case IscCodes.SQL_BLOB:				
				case IscCodes.SQL_ARRAY:
				case IscCodes.SQL_TIMESTAMP:
				case IscCodes.SQL_TYPE_TIME:			
				case IscCodes.SQL_TYPE_DATE:
				default:
					return false;
			}
		}

		public bool IsLong()
		{
			switch (this.SqlType)
			{
				case IscCodes.SQL_BLOB:
					return true;

				case IscCodes.SQL_ARRAY:
				case IscCodes.SQL_TEXT:
				case IscCodes.SQL_VARYING:
				case IscCodes.SQL_TIMESTAMP:
				case IscCodes.SQL_TYPE_TIME:			
				case IscCodes.SQL_TYPE_DATE:
				case IscCodes.SQL_SHORT:
				case IscCodes.SQL_LONG:
				case IscCodes.SQL_FLOAT:
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
				default:
					return false;
			}
		}

		public bool IsCharacter()
		{
			switch (this.SqlType)
			{
				case IscCodes.SQL_TEXT:
				case IscCodes.SQL_VARYING:
					return true;

				case IscCodes.SQL_ARRAY:
				case IscCodes.SQL_BLOB:
				case IscCodes.SQL_TIMESTAMP:
				case IscCodes.SQL_TYPE_TIME:			
				case IscCodes.SQL_TYPE_DATE:
				case IscCodes.SQL_SHORT:
				case IscCodes.SQL_LONG:
				case IscCodes.SQL_FLOAT:
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
				default:
					return false;				
			}
		}

		public bool IsArray()
		{
			switch (this.SqlType)
			{
				case IscCodes.SQL_ARRAY:
					return true;

				case IscCodes.SQL_TEXT:
				case IscCodes.SQL_VARYING:
				case IscCodes.SQL_BLOB:
				case IscCodes.SQL_TIMESTAMP:
				case IscCodes.SQL_TYPE_TIME:			
				case IscCodes.SQL_TYPE_DATE:
				case IscCodes.SQL_SHORT:
				case IscCodes.SQL_LONG:
				case IscCodes.SQL_FLOAT:
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
				default:
					return false;
			}
		}

		#endregion

		#region Private Methods

		private DbDataType getDbDataType()
		{
			switch (this.SqlType)
			{
				case IscCodes.SQL_TEXT:
					return DbDataType.Char;
				
				case IscCodes.SQL_VARYING:
					return DbDataType.VarChar;
				
				case IscCodes.SQL_SHORT:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return DbDataType.Decimal;
						}
						else
						{
							return DbDataType.Numeric;
						}
					}
					else
					{
						return DbDataType.SmallInt;
					}

				case IscCodes.SQL_LONG:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return DbDataType.Decimal;
						}
						else
						{
							return DbDataType.Numeric;
						}
					}
					else
					{
						return DbDataType.Integer;
					}
				
				case IscCodes.SQL_FLOAT:
					return DbDataType.Float;
				
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return DbDataType.Decimal;
						}
						else
						{
							return DbDataType.Numeric;
						}
					}
					else
					{
						return DbDataType.Double;
					}
								
				case IscCodes.SQL_BLOB:
					if (this.subType == 1)
					{
						return DbDataType.Text;
					}
					else
					{
						return DbDataType.Binary;
					}
				
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					if (this.numericScale < 0)
					{
						if (this.subType == 2)
						{
							return DbDataType.Decimal;
						}
						else
						{
							return DbDataType.Numeric;
						}
					}
					else
					{
						return DbDataType.BigInt;
					}
				
				case IscCodes.SQL_TIMESTAMP:
					return DbDataType.TimeStamp;

				case IscCodes.SQL_TYPE_TIME:
					return DbDataType.Time;

				case IscCodes.SQL_TYPE_DATE:
					return DbDataType.Date;

				case IscCodes.SQL_ARRAY:
					return DbDataType.Array;

				default:
					throw new SystemException("Invalid data type");
			}
		}

		#endregion
	}
}