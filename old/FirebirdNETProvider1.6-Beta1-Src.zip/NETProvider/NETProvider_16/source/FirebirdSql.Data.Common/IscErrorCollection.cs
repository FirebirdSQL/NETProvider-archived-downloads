//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Common
{
	[Serializable]
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class IscErrorCollection : ArrayList
	{
		#region Properties

		public IscError this[string errorMessage] 
		{
			get { return (IscError)this[IndexOf(errorMessage)]; }
			set { this[IndexOf(errorMessage)] = (IscError)value; }
		}

		public new IscError this[int errorIndex] 
		{
			get { return (IscError)base[errorIndex]; }
			set { base[errorIndex] = (IscError)value; }
		}

		#endregion

		#region Methods
	
		public bool Contains(string errorMessage)
		{
			return (-1 != this.IndexOf(errorMessage));
		}
		
		public int IndexOf(string errorMessage)
		{
			int index = 0;
			
			foreach (IscError item in this)
			{
				if (this.cultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}

			return -1;
		}

		public void RemoveAt(string errorMessage)
		{
			this.RemoveAt(this.IndexOf(errorMessage));
		}

		public IscError Add(IscError error)
		{
			base.Add(error);

			return error;
		}
		
		public IscError Add(int errorCode)
		{
			IscError error = new IscError(errorCode);			

			return this.Add(error);
		}

		public IscError Add(string message)
		{
			IscError error = new IscError(message);			

			return this.Add(error);
		}

		public IscError Add(int type, string strParam)
		{
			IscError error = new IscError(type, strParam);			

			return this.Add(error);
		}

		public IscError Add(int type, int errorCode)
		{
			IscError error = new IscError(type, errorCode);			

			return this.Add(error);
		}

		public IscError Add(int type, int errorCode, string strParam)
		{
			IscError error = new IscError(type, errorCode, strParam);

			return this.Add(error);
		}

		private bool cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(
				strA, 
				strB,
				CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth |
				CompareOptions.IgnoreCase) == 0 ? true : false;
		}

		#endregion
	}
}
