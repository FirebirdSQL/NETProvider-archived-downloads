//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Text;

using Borland.Data.Common;
using Borland.Data.Schema;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	public class FbConnection : ISQLConnection
	{
		#region Fields

		private IDbAttachment		db;
		private AttachmentParams	parameters;
		private string				connectionOptions;

		#endregion

		#region Internal Properties

		internal FactoryBase Factory
		{
			get { return this.db.Factory; }
		}

		#endregion
		
		#region Constructors

		public FbConnection()
		{
			this.db	= null;
		}

		#endregion

		#region ISQLConnection Methods

		public int Connect(
			string database, 
			string user,
			string password,
			string hostName)
		{
			FactoryBase factory = ClientFactory.GetInstance(parameters.ServerType);

			string connectionString =
				String.Format(
					"{0}={1};{2}={3};{4}={5};{6}={7};{8}",
					"DataSource", hostName,
					"Database", database,
					"User", user,
					"Password", password,
					this.connectionOptions);

			this.parameters	= new AttachmentParams(conenctionString);

			this.db = factory.CreateDbConnection(connectionString);
			this.db.Attach();			

			return 0;
		}

		public int Disconnect()
		{
			try
			{
				this.db.Detach();
			}
			catch
			{
			}

			return 0;
		}

		public int BeginTransaction(int transID, short isolationLevel)
		{
			throw new NotSupportedException();
		}

		public int Commit(int transID)
		{
			throw new NotSupportedException();
		}

		public int Rollback(int transID)
		{
			throw new NotSupportedException();
		}

		public int ChangeDatabase(
			string	database, 
			string	user, 
			string	password, 
			bool	connected)
		{
			throw new NotSupportedException();
		}

		public int FreeConnect()
		{
			this.Disconnect();
			this.db = null;

			return 0;
		}

		public void GetProperty(ConnectionProps connProp, out object value)
		{
			throw new NotSupportedException();
		}

		public void SetProperty(ConnectionProps connProp, object value)
		{
			throw new NotSupportedException();
		}

		public int SetOptions(string connOptions)
		{
			this.connectionOptions = connOptions;

			return 0;
		}

		public ISQLResolver GetResolver()
		{
			return new FbResolver(this);
		}

		public ISQLMetaData GetMetaData()
		{
			return new FbMetaData(this);
		}

		public ISQLCommand GetSQLCommand()
		{
			return new FbCommand(this);
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}