//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Data.Common;

using Borland.Data.Common;
using Borland.Data.Schema;

namespace FirebirdSql.Data.Bdp
{
	public class FbResolver : ISQLResolver
	{
		#region Fields

		private FbConnection	connection;
		private string[]		excludeFilter;
		private string[]		readOnly;
		private string			quotePrefix;
		private string			quoteSuffix;
		private DataRow			row;

		#endregion

		#region Properties

		public string[] ExcludeFilter 
		{ 
			get { return this.excludeFilter; }
			set	{ this.excludeFilter = value; }
		} 

		public string QuotePrefix 
		{ 
			get { return this.quotePrefix; }
			set	{ this.quotePrefix = value; }
		}

		public string QuoteSuffix
		{ 
			get { return this.quoteSuffix; }
			set	{ this.quoteSuffix = value; }
		}

		public string[] ReadOnly 
		{ 
			get { return this.readOnly; }
			set	{ this.readOnly = value; }
		}

		public DataRow Row 
		{ 
			get { return this.row; }
			set	{ this.row = value; }
		}

		#endregion

		#region Constructors

		public FbResolver(FbConnection connection)
		{
			this.connection		= connection;
			this.quotePrefix	= "\"";
			this.quoteSuffix	= "\"";
		}

		#endregion

		#region Methods

		public string GetSelectSQL(
			IDbConnection		connection, 
			DataRowCollection	columns, 
			string				tableName) 
		{
			throw new NotSupportedException();
		}

		public string GetDeleteSQL(
			IDbConnection		connection, 
			IDbCommand			command, 
			DataRowCollection	columns, 
			string				tableName, 
			BdpUpdateMode		updateMode)
		{
			throw new NotSupportedException();
		}

		public string GetUpdateSQL(
			IDbConnection		connection, 
			IDbCommand			command, 
			DataRowCollection	columns, 
			string				tableName, 
			BdpUpdateMode		updateMode)
		{
			throw new NotSupportedException();
		}

		public string GetInsertSQL(
			IDbConnection		connection, 
			IDbCommand			command, 
			DataRowCollection	columns, 
			string				tableName)
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}
