//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Globalization;
using System.Resources;
using System.Text;
using System.Reflection;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/encodings.xml' path='doc/member[@name="T:Encodings"]/*'/>
	internal class Encodings
	{	
		#region FIELDS

		private static string ENCODINGS		= "FirebirdSql.Data.Firebird.Resources.GDS.isc_encodings";
		private static ResourceManager		rm;
		
		private static bool initialized		= false;

		#endregion

		#region METHODS

		/// <include file='xmldoc/encodings.xml' path='doc/member[@name="M:Init"]/*'/>
		private static void Init()
		{			
			try 
			{				
				rm = new ResourceManager(ENCODINGS, Assembly.GetExecutingAssembly());				
			} 
			catch (Exception)
			{
			} 
			finally 
			{
				initialized = true;
			}
		}

		/// <include file='xmldoc/encodings.xml' path='doc/member[@name="M:GetFromFirebirdEncoding(System.String)"]/*'/>
		public static Encoding GetFromFirebirdEncoding(string fbencoding)
		{
			string encoding = null;
			
			if (!initialized) 
			{
				Init();
			}
			
			try
			{
				switch(fbencoding.ToUpper())
				{
					case "NONE":
						return Encoding.Default;						

					default:
						encoding = rm.GetString(fbencoding, CultureInfo.InvariantCulture);
						break;
				}
			}
			catch(Exception)
			{
				encoding = "Default";
			}
			
			return encoding == "Default" ? Encoding.Default : Encoding.GetEncoding(encoding);
		}

		#endregion
	}
}
