//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

using FirebirdSql.Data.Firebird;
using NUnit.Framework;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbImplicitTransactionTest : BaseTest
	{
		public FbImplicitTransactionTest() : base(false)
		{		
		}
		
		[Test]
		public void DataAdapterFillTest()
		{
			FbCommand		command = new FbCommand("select * from TEST where DATE_FIELD = ?", Connection);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@DATE_FIELD", FbDbType.Date, 4, "DATE_FIELD").Value = new DateTime(2003, 1, 5);
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");
			
			Console.WriteLine();
			Console.WriteLine("Implicit transactions - DataAdapter Fill Method - Test");

			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
				{
					Console.Write(col.ColumnName + "\t\t");
				}
				
				Console.WriteLine();
				
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
					{
						Console.Write(row[i] + "\t\t");
					}

					Console.WriteLine("");
				}
			}

			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}
	
		[Test]
		public void MultipleDataAdapterFillTest()
		{
			FbCommand		command = new FbCommand("select * from TEST where DATE_FIELD = ?", Connection);
			FbDataAdapter	adapter = new FbDataAdapter(command);

			adapter.SelectCommand.Parameters.Add("@DATE_FIELD", FbDbType.Date, 4, "DATE_FIELD").Value = new DateTime(2003, 1, 5);
			
			FbCommandBuilder builder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "TEST");
			
			Console.WriteLine();
			Console.WriteLine("Implicit transactions - DataAdapter Fill Method - Test");

			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
				{
					Console.Write(col.ColumnName + "\t\t");
				}
				
				Console.WriteLine();
				
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
					{
						Console.Write(row[i] + "\t\t");
					}

					Console.WriteLine("");
				}
			}

			adapter.SelectCommand.Parameters[0].Value = new DateTime(2003, 1, 6);

			ds = new DataSet();
			adapter.Fill(ds, "TEST");
			
			Console.WriteLine();
			Console.WriteLine("Implicit transactions - DataAdapter Fill Method - Test");

			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
				{
					Console.Write(col.ColumnName + "\t\t");
				}
				
				Console.WriteLine();
				
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
					{
						Console.Write(row[i] + "\t\t");
					}

					Console.WriteLine("");
				}
			}


			adapter.Dispose();
			builder.Dispose();
			command.Dispose();
		}

		[Test]
		public void ExecuteScalarTest()
		{
			FbCommand command = new FbCommand("select sum(int_field) from TEST", Connection);

			Console.WriteLine("\r\nExecuteScalar with implicit transaction: {0}", command.ExecuteScalar());

			command.Dispose();
		}

		[Test]
		public void UpdatedClobFieldTest()
		{
			Console.WriteLine("\r\nUpdate CLOB field with implicit transaction.");

			FbCommand command = new FbCommand("update TEST set clob_field = @clob_field where int_field = @int_field", Connection);
			command.Parameters.Add("@int_field", FbDbType.Integer).Value = 1;
			command.Parameters.Add("@clob_field", FbDbType.Text).Value = "Clob field update with implicit transaction";

			int i = command.ExecuteNonQuery();

			Assertion.AssertEquals(
				"Clob field update with implicit transaction failed", i, 1);

			// Force the implicit transaction to be committed
			command.Dispose();
		}

		[Test]
		public void UpdatedBlobFieldTest()
		{
			Console.WriteLine("\r\nUpdate BLOB field with implicit transaction.");

			FbCommand command = new FbCommand("update TEST set blob_field = @blob_field where int_field = @int_field", Connection);
			command.Parameters.Add("@int_field", FbDbType.Integer).Value = 1;
			command.Parameters.Add("@blob_field", FbDbType.Binary).Value = 
				Encoding.Default.GetBytes("Blob field update with implicit transaction");

			int i = command.ExecuteNonQuery();

			Assertion.AssertEquals(
				"Blob field update with implicit transaction failed", i, 1);

			// Force the implicit transaction to be committed
			command.Dispose();
		}

		[Test]
		public void UpdatedArrayFieldTest()
		{
			Console.WriteLine("\r\nUpdate CLOB field with implicit transaction.");

			int[] values = new int[4];

			values[0] = 10;
			values[1] = 20;
			values[2] = 30;
			values[3] = 40;
			
			FbCommand command = new FbCommand("update TEST set iarray_field = @iarray_field where int_field = @int_field", Connection);
			command.Parameters.Add("@int_field", FbDbType.Integer).Value = 1;
			command.Parameters.Add("@iarray_field", FbDbType.Array).Value = values;

			int i = command.ExecuteNonQuery();

			Assertion.AssertEquals(
				"Array field update with implicit transaction failed", i, 1);

			// Force the implicit transaction to be committed
			command.Dispose();
		}
	}
}
