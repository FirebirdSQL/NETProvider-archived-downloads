//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbForeignKeysSchema : FbAbstractDbSchema
	{
		#region CONSTRUCTORS

		public FbForeignKeysSchema() : base("ForeignKeys")
		{
		}

		#endregion

		#region ADD_METHODS

		public override void AddTables()
		{
			AddTable("rdb$relation_constraints rc");
		}

		public override void AddRestrictionColumns()
		{
			AddRestrictionColumn("rc.rdb$relation_name"		, "TABLE_NAME"		, null);
			AddRestrictionColumn("rc.rdb$constraint_name"	, "CONSTRAINT_NAME"	, null);
		}

		public override void AddDataColumns()
		{
			AddDataColumn("ref.rdb$match_option"		, "MATCH_OPTION");
			AddDataColumn("ref.rdb$update_rule"			, "UPDATE_RULE");
			AddDataColumn("ref.rdb$delete_rule"			, "DELETE_RULE");
			AddDataColumn("rc.rdb$index_name"			, "INDEX_NAME");
			AddDataColumn("rc.rdb$deferrable"			, "IS_DEFERRABLE");
			AddDataColumn("rc.rdb$initially_deferred"	, "INITIALLY_DEFERRED");
		}

		public override void AddJoins()
		{
			AddJoin("left join", "rdb$ref_constraints ref", "rc.rdb$constraint_name = ref.rdb$constraint_name");
		}

		public override void AddOrderByColumns()
		{
			AddOrderBy("rc.rdb$relation_name");
			AddOrderBy("rc.rdb$constraint_name");
		}

		public override void AddWhereFilters()
		{
			// Get Only Primary Key information
			AddWhereFilter("rc.rdb$constraint_type = 'FOREIGN KEY'");
		}

		#endregion

		#region PARSE_METHODS

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}