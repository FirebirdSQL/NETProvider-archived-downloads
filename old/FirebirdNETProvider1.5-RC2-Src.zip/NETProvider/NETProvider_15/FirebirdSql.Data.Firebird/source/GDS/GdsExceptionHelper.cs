//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Globalization;
using System.Resources;
using System.Text;
using System.Collections;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsExceptionHelper 
	{
		#region FIELDS
				
		private static ResourceManager	rm;
		private static bool				initialized = false;

		#endregion
	
		#region METHODS

		private static void Init()
		{
			try 
			{
				string resources = "FirebirdSql.Data.Firebird.Resources.GDS.isc_error_msg";

				rm = new ResourceManager(resources, 
					System.Reflection.Assembly.GetExecutingAssembly());
			} 
			catch (Exception)
			{				
			} 
			finally 
			{
				initialized = true;
			}
		}
		
		public static GdsMessage GetMessage(int code)
		{
			string message = null;

			if (!initialized) 
			{
				Init();
			}

			try
			{
				message = rm.GetString(code.ToString());
				// , CultureInfo.InvariantCulture);
			}
			catch(Exception)
			{		
			}
			finally
			{
				if (message == null)
				{
					message = "No message for code " + code.ToString() + " found.";
				}
			}

			return new GdsMessage(message);
		}
		
		#endregion
	}
	
	internal class GdsMessage 
	{
		#region FIELDS

		private string format;
		private ArrayList parameters = new ArrayList();

		#endregion

		#region METHODS

		public GdsMessage(string format)
		{
			this.format = format;
		}

		public int GetParamCount() 
		{
			int count = 0;

			if (format == null)
			{
				format = String.Empty;
			}

			for (int i = 0; i < format.Length; i++)
			{
				if (format[i] == '{') 
				{
					count++;
				}
			}

			return count;
		}
			
		public void SetParameter(int position, string text) 
		{
			parameters.Add(text);
		}
			
		public override string ToString() 
		{
			StringBuilder message = new StringBuilder();
			
			if (parameters.Count == GetParamCount())
			{
				message.AppendFormat(format, parameters.ToArray());
			}
			else
			{
				message.Append(format);
			}

			return message.ToString();
		}

		#endregion
	}
}
