//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsCharsetCollection : ArrayList
	{
		#region PROPERTIES

		public new GdsCharset this[int index]
		{
			get { return (GdsCharset)base[index]; }
			set { base[index] = (GdsCharset)value; }
		}

		public GdsCharset this[string name] 
		{
			get { return (GdsCharset)this[IndexOf(name)]; }
			set { this[IndexOf(name)] = (GdsCharset)value; }
		}

		#endregion

		#region METHODS

		public bool Contains(string name)
		{
			return(-1 != IndexOf(name));
		}

		public int IndexOf(string name)
		{
			int index = 0;
			foreach(GdsCharset item in this)
			{
				if (cultureAwareCompare(item.Name, name))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		public int IndexOf(int id)
		{
			int index = 0;
			foreach(GdsCharset item in this)
			{
				if (item.ID == id)
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		public void RemoveAt(string charset)
		{
			RemoveAt(IndexOf(charset));
		}

		public GdsCharset Add(GdsCharset charset)
		{
			base.Add(charset);

			return charset;
		}

		public GdsCharset Add(
			int id, 
			string charset, 
			int bytesPerCharacter,
			string systemCharset)
		{
			GdsCharset charSet = new GdsCharset(
				id, 
				charset, 
				bytesPerCharacter, 
				systemCharset);

			base.Add(charSet);

			return charSet;
		}

		public GdsCharset Add(
			int id, 
			string charset, 
			int bytesPerCharacter, 
			int cp)
		{
			GdsCharset charSet = new GdsCharset(
				id, 
				charset, 
				bytesPerCharacter, 
				cp);

			base.Add(charSet);

			return charSet;
		}

		public GdsCharset Add(
			int id, 
			string charset, 
			int bytesPerCharacter,
			Encoding encoding)
		{
			GdsCharset charSet = new GdsCharset(
				id, 
				charset, 
				bytesPerCharacter,
				encoding);

			base.Add(charSet);

			return charSet;
		}

		private bool cultureAwareCompare(string strA, string strB)
		{
			try
			{
				return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB,
						CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth |
						CompareOptions.IgnoreCase) == 0 ? true : false;
			}
			catch (Exception)
			{
				return strA.ToUpper() == strB.ToUpper() ? true : false;
			}
		}

		#endregion
	}
}
