//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using NUnit.Framework;

using System;
using System.Data;

using FirebirdSql.Data.Firebird;
using FirebirdSql.Data.Firebird.Events;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbEventsTest : BaseTest 
	{
		FbConnection	connection;
		FbTransaction	transaction;
				
		public FbEventsTest() : base()
		{		
		}

		[SetUp]
		public void Setup()
		{		
			connection = new FbConnection(GetConnectionString());
			connection.Open();

			transaction = connection.BeginTransaction();
		}
		
		[TearDown]
		public void TearDown()
		{
			connection.Close();
		}

		[Test]
		public void EventsTest()
		{							
			FbEvents fbEvents = new FbEvents(connection);

			FbEventAlertEventHandler e = new FbEventAlertEventHandler(processEvent);

			fbEvents.EventAlert += e;
			fbEvents.RegisterEvents("new_row", "change_row");
			
			fbEvents.QuequeEvents();

			FbCommand command = new FbCommand("UPDATE test_table_01 SET char_field = 'events test'", connection , transaction);
			
			command.ExecuteNonQuery();			
		}

		private void processEvent(object sender, FbEventAlertEventArgs e)
		{
			for (int i = 0; i < e.Counts.Length; i++)
			{
				Console.WriteLine("{0} Event - Counts : {1}", i, e.Counts[i]);
			}
		}
	}
}
