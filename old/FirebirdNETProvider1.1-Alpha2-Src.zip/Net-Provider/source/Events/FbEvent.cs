//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Net;
using System.Text;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Events
{
	/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="T:FbEvents"]/*'/>
	public sealed class FbEvents
	{
		#region EVENTS

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="E:EventAlert"]/*'/>
		public event FbEventAlertEventHandler EventAlert;

		#endregion

		#region FIELDS

		private FbConnection				connection;
		private string[]					events;
		private	isc_event_handle			handle;
		private EventRequestEventHandler	eventRequestHandler;
		private int[]						initialCounts;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="P:Connection"]/*'/>
		public FbConnection Connection
		{
			get { return connection; }
			set { connection = value; }
		}

		#endregion

		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbEvents()
		{
			eventRequestHandler = new EventRequestEventHandler(receiveEventNotification);			

			handle = new isc_event_handle_impl();
			handle.OnEventRequest += eventRequestHandler;
		}

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection)"]/*'/>
		public FbEvents(FbConnection connection) : this()
		{
			this.connection = connection;
		}

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection, System.Array)"]/*'/>
		public FbEvents(FbConnection connection, params string[] events) : this()
		{
			this.connection = connection;
			this.events		= events;
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:RegisterEvents(System.Array)"]/*'/>
		public void RegisterEvents(params string[] events)
		{
			if (events.Length > 15)
			{
				throw new ArgumentException("The number of events is greater than 15.");
			}

			this.events = events;
		}

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:QueEvents"]/*'/>
		public void QueEvents()
		{
			if (connection == null || connection.State != ConnectionState.Open)
			{
				throw new InvalidOperationException("Connection must valid and open.");
			}

			FbParameterBlock epb = buildEpb();

			try
			{
				lock (handle)
				{					
					connection.IscConnection.GDS.isc_que_events(
							connection.IscConnection.db	,
							handle						,
							(short)events.Length		,							
							epb.Dpb);					
				}
			}
			catch (GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:CancelEvents"]/*'/>
		public void CancelEvents()
		{
			if (connection == null || connection.State != ConnectionState.Open)
			{
				throw new InvalidOperationException("Connection must valid and open.");
			}
			if (handle == null)
			{
				throw new InvalidOperationException("There are no events to cancel.");
			}

			try
			{				
				lock (handle)
				{
					connection.IscConnection.GDS.isc_cancel_events(
						connection.IscConnection.db,
						handle);

					handle.OnEventRequest -= eventRequestHandler;

					handle				= null;
					eventRequestHandler	= null;
					initialCounts		= null;
				}
			}
			catch (GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		private void receiveEventNotification(object sender, EventRequestEventArgs e)
		{
			lock (handle)
			{
				int[] counts = getCounts(e.ResultBuffer);
		
				if (EventAlert != null)
				{
					EventAlert(this, new FbEventAlertEventArgs(counts));
				}
			}
		}

		private int[] getCounts(byte[] resultBuffer)
		{
			int[]	counts	= new int[events.Length];
			int		pos		= 1;

			if (resultBuffer != null)
			{
				for (int i = 0; i < events.Length; i++)
				{
					int		length		= resultBuffer[pos++];
					string	eventName	= connection.Encoding.GetString(resultBuffer, pos, length);

					pos += length;
				
					counts[i] = BitConverter.ToInt32(resultBuffer, pos);

					pos += 4;
				}

				if (initialCounts == null)
				{
					initialCounts = counts;
				}
				else
				{
					for (int i = 0; i < counts.Length; i++)
					{
						counts[i] -= initialCounts[i];
					}
				}
			}

			return counts;
		}

		private FbParameterBlock buildEpb()
		{
			FbParameterBlock epb = new FbParameterBlock();
			
			for (int i = 0; i < events.Length; i++)
			{
				epb.SetEpbProperty(events[i]);
			}

			return epb;
		}

		#endregion
	}	

	#region EVENTALERT_ARGS_CLASS

	/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="T:FbEventAlertEventArgs"]/*'/>
	public sealed class FbEventAlertEventArgs : EventArgs
	{
		private int[] counts;
																		 
		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="P:FbEventAlertEventArgs.Counts"]/*'/>
		public int[] Counts
		{
			get { return counts; } 
			set { counts = value; } 
		}

		/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="M:FbEventAlertEventArgs.#ctor"]/*'/>
		public FbEventAlertEventArgs(int[] counts)
		{
			this.counts = counts;
		}
	}

	#endregion

	#region DELEGATES

	/// <include file='xmldoc/fbevents.xml' path='doc/member[@name="D:FbEventAlertEventHandler"]/*'/>
	public delegate void FbEventAlertEventHandler(object sender, FbEventAlertEventArgs e);

	#endregion
}
