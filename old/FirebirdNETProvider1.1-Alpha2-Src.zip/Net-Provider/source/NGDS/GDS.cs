//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// ( Some parts of this file was ported from JayBird )
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Globalization;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/gds.xml' path='doc/member[@name="T:gds"]/*'/>
	internal class GDS : IGDS
	{
		#region CONSTANTS

		/* The protocol is defined blocks, rather than messages, to
		 * separate the protocol from the transport layer.  
		 */
		public const int CONNECT_VERSION2	= 2;

		/* Protocol 4 is protocol 3 plus server management functions */
		public const int PROTOCOL_VERSION3	= 3;
		public const int PROTOCOL_VERSION4	= 4;

		/* Protocol 5 includes support for a d_float data type */
		public const int PROTOCOL_VERSION5	= 5;

		/* Protocol 6 includes support for cancel remote events, blob seek,
		 * and unknown message type 
		 */
		public const int PROTOCOL_VERSION6	= 6;

		/* Protocol 7 includes DSQL support */
		public const int PROTOCOL_VERSION7	= 7;

		/* Protocol 8 includes collapsing first receive into a send, drop database,
		 * DSQL execute 2, DSQL execute immediate 2, DSQL insert, services, and
		 * transact request.
		 */
		public const int PROTOCOL_VERSION8	= 8;

		/* Protocol 9 includes support for SPX32
		 * SPX32 uses WINSOCK instead of Novell SDK
		 * In order to differentiate between the old implementation
		 * of SPX and this one, different PROTOCOL VERSIONS are used 
		 */
		public const int PROTOCOL_VERSION9	= 9;

		/* Protocol 10 includes support for warnings and removes the requirement for
		 * encoding and decoding status codes.*/
		public const int PROTOCOL_VERSION10	= 10;

		// Operation (packet) types
		public const int op_void                = 0;    // Packet has been voided
		public const int op_connect             = 1;    // Connect to remote server
		public const int op_exit                = 2;    // Remote end has exitted
		public const int op_accept              = 3;    // Server accepts connection
		public const int op_reject              = 4;    // Server rejects connection
		public const int op_protocol            = 5;    // Protocol selection
		public const int op_disconnect          = 6;    // Connect is going away
		public const int op_credit              = 7;    // Grant (buffer) credits
		public const int op_continuation        = 8;    // Continuation packet
		public const int op_response            = 9;    // Generic response block

		// Page server operations

		public const int op_open_file           = 10;   // Open file for page service
		public const int op_create_file         = 11;   // Create file for page service
		public const int op_close_file          = 12;   // Close file for page service
		public const int op_read_page           = 13;   // optionally lock and read page
		public const int op_write_page          = 14;   // write page and optionally release lock
		public const int op_lock                = 15;   // sieze lock
		public const int op_convert_lock        = 16;   // convert existing lock
		public const int op_release_lock        = 17;   // release existing lock
		public const int op_blocking            = 18;   // blocking lock message

		// Full context server operations

		public const int op_attach              = 19;   // Attach database
		public const int op_create              = 20;   // Create database
		public const int op_detach              = 21;   // Detach database
		public const int op_compile             = 22;   // Request based operations
		public const int op_start               = 23;
		public const int op_start_and_send      = 24;
		public const int op_send                = 25;
		public const int op_receive             = 26;
		public const int op_unwind              = 27;
		public const int op_release             = 28;

		public const int op_transaction         = 29;   // Transaction operations
		public const int op_commit              = 30;
		public const int op_rollback            = 31;
		public const int op_prepare             = 32;
		public const int op_reconnect           = 33;

		public const int op_create_blob         = 34;   // Blob operations //
		public const int op_open_blob           = 35;
		public const int op_get_segment         = 36;
		public const int op_put_segment         = 37;
		public const int op_cancel_blob         = 38;
		public const int op_close_blob          = 39;

		public const int op_info_database       = 40;   // Information services
		public const int op_info_request        = 41;
		public const int op_info_transaction    = 42;
		public const int op_info_blob           = 43;

		public const int op_batch_segments      = 44;   // Put a bunch of blob segments

		public const int op_mgr_set_affinity    = 45;   // Establish server affinity
		public const int op_mgr_clear_affinity  = 46;   // Break server affinity
		public const int op_mgr_report          = 47;   // Report on server

		public const int op_que_events          = 48;   // Que event notification request
		public const int op_cancel_events       = 49;   // Cancel event notification request
		public const int op_commit_retaining    = 50;   // Commit retaining (what else)
		public const int op_prepare2            = 51;   // Message form of prepare
		public const int op_event               = 52;   // Completed event request (asynchronous)
		public const int op_connect_request     = 53;   // Request to establish connection
		public const int op_aux_connect         = 54;   // Establish auxiliary connection
		public const int op_ddl                 = 55;   // DDL call
		public const int op_open_blob2          = 56;
		public const int op_create_blob2        = 57;
		public const int op_get_slice           = 58;
		public const int op_put_slice           = 59;
		public const int op_slice               = 60;   // Successful response to public const int op_get_slice
		public const int op_seek_blob           = 61;   // Blob seek operation

		// DSQL operations //

		public const int op_allocate_statement  = 62;   // allocate a statment handle
		public const int op_execute             = 63;   // execute a prepared statement
		public const int op_exec_immediate      = 64;   // execute a statement
		public const int op_fetch               = 65;   // fetch a record
		public const int op_fetch_response      = 66;   // response for record fetch
		public const int op_free_statement      = 67;   // free a statement
		public const int op_prepare_statement   = 68;   // prepare a statement
		public const int op_set_cursor          = 69;   // set a cursor name
		public const int op_info_sql            = 70;

		public const int op_dummy               = 71;   // dummy packet to detect loss of client

		public const int op_response_piggyback  = 72;   // response block for piggybacked messages
		public const int op_start_and_receive   = 73;
		public const int op_start_send_and_receive  = 74;

		public const int op_exec_immediate2     = 75;   // execute an immediate statement with msgs
		public const int op_execute2            = 76;   // execute a statement with msgs
		public const int op_insert              = 77;
		public const int op_sql_response        = 78;   // response from execute; exec immed; insert

		public const int op_transact            = 79;
		public const int op_transact_response   = 80;
		public const int op_drop_database       = 81;

		public const int op_service_attach      = 82;
		public const int op_service_detach      = 83;
		public const int op_service_info        = 84;
		public const int op_service_start       = 85;

		public const int op_rollback_retaining  = 86;

		public const int MAX_BUFFER_SIZE	= 1024;
		public const int MAX_FETCH_ROWS		= 200;


		public const int ARRAY_DESC_COLUMN_MAJOR = 1;	/* Set for FORTRAN */
	
		#endregion

		#region CONSTRUCTORS
	    
		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public GDS() 
		{			
		}

		#endregion

		#region SERVICE_API_METHODS

		public void isc_service_attach(string service, 
										AttachInfo attachInfo,
										isc_svc_handle svc_handle, 
										IParameterBuffer spb)
		{
			isc_svc_handle_impl svc = (isc_svc_handle_impl) svc_handle;

			if (svc == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_svc_handle);
			}

			lock (svc) 
			{
				try 
				{
					svc.AttachInfo = attachInfo;

					svc.Connect();

					svc.Output.WriteInt(op_service_attach);
					svc.Output.WriteInt(0);
					svc.Output.WriteString(service);
					svc.Output.WriteTyped(GdsCodes.isc_spb_version, spb);
					svc.Output.Flush();

					try 
					{
						Response r = receiveResponse(svc);
						svc.Handle = r.resp_object;
					} 
					catch (GDSException g) 
					{
						svc.Disconnect();
						throw g;
					}
				} 
				catch (IOException)
				{
					svc.Disconnect();
					throw new GDSException(GdsCodes.isc_net_write_err);
				}
			}
		}

		public void isc_service_start(isc_svc_handle 	svc_handle	,
		                              IParameterBuffer 	spb)
		{
			isc_svc_handle_impl svc = (isc_svc_handle_impl) svc_handle;

			if (svc == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_svc_handle);
			}

			lock (svc) 
			{
				try 
				{
					svc.Output.WriteInt(op_service_start);
					svc.Output.WriteInt(svc.Handle);
					svc.Output.WriteInt(0);
					svc.Output.WriteBuffer(spb.GetContents(), spb.Length);
					svc.Output.Flush();

					try 
					{
						Response r = receiveResponse(svc);
					} 
					catch (GDSException g) 
					{
						throw g;
					}
				} 
				catch (IOException)
				{
					throw new GDSException(GdsCodes.isc_net_write_err);
				}
			}
		}

		public void isc_service_query(isc_svc_handle svc_handle	,
									IParameterBuffer 	spb		,
									int 		request_length	,
									byte[] 		request_buffer	,
									int 		buffer_length	,
									byte[] 		buffer)
		{
			isc_svc_handle_impl svc = (isc_svc_handle_impl) svc_handle;

			if (svc == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_svc_handle);
			}
			
			lock (svc) 
			{			
				try 
				{					
					svc.Output.WriteInt(op_service_info);					//	operation
					svc.Output.WriteInt(svc.Handle);						//	db_handle
					svc.Output.WriteInt(0);									//	incarnation					
					svc.Output.WriteTyped(GdsCodes.isc_spb_version, spb);	//	spb
					svc.Output.WriteBuffer(request_buffer, request_length); //	request buffer
					svc.Output.WriteInt(buffer_length);						//	result buffer length

					svc.Output.Flush();

					Response r = receiveResponse(svc);

					System.Array.Copy(r.resp_data, 0, buffer, 0, buffer_length);
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_network_error);
				}
			}
		}

		public void isc_service_detach(isc_svc_handle svc_handle)
		{
			isc_svc_handle_impl svc = (isc_svc_handle_impl) svc_handle;

			if (svc == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_svc_handle);
			}

			lock (svc) 
			{	        
				try 
				{
					svc.Output.WriteInt(op_service_detach);
					svc.Output.WriteInt(svc.Handle);
					svc.Output.Flush();            
					
					receiveResponse(svc);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_network_error);
				}
				finally
				{
					try 
					{
						svc.Disconnect();
					}
					catch (IOException) 
					{
						throw new GDSException(GdsCodes.isc_network_error);
					} 
				}
			}
		}
		
		#endregion

		#region DATABASE_METHODS

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_create_database(System.String,FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.IParameterBuffer)"]/*'/>
		public void isc_create_database(string file_name,
									isc_db_handle db_handle,
									IParameterBuffer c)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			lock (db) 
			{
				AttachInfo attachInfo = new AttachInfo(file_name);
				connect(db, attachInfo);
				try 
				{
					db.Output.WriteInt(op_create);
					db.Output.WriteInt(0);					// packet->p_atch->p_atch_database
					db.Output.WriteString(attachInfo.FileName);
					db.Output.WriteTyped(GdsCodes.isc_dpb_version1, c);
					db.Output.Flush();

					try 
					{
						Response r = receiveResponse(db);
						db.Handle = r.resp_object;
					} 
					catch (GDSException g) 
					{
						try
						{
							db.Disconnect();
						}
						catch (Exception)
						{
						}

						throw g;
					}
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_write_err);
				}
			}
		}

		public void isc_attach_database(string host				,
										int port				,
										string file_name		,
										int packetSize			,
										isc_db_handle db_handle	,
										IParameterBuffer dpb)
		{
			try
			{
				AttachInfo attachInfo = new AttachInfo(host, port, file_name, packetSize);
				isc_attach_database(attachInfo, db_handle, dpb);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		public void isc_attach_database(string connectstring,
									isc_db_handle db_handle,
									IParameterBuffer dpb)
		{
			try
			{
				AttachInfo attachInfo = new AttachInfo(connectstring);
				isc_attach_database(attachInfo, db_handle, dpb);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_attach_database(AttachInfo,FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.IParameterBuffer)"]/*'/>
		public void isc_attach_database(AttachInfo attachInfo,
										isc_db_handle db_handle, IParameterBuffer dpb)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			lock (db) 
			{
				connect(db, attachInfo);
				try
				{
					db.Output.WriteInt(op_attach);
					db.Output.WriteInt(0);
					db.Output.WriteString(attachInfo.FileName);
					db.Output.WriteTyped(GdsCodes.isc_dpb_version1, dpb);
					db.Output.Flush();
					
					try 
					{
						Response r = receiveResponse(db);
						db.Handle = r.resp_object;
					}
					catch (GDSException ge) 
					{
						try
						{
							db.Disconnect();
						}
						catch (Exception)
						{
						}

						throw ge;
					}
				} 
				catch (IOException)
				{
					throw new GDSException(GdsCodes.isc_net_write_err);
				}
			}			
		}

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_database_info(FirebirdSql.Data.INGDS.isc_db_handle,System.Int32,System.Array,System.Int32,System.Array)"]/*'/>
		public void isc_database_info(isc_db_handle db_handle,
									int item_length,
									byte[] items,
									int buffer_length,
									byte[] buffer)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			if (db == null)
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			
			lock (db) 
			{			
				try 
				{					
					// see src/remote/protocol.h for packet definition (p_info struct)					
					db.Output.WriteInt(op_info_database);		//	operation
					db.Output.WriteInt(db.Handle);				//	db_handle
					db.Output.WriteInt(0);						//	incarnation
					db.Output.WriteBuffer(items, item_length);  //	items
					db.Output.WriteInt(buffer_length);			//	result buffer length

					db.Output.Flush();

					Response r = receiveResponse(db);

					System.Array.Copy(r.resp_data, 0, buffer, 0, buffer_length);
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_network_error);
				}
			}
		}

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_detach_database(FirebirdSql.Data.INGDS.isc_db_handle)"]/*'/>
		public void isc_detach_database(isc_db_handle db_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			lock (db) 
			{
				if (db_handle.HasTransactions()) 
				{
					throw new GDSException(GdsCodes.isc_open_trans, db.TransactionCount());
				}
	        
				try 
				{
					db.Output.WriteInt(op_detach);
					db.Output.WriteInt(db.Handle);
					db.Output.Flush();            

					receiveResponse(db);					
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_network_error);
				}
				finally
				{
					try 
					{
						db.Disconnect();
					}
					catch (IOException) 
					{
						throw new GDSException(GdsCodes.isc_network_error);
					} 
				}
			}
		}

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_drop_database(FirebirdSql.Data.INGDS.isc_db_handle)"]/*'/>
		public void isc_drop_database(isc_db_handle db_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			lock (db) 
			{				
				try 
				{
					db.Output.WriteInt(op_drop_database);
					db.Output.WriteInt(db.Handle);
					db.Output.Flush();            
					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_network_error);
				}
			}
		}

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_expand_dpb(System.Array,System.Int32,System.Int32,System.Array)"]/*'/>
		public byte[] isc_expand_dpb(byte[] dpb, int dpb_length,
			int param, object[] parameters)
		{
			return dpb;
		}

		#endregion

		#region TRANSACTION_METHODS

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_start_transaction(FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_db_handle,System.Collections.ArrayList)"]/*'/>
		public void isc_start_transaction(isc_tr_handle tr_handle,
											isc_db_handle db_handle,
											ArrayList tpb)
		{                               

			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			if (tr_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			if (db_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			
			lock (db) 
			{
				if (tr.State != TxnState.NOTRANSACTION) 
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}
				tr.State = TxnState.TRANSACTIONSTARTING;

				try {
					db.Output.WriteInt(op_transaction);
					db.Output.WriteInt(db.Handle);
					db.Output.WriteSet(GdsCodes.isc_tpb_version3, tpb);					
					db.Output.Flush();            

					Response r = receiveResponse(db);
					tr.Handle = r.resp_object;
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_network_error);
				}
				
				tr.DbHandle = db;
				tr.State    = TxnState.TRANSACTIONSTARTED;				
			}
		}

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_commit_transaction(FirebirdSql.Data.INGDS.isc_tr_handle)"]/*'/>
		public void isc_commit_transaction(isc_tr_handle tr_handle)
		{
			if (tr_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			isc_tr_handle_impl tr = (isc_tr_handle_impl)tr_handle;
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock (db) 
			{
				if (tr.State != TxnState.TRANSACTIONSTARTED && tr.State != TxnState.TRANSACTIONPREPARED)				
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}
				
				tr.State = TxnState.TRANSACTIONCOMMITTING;

				try 
				{					
					db.Output.WriteInt(op_commit);
					db.Output.WriteInt(tr.Handle);
					db.Output.Flush();

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}

				tr.State = TxnState.NOTRANSACTION;
				tr.UnsetDbHandle();
			}
		}

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_commit_retaining(FirebirdSql.Data.INGDS.isc_tr_handle)"]/*'/>
		public void isc_commit_retaining(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock (db) 
			{
				if (tr.State != TxnState.TRANSACTIONSTARTED && tr.State != TxnState.TRANSACTIONPREPARED)
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}
				tr.State = TxnState.TRANSACTIONCOMMITTING;

				try 
				{
					db.Output.WriteInt(op_commit_retaining);
					db.Output.WriteInt(tr.Handle);
					db.Output.Flush();

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
				tr.State = TxnState.TRANSACTIONSTARTED;
			}
		}

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_prepare_transaction(FirebirdSql.Data.INGDS.isc_tr_handle)"]/*'/>
		public void isc_prepare_transaction(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}
						
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock (db) 
			{
				if (tr.State != TxnState.TRANSACTIONSTARTED) 
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}
				tr.State = TxnState.TRANSACTIONPREPARING;
				try 
				{
					db.Output.WriteInt(op_prepare);
					db.Output.WriteInt(tr.Handle);
					db.Output.Flush();

					receiveResponse(db);
				} 
				catch (IOException)
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
				tr.State = TxnState.TRANSACTIONPREPARED;
			}
		}

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_prepare_transaction2(FirebirdSql.Data.INGDS.isc_tr_handle,System.Array)"]/*'/>
		public void isc_prepare_transaction2(isc_tr_handle tr_handle,
											byte[] bytes)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock (db) 
			{
				if (tr.State != TxnState.TRANSACTIONSTARTED) 
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}
				tr.State = TxnState.TRANSACTIONPREPARING;
				try 
				{
					db.Output.WriteInt(op_prepare2);
					db.Output.WriteInt(tr.Handle);
					db.Output.WriteBuffer(bytes, bytes.Length);
					db.Output.Flush();

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}

				tr.State = TxnState.TRANSACTIONPREPARED;
			}
		}

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_rollback_transaction(FirebirdSql.Data.INGDS.isc_tr_handle)"]/*'/>
		public void isc_rollback_transaction(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock (db)
			{
				if (tr.State == TxnState.NOTRANSACTION)
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}

				tr.State = TxnState.TRANSACTIONROLLINGBACK;

				try 
				{
					db.Output.WriteInt(op_rollback);
					db.Output.WriteInt(tr.Handle);
					db.Output.Flush();            

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
				finally
				{
					tr.State = TxnState.NOTRANSACTION;
					tr.UnsetDbHandle();
				}
			}
		}

		/// <include file='xmldoc/gds_transaction.xml' path='doc/member[@name="M:isc_rollback_retaining(FirebirdSql.Data.INGDS.isc_tr_handle)"]/*'/>
		public void isc_rollback_retaining(isc_tr_handle tr_handle)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}
			isc_db_handle_impl db = (isc_db_handle_impl)tr.DbHandle;

			lock (db) 
			{
				if (tr.State != TxnState.TRANSACTIONSTARTED && tr.State != TxnState.TRANSACTIONPREPARED)
				{
					throw new GDSException(GdsCodes.isc_tra_state);
				}
				tr.State = TxnState.TRANSACTIONROLLINGBACK;

				try 
				{
					db.Output.WriteInt(op_rollback_retaining);
					db.Output.WriteInt(tr.Handle);
					db.Output.Flush();

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
				tr.State = TxnState.TRANSACTIONSTARTED;
			}
		}

		#endregion

		#region DYNAMIC_SQL_METHODS

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_allocate_statement(FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.isc_stmt_handle)"]/*'/>
		public void isc_dsql_allocate_statement(isc_db_handle db_handle,
											isc_stmt_handle stmt_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;

			if (db_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			if (stmt_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_req_handle);
			}

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_allocate_statement);
					db.Output.WriteInt(db.Handle);
					db.Output.Flush();
					Response r  = receiveResponse(db);
					stmt.Handle = r.resp_object;
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}

				stmt.DbHandle = db;
				db.SqlRequest.Add(stmt);
				stmt.AllRowsFetched = false;
			}
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_allocate_statement2(FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.isc_stmt_handle)"]/*'/>
		public void isc_dsql_alloc_statement2(isc_db_handle db_handle,
											isc_stmt_handle stmt_handle)
		{
			throw new GDSException(GdsCodes.isc_wish_list);
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_describe(FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32)"]/*'/>
		public XSQLDA isc_dsql_describe(isc_stmt_handle stmt_handle,
									int da_version)
		{
			byte[] describe_select_info = new byte[] { 
									GdsCodes.isc_info_sql_select,
									GdsCodes.isc_info_sql_describe_vars,
									GdsCodes.isc_info_sql_sqlda_seq,
									GdsCodes.isc_info_sql_type,
									GdsCodes.isc_info_sql_sub_type,
									GdsCodes.isc_info_sql_scale,
									GdsCodes.isc_info_sql_length,
									GdsCodes.isc_info_sql_field,
									GdsCodes.isc_info_sql_relation,
									GdsCodes.isc_info_sql_owner,
									GdsCodes.isc_info_sql_alias,
									GdsCodes.isc_info_sql_describe_end};

			try
			{
				byte[] buffer = isc_dsql_sql_info(stmt_handle, 
										describe_select_info.Length, 
										describe_select_info, MAX_BUFFER_SIZE);

				return parseSqlInfo(stmt_handle, buffer, describe_select_info);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
		
		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_describe_bind(FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32)"]/*'/>
		public XSQLDA isc_dsql_describe_bind(isc_stmt_handle stmt_handle,
											int da_version) 
		{
			byte[] describe_bind_info = new byte[] { 
									GdsCodes.isc_info_sql_bind,
									GdsCodes.isc_info_sql_describe_vars,
									GdsCodes.isc_info_sql_sqlda_seq,
									GdsCodes.isc_info_sql_type,
									GdsCodes.isc_info_sql_sub_type,
									GdsCodes.isc_info_sql_scale,
									GdsCodes.isc_info_sql_length,
									GdsCodes.isc_info_sql_field,
									GdsCodes.isc_info_sql_relation,
									GdsCodes.isc_info_sql_owner,
									GdsCodes.isc_info_sql_alias,
									GdsCodes.isc_info_sql_describe_end };

			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;

			try
			{		        
				byte[] buffer = isc_dsql_sql_info(stmt_handle,
								describe_bind_info.Length, describe_bind_info,
								MAX_BUFFER_SIZE);
		        
				stmt.InSqlda = parseSqlInfo(stmt_handle, buffer, describe_bind_info);
			}
			catch(GDSException ge)
			{
				throw ge;
			}

			return stmt.InSqlda;
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_execute(FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32,FirebirdSql.Data.INGDS.XSQLDA)"]/*'/>
		public void isc_dsql_execute(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									int da_version,
									XSQLDA xsqlda)
		{
			try
			{
				isc_dsql_execute2(tr_handle, stmt_handle, da_version,
					xsqlda, null);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
		
		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_execute2(FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32,FirebirdSql.Data.INGDS.XSQLDA,FirebirdSql.Data.INGDS.XSQLDA)"]/*'/>
		public void isc_dsql_execute2(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									int da_version,									
									XSQLDA in_xsqlda,
									XSQLDA out_xsqlda)
		{
			isc_tr_handle_impl	 tr		= (isc_tr_handle_impl) tr_handle;
			isc_stmt_handle_impl stmt	= (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl	 db		= stmt.DbHandle;

			stmt.ClearRows();
	        
			// Test Handles needed here
			lock (db) 
			{
				try 
				{					
					if (!isSQLDataOK(in_xsqlda)) 
					{
						throw new GDSException(GdsCodes.isc_dsql_sqlda_value_err);
					}
	                
					db.Output.WriteInt((out_xsqlda == null) ? op_execute : op_execute2);
					db.Output.WriteInt(stmt.Handle);
					db.Output.WriteInt(tr.Handle);

					writeBLR(db, in_xsqlda);
					db.Output.WriteInt(0);								// message number = in_message_type
					db.Output.WriteInt(((in_xsqlda == null) ? 0 : 1));  // stmt->rsr_bind_format

					if (in_xsqlda != null) 
					{
						writeSQLData(db, in_xsqlda);
					}

					if (out_xsqlda != null) 
					{
						writeBLR(db, out_xsqlda);
						db.Output.WriteInt(0);		//out_message_number = out_message_type
					}
					db.Output.Flush();            

					if (nextOperation(db) == op_sql_response) 
					{
						// This would be an Execute procedure
						stmt.Rows.Add(receiveSqlResponse(db, out_xsqlda));
						
						stmt.AllRowsFetched		= true;
						stmt.IsSingletonResult	= true;
					}
					else 
					{
						stmt.IsSingletonResult = false;
					}

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}
	    
		public void isc_dsql_execute_immediate(isc_db_handle db_handle,
											isc_tr_handle tr_handle,
											string statement,
											XSQLDA xsqlda)
		{
			try
			{
				isc_dsql_exec_immed2(db_handle, tr_handle, statement, xsqlda, null);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}
		
		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_exec_immed2(FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.isc_tr_handle,System.String,System.Int32,FirebirdSql.Data.INGDS.XSQLDA,FirebirdSql.Data.INGDS.XSQLDA)"]/*'/>
		public void isc_dsql_exec_immed2(isc_db_handle db_handle,
										isc_tr_handle tr_handle,
										string statement,
										XSQLDA in_xsqlda,
										XSQLDA out_xsqlda)
		{
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;

			lock (db) 
			{
				try 
				{
					if (!isSQLDataOK(in_xsqlda)) 
					{
						throw new GDSException(GdsCodes.isc_dsql_sqlda_value_err);
					}
	                
					if (in_xsqlda == null && out_xsqlda == null) 
					{
						db.Output.WriteInt(op_exec_immediate);
					} 
					else 
					{
						db.Output.WriteInt(op_exec_immediate2);

						writeBLR(db, in_xsqlda);
						db.Output.WriteInt(0);
						db.Output.WriteInt(((in_xsqlda == null) ? 0 : 1));

						if (in_xsqlda != null) 
						{
							writeSQLData(db, in_xsqlda);
						}

						writeBLR(db, out_xsqlda);
						db.Output.WriteInt(0);
					}

					db.Output.WriteInt(tr.Handle);
					db.Output.WriteInt(0);
					db.Output.WriteInt(db.AttachInfo.Dialect);
					db.Output.WriteString(statement, db.AttachInfo.Encoding);
					db.Output.WriteString(String.Empty);
					db.Output.WriteInt(0);
					db.Output.Flush();            
					
					if (nextOperation(db) == op_sql_response) 
					{
						receiveSqlResponse(db, out_xsqlda);
					}

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_fetch(FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32,FirebirdSql.Data.INGDS.XSQLDA)"]/*'/>
		public object[] isc_dsql_fetch(isc_stmt_handle stmt_handle,
								int da_version,
								XSQLDA xsqlda)
		{
			isc_stmt_handle_impl	stmt	= (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl		db		= stmt.DbHandle;

			if (stmt_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_req_handle);
			}

			if (xsqlda == null) 
			{
				throw new GDSException(GdsCodes.isc_dsql_sqlda_err);
			}

			if (!stmt.AllRowsFetched && stmt.Rows.Count == 0) 
			{
				//Fetch next batch of rows
				lock (db) 
				{
					try 
					{						
						db.Output.WriteInt(op_fetch);
						db.Output.WriteInt(stmt.Handle);
						writeBLR(db, xsqlda);
						db.Output.WriteInt(0);              // p_sqldata_message_number
						db.Output.WriteInt(MAX_FETCH_ROWS); // p_sqldata_messages
						db.Output.Flush();

						if (nextOperation(db) == op_fetch_response) 
						{
							int sqldata_status;
							int sqldata_messages;
							do 
							{
								int op = readOperation(db);
								sqldata_status = db.Input.ReadInt();
								sqldata_messages = db.Input.ReadInt();

								if (sqldata_messages > 0 && sqldata_status == 0) 
								{
									stmt.Rows.Add(readSQLData(db, xsqlda));
								}

							} while (sqldata_messages > 0 && sqldata_status == 0);

							if (sqldata_status == 100) 
							{
								stmt.AllRowsFetched = true;
							}
						}
						else 
						{
							receiveResponse(db);
						}
					} 
					catch (IOException) 
					{
						throw new GDSException(GdsCodes.isc_net_read_err);
					}
				}
			}

			if (stmt.Rows.Count > 0) 
			{
				// Return next row from cache.				
				object[] row = (object[])stmt.Rows[0];
				
				stmt.Rows.RemoveAt(0);
				
				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					xsqlda.sqlvar[i].sqldata = row[i];					
					xsqlda.sqlvar[i].sqlind = (row[i] == null ? -1 : 0);
				}
				
				/*
				for (int i = xsqlda.sqld; i < xsqlda.sqln; i++) 
				{
					// is this really necessary?
					xsqlda.sqlvar[i].sqldata = null;
				}
				*/

				return row;
			}
			else 
			{
				for (int i = 0; i < xsqlda.sqln; i++) 
				{
					xsqlda.sqlvar[i].sqldata = null;
				}
				
				return null;	// no rows fetched
			}
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_free_statement(FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32)"]/*'/>
		public void isc_dsql_free_statement(isc_stmt_handle stmt_handle,
			int option)
		{
			isc_stmt_handle_impl	stmt	= (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl		db		= stmt.DbHandle;

			if (stmt_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_req_handle);
			}

			// Does not seem to be possible or necessary to close
			// an execute procedure statement.
			if (stmt.IsSingletonResult && option == GdsCodes.DSQL_close) 
			{
				return;        
			}
	        
			lock (db) 
			{
				try 
				{
					if (!db.IsValid) 
					{
						// too late, socket has been closed
						return;
					}

					db.Output.WriteInt(op_free_statement);
					db.Output.WriteInt(stmt.Handle);
					db.Output.WriteInt(option);
					db.Output.Flush();

					receiveResponse(db);
					if (option == GdsCodes.DSQL_drop) 
					{
						stmt.InSqlda	= null;
						stmt.OutSqlda	= null;
					}
					stmt.ClearRows();
					db.SqlRequest.Remove(stmt);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_prepare(FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_stmt_handle,System.String,System.String,System.Int32)"]/*'/>
		public XSQLDA isc_dsql_prepare(isc_tr_handle tr_handle,
									isc_stmt_handle stmt_handle,
									string statement)
		{
			isc_tr_handle_impl tr	  = (isc_tr_handle_impl) tr_handle;
			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl db	  = stmt.DbHandle;

			if (tr_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			if (stmt_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_req_handle);
			}

			// Reinitialize stmt SQLDA members.
			stmt.InSqlda	= null;
			stmt.OutSqlda	= null;

			byte[] sql_prepare_info = new byte[] { 
									GdsCodes.isc_info_sql_select,
									GdsCodes.isc_info_sql_describe_vars,
									GdsCodes.isc_info_sql_sqlda_seq,
									GdsCodes.isc_info_sql_type,
									GdsCodes.isc_info_sql_sub_type,
									GdsCodes.isc_info_sql_scale,
									GdsCodes.isc_info_sql_length,
									GdsCodes.isc_info_sql_field,
									GdsCodes.isc_info_sql_relation,
									GdsCodes.isc_info_sql_owner,
									GdsCodes.isc_info_sql_alias,
									GdsCodes.isc_info_sql_describe_end};

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_prepare_statement);
					db.Output.WriteInt(tr.Handle);
					db.Output.WriteInt(stmt.Handle);
					db.Output.WriteInt(db.AttachInfo.Dialect);
					db.Output.WriteString(statement, db.AttachInfo.Encoding);
					db.Output.WriteBuffer(sql_prepare_info, sql_prepare_info.Length);
					db.Output.WriteInt(MAX_BUFFER_SIZE);
					db.Output.Flush();

					Response r = receiveResponse(db);
					stmt.OutSqlda = parseSqlInfo(stmt_handle, r.resp_data, sql_prepare_info);

					return stmt.OutSqlda;
				} 
				catch (IOException)
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}				
			}
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_set_cursor_name(FirebirdSql.Data.INGDS.isc_stmt_handle,System.String,System.Int32)"]/*'/>
		public void isc_dsql_set_cursor_name(isc_stmt_handle stmt_handle,
											string cursor_name,
											int type)
		{
			isc_stmt_handle_impl	stmt	= (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl		db		= stmt.DbHandle;

			if (stmt_handle == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_req_handle);
			}

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_set_cursor);
					db.Output.WriteInt(stmt.Handle);

					byte[] buffer = new byte[cursor_name.Length + 1];
					System.Array.Copy(Encoding.Default.GetBytes(cursor_name), 0,
							buffer, 0, Encoding.Default.GetByteCount(cursor_name));
					buffer[cursor_name.Length] = (byte) 0;

					db.Output.WriteBuffer(buffer, buffer.Length);
					db.Output.WriteInt(0);
					db.Output.Flush();

					receiveResponse(db);
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}
		
		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_dsql_sql_info(FirebirdSql.Data.INGDS.isc_stmt_handle,System.Int32,System.Array,System.Int32)"]/*'/>
		public byte[] isc_dsql_sql_info(isc_stmt_handle stmt_handle,
									int item_length,
									byte[] items,
									int buffer_length)
		{
			isc_stmt_handle_impl	stmt	= (isc_stmt_handle_impl) stmt_handle;
			isc_db_handle_impl		db		= stmt.DbHandle;

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_info_sql);
					db.Output.WriteInt(stmt.Handle);
					db.Output.WriteInt(0);
					db.Output.WriteBuffer(items, item_length);
					db.Output.WriteInt(buffer_length);
					db.Output.Flush();

					Response r = receiveResponse(db);
					return r.resp_data;
				} 
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:get_plan_info(FirebirdSql.Data.INGDS.isc_stmt_handle)"]/*'/>
		public string get_plan_info(isc_stmt_handle stmt_handle) 
		{
			string plan = String.Empty;
			
			byte[] describe_plan_info = new byte[] { 
									GdsCodes.isc_info_sql_get_plan,
									GdsCodes.isc_info_end };

			isc_stmt_handle_impl stmt = (isc_stmt_handle_impl) stmt_handle;

			try
			{		        
				byte[] buffer = isc_dsql_sql_info(stmt_handle,
								describe_plan_info.Length, describe_plan_info,
								MAX_BUFFER_SIZE);
				

				int len = buffer[1];				
				len += buffer[2] << 8;
												
				plan = Encoding.Default.GetString(buffer, 4, --len);
			}
			catch(GDSException ge)
			{
				throw ge;
			}

			return plan;
		}

		/// <include file='xmldoc/gds_dsql.xml' path='doc/member[@name="M:isc_vax_integer(System.Array,system.Int32,system.Int32)"]/*'/>
		public int isc_vax_integer(byte[] buffer, int pos, int length) 
		{
			int value;
			int shift;

			value = shift = 0;

			int i = pos;
			while (--length >= 0) 
			{
				value += (buffer[i++] & 0xff) << shift;
				shift += 8;
			}
			
			return value;
		}

		#endregion

		#region ARRAY_METHODS
	
		private string stuff(string sdl, short count, params object[] va_arg)
		{	
			for (int i = 0; i < count; i++) 
			{
				sdl += Convert.ToChar(va_arg[i]);
			}
			
			return sdl;
		}
		
		private string stuff_sdl(string sdl, byte sdl_value)
		{
			return stuff(sdl, 1, sdl_value);
		}

		private string stuff_word(string sdl, int sdl_value)
		{
			return stuff(sdl, 2, sdl_value, sdl_value >> 8);
		}

		private string stuff_long(string sdl, long sdl_value)
		{
			return stuff(sdl, 4, sdl_value, sdl_value >> 8, sdl_value >> 16, sdl_value >> 24);
		}
	
		private string stuff_literal(string sdl, long sdl_value)
		{
			if (sdl_value >= -128 && sdl_value <= 127)
			{
				return stuff(sdl, 2, GdsCodes.isc_sdl_tiny_integer, sdl_value);
			}
		
			if (sdl_value >= -32768 && sdl_value <= 32767)
			{
				return stuff(sdl, 3, GdsCodes.isc_sdl_short_integer, sdl_value, sdl_value >> 8);				
			}
		
			sdl = stuff_sdl(sdl, GdsCodes.isc_sdl_long_integer);
			return stuff_long(sdl, sdl_value);	
		}
		
		private string stuff_string(string sdl, int sdl_constant, string sdl_value)
		{
			sdl = stuff_sdl(sdl, (byte)sdl_constant);
			sdl	= stuff_sdl(sdl, (byte)sdl_value.Length);
		
			for(int i = 0; i < sdl_value.Length; i++)
			{
				sdl = stuff_sdl(sdl, (byte)sdl_value[i]);
			}	
			
			return sdl;
		}

		/// <include file='xmldoc/gds_array.xml' path='doc/member[@name="M:isc_array_gen_sdl(FirebirdSql.Data.INGDS.ISC_ARRAY_DESC)"]/*'/>
		public string isc_array_gen_sdl(ISC_ARRAY_DESC desc)
		{
			int 			n;
			int 			from;
			int 			to;
			int 			increment;
			int 			dimensions;
			ISC_ARRAY_BOUND tail;
			string			sdl;
				
			dimensions = desc.array_desc_dimensions;
		
			if (dimensions > 16)
			{
				throw new GDSException(GdsCodes.isc_invalid_dimension);
			}
		
			sdl = String.Empty;
					
			sdl = stuff(sdl, 4, GdsCodes.isc_sdl_version1, GdsCodes.isc_sdl_struct, 1, desc.array_desc_dtype);
			
			switch (desc.array_desc_dtype) 
			{
				case GdsCodes.blr_short:
				case GdsCodes.blr_long:
				case GdsCodes.blr_int64:
				case GdsCodes.blr_quad:
					sdl = stuff_sdl(sdl, (byte)desc.array_desc_scale);
					break;
			
				case GdsCodes.blr_text:
				case GdsCodes.blr_cstring:
				case GdsCodes.blr_varying:
					sdl = stuff_word(sdl, desc.array_desc_length);
					break;

				default:
					break;
			}
		
			sdl = stuff_string(sdl, GdsCodes.isc_sdl_relation, desc.array_desc_relation_name);
		
			sdl = stuff_string(sdl, GdsCodes.isc_sdl_field, desc.array_desc_field_name);
					
			if ((desc.array_desc_flags & GDS.ARRAY_DESC_COLUMN_MAJOR) == GDS.ARRAY_DESC_COLUMN_MAJOR)
			{
				from		= dimensions - 1;
				to 			= -1;
				increment 	= -1;
			}
			else 
			{
				from 		= 0;
				to 			= dimensions;
				increment 	= 1;
			}
		
			for (n = from; n != to; n += increment) 
			{
				tail = desc.array_desc_bounds[n];
				if (tail.array_bound_lower == 1) 
				{
					sdl = stuff(sdl, 2, GdsCodes.isc_sdl_do1, n);
				}
				else 
				{
					sdl = stuff(sdl, 2, GdsCodes.isc_sdl_do2, n);
					
					sdl = stuff_literal(sdl, (long)tail.array_bound_lower);				
				}
				sdl = stuff_literal(sdl, (long)tail.array_bound_upper);
			}
		
			sdl = stuff(sdl, 5, GdsCodes.isc_sdl_element, 1, GdsCodes.isc_sdl_scalar, 0, dimensions);
		
			for (n = 0; n < dimensions; n++)
			{
				sdl = stuff(sdl, 2, GdsCodes.isc_sdl_variable, n);
			}
		
			return stuff_sdl(sdl, GdsCodes.isc_sdl_eoc);
		}

		/// <include file='xmldoc/gds_array.xml' path='doc/member[@name="M:isc_array_get_slice(isc_db_handle,isc_tr_handle,System.Long,ISC_ARRAY_DESC,System.Int32)"]/*'/>		
		public byte[] isc_array_get_slice(isc_db_handle db_handle, isc_tr_handle tr_handle,
										long array_id, ISC_ARRAY_DESC desc, int slice_length)
		{
			string 	sdl;
		
			// Generate array field sdl string
			sdl = isc_array_gen_sdl(desc);
								
			isc_db_handle_impl db = (isc_db_handle_impl)db_handle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			
			isc_tr_handle_impl tr = (isc_tr_handle_impl)tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			lock (db) 
			{
				try 
				{					
					db.Output.WriteInt(op_get_slice);		// Op code
					db.Output.WriteInt(tr.Handle); 			// Transaction
					db.Output.WriteLong(array_id);			// Array id
					db.Output.WriteInt(slice_length);		// Slice length
					db.Output.WriteString(sdl);				// Slice description language
					db.Output.WriteString("");				// Slice parameters					
					db.Output.WriteInt(0);					// Slice proper
					db.Output.Flush();

					return receiveSliceResponse(db, desc);
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_array.xml' path='doc/member[@name="M:isc_array_put_slice(isc_db_handle,isc_tr_handle,System.Long,ISC_ARRAY_DESC,System.Array,System.Int32)"]/*'/>
		public long isc_array_put_slice(isc_db_handle db_handle, isc_tr_handle tr_handle, 
										long array_id, ISC_ARRAY_DESC desc, System.Array source_array,
										int slice_length, Encoding encoding)
		{
			string 	sdl;
		
			// Generate array field sdl string
			sdl = isc_array_gen_sdl(desc);
								
			isc_db_handle_impl db = (isc_db_handle_impl)db_handle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			
			isc_tr_handle_impl tr = (isc_tr_handle_impl)tr_handle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			lock (db) 
			{
				try 
				{					
					db.Output.WriteInt(op_put_slice);	// Op code
					db.Output.WriteInt(tr.Handle); 		// Transaction
					db.Output.WriteLong(array_id);		// Array id
					db.Output.WriteInt(slice_length);	// Slice length
					db.Output.WriteString(sdl);			// Slice description language
					db.Output.WriteString("");			// Slice parameters
					db.Output.WriteSlice(this, desc, 
					                     source_array, 
					                     slice_length,
					                     encoding);		// Slice proper
					db.Output.Flush();

					Response r = receiveResponse(db);
					
					return r.resp_blob_id;
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}			
		}
	
		#endregion

		#region BLOB_METHODS

		/// <include file='xmldoc/gds_blob.xml' path='doc/member[@name="M:isc_create_blob2(FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_blob_handle,FirebirdSql.Data.INGDS.IParameterBuffer)"]/*'/>
		public void isc_create_blob2(isc_db_handle db_handle,
			isc_tr_handle tr_handle,
			isc_blob_handle blob_handle, //contains blob_id
			IParameterBuffer bpb)
		{
			try
			{
				openOrCreateBlob(db_handle, tr_handle, blob_handle, bpb, (bpb == null)? op_create_blob: op_create_blob2);
				((isc_blob_handle_impl)blob_handle).RBLAddValue(GdsCodes.RBL_create);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <include file='xmldoc/gds_blob.xml' path='doc/member[@name="M:isc_open_blob2(FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_blob_handle,FirebirdSql.Data.INGDS.IParameterBuffer)"]/*'/>
		public void isc_open_blob2(isc_db_handle db_handle,
			isc_tr_handle tr_handle,
			isc_blob_handle blob_handle, //contains blob_id
			IParameterBuffer bpb)
		{
			try
			{
				openOrCreateBlob(db_handle, tr_handle, blob_handle, bpb, (bpb == null)? op_open_blob: op_open_blob2);
			}
			catch(GDSException ge)
			{
				throw ge;
			}
		}

		/// <include file='xmldoc/gds_blob.xml' path='doc/member[@name="M:openOrCreateBlob(FirebirdSql.Data.INGDS.isc_db_handle,FirebirdSql.Data.INGDS.isc_tr_handle,FirebirdSql.Data.INGDS.isc_blob_handle,FirebirdSql.Data.INGDS.IParameterBuffer,System.Int32)"]/*'/>
		private void openOrCreateBlob(isc_db_handle db_handle,
							isc_tr_handle tr_handle,
							isc_blob_handle blob_handle,		//contains blob_id
							IParameterBuffer bpb,
							int op)
		{
			isc_db_handle_impl db = (isc_db_handle_impl) db_handle;
			isc_tr_handle_impl tr = (isc_tr_handle_impl) tr_handle;
			isc_blob_handle_impl blob = (isc_blob_handle_impl) blob_handle;

			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}
			if (blob == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_segstr_handle);
			}

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op);
					if (bpb != null) 
					{
						db.Output.WriteTyped(GdsCodes.isc_bpb_version1, bpb);
					}
					db.Output.WriteInt(tr.Handle);

					db.Output.WriteLong(blob.Handle);
					db.Output.Flush();            


					Response r = receiveResponse(db);
					blob.DbHandle	= db;
					blob.TrHandle	= tr;
					blob.RblId		= r.resp_object;
					blob.Handle		= r.resp_blob_id;
					tr.AddBlob(blob);
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_blob.xml' path='doc/member[@name="M:isc_get_segment(FirebirdSql.Data.INGDS.isc_blob_handle,System.Int32)"]/*'/>
		public byte[] isc_get_segment(isc_blob_handle blob_handle, int requested)
		{
			isc_blob_handle_impl	blob	= (isc_blob_handle_impl) blob_handle;
			isc_db_handle_impl		db		= blob.DbHandle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			isc_tr_handle_impl tr = blob.TrHandle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_get_segment);
					db.Output.WriteInt(blob.RblId);
					db.Output.WriteInt((requested + 2 < short.MaxValue) ? requested+2 : short.MaxValue);
					db.Output.WriteInt(0);
					db.Output.Flush();

					Response resp = receiveResponse(db);
					blob.RBLRemoveValue(GdsCodes.RBL_segment);
					if (resp.resp_object == 1) 
					{
						blob.RBLAddValue(GdsCodes.RBL_segment);						
					}
					else if (resp.resp_object == 2) {
						blob.RBLAddValue(GdsCodes.RBL_eof_pending);
					}
					byte[] buffer = resp.resp_data;
					if (buffer.Length == 0) 
					{
						// previous segment was last, this has no data
						return buffer;
					}
					int len = 0;
					int srcpos = 0;
					int destpos = 0;
					while (srcpos < buffer.Length) 
					{
						len = isc_vax_integer(buffer, srcpos, 2);
						srcpos	+= 2;
						System.Array.Copy(buffer, srcpos, buffer, destpos, len);
						srcpos	+= len;
						destpos += len;
					}
					byte[] result = new byte[destpos];
					System.Array.Copy(buffer, 0, result, 0, destpos);

					return result;
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_blob.xml' path='doc/member[@name="M:isc_put_segment(FirebirdSql.Data.INGDS.isc_blob_handle,System.Array)"]/*'/>
		public void isc_put_segment(isc_blob_handle blob_handle, byte[] buffer)
		{
			isc_blob_handle_impl	blob	= (isc_blob_handle_impl) blob_handle;
			isc_db_handle_impl		db		= blob.DbHandle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			isc_tr_handle_impl tr = blob.TrHandle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_batch_segments);
					db.Output.WriteInt(blob.RblId);
					db.Output.WriteBlobBuffer(buffer);
					db.Output.Flush();

					Response resp = receiveResponse(db);
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		/// <include file='xmldoc/gds_blob.xml' path='doc/member[@name="M:isc_close_blob(FirebirdSql.Data.INGDS.isc_blob_handle)"]/*'/>
		public void isc_close_blob(isc_blob_handle blob_handle)
		{
			isc_blob_handle_impl blob = (isc_blob_handle_impl) blob_handle;
			isc_db_handle_impl	 db   = blob.DbHandle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			isc_tr_handle_impl tr = blob.TrHandle;
			if (tr == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_trans_handle);
			}
			releaseObject(db, op_close_blob, blob.RblId);
			tr.RemoveBlob(blob);
		}

		#endregion

		#region EVENTS_METHODS

		public void isc_connection_request(isc_db_handle db_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl)db_handle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op_connect_request);
					db.Output.WriteInt(db.Handle);
					db.Output.WriteInt(GdsCodes.P_REQ_async);
					db.Output.WriteInt(0);

					db.Output.Flush();

					int op = readOperation(db);

					byte[] buffer = new byte[36];

					db.Input.Read(buffer, 0, buffer.Length);

					db.AsyncDB					= new isc_db_handle_impl();
					db.AsyncDB.AttachInfo		= db.AttachInfo;
					db.AsyncDB.AttachInfo.Port	= BitConverter.ToInt16(buffer, 4);

					db.AsyncDB.Connect();
					db.AsyncDB.Handle = BitConverter.ToInt32(buffer, 0);
					db.AsyncDB.Events = new Hashtable();

					// Start the Async thread
					db.AsyncDB.StartEventThread();
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		public void isc_que_events(isc_db_handle db_handle			, 
									isc_event_handle event_handle	,
									short length					,
									IParameterBuffer epb)
		{
			isc_db_handle_impl db = (isc_db_handle_impl)db_handle;			
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}
			
			if (db.AsyncDB == null)
			{
				isc_connection_request(db);
			}

			lock (db.AsyncDB)
			{
				lock (db) 
				{
					try 
					{
						db.Output.WriteInt(op_que_events);					// Op code
						db.Output.WriteInt(db.Handle); 						// Database object id
						db.Output.WriteTyped(GdsCodes.EPB_version1, epb);	// Event description block
						db.Output.WriteInt(0);								// Address of ast routine
						db.Output.WriteInt(0);								// Argument to ast routine						
						db.Output.WriteInt(++db.RemoteEventId);				// Client side id of remote event

						db.Output.Flush();

						Response r = receiveResponse(db_handle);

						// Update event LocalID and Handle ID
						event_handle.Handle		= r.resp_object;
						event_handle.LocalID	= db.RemoteEventId;

						db.AsyncDB.Events.Add(event_handle.LocalID, event_handle);
					}
					catch (IOException) 
					{
						throw new GDSException(GdsCodes.isc_net_read_err);
					}
				}
			}
		}

		public void isc_cancel_events(isc_db_handle db_handle, isc_event_handle event_handle)
		{
			isc_db_handle_impl db = (isc_db_handle_impl)db_handle;
			if (db == null) 
			{
				throw new GDSException(GdsCodes.isc_bad_db_handle);
			}

			lock (db.AsyncDB)
			{
				lock (db) 
				{
					try 
					{
						db.Output.WriteInt(op_cancel_events);		// Op code
						db.Output.WriteInt(db.Handle); 				// Database object id
						db.Output.WriteInt(event_handle.Handle);	// Event ID

						db.Output.Flush();

						Response r = receiveResponse(db_handle);

						if (db.AsyncDB != null)
						{
							db.AsyncDB.Events.Remove(event_handle.LocalID);
						}
					}
					catch (IOException) 
					{
						throw new GDSException(GdsCodes.isc_net_read_err);
					}
				}
			}
		}

		#endregion

		#region ERROR_INFO_METHODS

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:isc_sql_code(System.Int32)"]/*'/>
		public int isc_sqlcode(int errorCode)
		{
			ushort	code;
			/* SQL code -999 (GENERIC_SQLCODE) is generic, meaning "no other sql code
			 * known".  Now scan the status vector, seeing if there is ANY sqlcode
			 * reported.  Make note of the first error in the status vector who's 
			 * SQLCODE is NOT -999, that will be the return code if there is no specific
			 * sqlerr reported. 
			 */
			int	sqlCode = GdsCodes.GENERIC_SQLCODE;	/* error of last resort */
						 
			ushort fac	  = (ushort)SqlCode.GetFacility(errorCode);
			ushort class_ = (ushort)SqlCode.GetClass(errorCode);

			code = (ushort)SqlCode.GetCode(errorCode);

			if ((code < SqlCode.SqlCodes.Length / 2) &&
				(SqlCode.SqlCodes[code] != GdsCodes.GENERIC_SQLCODE))
			{
				sqlCode = SqlCode.SqlCodes[code];				
			}

			return sqlCode;
		}
		
		#endregion

		#region HANDLE_DECLARATION_METHODS

		public isc_db_handle get_new_isc_db_handle() 
		{
			return new isc_db_handle_impl();
		}

		public isc_tr_handle get_new_isc_tr_handle() 
		{
			return new isc_tr_handle_impl();
		}

		public isc_stmt_handle get_new_isc_stmt_handle() 
		{
			return new isc_stmt_handle_impl();
		}

		public isc_blob_handle get_new_isc_blob_handle() 
		{
			return new isc_blob_handle_impl();
		}

		public isc_svc_handle get_new_isc_svc_handle() 
		{
			return new isc_svc_handle_impl();
		}

		#endregion

		#region MISC_METHODS

		/// <include file='xmldoc/gds.xml' path='doc/member[@name="M:connect(FirebirdSql.Data.NGDS.isc_db_handle_impl,FirebirdSql.Data.NGDS.DbAttachInfo)"]/*'/>
		private void connect(isc_db_handle_impl db, AttachInfo attachInfo)
		{
			try 
			{	
				db.AttachInfo = attachInfo;

				db.Connect();
				
				// Here we identify the user to the engine.  This may or may not be used 
				// as login info to a database.				
				string user = Environment.UserName;
				string host = System.Net.Dns.GetHostName();
				
				int n = 0;
				byte[] user_id = new byte[200];
				
				int userLength = Encoding.Default.GetByteCount(user);
				user_id[n++] = 1;		// CNCT_user
				user_id[n++] = (byte)userLength;
				System.Array.Copy(Encoding.Default.GetBytes(user), 0, user_id, n, userLength);
				n += userLength;
				
				int hostLength = Encoding.Default.GetByteCount(host);
				user_id[n++] = 4;		// CNCT_host
				user_id[n++] = (byte)host.Length;
				System.Array.Copy(Encoding.Default.GetBytes(host), 0, user_id, n, hostLength);
				n += hostLength;
	            
				user_id[n++] = 6;		// CNCT_user_verification
				user_id[n++] = 0;

				db.Output.WriteInt(op_connect);
				db.Output.WriteInt(op_attach);
				db.Output.WriteInt(CONNECT_VERSION2);		// CONNECT_VERSION2
				db.Output.WriteInt(1);						// arch_generic

				db.Output.WriteString(attachInfo.FileName);	// p_cnct_file
				db.Output.WriteInt(1);						// p_cnct_count
				db.Output.WriteBuffer(user_id, n);			// p_cnct_user_id
				
				db.Output.WriteInt(PROTOCOL_VERSION10);
				db.Output.WriteInt(1);						// arch_generic
				db.Output.WriteInt(2);						// ptype_rpc
				db.Output.WriteInt(3);						// ptype_batch_send
				db.Output.WriteInt(2);
			
				db.Output.Flush();				
				
				if (readOperation(db) == op_accept) 
				{
					db.ProtocolVersion		= db.Input.ReadInt();
					db.ProtocolArchitecture = db.Input.ReadInt();
					db.Input.ReadInt();
				} 
				else 
				{
					try
					{					
						db.Disconnect();
					}
					catch (Exception)
					{
					}
					finally
					{
						throw new GDSException(GdsCodes.isc_connect_reject);
					}
				}
			} 
			catch (IOException)
			{
				throw new GDSException(GdsCodes.isc_arg_gds, 
									GdsCodes.isc_network_error, 
									attachInfo.Server);
			}
		}

		private object[] receiveSqlResponse(isc_db_handle_impl db, XSQLDA xsqlda)
		{
			try 
			{
				if (readOperation(db) == op_sql_response) 
				{
					int messages = db.Input.ReadInt();
					if (messages > 0) 
					{
						return readSQLData(db, xsqlda);
					}
					else 
					{
						return null;
					}
				} 
				else 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			} 
			catch (IOException ex) 
			{
				// ex.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_net_read_err, ex.Message);
			}
		}

		private byte[] receiveSliceResponse(isc_db_handle_impl db, 
		                                    ISC_ARRAY_DESC desc)
		{
			try 
			{
				int op = readOperation(db);
				if (op == op_slice)
				{
					return db.Input.ReadSlice(desc);
				}
				else
				{
					db.Op = op;
					
					// Receive standard response
					receiveResponse(db);

					return null;
				}
			} 
			catch (IOException ex) 
			{
				// ex.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_net_read_err, ex.Message);
			}
		}

		private Response receiveResponse(isc_inet inet)
		{
			try 
			{
				int op = readOperation(inet);
				if (op == op_response) 
				{
					Response r = new Response();

					r.resp_object 	= inet.Input.ReadInt();
					r.resp_blob_id 	= inet.Input.ReadLong();
					r.resp_data 	= inet.Input.ReadBuffer();

					readStatusVector(inet);
			
					return r;
				} 
				else 
				{
					return null;
				}
			} 
			catch (IOException ex) 
			{
				// ex.getMessage() makes little sense here, it will not be displayed
				// because error message for isc_net_read_err does not accept params
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_net_read_err, ex.Message);
			}
		}

		private int readOperation(isc_inet inet)
		{
			int op = (inet.Op >= 0) ? inet.Op : nextOperation(inet);
			inet.Op = -1;

			return op;
		}

		private int nextOperation(isc_inet inet)
		{
			do 
			{
				/* loop as long as we are receiving dummy packets, just
				 * throwing them away--note that if we are a server we won't
				 * be receiving them, but it is better to check for them at
				 * this level rather than try to catch them in all places where
				 * this routine is called 
				 */
				inet.Op = inet.Input.ReadInt();
			} while (inet.Op == op_dummy);

			return inet.Op;
		}

		private void readStatusVector(isc_inet inet)
		{
			try 
			{
				GDSException exception = new GDSException();

				while (true) 
				{
					int arg = inet.Input.ReadInt();
					switch (arg) 
					{
						case GdsCodes.isc_arg_gds: 
							int er = inet.Input.ReadInt();
							if (er != 0) 
							{
								exception.Errors.Add(arg, er);
							}
							break;

						case GdsCodes.isc_arg_end:
						{		
							if (exception.Errors.Count != 0 && !exception.IsWarning()) 
							{
								exception.BuildExceptionMessage();
								throw exception;
							}
							else
							{
								if (exception.Errors.Count != 0 && exception.IsWarning())
								{
									exception.BuildExceptionMessage();
									inet.ProcessWarning(exception);
								}
							}
						}
						return;
						
						case GdsCodes.isc_arg_interpreted:						
						case GdsCodes.isc_arg_string:
						{
							string arg_value = inet.Input.ReadString();
							exception.Errors.Add(arg, arg_value);
						}
						break;
						
						case GdsCodes.isc_arg_number:
						{
							int arg_value = inet.Input.ReadInt();
							exception.Errors.Add(arg, arg_value);
						}
						break;
						
						default:
						{
							int e = inet.Input.ReadInt();
							if (e != 0) 
							{
								exception.Errors.Add(arg, e);
							}
						}
						break;
					}
				}
			}
			catch (IOException ioe)
			{
				/* ioe.getMessage() makes little sense here, it will not be displayed
				 * because error message for isc_net_read_err does not accept params
				 */
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_net_read_err, ioe.Message);
			}
		}

		private void writeBLR(isc_db_handle_impl db, XSQLDA xsqlda)
		{
			int		blr_len = 0;
			byte[]	blr		= null;

			if (xsqlda != null) 
			{
				// Determine the BLR length
				blr_len = 8;
				int par_count = 0;

				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					int dtype = xsqlda.sqlvar[i].sqltype & ~1;

					switch (dtype)
					{
						case GdsCodes.SQL_VARYING:
						case GdsCodes.SQL_TEXT:
							blr_len += 3;
							break;

						case GdsCodes.SQL_SHORT:
						case GdsCodes.SQL_LONG:
						case GdsCodes.SQL_INT64:
						case GdsCodes.SQL_QUAD:
						case GdsCodes.SQL_BLOB:
						case GdsCodes.SQL_ARRAY:
							blr_len += 2;
							break;

						default:
							blr_len++;
							break;
					}

					blr_len += 2;
					par_count += 2;
				}

				blr = new byte[blr_len];

				int n = 0;
				blr[n++] = GdsCodes.blr_version5;
				blr[n++] = GdsCodes.blr_begin;
				blr[n++] = GdsCodes.blr_message;
				blr[n++] = 0;

				blr[n++] = (byte) (par_count & 255);
				blr[n++] = (byte) (par_count >> 8);

				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					int dtype = xsqlda.sqlvar[i].sqltype & ~1;
					int len = xsqlda.sqlvar[i].sqllen;

					switch (dtype)
					{
						case GdsCodes.SQL_VARYING:
							blr[n++] = GdsCodes.blr_varying;
							blr[n++] = (byte) (len & 255);
							blr[n++] = (byte) (len >> 8);
							break;

						case GdsCodes.SQL_TEXT:
							blr[n++] = GdsCodes.blr_text;
							blr[n++] = (byte) (len & 255);
							blr[n++] = (byte) (len >> 8);
							break;

						case GdsCodes.SQL_DOUBLE:
							blr[n++] = GdsCodes.blr_double;
							break;

						case GdsCodes.SQL_FLOAT:
							blr[n++] = GdsCodes.blr_float;
							break;

						case GdsCodes.SQL_D_FLOAT:
							blr[n++] = GdsCodes.blr_d_float;
							break;

						case GdsCodes.SQL_TYPE_DATE:
							blr[n++] = GdsCodes.blr_sql_date;
							break;

						case GdsCodes.SQL_TYPE_TIME:
							blr[n++] = GdsCodes.blr_sql_time;
							break;

						case GdsCodes.SQL_TIMESTAMP:
							blr[n++] = GdsCodes.blr_timestamp;
							break;

						case GdsCodes.SQL_BLOB:
							blr[n++] = GdsCodes.blr_quad;
							blr[n++] = 0;
							break;

						case GdsCodes.SQL_ARRAY:
							blr[n++] = GdsCodes.blr_quad;
							blr[n++] = 0;
							break;

						case GdsCodes.SQL_LONG:
							blr[n++] = GdsCodes.blr_long;
							blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
							break;

						case GdsCodes.SQL_SHORT:
							blr[n++] = GdsCodes.blr_short;
							blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
							break;

						case GdsCodes.SQL_INT64:
							blr[n++] = GdsCodes.blr_int64;
							blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
							break;

						case GdsCodes.SQL_QUAD:
							blr[n++] = GdsCodes.blr_quad;
							blr[n++] = (byte) xsqlda.sqlvar[i].sqlscale;
							break;
					}

	//                    return error_dsql_804 (gds__dsql_sqlda_value_err);

					blr[n++] = GdsCodes.blr_short;
					blr[n++] = 0;
				}

				blr[n++] = GdsCodes.blr_end;
				blr[n++] = GdsCodes.blr_eoc;
			}

			try 
			{
				db.Output.WriteBuffer(blr, blr_len);
			} 
			catch (IOException) 
			{
				throw new GDSException(GdsCodes.isc_net_write_err);
			}

		}

		private bool isSQLDataOK(XSQLDA xsqlda) 
		{
			if (xsqlda != null) 
			{
				for (int i = 0; i < xsqlda.sqld; i++) 
				{
					if ((xsqlda.sqlvar[i].sqlind != -1) &&
						(xsqlda.sqlvar[i].sqldata == null)) 
					{
						return false;
					}
				}
			}
			return true;
		}

		private void writeSQLData(isc_db_handle_impl db, XSQLDA xsqlda)
		{
			// This only works if not (port->port_flags & PORT_symmetric)
			for (int i = 0; i < xsqlda.sqld; i++) 
			{
				writeSQLDatum(db, xsqlda.sqlvar[i]);
			}
		}

		private void writeSQLDatum(isc_db_handle_impl db, XSQLVAR xsqlvar)
		{				
			fixNull(xsqlvar);

			try 
			{
				object sqldata = xsqlvar.sqldata;

				switch (xsqlvar.sqltype & ~1) 
				{
					case GdsCodes.SQL_TEXT:
						db.Output.WriteOpaque((byte[])sqldata, xsqlvar.sqllen);
						break;

					case GdsCodes.SQL_VARYING:
						db.Output.WriteInt(((byte[])sqldata).Length);
						db.Output.WriteOpaque((byte[])sqldata, ((byte[])sqldata).Length);
						break;
										
					case GdsCodes.SQL_SHORT:
					case GdsCodes.SQL_LONG:						
						db.Output.WriteInt(Convert.ToInt32(sqldata));
						break;
					
					case GdsCodes.SQL_FLOAT:
						db.Output.WriteFloat(Convert.ToSingle(sqldata));
						break;
					
					case GdsCodes.SQL_DOUBLE:
						db.Output.WriteDouble(Convert.ToDouble(sqldata));
						break;
	
					case GdsCodes.SQL_TIMESTAMP:
						db.Output.WriteInt(EncodeDate((System.DateTime) sqldata));
						db.Output.WriteInt(EncodeTime((System.DateTime) sqldata));
						break;
					
					case GdsCodes.SQL_BLOB:
					case GdsCodes.SQL_ARRAY:
					case GdsCodes.SQL_INT64:
					case GdsCodes.SQL_QUAD:
						db.Output.WriteLong(Convert.ToInt64(sqldata));
						break;
					
					case GdsCodes.SQL_TYPE_TIME:
						db.Output.WriteInt(EncodeTime((System.DateTime) sqldata));
						break;
					
					case GdsCodes.SQL_TYPE_DATE:
						db.Output.WriteInt(EncodeDate((System.DateTime) sqldata));
						break;
					
					default:
						throw new GDSException("Unknown sql data type: " + xsqlvar.sqltype);
				}

				db.Output.WriteInt(xsqlvar.sqlind);
			} 
			catch (IOException) 
			{
				throw new GDSException(GdsCodes.isc_net_write_err);
			}
		}

		private void fixNull(XSQLVAR xsqlvar)
		{
			if ((xsqlvar.sqlind == -1) && (xsqlvar.sqldata == null))
			{
				switch (xsqlvar.sqltype & ~1) 
				{
					case GdsCodes.SQL_TEXT:
						xsqlvar.sqldata = new byte[xsqlvar.sqllen];
						break;
					
					case GdsCodes.SQL_VARYING:
						xsqlvar.sqldata = new byte[0];
						break;
					
					case GdsCodes.SQL_SHORT:
						xsqlvar.sqldata = (short) 0;
						break;
					
					case GdsCodes.SQL_LONG:
						xsqlvar.sqldata = (int) 0;
						break;
					
					case GdsCodes.SQL_FLOAT:
						xsqlvar.sqldata = (float) 0;
						break;
					
					case GdsCodes.SQL_DOUBLE:
						xsqlvar.sqldata = (double) 0;
						break;

					case GdsCodes.SQL_TIMESTAMP:
						xsqlvar.sqldata  = new System.DateTime(0 * 10000L + 621355968000000000);
						break;
					
					case GdsCodes.SQL_BLOB:
					case GdsCodes.SQL_ARRAY:
					case GdsCodes.SQL_QUAD:
					case GdsCodes.SQL_INT64:
						xsqlvar.sqldata = (long) 0;
						break;
					
					case GdsCodes.SQL_TYPE_TIME:
						xsqlvar.sqldata = new System.DateTime(0 * 10000L + 621355968000000000);
						break;

					case GdsCodes.SQL_TYPE_DATE:
						xsqlvar.sqldata = new System.DateTime(0 * 10000L + 621355968000000000);
						break;

					default:
						throw new GDSException("Unknown sql data type: " + xsqlvar.sqltype);
				}
			}
		}

		public object EncodeDecimal(System.Decimal d, int scale, int sqltype)
		{
			long multiplier = 1;
			
			if (scale < 0)
			{
				int exp = scale * (-1);
				multiplier = (long)System.Math.Pow(10, exp);
			}
			
			switch (sqltype & ~1)
			{
				case GdsCodes.SQL_SHORT:
					return (short)(d * multiplier);
				
				case GdsCodes.SQL_LONG:
					return (int)(d * multiplier);
				
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					return (long)(d * multiplier);
											
				case GdsCodes.SQL_DOUBLE:
				default:
				{
					return d;
				}
			}
		}

		public System.Decimal DecodeDecimal(object d, int scale, int sqltype)
		{
			long	divisor = 1;
			decimal returnValue;

			if (scale < 0)
			{
				int exp = scale * (-1);
				divisor = (long)System.Math.Pow(10, exp);
			}
			
			switch (sqltype & ~1)
			{
				case GdsCodes.SQL_SHORT:
				case GdsCodes.SQL_LONG:
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					returnValue = Convert.ToDecimal(d) / divisor;
					break;
											
				case GdsCodes.SQL_DOUBLE:
				default:
					returnValue = Convert.ToDecimal(d);
					break;
			}

			return returnValue;
		}

		public int EncodeTime(System.DateTime d) 
		{
			GregorianCalendar calendar = new GregorianCalendar();			

			long millisInDay = calendar.GetHour(d) * 60 * 60 * 1000	+
								calendar.GetMinute(d) * 60 * 1000	+
								calendar.GetSecond(d) * 1000;				
			
			int iTime = (int) (millisInDay * 10);

			return iTime;
		}

		public int EncodeDate(System.DateTime d)
		{			
			int day, month, year;
			int c, ya;

			GregorianCalendar calendar = new GregorianCalendar();

			day		= calendar.GetDayOfMonth(d);
			month	= calendar.GetMonth(d);
			year	= calendar.GetYear(d);

			if (month > 2) 
			{
				month -= 3;
			} 
			else
			{
				month	+= 9;
				year	-= 1;
			}

			c	= year / 100;
			ya	= year - 100 * c;

			return ((146097 * c) / 4		+
					(1461 * ya) / 4			+
					(153 * month + 2) / 5	+
					day + 1721119 - 2400001);
		}

		public System.DateTime DecodeTime(int sql_time) 
		{
			return new System.DateTime((sql_time / 10000) * 1000 * 10000L + 621355968000000000);
		}

		public System.DateTime DecodeDate(int sql_date) 
		{
			int year, month, day, century;

			sql_date	-= 1721119 - 2400001;
			century		= (4 * sql_date - 1) / 146097;
			sql_date	= 4 * sql_date - 1 - 146097 * century;
			day			= sql_date / 4;

			sql_date	= (4 * day + 3) / 1461;
			day			= 4 * day + 3 - 1461 * sql_date;
			day			= (day + 4) / 4;

			month		= (5 * day - 3) / 153;
			day			= 5 * day - 3 - 153 * month;
			day			= (day + 5) / 5;

			year		= 100 * century + sql_date;

			if (month < 10) 
			{
				month += 3;
			} 
			else 
			{
				month	-= 9;
				year	+= 1;
			}

			DateTime date = new System.DateTime(year, month, day);		

			return date.Date;
		}

		/* Now returns results in object[] and in xsqlda.data
		 * Nulls are represented by null values in object array,
		 * but by sqlind = -1 in xsqlda.
		 */
		private object[] readSQLData(isc_db_handle_impl db, XSQLDA xsqlda)
		{
			// This only works if not (port->port_flags & PORT_symmetric)
			object[] row = new object[xsqlda.sqld];
			for (int i = 0; i < xsqlda.sqld; i++) 
			{
				row[i] = readSQLDatum(db, xsqlda.sqlvar[i]);
			}
			return row;
		}

		private object readSQLDatum(isc_db_handle_impl db, XSQLVAR xsqlvar) 
		{
			try 
			{
				switch (xsqlvar.sqltype & ~1) 
				{
					case GdsCodes.SQL_TEXT:
						xsqlvar.sqldata = db.Input.ReadOpaque(xsqlvar.sqllen);
						break;
					
					case GdsCodes.SQL_VARYING:						
						xsqlvar.sqldata = db.Input.ReadOpaque(db.Input.ReadInt());
						break;
					
					case GdsCodes.SQL_SHORT:
						xsqlvar.sqldata = (short)db.Input.ReadInt();
						break;
					
					case GdsCodes.SQL_LONG:
						xsqlvar.sqldata = db.Input.ReadInt();
						break;
					
					case GdsCodes.SQL_FLOAT:
						xsqlvar.sqldata = (float)db.Input.ReadSingle();
						break;
					
					case GdsCodes.SQL_DOUBLE:	
						xsqlvar.sqldata = (double)db.Input.ReadDouble();
						break;
		
					case GdsCodes.SQL_TIMESTAMP:
						DateTime date = DecodeDate(db.Input.ReadInt());
						DateTime time = DecodeTime(db.Input.ReadInt());

						xsqlvar.sqldata = new System.DateTime(
										date.Year, date.Month, date.Day,
										time.Hour,time.Minute, time.Second, time.Millisecond);
						break;
										
					case GdsCodes.SQL_TYPE_TIME:
						xsqlvar.sqldata = DecodeTime(db.Input.ReadInt());
						break;
					
					case GdsCodes.SQL_TYPE_DATE:
						xsqlvar.sqldata = DecodeDate(db.Input.ReadInt());
						break;
					
					case GdsCodes.SQL_BLOB:					
					case GdsCodes.SQL_ARRAY:				
					case GdsCodes.SQL_QUAD:
					case GdsCodes.SQL_INT64:
						xsqlvar.sqldata = db.Input.ReadLong();
						break;
				}

				xsqlvar.sqlind = db.Input.ReadInt();

				if (xsqlvar.sqlind == 0) 
				{
					return xsqlvar.sqldata;
				}
				else if (xsqlvar.sqlind == -1) {
					return null;
				}
				else {
					throw new GDSException("invalid sqlind value: " + xsqlvar.sqlind);
				}
			} 
			catch (IOException) 
			{
				throw new GDSException(GdsCodes.isc_net_read_err);
			}
		}

		private XSQLDA parseSqlInfo(isc_stmt_handle stmt_handle,
									byte[] info,
									byte[] items) 
		{
			XSQLDA xsqlda = new XSQLDA();
			int lastindex = 0;
			while ((lastindex = parseTruncSqlInfo(info, xsqlda, lastindex)) > 0) 
			{
				lastindex--;               // Is this OK ?
				
				byte[] new_items = new byte[4 + items.Length];
				new_items[0] = GdsCodes.isc_info_sql_sqlda_start;
				new_items[1] = 2;
				new_items[2] = (byte) (lastindex & 255);
				new_items[3] = (byte) (lastindex >> 8);

				Array.Copy(items, 0, new_items, 4, items.Length);
				info = isc_dsql_sql_info(stmt_handle, new_items.Length, new_items, info.Length);
			}

			return xsqlda;
		}
	    	    
		private int parseTruncSqlInfo(byte[] info, XSQLDA xsqlda, int lastindex)
		{
			byte item;
			int index = 0;

			int i = 2;

			int len = isc_vax_integer(info, i, 2);
			i += 2;
			int n = isc_vax_integer(info, i, len);
			i += len;
			if (xsqlda.sqlvar == null) 
			{
				xsqlda.sqld = xsqlda.sqln = n;
				xsqlda.sqlvar = new XSQLVAR[xsqlda.sqln];
			}

			while (info[i] != GdsCodes.isc_info_end) 
			{
				while ((item = info[i++]) != GdsCodes.isc_info_sql_describe_end) 
				{
					switch (item) 
					{
						case GdsCodes.isc_info_sql_sqlda_seq:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							index = isc_vax_integer(info, i, len);
							i += len;
							xsqlda.sqlvar[index - 1] = new XSQLVAR();
							break;
						
						case GdsCodes.isc_info_sql_type:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqltype = isc_vax_integer (info, i, len);
							i += len;
							break;

						case GdsCodes.isc_info_sql_sub_type:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqlsubtype = isc_vax_integer (info, i, len);
							i += len;
							break;
						
						case GdsCodes.isc_info_sql_scale:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqlscale = isc_vax_integer (info, i, len);
							i += len;
							break;
						
						case GdsCodes.isc_info_sql_length:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].sqllen = isc_vax_integer (info, i, len);
							i += len;
							break;

						case GdsCodes.isc_info_sql_field:
							len = isc_vax_integer(info, i, 2);
							i += 2;							
							xsqlda.sqlvar[index - 1].sqlname = 
										Encoding.Default.GetString(info,i,len);
							i += len;
							break;							
						
						case GdsCodes.isc_info_sql_relation:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].relname = 
										Encoding.Default.GetString(info,i,len);
							i += len;
							break;
						
						case GdsCodes.isc_info_sql_owner:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].ownname = 
												Encoding.Default.GetString(info,i,len);
							i += len;
							break;

						case GdsCodes.isc_info_sql_alias:
							len = isc_vax_integer(info, i, 2);
							i += 2;
							xsqlda.sqlvar[index - 1].aliasname = 
												Encoding.Default.GetString(info,i,len);
							i += len;
							break;

						case GdsCodes.isc_info_truncated:
							return lastindex;

						default:
							throw new GDSException(GdsCodes.isc_dsql_sqlda_err);
					}
				}
				lastindex = index;
			}
			return 0;
		}

		/*
		//DEBUG
		private void checkAllRead(BinaryReader input)
		{
			try 
			{
				int i = (int)input.PeekChar();
				if (i > 0) 
				{
					// if (log != null) log.Debug("Extra bytes in packet read: " + i);
					byte[] b = new byte[i];					
					input.Read(b, 0, i);					
					for (int j = 0; j < ((b.Length < 16) ? b.Length : 16) ; j++) 
					{
						// 	if (log != null) log.Debug("byte: " + b[j]);
					}
				}
			}
			catch (IOException e) 
			{
				throw new GDSException("IOException in checkAllRead: " + e);
			}
		}
		*/

		private void releaseObject(isc_db_handle_impl db, int op, int id)
		{
			lock (db) 
			{
				try 
				{
					db.Output.WriteInt(op);
					db.Output.WriteInt(id);
					db.Output.Flush();            
					receiveResponse(db);
				}
				catch (IOException) 
				{
					throw new GDSException(GdsCodes.isc_net_read_err);
				}
			}
		}

		#endregion

		#region INNER_CLASSES
			
		internal class Response 
		{
			public int	  resp_object;
			public long	  resp_blob_id;
			public byte[] resp_data;
		}

		#endregion
	}
}
