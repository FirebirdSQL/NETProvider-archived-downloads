//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;
using System.Collections;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	#region ATTACH_INFO_CLASS

	internal class AttachInfo 
	{
		#region FIELDS

		private string		userName;
		private string		userPassword;
		private string		server;
		private int			port;
		private string		fileName;
		private int			packetSize;
		private	byte		dialect;
		private string		charset;
		private string		role;
		private Encoding	encoding;

		#endregion

		#region PROPERTIES

		public string UserName
		{
			get { return userName; }
			set { userName = value; }
		}

		public string UserPassword
		{
			get { return userPassword; }
			set { userPassword = value; }
		}

		public string Server
		{
			get { return server; }
			set { server = value; }
		}

		public int Port
		{
			get { return port; }
			set { port = value; }
		}

		public string FileName
		{
			get { return fileName; }
			set { fileName = value; }
		}

		public int PacketSize
		{
			get { return packetSize; }
			set { packetSize = value; }
		}

		public string Role
		{
			get { return role; }
			set { role = value; }
		}

		public byte Dialect
		{
			get { return dialect; }
			set { dialect = value; }
		}

		public string Charset
		{
			get { return charset; }
			set { charset = value; }
		}

		public Encoding Encoding
		{
			get { return encoding; }
			set { encoding = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public AttachInfo()
		{
			userName	= String.Empty;
			userPassword= String.Empty;
			fileName	= String.Empty;
			role		= String.Empty;		
			charset		= String.Empty;			
			server		= "localhost";
			port		= 3050;
			dialect		= 3;			
			packetSize	= 8192;
			encoding	= Encoding.Default;
		}

		public AttachInfo(string connectInfo) : this()
		{
			if (connectInfo == null) 
			{
				throw new GDSException("Connection string missing");
			}

			/* allows standard syntax //host:port/....
			 * and old fb syntax host/port:....
			 */
			connectInfo = connectInfo.Trim();
			char hostSepChar;
			char portSepChar;
			if (connectInfo.StartsWith("//"))
			{
				connectInfo = connectInfo.Substring(2);
				hostSepChar = '/';
				portSepChar = ':';
			}
			else 
			{
				hostSepChar = ':';
				portSepChar = '/';
			}

			int sep = connectInfo.IndexOf(hostSepChar);
			if (sep == 0 || sep == connectInfo.Length - 1) 
			{
				throw new GDSException("Bad connection string: '"+hostSepChar+"' at beginning or end of:" + connectInfo +  GdsCodes.isc_bad_db_format);
			}
			else if (sep > 0) 
			{
				server = connectInfo.Substring(0, sep);
				fileName = connectInfo.Substring(sep + 1);
				int portSep = server.IndexOf(portSepChar);
				if (portSep == 0 || portSep == server.Length - 1) 
				{
					throw new GDSException("Bad server string: '"+portSepChar+"' at beginning or end of: " + server +  GdsCodes.isc_bad_db_format);
				}
				else if (portSep > 0) 
				{
					port = int.Parse(server.Substring(portSep + 1));							
					server = server.Substring(0, portSep);
				}
			}
			else if (sep == -1) 
			{
				fileName = connectInfo;
			}
		}

		public AttachInfo(string server, int port, string fileName, int packetSize) : this()
		{
			if (fileName == null || fileName.Equals(String.Empty)) 
			{
				throw new GDSException("null filename in DbAttachInfo");
			}
			if (server != null) 
			{
				this.server = server;
			}
			this.fileName	= fileName;
			this.port		= port;
			this.packetSize	= packetSize;
		}

		#endregion
	}

	#endregion

	/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="T:isc_db_handle_impl"]/*'/>
	internal class isc_db_handle_impl : isc_db_handle 
	{
		#region EVENTS

		public event DbWarningMessageEventHandler DbWarningMessage;

		#endregion

		#region FIELDS

		private AttachInfo			attachInfo;
		private Thread				eventThread;
		private bool				invalid;
		private int					rdb_id;
		private ArrayList			rdb_transactions	= new ArrayList();	
		private ArrayList			rdb_sql_requests	= new ArrayList();
		private Socket				socket				= null;
		private NetworkStream		networkStream		= null;
		private XdrOutputStream		output;
		private XdrInputStream		input;
		private int					op					= -1;
		private int					protocolVersion		= 10;
		private int					protocolArchitecture;

		private int					remote_event_id;
		private Hashtable			events;
		private isc_db_handle		asyncDB;
		private bool				asyncReads;

		#endregion

		#region PROPERTIES

		public AttachInfo AttachInfo
		{
			get { return attachInfo; }
			set { attachInfo = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Handle"]/*'/>
		public int Handle
		{
			get
			{
				CheckValidity();
				return rdb_id;
			}
			set
			{
				CheckValidity();
				rdb_id = value;
			}
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:DbSocket"]/*'/>
		public Socket DbSocket
		{
			get { return socket; }
			set { socket = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:DbNetworkStream"]/*'/>
		public NetworkStream DbNetworkStream
		{
			get { return networkStream; }
			set { networkStream = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Output"]/*'/>
		public XdrOutputStream Output
		{
			get { return output; }
			set { output = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Input"]/*'/>
		public XdrInputStream Input
		{
			get { return input; }
			set { input = value; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:Transactions"]/*'/>
		public ArrayList Transactions
		{
			get { return rdb_transactions; }
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="P:IsValid"]/*'/>
		public bool IsValid
		{
			get { return !invalid; }
		}
		
		public ArrayList SqlRequest
		{
			get { return rdb_sql_requests; }
		}

		public int Op
		{
			get { return op; }
			set { op = value; }
		}

		public int ProtocolVersion
		{
			get { return protocolVersion; }
			set { protocolVersion = value; }
		}

		public int ProtocolArchitecture
		{
			get { return protocolArchitecture; }
			set { protocolArchitecture = value; }
		}

		public int RemoteEventId
		{
			get { return remote_event_id; }
			set { remote_event_id = value; }
		}

		public isc_db_handle AsyncDB
		{
			get { return asyncDB; }
			set { asyncDB = value; }
		}
		
		public Hashtable Events
		{
			get { return events; }
			set { events = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public isc_db_handle_impl()
		{
			attachInfo = new AttachInfo();
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:HasTransactions"]/*'/>
		public bool HasTransactions()
		{
			CheckValidity();
			return rdb_transactions.Count == 0 ? false : true;
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:TransactionCount"]/*'/>
		public int TransactionCount()
		{
			CheckValidity();
			return rdb_transactions.Count;
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:AddTransaction(FirebirdSql.Data.NGDS.isc_tr_handle_impl)"]/*'/>
		public void AddTransaction(isc_tr_handle_impl tr)
		{
			CheckValidity();
			rdb_transactions.Add(tr);
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:RemoveTransaction(FirebirdSql.Data.NGDS.isc_tr_handle_impl)"]/*'/>
		public void RemoveTransaction(isc_tr_handle_impl tr)
		{
			CheckValidity();
			rdb_transactions.Remove(tr);
		}
				
		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:CheckValidity"]/*'/>
		private void CheckValidity() 
		{
			if (invalid)
			{
				throw new InvalidOperationException("This database handle is invalid and cannot be used anymore.");
			}
		}

		/// <include file='xmldoc/isc_db_handle_impl.xml' path='doc/member[@name="M:ProcessWarning(FirebirdSql.Data.INGDS.GDSException)"]/*'/>
		public void ProcessWarning(GDSException warning) 
		{
			if (DbWarningMessage != null)
			{
				DbWarningMessage(this, new DbWarningMessageEventArgs(warning));
			}
		}

		public void Connect()
		{
			try 
			{
				IPAddress hostadd = Dns.Resolve(attachInfo.Server).AddressList[0];
				IPEndPoint EPhost = new IPEndPoint(hostadd, attachInfo.Port);

				socket = new Socket(AddressFamily.InterNetwork,
									SocketType.Stream, ProtocolType.IP);

				// Set Receive Buffer size.
				socket.SetSocketOption(SocketOptionLevel.Socket,
					SocketOptionName.ReceiveBuffer, attachInfo.PacketSize);

				// Set Send Buffer size.
				socket.SetSocketOption(SocketOptionLevel.Socket,
					SocketOptionName.SendBuffer, attachInfo.PacketSize);
				
				// Disables the Nagle algorithm for send coalescing.
				socket.SetSocketOption(SocketOptionLevel.Socket,
					SocketOptionName.NoDelay, 1);

				// Make the socket to connect to the Server
				socket.Connect(EPhost);					
				networkStream = new NetworkStream(socket, true);

				// Configure input and output streams
				output = new XdrOutputStream(new BufferedStream(networkStream));
				input  = new XdrInputStream(new BufferedStream(networkStream));				
			} 
			catch (SocketException) 
			{
				string message = "Cannot resolve host " + attachInfo.Server;

				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_network_error, attachInfo.Server);
			}
		}

		public void Disconnect()
		{
			try
			{
				if (asyncDB != null)
				{
					lock (asyncDB)
					{
						asyncDB.StopEventThread();
						asyncDB.Disconnect();
					}
				}

				if (input != null)
				{
					input.Close();
				}
				if (output != null)
				{
					output.Close();
				}
				if (networkStream != null)
				{
					networkStream.Close();
				}
				if (socket != null)
				{
					socket.Close();
				}
			     
				input  = null;
				output = null;
				
				socket		  = null;
				networkStream = null;

				invalid = true;
			}
			catch(IOException ex)
			{
				throw ex;
			}
		}

		public void StartEventThread()
		{
			asyncReads = true;

			eventThread = new Thread(new ThreadStart(eventThreadHandler));
			eventThread.Start();
			eventThread.IsBackground = true;
		}

		public void StopEventThread()
		{
			lock (this)
			{
				if (eventThread != null)
				{
					asyncReads = false;
					if (eventThread.ThreadState == ThreadState.Running)
					{
						eventThread.Abort();						
					}
					eventThread = null;
				}
			}
		}

		private void eventThreadHandler()
		{
			int	eventOP	= -1;

			while (asyncReads)
			{
				try
				{
					eventOP = input.ReadByte();
					lock (this)
					{						
						switch(eventOP)
						{
							case GDS.op_exit:
							case GDS.op_disconnect:
							{
								Disconnect();
							}
							break;

							case GDS.op_event:
							{
								int		rdb_id		= input.ReadInt();							
								byte[]	buffer		= input.ReadBuffer();
								byte[]	ast			= input.ReadBytes(8);
								int		event_id	= input.ReadInt();

								isc_event_handle eventHandle = (isc_event_handle_impl)events[event_id];

								// Notify event request
								if (eventHandle != null)
								{
									eventHandle.NotifyEvent(buffer);
								}
							}
							break;
						}
					}					
				}
				catch (Exception)
				{
					asyncReads = false;
				}
			}
		}

		#endregion
	}
}