//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author: Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Runtime.InteropServices;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/layouts.xml' path='doc/member[@name="T:DoubleLayout"]/*'/>
	[StructLayout(LayoutKind.Explicit)]
	internal sealed class DoubleLayout
	{
		[FieldOffset(0)] public double d;
		[FieldOffset(0)] public int i0;
		[FieldOffset(4)] public int i4;
	}

	/// <include file='xmldoc/layouts.xml' path='doc/member[@name="T:FloatLayout"]/*'/>
	[StructLayout(LayoutKind.Explicit)]
	internal sealed class FloatLayout
	{
		[FieldOffset(0)] public float f;
		[FieldOffset(0)] public int i0;
	}
}
