//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Net;
using System.Collections;
using System.Net.Sockets;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{	
	internal class isc_svc_handle_impl : isc_svc_handle 
	{
		#region FIELDS
		
		private AttachInfo			attachInfo;
		private int 				handle;
		private string 				service;
		private Socket				socket;
		private NetworkStream		networkStream;
		private XdrOutputStream		output;
		private XdrInputStream		input;
		
		private	int 				op;

		#endregion

		#region PROPERTIES

		public AttachInfo AttachInfo
		{
			get { return attachInfo; }
			set { attachInfo = value; }
		}

		public int Handle
		{
			get { return handle; }
			set { handle = value; }			
		}

		public string Service
		{
			get { return service; }
			set { service = value; }
		}

		public XdrOutputStream Output
		{
			get { return output; }
			set { output = value; }
		}

		public XdrInputStream Input
		{
			get { return input; }
			set { input = value; }
		}

		public int Op
		{
			get { return op; }
			set { op = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public isc_svc_handle_impl()
		{
			service		= String.Empty;
			op			= -1;
		}

		#endregion

		#region METHODS
		
		public void Connect()
		{			
			try 
			{
				try 
				{					
					IPAddress	hostadd = Dns.Resolve(attachInfo.Server).AddressList[0];
					IPEndPoint	EPhost	= new IPEndPoint(hostadd, attachInfo.Port);

					// Create a new socket
					socket = new Socket(AddressFamily.InterNetwork,
											SocketType.Stream,
											ProtocolType.IP);
				
					// Disables the Nagle algorithm for send coalescing.
					socket.SetSocketOption(SocketOptionLevel.Socket,
						SocketOptionName.NoDelay,
						1);
	
					// Make the socket to connect to the Server
					socket.Connect(EPhost);
					networkStream = new NetworkStream(socket, true);
				} 
				catch (SocketException)
				{
					string message = "Cannot resolve host " + attachInfo.Server;
					throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_network_error, attachInfo.Server);
				}

				output = new XdrOutputStream(new BufferedStream(networkStream));
				input  = new XdrInputStream(new BufferedStream(networkStream));				
			} 
			catch (IOException) 
			{
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_network_error, attachInfo.Server);
			}
		}
		
		public void Disconnect()
		{
			try
			{
				if (input != null)
				{
					input.Close();
					input = null;
				}
				if (output != null)
				{
					output.Close();
					output = null;
				}
				if (networkStream != null)
				{					
					networkStream.Close();
					networkStream = null;
				}
				if (socket != null)
				{
					socket.Close();
					socket = null;
				}			     				
			}
			catch(IOException ioe)
			{
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_net_read_err, ioe.Message);
			}			
		}

		public void ProcessWarning(GDSException warning) 
		{
		}
		
		#endregion
	}
}
