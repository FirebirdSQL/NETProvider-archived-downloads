//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using FirebirdSql.Data.INGDS;

using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.NGDS
{	
	/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="T:isc_stmt_handle_impl"]/*'/>
	internal class isc_stmt_handle_impl : isc_stmt_handle
	{
		#region FIELDS

		private int					rsr_id;
		private isc_db_handle_impl	rsr_rdb;
		private XSQLDA				in_sqlda;
		private XSQLDA				out_sqlda;
		private ArrayList			rows;
		private bool				allRowsFetched;
		private bool				isSingletonResult;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:Handle"]/*'/>
		public int Handle
		{
			get { return rsr_id; }
			set { rsr_id = value; }
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:AllRowsFetched"]/*'/>
		public bool AllRowsFetched
		{
			get { return allRowsFetched; }
			set { allRowsFetched = value; }
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:IsSingletonResult"]/*'/>
		public bool IsSingletonResult
		{
			get { return isSingletonResult; }
			set { isSingletonResult = value; }
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:DbHandle"]/*'/>
		public isc_db_handle_impl DbHandle
		{
			get { return rsr_rdb; }
			set
			{
				this.rsr_rdb = (isc_db_handle_impl)value;
			}
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="T:InSqlda"]/*'/>
		public XSQLDA InSqlda
		{
			get { return in_sqlda; }
			set { in_sqlda = value; }
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:OutSqlda"]/*'/>
		public XSQLDA OutSqlda
		{
			get { return out_sqlda; }
			set { out_sqlda = value; }
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:Rows"]/*'/>
		public ArrayList Rows
		{
			get { return rows; }
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="M:ClearRows"]/*'/>
		public void ClearRows() 
		{
			rows.Clear();
			allRowsFetched = false;
		}

		#endregion

		#region CONSTRUCTORS

		public isc_stmt_handle_impl()
		{
			rows				= new ArrayList();
			allRowsFetched		= false;
			isSingletonResult	= false;
		}

		#endregion
	}
}
