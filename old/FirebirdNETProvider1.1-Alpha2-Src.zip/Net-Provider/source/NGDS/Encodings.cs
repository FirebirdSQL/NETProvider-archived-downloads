//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	internal class FbCharset
	{
		#region FIELDS

		private string 	fbName;
		private string 	dnName;
		private int		fbId;

		#endregion

		#region PROPERTIES

		public string FbName
		{
			get { return fbName; }
		}
		
		public string DnName
		{
			get { return dnName; }
		}
		
		public int FbId
		{
			get { return fbId; }
		}

		#endregion
		
		#region CONSTRUCTORS

		public FbCharset(string fbName, string dnName, int fbId)
		{
			this.fbName = fbName;
			this.dnName = dnName;
			this.fbId	= fbId;			
		}

		#endregion
	}
	
	/// <include file='xmldoc/encodings.xml' path='doc/member[@name="T:Encodings"]/*'/>
	internal class Encodings
	{	
		#region FIELDS
		
		private static bool 		initialized		= false;
		private static ArrayList 	fbCharacterSets = new ArrayList();

		#endregion		
			
		#region METHODS

		/// <include file='xmldoc/encodings.xml' path='doc/member[@name="M:Init"]/*'/>
		private static void Init()
		{			
			fbCharacterSets.Add(new FbCharset("NONE"		, "default"	, GdsCodes.CS_NONE));
			// American Standard Code for Information Interchange	
			fbCharacterSets.Add(new FbCharset("ASCII"		, "ascii"	, GdsCodes.CS_ASCII));
			// Eight-bit Unicode Transformation Format
			fbCharacterSets.Add(new FbCharset("UNICODE_FSS"	, "UTF-8"	, GdsCodes.CS_UNICODE_FSS));
			// Shift-JIS, Japanese
			fbCharacterSets.Add(new FbCharset("SJIS_0208"	, "shift_jis", GdsCodes.CS_SJIS));
			// Windows Japanese	
			fbCharacterSets.Add(new FbCharset("ISO2022-JP"	, "iso-2022-jp", GdsCodes.CS_JIS_0208));			
			// JIS X 0201, 0208, 0212, EUC encoding, Japanese
			fbCharacterSets.Add(new FbCharset("EUCJ_0208"	, "euc-jp"	, GdsCodes.CS_EUCJ));
			// MS-DOS United States, Australia, New Zealand, South Africa	
			fbCharacterSets.Add(new FbCharset("DOS437"		, "IBM437"	, GdsCodes.CS_DOS_437));
			// MS-DOS Latin-1				
			fbCharacterSets.Add(new FbCharset("DOS850"		, "ibm850"	, GdsCodes.CS_DOS_850));
			// MS-DOS Nordic	
			fbCharacterSets.Add(new FbCharset("DOS865"		, "IBM865"	, GdsCodes.CS_DOS_865));
			// MS-DOS Portuguese	
			fbCharacterSets.Add(new FbCharset("DOS860"		, "IBM860"	, GdsCodes.CS_DOS_860));
			// MS-DOS Canadian French	
			fbCharacterSets.Add(new FbCharset("DOS863"		, "IBM863"	, GdsCodes.CS_DOS_863));
			// ISO 8859-1, Latin alphabet No. 1
			fbCharacterSets.Add(new FbCharset("ISO8859_1"	, "iso-8859-1", GdsCodes.CS_ISO8859_1));
			// ISO 8859-2, Latin alphabet No. 2
			fbCharacterSets.Add(new FbCharset("ISO8859_2"	, "iso-8859-2", GdsCodes.CS_ISO8859_2));		
			// Windows Korean	
			fbCharacterSets.Add(new FbCharset("KSC_5601"	, "ks_c_5601-1987", GdsCodes.CS_KSC5601));
			// MS-DOS Icelandic	
			fbCharacterSets.Add(new FbCharset("DOS861"		, "ibm861"	, GdsCodes.CS_DOS_861));
			// Windows Eastern European
			fbCharacterSets.Add(new FbCharset("WIN1250"		, "windows-1250", GdsCodes.CS_WIN1250));
			// Windows Cyrillic
			fbCharacterSets.Add(new FbCharset("WIN1251"		, "windows-1251", GdsCodes.CS_WIN1251));
			// Windows Latin-1
			fbCharacterSets.Add(new FbCharset("WIN1252"		, "windows-1252", GdsCodes.CS_WIN1252));
			// Windows Greek
			fbCharacterSets.Add(new FbCharset("WIN1253"		, "windows-1253", GdsCodes.CS_WIN1253));
			// Windows Turkish
			fbCharacterSets.Add(new FbCharset("WIN1254"		, "windows-1254", GdsCodes.CS_WIN1254));
			// Big5, Traditional Chinese
			fbCharacterSets.Add(new FbCharset("BIG_5"		, "big5"	, GdsCodes.CS_BIG5));
			// GB2312, EUC encoding, Simplified Chinese	
			fbCharacterSets.Add(new FbCharset("GB_2312"		, "gb2312"	, GdsCodes.CS_GB2312));
			// Windows Hebrew
			fbCharacterSets.Add(new FbCharset("WIN1255"		, "windows-1255", GdsCodes.CS_WIN1255));
			// Windows Arabic	
			fbCharacterSets.Add(new FbCharset("WIN1256"		, "windows-1256", GdsCodes.CS_WIN1256));
			// Windows Baltic	
			fbCharacterSets.Add(new FbCharset("WIN1257"		, "windows-1257", GdsCodes.CS_WIN1257));			
		}

		/// <include file='xmldoc/encodings.xml' path='doc/member[@name="M:GetEncodingFormFbName(System.String)"]/*'/>
		public static FbCharset GetFromFbName(string fbCharset)
		{			
			if (!initialized) 
			{
				Init();
			}
			
			fbCharset = fbCharset.ToUpper();
			
			foreach(FbCharset charset in fbCharacterSets)
			{
				if (charset.FbName == fbCharset)
				{
					return charset;
				}
			}
			
			return (FbCharset)fbCharacterSets[0];
		}

		/// <include file='xmldoc/encodings.xml' path='doc/member[@name="M:GetEncodingFormFbName(System.String)"]/*'/>
		public static FbCharset GetFromFbId(int fbId)
		{			
			if (!initialized) 
			{
				Init();
			}
						
			foreach(FbCharset charset in fbCharacterSets)
			{
				if (charset.FbId == fbId)
				{
					return charset;
				}
			}
			
			return (FbCharset)fbCharacterSets[0];
		}

		#endregion
	}
}
