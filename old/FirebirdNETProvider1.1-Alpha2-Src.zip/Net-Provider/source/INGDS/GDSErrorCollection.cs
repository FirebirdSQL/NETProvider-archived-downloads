//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="T:GDSErrorCollection"]/*'/>
	internal sealed class GDSErrorCollection : ArrayList
	{
		#region PROPERTIES

		/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="P:Item(System.String)"]/*'/>
		public GDSError this[string errorMessage] 
		{
			get { return (GDSError)this[IndexOf(errorMessage)]; }
			set { this[IndexOf(errorMessage)] = (GDSError)value; }
		}

		/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="P:Item(System.Int32)"]/*'/>
		public new GDSError this[int errorIndex] 
		{
			get { return (GDSError)base[errorIndex]; }
			set { base[errorIndex] = (GDSError)value; }
		}

		#endregion

		#region METHODS
	
		/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="M:Contains(System.String)"]/*'/>
		public bool Contains(string errorMessage)
		{
			return(-1 != IndexOf(errorMessage));
		}
		
		/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="M:IndexOf(System.String)"]/*'/>
		public int IndexOf(string errorMessage)
		{
			int index = 0;
			foreach(GDSError item in this)
			{
				if (0 == _cultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="M:RemoveAt(System.String)"]/*'/>
		public void RemoveAt(string errorMessage)
		{
			RemoveAt(IndexOf(errorMessage));
		}

		/// <include file='xmldoc/gdserrorcollection.xml' path='doc/member[@name="M:Add(FirebirdSql.Data.INGDS.GDSError)"]/*'/>
		internal GDSError Add(GDSError error)
		{
			base.Add(error);

			return error;
		}
		
		internal GDSError Add(int errorCode)
		{
			GDSError error = new GDSError(errorCode);			

			return Add(error);
		}

		internal GDSError Add(string message)
		{
			GDSError error = new GDSError(message);			

			return Add(error);
		}

		internal GDSError Add(int type, string strParam)
		{
			GDSError error = new GDSError(type, strParam);			

			return Add(error);
		}

		internal GDSError Add(int type, int errorCode)
		{
			GDSError error = new GDSError(type, errorCode);			

			return Add(error);
		}

		internal GDSError Add(int type, int errorCode, string strParam)
		{
			GDSError error = new GDSError(type, errorCode, strParam);

			return Add(error);
		}

		private int _cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB, CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | CompareOptions.IgnoreCase);
		}

		#endregion
	}
}
