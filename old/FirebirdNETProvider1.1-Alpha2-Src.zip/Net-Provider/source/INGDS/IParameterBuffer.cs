//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author: Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Runtime.Serialization;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="T:IParameterBuffer"]/*'/>
	internal interface IParameterBuffer
	{
		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:Length"]/*'/>
		int Length
		{
			get;
		}
		
		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:Append(System.Int32)"]/*'/>
		void Append(int type);		

		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:Append(System.Int32,System.Byte)"]/*'/>
		void Append(int type, byte content);

		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:Append(System.Int32,System.Int16)"]/*'/>
		void Append(int type, short content);

		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:Append(System.Int32,System.Int32)"]/*'/>
		void Append(int type, int content);

		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:Append(System.Int32,System.Array)"]/*'/>		
		void Append(int type, byte[] content);

		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:AppendSpb(System.Int32,System.Array)"]/*'/>		
		void AppendSpb(int type, byte[] content);
		
		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:AppendSpb(System.Int32,System.Byte)"]/*'/>		
		void AppendSpb(int type, byte content);
		
		/// <include file='xmldoc/iparameterbuffer.xml' path='doc/member[@name="P:AppendSpb(System.Int32,System.Int32)"]/*'/>		
		void AppendSpb(int type, int content);		

		void AppendEpb(byte[] content);		

		byte[] GetContents();
		
		void Close();
	}
}
