//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author: Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.INGDS
{
	internal class EventRequestEventArgs : EventArgs
	{
		private byte[] resultBuffer;
 
		public byte[] ResultBuffer
		{
			get { return resultBuffer; } 
			set { resultBuffer = value; } 
		}

		public EventRequestEventArgs(byte[] resultBuffer)
		{
			this.resultBuffer = resultBuffer;
		}
	}

	internal delegate void EventRequestEventHandler(object sender, EventRequestEventArgs e);

	internal interface isc_event_handle
	{
		event EventRequestEventHandler OnEventRequest;

		int Handle
		{
			get;
			set;
		}

		int LocalID
		{
			get;
			set;
		}

		void NotifyEvent(byte[] resultBuffer);
	}
}
