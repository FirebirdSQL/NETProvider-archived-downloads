//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird.Services
{
	/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="T:FbStatisticalFlags"]/*'/>
    [Flags] 
    public enum FbStatisticalFlags
    {
    	/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:FbStatisticalFlags.DataPages"]/*'/>
		DataPages				= 0x01,
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:FbStatisticalFlags.DatabaseLog"]/*'/>
		DatabaseLog				= 0x02,
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:FbStatisticalFlags.HeaderPages"]/*'/>
		HeaderPages				= 0x04,
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:FbStatisticalFlags.IndexPages"]/*'/>
		IndexPages				= 0x08,
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:FbStatisticalFlags.SystemTablesRelations"]/*'/>
		SystemTablesRelations	= 0x10,
    }
	
	/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="T:FbStatistical"]/*'/>
	public sealed class FbStatistical : FbService
	{
		#region FIELDS
		
		private string 				database;
		private FbStatisticalFlags 	options;
		
		#endregion
		
		#region PROPERTIES
		
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get { return database; }
			set { database = value; }
		}
		
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="P:Options"]/*'/>
		public FbStatisticalFlags Options
		{
			get { return options; }
			set { options = value; }
		}
				
		#endregion
		
		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbStatistical() : base()
		{
			database = String.Empty;
		}		
		
		#endregion

		#region METHODS
		
		/// <include file='xmldoc/fbstatistical.xml' path='doc/member[@name="M:Start"]/*'/>
		public void Start()
		{		
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_db_stats);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_options, (int)options);
			
			// Start execution
			startTask();
			
			// Reset ParameterBlock
			startSpb.Reset();			
		}
		
		#endregion		
	}
}
