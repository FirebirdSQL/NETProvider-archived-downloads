//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird.Services
{	   	
    /// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="T:FbSecurity"]/*'/>
	public sealed class FbSecurity : FbService
	{				
		#region PROPERTIES
		
		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="P:UsersDbPath"]/*'/>
		public string UsersDbPath
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_user_dbpath});
				System.Collections.ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}			
		}
		
		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbSecurity() : base()
		{
		}
		
		#endregion
		
		
		#region METHODS

		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="M:AddUser(FirebirdSql.Data.Firebird.Services.UserData)"]/*'/>
		public void AddUser(FbUserData user)
		{
			if (user.UserName.Length == 0)
			{
				throw new InvalidOperationException("Invalid user name.");
			}
			if (user.UserPassword.Length == 0)
			{
				throw new InvalidOperationException("Invalid user password.");
			}
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_add_user);
						
			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_username, user.UserName);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_password, user.UserPassword);
			if (user.FirstName != null && user.FirstName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_firstname, user.FirstName);
			}
			if (user.MiddleName != null && user.MiddleName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_middlename, user.MiddleName);
			}
			if (user.LastName != null && user.LastName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_lastname, user.LastName);
			}
			if (user.UserID != 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_userid, user.UserID);
			}			
			if (user.GroupID != 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_groupid, user.GroupID);
			}
			if (user.GroupName != null && user.GroupName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_groupname, user.GroupName);
			}
			if (user.RoleName != null && user.RoleName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sql_role_name, user.RoleName);
			}
			
			// Start execution
			startTask();
			
			// Reset ParameterBlock
			startSpb.Reset();
			
			Close();
		}
		
		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="M:DeleteUser(FirebirdSql.Data.Firebird.Services.UserData)"]/*'/>
		public void DeleteUser(FbUserData user)
		{
			if (user.UserName.Length == 0)
			{
				throw new InvalidOperationException("Invalid user name.");
			}
			
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_delete_user);

			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_username, user.UserName);
			if (user.RoleName != null && user.RoleName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sql_role_name, user.RoleName);
			}
			
			// Start execution
			startTask();
			
			// Reset ParameterBlock
			startSpb.Reset();
			
			Close();			
		}
		
		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="M:ModifyUser(FirebirdSql.Data.Firebird.Services.UserData)"]/*'/>
		public void ModifyUser(FbUserData user)
		{
			if (user.UserName.Length == 0)
			{
				throw new InvalidOperationException("Invalid user name.");
			}
			if (user.UserPassword.Length == 0)
			{
				throw new InvalidOperationException("Invalid user password.");
			}

			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_modify_user);

			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_username, user.UserName);
			if (user.UserPassword.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_password, user.UserPassword);
			}
			if (user.FirstName != null)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_firstname, user.FirstName);
			}
			if (user.MiddleName != null)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_middlename, user.MiddleName);
			}
			if (user.LastName != null)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_lastname, user.LastName);
			}
			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_userid, user.UserID);				
			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_groupid, user.GroupID);
			if (user.GroupName != null && user.GroupName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_groupname, user.GroupName);
			}
			if (user.RoleName != null && user.RoleName.Length > 0)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_sql_role_name, user.RoleName);
			}
			
			// Start execution
			startTask();
			
			// Reset ParameterBlock
			startSpb.Reset();
			
			Close();			
		}

		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="M:DisplayUsers"]/*'/>
		public FbUserData DisplayUser(string userName)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_display_user);			
			startSpb.SetSpbProperty(GdsCodes.isc_spb_sec_username, userName);
						
			// Start execution
			startTask();

			byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_users});
			System.Collections.ArrayList info = base.parseQueryInfo(buffer);

			// Reset ParameterBlock
			startSpb.Reset();
			
			Close();
		
			FbUserData userData = (FbUserData)info[0];
			
			return userData;
		}

		/// <include file='xmldoc/fbsecurity.xml' path='doc/member[@name="M:DisplayUsers"]/*'/>
		public FbUserData[] DisplayUsers()
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_display_user);			
						
			// Start execution
			startTask();

			byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_users});
			System.Collections.ArrayList info = base.parseQueryInfo(buffer);

			// Reset ParameterBlock
			startSpb.Reset();
			
			Close();
		
			return (FbUserData[])info[0];
		}
		
		#endregion
	}
}
