//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird.Services
{	
    /// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="T:FbShutdownMode"]/*'/>	
	public enum FbShutdownMode
	{
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:FbShutdownMode.Forced"]/*'/>	
		Forced,
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:FbShutdownMode.DenyTransaction"]/*'/>	
		DenyTransaction,
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:FbShutdownMode.DenyConnection"]/*'/>	
		DenyConnection
	}
	
    /// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="T:FbConfiguration"]/*'/>
	public sealed class FbConfiguration : FbService
	{
		#region FIELDS
		
		private string 					database;
		
		#endregion
		
		#region PROPERTIES
		
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get { return database; }
			set { database = value; }
		}
			
		#endregion
		
		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbConfiguration() : base()
		{
			database = String.Empty;
		}
		
		#endregion
		
		#region METHODS
				
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:SetSqlDialect(System.Int32)"]/*'/>
		public void SetSqlDialect(int sqlDialect)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_set_sql_dialect, sqlDialect);

			// Start execution
			startTask();
			
			// Reset parameter block
			startSpb.Reset();			
			
			Close();
		}

		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:SetSweepInterval(System.Int32)"]/*'/>
		public void SetSweepInterval(int sweepInterval)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_sweep_interval, sweepInterval);

			// Start execution
			startTask();
			
			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}

		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:SetPageBuffers(System.Int32)"]/*'/>
		public void SetPageBuffers(int pageBuffers)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_page_buffers, pageBuffers);

			// Start execution
			startTask();
									
			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}
		
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:DatabaseShutdown(FbShutdownMode, System.Int32)"]/*'/>
		public void DatabaseShutdown(FbShutdownMode mode, int seconds)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);

			switch (mode)
			{
				case FbShutdownMode.Forced:
					startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_shutdown_db, seconds);
					break;
				
				case FbShutdownMode.DenyTransaction:
					startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_deny_new_transactions, seconds);	
					break;

				case FbShutdownMode.DenyConnection:
					startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_deny_new_attachments, seconds);
					break;
			}

			// Start execution
			startTask();

			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}
		
		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:DatabaseOnline"]/*'/>
		public void DatabaseOnline()
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_options, GdsCodes.isc_spb_prp_db_online);

			// Start execution
			startTask();

			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}

		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:ActivateShadows"]/*'/>
		public void ActivateShadows()
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_options, GdsCodes.isc_spb_prp_activate);

			// Start execution
			startTask();

			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}

		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:SetForcedWrites(System.Boolean)"]/*'/>
		public void SetForcedWrites(bool forcedWrites)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);

			// WriteMode
			if (forcedWrites)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_write_mode, 
				                     (byte)GdsCodes.isc_spb_prp_wm_sync);
			}
			else
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_write_mode, 
				                     (byte)GdsCodes.isc_spb_prp_wm_async);
			}			

			// Start execution
			startTask();

			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}

		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:SetReserveSpace(System.Boolean)"]/*'/>
		public void SetReserveSpace(bool reserveSpace)
		{
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);

			// Reserve Space
			if (reserveSpace)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_reserve_space, 
				                     (byte)GdsCodes.isc_spb_prp_res);
			}
			else
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_reserve_space, 
				                     (byte)GdsCodes.isc_spb_prp_res_use_full);
			}

			// Start execution
			startTask();			

			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}

		/// <include file='xmldoc/fbconfiguration.xml' path='doc/member[@name="M:SetAccessMode(System.Booelan)"]/*'/>
		public void SetAccessMode(bool readOnly)
		{
			// Configure Spb
			startSpb = new FbParameterBlock();

			startSpb.SetProperty(GdsCodes.isc_action_svc_properties);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			
			if (readOnly)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_access_mode, 
				                     (byte)GdsCodes.isc_spb_prp_am_readonly);
			}
			else
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_prp_access_mode, 
				                     (byte)GdsCodes.isc_spb_prp_am_readwrite);
			}
			
			// Start execution
			startTask();

			// Reset parameter block
			startSpb.Reset();
			
			Close();
		}
		
		#endregion
	}
}
