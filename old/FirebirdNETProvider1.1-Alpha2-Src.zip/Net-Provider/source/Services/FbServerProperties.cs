//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird.Services
{
	/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="T:FbServerProperties"]/*'/>
	public sealed class FbServerProperties : FbService
	{
		#region PROPERTIES

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:Version"]/*'/>
		public int Version
		{
			get
			{
				byte[] buffer	= queryService(new byte[] {GdsCodes.isc_info_svc_version});
				ArrayList info	= base.parseQueryInfo(buffer);
						
				return info.Count != 0 ? (int)info[0] : 0;
			}
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:ServerVersion"]/*'/>
		public string ServerVersion
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_server_version});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:Implementation"]/*'/>
		public string Implementation
		{
			get
			{
				byte[] buffer	= queryService(new byte[] {GdsCodes.isc_info_svc_implementation});
				ArrayList info	= base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:RootDirectory"]/*'/>
		public string RootDirectory
		{			
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_env});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:LockManager"]/*'/>
		public string LockManager
		{			
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_env_lock});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:MessageFile"]/*'/>
		public string MessageFile
		{			
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_env_msg});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:DatabasesInfo"]/*'/>
		public FbDatabasesInfo DatabasesInfo
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_svr_db_info});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (FbDatabasesInfo)info[0] : new FbDatabasesInfo();
			}			
		}

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="P:ServerConfig"]/*'/>
		public FbServerConfig ServerConfig
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_config});			
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (FbServerConfig)info[0] : new FbServerConfig();
			}
		}

		/*		
		public int LicenseMask
		{			
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_license_mask});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (int)info[0] : 0;
			}
		}

		public int LicensedUsers
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_licensed_users});
				ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (int)info[0] : 0;
			}
		}
		*/
									
		#endregion
		
		#region CONSTRUCTORS

		/// <include file='xmldoc/fbserverproperties.xml' path='doc/member[@name="M:#ctor"]/*'/>		
		public FbServerProperties() : base()
		{
		}
		
		#endregion		
	}
}
