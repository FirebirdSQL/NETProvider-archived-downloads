//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbparameterblock.xml' path='doc/member[@name="T:FbParameterBlock"]/*'/>
	internal class FbParameterBlock
	{
		#region FIELDS

		private ParameterBuffer buffer;

		#endregion

		#region PROPERTIES

		public IParameterBuffer Dpb
		{
			get { return buffer; }
		}

		#endregion

		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbparameterblock.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbParameterBlock() 
		{
			buffer = new ParameterBuffer();
		}

		#endregion

		#region METHODS

		public void SetProperty(int type, string content) 
		{
			buffer.Append(type, Encoding.Default.GetBytes(content));
		}

		public void SetProperty(int type) 
		{
			buffer.Append(type);
		}

		public void SetProperty(int type, byte content) 
		{
			buffer.Append(type, content);
		}

		public void SetProperty(int type, int content) 
		{
			buffer.Append(type, content);
		}

		public void SetProperty(int type, short content) 
		{
			buffer.Append(type, content);
		}

		public void SetProperty(int type, byte[] content)
		{
			buffer.Append(type, content);
		}

		public void SetSpbProperty(int type, string content) 
		{
			buffer.AppendSpb(type, Encoding.Default.GetBytes(content));
		}

		public void SetSpbProperty(int type, byte content) 
		{
			buffer.AppendSpb(type, content);
		}

		public void SetSpbProperty(int type, int content) 
		{
			buffer.AppendSpb(type, content);
		}

		public void SetEpbProperty(string content) 
		{			
			buffer.AppendEpb(Encoding.Default.GetBytes(content.Trim()));
		}
		
		public void Reset()
		{
			buffer.Close();
			
			buffer = new ParameterBuffer();			
		}
		
		#endregion
	}
}
