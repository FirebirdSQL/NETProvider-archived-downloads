//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;
using System.Data;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="T:FbDatabseInfo"]/*'/>
	public class FbDatabaseInfo
	{
		#region FIELDS

		private FbConnection connection;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:Connection"]/*'/>
		public FbConnection Connection
		{
			get { return connection; }
			set { connection = value;}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:IscVersion"]/*'/>
		public string IscVersion
		{
			get 
			{ 
				return (string)getItemInfo(GdsCodes.isc_info_isc_version);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ServerVersion"]/*'/>
		public string ServerVersion
		{
			get 
			{ 
				return (string)getItemInfo(GdsCodes.isc_info_firebird_version);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ServerClass"]/*'/>
		public string ServerClass
		{
			get 
			{
				return (string)getItemInfo(GdsCodes.isc_info_db_class);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:PageSize"]/*'/>
		public int PageSize
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_page_size);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:AllocationPages"]/*'/>
		public int AllocationPages
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_allocation);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:BaseLevel"]/*'/>
		public string BaseLevel
		{
			get
			{
				return (string)getItemInfo(GdsCodes.isc_info_base_level);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:DbId"]/*'/>
		public string DbId
		{
			get
			{
				return (string)getItemInfo(GdsCodes.isc_info_db_id);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:Implementation"]/*'/>
		public string Implementation
		{
			get
			{
				return (string)getItemInfo(GdsCodes.isc_info_implementation);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:NoReserve"]/*'/>
		public bool NoReserve
		{
			get
			{
				return (bool)getItemInfo(GdsCodes.isc_info_no_reserve);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:OdsVersion"]/*'/>
		public int OdsVersion
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_ods_version);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:OdsMinorVersion"]/*'/>
		public int OdsMinorVersion
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_ods_minor_version);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:MaxMemory"]/*'/>
		public int MaxMemory
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_max_memory);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:CurrentMemory"]/*'/>
		public int CurrentMemory
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_current_memory);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ForcedWrites"]/*'/>
		public bool ForcedWrites
		{
			get
			{
				return (bool)getItemInfo(GdsCodes.isc_info_forced_writes);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:NumBuffers"]/*'/>
		public int NumBuffers
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_num_buffers);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:SweepInterval"]/*'/>
		public int SweepInterval
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_sweep_interval);
			}			
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ReadOnly"]/*'/>
		public bool ReadOnly
		{
			get
			{				
				return (bool)getItemInfo(GdsCodes.isc_info_db_read_only);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:Fetches"]/*'/>
		public int Fetches
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_fetches);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:Marks"]/*'/>
		public int Marks
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_marks);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:Reads"]/*'/>
		public int Reads
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_reads);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:Writes"]/*'/>
		public int Writes
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_writes);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:BackoutCount"]/*'/>
		public int BackoutCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_backout_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:DeleteCount"]/*'/>
		public int DeleteCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_delete_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ExpungeCount"]/*'/>
		public int ExpungeCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_expunge_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:InsertCount"]/*'/>
		public int InsertCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_insert_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:PurgeCount"]/*'/>
		public int PurgeCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_purge_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ReadIdxCount"]/*'/>
		public int ReadIdxCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_read_idx_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ReadSeqCount"]/*'/>
		public int ReadSeqCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_read_seq_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ReadSeqCount"]/*'/>
		public int UpdateCount
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_update_count);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:DatabaseSizeInPages"]/*'/>
		public int DatabaseSizeInPages
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_db_size_in_pages);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:OldestTransaction"]/*'/>
		public int OldestTransaction
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_oldest_transaction);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:OldestActiveTransaction"]/*'/>
		public int OldestActiveTransaction
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_oldest_active);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:OldestActiveSnapshot"]/*'/>
		public int OldestActiveSnapshot
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_oldest_snapshot);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:NextTransaction"]/*'/>
		public int NextTransaction
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_next_transaction);
			}
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="P:ActiveTransactions"]/*'/>
		public int ActiveTransactions
		{
			get
			{
				return (int)getItemInfo(GdsCodes.isc_info_active_transactions);
			}
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="M:#ctor"]/*'/>	
		public FbDatabaseInfo()
		{
		}

		/// <include file='xmldoc/fbdatabaseinfo.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection)"]/*'/>	
		public FbDatabaseInfo(FbConnection connection)
		{
			this.connection	= connection;
		}

		#endregion

		#region METHODS
		
		private object getItemInfo(byte itemNumber)
		{			
			IGDS gds = connection.IscConnection.GDS;
			
			// Response buffer
			byte[] buffer = new byte[1024];
	
			// Database info
			byte[] databaseInfo  = new byte[]
			{
				itemNumber,
				GdsCodes.isc_info_end
			};
			
			checkConnection();			

			gds.isc_database_info(
				connection.IscConnection.db		,
				databaseInfo.Length				,
				databaseInfo					,
				buffer.Length					,
				buffer);

			int pos 	= 0;
			int length	= 0;
			int type	= 0;
			while ((type = buffer[pos++]) != GdsCodes.isc_info_end)
			{
				length 	= gds.isc_vax_integer(buffer, pos, 2);
				pos 	+= 2;
				switch (type) 
				{
					//
					// Database characteristics
					//

					case GdsCodes.isc_info_allocation:
						// Number of database pages allocated
						return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_base_level:
						/* Database version (level) number:
						 *  		1 byte containing the number 1
						 *  		1 byte containing the version number
						 */
						return buffer[pos].ToString() + "." + buffer[pos + 1].ToString();

					case GdsCodes.isc_info_db_id:
					{
						/* Database file name and site name:
						 *  	• 1 byte containing the number 2
						 *  	• 1 byte containing the length, d, of the database file name in bytes
						 *  	• A string of d bytes, containing the database file name
						 *  	• 1 byte containing the length, l, of the site name in bytes
						 *  	• A string of l bytes, containing the site name
						 */
						string dbFile 	= Encoding.Default.GetString(buffer, pos + 2, buffer[pos + 1]);
						int sitePos 	= pos + 2 + buffer[pos + 1];
						int siteLength	= buffer[sitePos];
						string siteName = Encoding.Default.GetString(buffer, sitePos + 1, siteLength);
						sitePos 		+= siteLength + 1;
						siteLength		= buffer[sitePos];						
						siteName 		+= "." + Encoding.Default.GetString(buffer, sitePos + 1, siteLength);
						
						return siteName + ":" + dbFile;
					}

					case GdsCodes.isc_info_implementation:
						/* Database implementation number:
						 * 		• 1 byte containing a 1
						 *	 	• 1 byte containing the implementation number
						 *  	• 1 byte containing a “class” number, either 1 or 12
						 */
						return 	buffer[pos].ToString() 		+ "." + 
								buffer[pos + 1].ToString() 	+ "." + 
								buffer[pos + 2].ToString();

					case GdsCodes.isc_info_no_reserve:
						/* 0 or 1
						 * 		• 0 indicates space is reserved on each database page for holding
						 * 			backup versions of modified records [Default]
						 * 		• 1 indicates no space is reserved for such records
						 */
						return buffer[pos] == 1 ? true : false;

					case GdsCodes.isc_info_ods_version:
						/* ODS major version number
						 * 		• Databases with different major version numbers have different
						 * 			physical layouts; a database engine can only access databases
						 * 			with a particular ODS major version number
						 * 		• Trying to attach to a database with a different ODS number
						 * 			results in an error
						 */
						 return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_ods_minor_version:
						/* On-disk structure (ODS) minor version number; an increase in a
						 * minor version number indicates a non-structural change, one that
						 * still allows the database to be accessed by database engines with
						 * the same major version number but possibly different minor
						 * version numbers
						 */
						return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_page_size:
						/* Number of bytes per page of the attached database; use with
						 * isc_info_allocation to determine the size of the database
						 */
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_isc_version:
					{
						/* Version identification string of the database implementation:
						 * 		• 1 byte containing the number 1
						 * 		• 1 byte specifying the length, n, of the following string
						 * 		• n bytes containing the version identification string
						 */						
						int len = buffer[pos + 1];
						return Encoding.Default.GetString(buffer, pos + 2, len);
					}

					//
					// Environmental characteristics
					//

					case GdsCodes.isc_info_current_memory:
						// Amount of server memory (in bytes) currently in use
						return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_forced_writes:
						/* Number specifying the mode in which database writes are performed
						 * (0 for asynchronous, 1 for synchronous)
						 */
						 return buffer[pos] == 1 ? true : false;
						 
					case GdsCodes.isc_info_max_memory:
						/* Maximum amount of memory (in bytes) used at one time since the first
						 * process attached to the database
						 */
						return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_num_buffers:
						// Number of memory buffers currently allocated
						return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_sweep_interval:
						/* Number of transactions that are committed between “sweeps” to
						 * remove database record versions that are no longer needed
						 */
						return gds.isc_vax_integer(buffer, pos, length);

					//
					// Performance statistics
					//

					case GdsCodes.isc_info_fetches:
						// Number of reads from the memory buffer cache
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_marks:
						// Number of writes to the memory buffer cache
						return gds.isc_vax_integer(buffer, pos, length);
													
					case GdsCodes.isc_info_reads:
						// Number of page reads
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_writes:
						// Number of page writes
						return gds.isc_vax_integer(buffer, pos, length);

					//
					// Database operation counts
					//

					case GdsCodes.isc_info_backout_count:
						// Number of removals of a version of a record
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_delete_count:
						// Number of database deletes since the database was last attached
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_expunge_count:
						/* Number of removals of a record and all of its ancestors, for records
						 * whose deletions have been committed
						 */
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_insert_count:
						// Number of inserts into the database since the database was last attached 
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_purge_count:
						// Number of removals of old versions of fully mature records
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_read_idx_count:
						// Number of reads done via an index since the database was last attached
						return gds.isc_vax_integer(buffer, pos, length);

					case GdsCodes.isc_info_read_seq_count:
						/* Number of sequential sequential table scans (row reads) done on each 
						 * table since the database was last attached
						 */
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_update_count:
						// Number of database updates since the database was last attached
						return gds.isc_vax_integer(buffer, pos, length);
					
					//
					// Misc
					//

					case GdsCodes.isc_info_firebird_version:
					{						
						int len = buffer[pos + 1];
						return Encoding.Default.GetString(buffer, pos + 2, len);
					}

					case GdsCodes.isc_info_db_class:
					{
						int serverClass = gds.isc_vax_integer(buffer, pos, length);
						if (serverClass == GdsCodes.isc_info_db_class_classic_access)
						{
							return "CLASSIC SERVER";
						}
						else
						{
							return "SUPER SERVER";
						}
						
					}
											
					case GdsCodes.isc_info_db_read_only:
						return buffer[pos] == 1 ? true : false;

					case GdsCodes.isc_info_db_size_in_pages:
						// Database size in pages.
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_oldest_transaction:
						// Number of oldest transaction
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_oldest_active:
						// Number of oldest active transaction
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_oldest_snapshot:
						// Number of oldest snapshot transaction
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_next_transaction:
						// Number of next transaction
						return gds.isc_vax_integer(buffer, pos, length);
					
					case GdsCodes.isc_info_active_transactions:
						// Number of active transactions
						return gds.isc_vax_integer(buffer, pos, length);
				}
				
				pos += length;
			}
			
			return 0;
		}

		private void checkConnection()
		{
			if (connection == null || connection.State == ConnectionState.Closed)
			{
				throw new InvalidOperationException("Connection must valid and open");
			}			
		}

		#endregion
	}
}
