//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Net;
using System.Text;
using System.Collections;
using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbarray.xml' path='doc/member[@name="T:FbArray"]/*'/>
	internal sealed class FbArray
	{
		#region FIELDS

		private FbConnection  connection	= null;
		private FbTransaction transaction	= null;

		private string field_name			= null;
		private string relation_name		= null;

		private string rdb_field_name		= null;

		private long array_id;
		
		#endregion

		/// <include file='xmldoc/fbarray.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction,System.Int64,System.String,System.String)"]/*'/>
		public FbArray(FbConnection connection, FbTransaction transaction, 
						long array_id, string relation_name, string field_name)
		{
			this.connection		= connection;
			this.transaction	= transaction;
			this.array_id		= array_id;
			this.field_name		= field_name;
			this.relation_name	= relation_name;
		}

		public System.Array Read()
		{
			try
			{
				ISC_ARRAY_DESC desc = isc_array_lookup_bounds();
							
				byte[] slice = connection.IscConnection.GDS.isc_array_get_slice(
											connection.IscConnection.db,
											transaction.IscTransaction,
											array_id,
											desc,				
											getSliceLength(desc, true));
				
				return decodeSlice(desc, slice);
			}
			catch (GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		public long Write(System.Array source_array)
		{
			try
			{
				ISC_ARRAY_DESC desc = isc_array_lookup_bounds();
								
				return connection.IscConnection.GDS.isc_array_put_slice(
											connection.IscConnection.db,
											transaction.IscTransaction,
											array_id,
											desc,
											source_array,
											getSliceLength(desc, false),
											connection.Encoding);
			}
			catch(GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		private ISC_ARRAY_DESC isc_array_lookup_desc()
		{
			ISC_ARRAY_DESC desc = new ISC_ARRAY_DESC();

			FbTransaction transaction = new FbTransaction(connection);
			transaction.BeginTransaction();

			FbStatement statement = getArrayDesc(
											transaction		,
											null			,
											null			,
											relation_name	,
											field_name);

			statement.Execute();

			if(statement.Resultset.Fetch())
			{								
				desc.array_desc_relation_name	= relation_name;
				desc.array_desc_field_name		= field_name;
				desc.array_desc_dtype			= statement.Resultset.GetByte(0);
				desc.array_desc_scale			= statement.Resultset.GetInt16(1);
				desc.array_desc_length			= statement.Resultset.GetInt16(2);
				desc.array_desc_dimensions		= statement.Resultset.GetInt16(3);
				desc.array_desc_flags			= 0;

				this.rdb_field_name				= statement.Resultset.GetString(4);
			}			
			else
			{
				throw new InvalidOperationException();
			}
			
			transaction.InternalRollback(false);

			statement.Dispose();
			statement = null;

			return desc;
		}

		private ISC_ARRAY_DESC isc_array_lookup_bounds()
		{
			int				i;
			ISC_ARRAY_DESC	desc = isc_array_lookup_desc();

			FbTransaction transaction = new FbTransaction(connection);
			transaction.BeginTransaction();

			FbStatement statement = getArrayBounds(
													transaction	,
													null		,
													null		,
													this.rdb_field_name);

			statement.Execute();

			i = 0;
			desc.array_desc_bounds = new ISC_ARRAY_BOUND[16];
			while(statement.Resultset.Fetch())
			{				
				desc.array_desc_bounds[i].array_bound_lower = statement.Resultset.GetInt16(0);
				desc.array_desc_bounds[i].array_bound_upper = statement.Resultset.GetInt16(1);

				i++;
			}			
			
			transaction.InternalRollback(false);

			statement.Dispose();
			statement = null;

			return desc;
		}
		
		/// <include file='xmldoc/fbarray.xml' path='doc/member[@name="M:GetArrayDesc(FirebirdSql.Data.Firebird.FbTransaction,System.String,System.String,System.String,System.String)"]/*'/>
		private FbStatement getArrayDesc(FbTransaction transaction, 
			string tableCat,
			string tableSchema,
			string tableName,
			string fieldName)
		{
			StringBuilder sql = new StringBuilder();

			sql.Append(
				"SELECT Y.RDB$FIELD_TYPE, Y.RDB$FIELD_SCALE, Y.RDB$FIELD_LENGTH, Y.RDB$DIMENSIONS, X.RDB$FIELD_SOURCE " +
				"FROM RDB$RELATION_FIELDS X, RDB$FIELDS Y " +
				"WHERE X.RDB$FIELD_SOURCE = Y.RDB$FIELD_NAME ");

			if (tableName != null)
			{
				if (tableName.Length != 0)
				{
					sql.AppendFormat(" AND X.RDB$RELATION_NAME = '{0}'", tableName);
				}
			}
					
			if (fieldName != null)
			{
				if (fieldName.Length != 0)
				{
					sql.AppendFormat(" AND X.RDB$FIELD_NAME = '{0}'", fieldName);					
				}
			}
									
			try
			{
				FbStatement statement = new FbStatement();

				statement.CommandText = sql.ToString();
				statement.Connection  = transaction.Connection;
				statement.Transaction = transaction;
				
				return statement;
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/fbarray.xml' path='doc/member[@name="M:GetArrayBounds(FirebirdSql.Data.Firebird.FbTransaction,System.String,System.String)"]/*'/>
		private FbStatement getArrayBounds(FbTransaction transaction, 
													string tableCat,
													string tableSchema,
													string fieldName)
		{
			StringBuilder sql = new StringBuilder();

			sql.Append("SELECT X.RDB$LOWER_BOUND, X.RDB$UPPER_BOUND FROM RDB$FIELD_DIMENSIONS X ");				
					
			if (fieldName != null)
			{
				if (fieldName.Length != 0)
				{
					sql.AppendFormat("WHERE X.RDB$FIELD_NAME = '{0}'", fieldName);
				}
			}

			sql.Append(" ORDER BY X.RDB$DIMENSION");
									
			try
			{
				FbStatement statement = new FbStatement();

				statement.CommandText = sql.ToString();
				statement.Connection  = transaction.Connection;
				statement.Transaction = transaction;
				
				return statement;
			}
			catch (FbException ex)
			{
				throw ex;
			}
		}
		
		private int getSliceLength(ISC_ARRAY_DESC desc, bool read)
		{
			Encoding	encoding		= connection.Encoding;
			int 		length 			= 0;
			int			elements		= 0;

			for (int i = 0; i < desc.array_desc_dimensions; i++)
			{
				ISC_ARRAY_BOUND bound = desc.array_desc_bounds[i];
				
				elements += bound.array_bound_lower * bound.array_bound_upper;
			}

			switch (desc.array_desc_dtype)
			{
				case GdsCodes.blr_text:
				case GdsCodes.blr_text2:
				case GdsCodes.blr_cstring:
				case GdsCodes.blr_cstring2:
				case GdsCodes.blr_varying:
				case GdsCodes.blr_varying2:
					// Char & VarChar
					length =  elements * encoding.GetMaxByteCount(desc.array_desc_length);
					length += elements * ((4 - encoding.GetMaxByteCount(desc.array_desc_length)) & 3);
					break;

				case GdsCodes.blr_short:
					length = elements * desc.array_desc_length;
					if (read)
					{
						length *= 2;
					}
					break;
				
				default:
					length = elements * desc.array_desc_length;
					break;
			}						
			
			return length;
		}
						
		private System.Array decodeSlice(ISC_ARRAY_DESC desc, byte[] slice)
		{
			System.Array 	sliceData		= null;			
			int				slicePosition	= 0;
			FbType			type			= FbType.Array;
			Type			systemType		= null;
			int 			temp 			= 0;
			Encoding		encoding		= connection.Encoding;
			int[]			lengths 		= new int[desc.array_desc_dimensions];
			int[]			lowerBounds		= new int[desc.array_desc_dimensions];			

			// Get upper and lower bounds of each dimension
			for (int i = 0; i < desc.array_desc_dimensions; i++)
			{
				lowerBounds[i] 	= desc.array_desc_bounds[i].array_bound_lower;
				lengths[i] 		= desc.array_desc_bounds[i].array_bound_upper;
			}
			
			sliceData = getArrayFromDesc(desc, ref type, ref systemType, lengths, lowerBounds);

			System.Array tempData = System.Array.CreateInstance(systemType, sliceData.Length);

			for (int i = 0; i < tempData.Length; i++)
			{
				if (slicePosition >= slice.Length)
				{
					break;
				}
				int item_length = desc.array_desc_length;
				
				switch(type)
				{							
					case FbType.Text:
					{
						// Char
						string strValue = encoding.GetString(slice, slicePosition, item_length);
												
						tempData.SetValue(strValue, i);
					}
					break;
					
					case FbType.VarChar:
					{
						// VarChar						
						item_length 	= BitConverter.ToInt32(slice, slicePosition);
						item_length 	= IPAddress.HostToNetworkOrder(item_length);
						slicePosition 	+= 4;
						
						string strValue = encoding.GetString(slice, slicePosition, item_length);
												
						tempData.SetValue(strValue, i);
					}
					break;
					
					case FbType.SmallInt:
					{
						// Smallint
						int sintValue = BitConverter.ToInt32(slice, slicePosition);
						sintValue = IPAddress.HostToNetworkOrder(sintValue);
	
						slicePosition += 2;
	
						if (desc.array_desc_scale < 0)		
						{
							decimal dvalue = connection.IscConnection.GDS.DecodeDecimal(
														sintValue, 
														desc.array_desc_scale,
														GdsCodes.SQL_SHORT);
							tempData.SetValue(dvalue, i);
						}
						else
						{							
							tempData.SetValue(Convert.ToInt16(sintValue), i);
						}
					}
					break;
	
					case FbType.Integer:
					{
						// Integer
						int intValue = BitConverter.ToInt32(slice, slicePosition);
						intValue = IPAddress.HostToNetworkOrder(intValue);
					
						if (desc.array_desc_scale < 0)		
						{								
							decimal dvalue = connection.IscConnection.GDS.DecodeDecimal(
														intValue, 
														desc.array_desc_scale,
														GdsCodes.SQL_LONG);
							tempData.SetValue(dvalue, i);
						}
						else
						{							
							tempData.SetValue(intValue, i);
						}
					}
					break;
	
					case FbType.BigInt:
					{
						// BigInt/Long
						long bintValue = BitConverter.ToInt64(slice, slicePosition);
						bintValue = IPAddress.HostToNetworkOrder(bintValue);
					
						if (desc.array_desc_scale < 0)		
						{
							decimal dvalue = connection.IscConnection.GDS.DecodeDecimal(
														bintValue, 
														desc.array_desc_scale,
														GdsCodes.SQL_INT64);
							tempData.SetValue(dvalue, i);
						}
						else
						{							
							tempData.SetValue(bintValue, i);
						}
					}
					break;
					
					case FbType.Double:
					{
						// Double						
						DoubleLayout dlayout = new DoubleLayout();
			
						dlayout.d	= BitConverter.ToDouble(slice, slicePosition);
						dlayout.i0	= IPAddress.HostToNetworkOrder(dlayout.i0);
						dlayout.i4	= IPAddress.HostToNetworkOrder(dlayout.i4);
			
						temp 		= dlayout.i0;
						dlayout.i0 	= dlayout.i4;
						dlayout.i4 	= temp;
			
						tempData.SetValue(dlayout.d, i);
					}
					break;
	
					case FbType.Float:
					{
						// Float
						FloatLayout flayout = new FloatLayout();								
																	
						flayout.f  = BitConverter.ToSingle(slice, slicePosition);
						flayout.i0 = IPAddress.HostToNetworkOrder(flayout.i0);
					
						tempData.SetValue(flayout.f, i);
					}
					break;
										
					case FbType.TimeStamp:
					{
						// TimeStamp
						int idate	= BitConverter.ToInt32(slice, slicePosition);
						idate		= IPAddress.HostToNetworkOrder(idate);
						
						int itime	= BitConverter.ToInt32(slice, slicePosition + 4);
						itime		= IPAddress.HostToNetworkOrder(itime);
					
						DateTime date = connection.IscConnection.GDS.DecodeDate(idate);
						DateTime time = connection.IscConnection.GDS.DecodeTime(itime);

						DateTime timestamp = new System.DateTime(
										date.Year, date.Month, date.Day,
										time.Hour,time.Minute, time.Second, time.Millisecond);
					
						
						tempData.SetValue(timestamp, i);
					}
					break;
					
					case FbType.Time:
					{
						// Time
						int itime 	= BitConverter.ToInt32(slice, slicePosition);
						itime		= IPAddress.HostToNetworkOrder(itime);
					
						DateTime time = connection.IscConnection.GDS.DecodeTime(itime);					
						
						tempData.SetValue(time, i);
					}
					break;
					
					case FbType.Date:
					{
						// Date
						int idate 	= BitConverter.ToInt32(slice, slicePosition);
						idate		= IPAddress.HostToNetworkOrder(idate);
					
						DateTime date = connection.IscConnection.GDS.DecodeDate(idate);
						
						tempData.SetValue(date, i);
					}
					break;
				}
				
				slicePosition += item_length;
			}
			
			if (systemType.IsPrimitive)
			{
				// For primitive types we can use System.Buffer to copy generated data to destination array
				System.Buffer.BlockCopy(tempData, 0, sliceData, 0, System.Buffer.ByteLength(tempData));
			}
			else
			{
				sliceData = tempData;	
			}
			
			return sliceData;
		}		
						
		private System.Array getArrayFromDesc(ISC_ARRAY_DESC desc, ref FbType type, ref Type systemType, int[] lengths, int[] lowerBounds)
		{
			switch (desc.array_desc_dtype)
			{
				case GdsCodes.blr_text:
				case GdsCodes.blr_text2:
				case GdsCodes.blr_cstring:
				case GdsCodes.blr_cstring2:
					// Char
					type 		= FbType.Text;
					systemType 	= typeof(System.String);
					break;

				case GdsCodes.blr_varying:
				case GdsCodes.blr_varying2:
					// VarChar
					type = FbType.VarChar;
					systemType 	= typeof(System.String);
					break;

				case GdsCodes.blr_short:
					// Short/Smallint
					type = FbType.SmallInt;
					if (desc.array_desc_scale < 0)
					{
						systemType 	= typeof(System.Decimal);
					}
					else
					{
						systemType 	= typeof(System.Int16);
					}
					break;

				case GdsCodes.blr_long:
					// Integer
					type = FbType.Integer;
					if (desc.array_desc_scale < 0)
					{
						systemType 	= typeof(System.Decimal);
					}
					else
					{
						systemType 	= typeof(System.Int32);
					}
					break;
				
				case GdsCodes.blr_float:
					// Float
					type = FbType.Float;
					systemType 	= typeof(System.Single);
					break;
									
				case GdsCodes.blr_double:
				case GdsCodes.blr_d_float:
					// Double
					type = FbType.Double;
					systemType 	= typeof(System.Double);
					break;
												
				case GdsCodes.blr_quad:
				case GdsCodes.blr_int64:
					// Long/Quad
					type = FbType.BigInt;
					if (desc.array_desc_scale < 0)
					{
						systemType 	= typeof(System.Decimal);
					}
					else
					{
						systemType 	= typeof(System.Int64);
					}
					break;
				
				case GdsCodes.blr_timestamp:
					// Timestamp
					type = FbType.TimeStamp;
					systemType 	= typeof(System.DateTime);
					break;

				case GdsCodes.blr_sql_time:			
					// Time
					type = FbType.Time;
					systemType 	= typeof(System.DateTime);
					break;

				case GdsCodes.blr_sql_date:				
					// Date
					type = FbType.Date;
					systemType 	= typeof(System.DateTime);
					break;
				
				default:
					throw new NotSupportedException("Unknown data type");
			}
			
			return System.Array.CreateInstance(systemType, lengths, lowerBounds);
		}
	}	
}
