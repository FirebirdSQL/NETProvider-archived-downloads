//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="T:FbIscConnection"]/*'/>
	internal class FbIscConnection
	{
		#region FIELDS
				
		internal isc_db_handle_impl	db;
		
		private IGDS	gds;
		private string	connectionString;		
		private int		connectionTimeout;
		private long	lifetime;
		private long	created;
		private bool	pooling;
		private int		packetSize;
		private bool	pooled;		

		#endregion

		#region PROPERTIES

		public IGDS GDS
		{
			get { return gds; }
		}

		public string ConnectionString
		{
			get { return connectionString; }
		}

		public string DataSource
		{
			get { return db.AttachInfo.Server; }
		}

		public int ConnectionTimeout
		{ 
			get { return connectionTimeout; } 
		}

		public string Database
		{ 
			get { return db.AttachInfo.FileName; } 
		}

		/*
		public string User
		{ 
			get { return db.AttachInfo.UserName; } 
		}

		public string Password
		{ 
			get { return db.AttachInfo.UserPassword; } 
		}

		public byte	Dialect
		{ 
			get { return db.AttachInfo.Dialect; } 
		}

		public string Role
		{ 
			get { return db.AttachInfo.Role; } 
		}

		public string Charset
		{ 
			get { return db.AttachInfo.Charset; } 
		}
		*/

		public long Lifetime
		{
			get { return lifetime; }
		}

		public int PacketSize
		{
			get { return packetSize; }
		}

		public long Created
		{
			get { return created; }
			set { created = value; }
		}
		
		public bool Pooling
		{
			get { return pooling; }
		}

		public bool Pooled
		{
			get { return pooled; }
			set { pooled = value; }
		}

		#endregion

		#region CONSTRUCTORS

		private FbIscConnection()
		{
			gds					= GDSFactory.NewGDS();
			db					= (isc_db_handle_impl)gds.get_new_isc_db_handle();
			connectionString	= String.Empty;		
			connectionTimeout	= 15;
			lifetime			= 0;
			created				= 0;
			pooling				= true;
			packetSize			= 8192;
			pooled				= true;
		}

		public FbIscConnection(string connectionString) : this()
		{
			this.connectionString = connectionString;

			ParseConnectionString(connectionString);
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:Open"]/*'/>
		public void Open()
		{				
			// New instance of RequestConnectionInfo class
			FbParameterBlock dpb = new FbParameterBlock();
			
			// DPB configuration
			dpb.SetProperty(GdsCodes.isc_dpb_dummy_packet_interval, 
							new byte[] {120, 10, 0, 0});
			dpb.SetProperty(GdsCodes.isc_dpb_sql_dialect, 
							new byte[] {db.AttachInfo.Dialect, 0, 0, 0});
			dpb.SetProperty(GdsCodes.isc_dpb_lc_ctype, db.AttachInfo.Charset);
			if (db.AttachInfo.Role != null)
			{
				if (db.AttachInfo.Role.Length > 0)
				{
					dpb.SetProperty(GdsCodes.isc_dpb_sql_role_name, db.AttachInfo.Role);
				}
			}
			dpb.SetProperty(GdsCodes.isc_dpb_connect_timeout, connectionTimeout);
			dpb.SetProperty(GdsCodes.isc_dpb_user_name, db.AttachInfo.UserName);
			dpb.SetProperty(GdsCodes.isc_dpb_password, db.AttachInfo.UserPassword);

			// Connect to database
			gds.isc_attach_database(GetDatabaseUrl(), db, dpb.Dpb);

			this.connectionTimeout	= connectionTimeout;
			
			// Reset ParameterBlock
			dpb.Reset();
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close()
		{	
			gds.isc_detach_database(db);
			db	= null;
		}

		public void CancelEvents()
		{
			try
			{
				if (db.AsyncDB != null)
				{
					System.Threading.Thread.Sleep(10);

					lock (db.AsyncDB)
					{
						isc_event_handle_impl[] events = new isc_event_handle_impl[db.AsyncDB.Events.Values.Count];
						db.AsyncDB.Events.Values.CopyTo(events, 0);
						for (int i = 0; i < events.Length; i++)
						{
							isc_event_handle_impl eventHandle = events[i];
							lock (eventHandle)
							{
								gds.isc_cancel_events(db, eventHandle);
							}
						}

						db.AsyncDB.StopEventThread();
						db.AsyncDB.Disconnect();
					}
				}
			}
			catch (GDSException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:VerifyAttachedDB"]/*'/>
		public bool VerifyAttachedDB()
		{
			int INFO_SIZE = 16;
			
			byte[] buffer = new byte[INFO_SIZE];
			
			// Do not actually ask for any information
			byte[] databaseInfo  = new byte[]
			{
				GdsCodes.isc_info_end
			};

			try 
			{
				gds.isc_database_info(db, databaseInfo.Length, databaseInfo, INFO_SIZE, buffer);

				return true;
			}
			catch
			{
				return false;
			}
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:ParseConnectionString"]/*'/>
		internal void ParseConnectionString(string connStr)
		{
			string	database	= null;
			string	user		= null;
			string	password	= null;
			string	dataSource	= "localhost";
			int		port		= 3050;
			string	charset		= "NONE";
			string	role		= null;
			byte	dialect		= 3;
			int		lifetime	= 0;
			bool	pooling		= true;
			int		connectionTimeout = 15;
			int		packetSize	= 8192;

			string[] elements = connStr.Split(';');			

			for (int i = 0; i < elements.Length; i++)
			{
				string[] values = elements[i].Split('=');

				if (values.Length == 2)
				{
					if (values[0] != null && values[1] != null)
					{
						switch (values[0].Trim().ToUpper())
						{
							case "DATABASE":
								database = values[1];
								break;

							case "USER":
								user = values[1];
								break;

							case "PASSWORD":
								password = values[1];
								break;

							case "SERVER":
							case "HOST":
							case "DATASOURCE":
								dataSource = values[1];
								break;

							case "PORT":
								port = Int32.Parse(values[1]);
								break;

							case "DIALECT":
								dialect = byte.Parse(values[1]);
								break;

							case "CHARSET":
								charset = values[1];
								break;

							case "ROLE":
								role 	= values[1];
								break;

							case "LIFETIME":
							case "CONNECTION LIFETIME":
								lifetime = Int32.Parse(values[1]);
								break;

							case "POOLING":						
								pooling = bool.Parse(values[1]);
								break;

							case "TIMEOUT":
							case "CONNECTION TIMEOUT":
								connectionTimeout = Int32.Parse(values[1]);
								break;

							case "PACKET SIZE":
								packetSize = Int32.Parse(values[1]);
								break;

							default:
								break;
						}
					}
				}
			}

			if (db == null || user == null || password == null || dataSource == null)
			{
				throw new ArgumentException("An invalid connection string argument has been supplied or a required connection string argument has not been supplied.");
			}
			else
			{
				if (packetSize < 512 || packetSize > 32767)
				{
					// Valor 'Packet Size' no vlido de '100'. El valor debe ser un entero >= 512 y <= 32767.
					StringBuilder msg = new StringBuilder();

					msg.AppendFormat("'Packet Size' value of {0} is not valid.", packetSize);
					msg.AppendFormat("The value should be an integer >= 512 and <= 32767.");

					throw new ArgumentException(msg.ToString());
				}
				else
				{
					db.AttachInfo.Server		= dataSource;
					db.AttachInfo.Port			= port;
					db.AttachInfo.FileName		= database;
					db.AttachInfo.UserName		= user;
					db.AttachInfo.UserPassword	= password;
					db.AttachInfo.Charset		= charset;
					db.AttachInfo.Dialect		= dialect;
					db.AttachInfo.Role			= role;
					db.AttachInfo.PacketSize	= packetSize;
					this.pooling				= pooling;
					this.lifetime				= lifetime * TimeSpan.TicksPerSecond;
					this.connectionTimeout		= connectionTimeout;

					// Set up the encoding field
					if (Encodings.GetFromFbName(db.AttachInfo.Charset).DnName != "default")
					{
						db.AttachInfo.Encoding = Encoding.GetEncoding(Encodings.GetFromFbName(db.AttachInfo.Charset).DnName);
					}
				}
			}
		}

		private string GetDatabaseUrl()
		{
			return db.AttachInfo.Server + "/" + db.AttachInfo.Port.ToString() + ":" + db.AttachInfo.FileName;
		}

		#endregion
	}
}
