//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Data;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	abstract class StatementBase
	{
		#region Properties

		public abstract IDbAttachment DB
		{
			get;
			set;
		}
		
		public abstract RowDescriptor Parameters
		{
			get;
			set;
		}

		public abstract RowDescriptor Fields
		{
			get;
		}

		public abstract int RecordsAffected
		{
			get;
		}

		public abstract bool IsPrepared
		{
			get;
		}

		public abstract string CommandText
		{
			get;
			set;
		}

		public abstract object[] Rows
		{
			get;
		}

		public abstract ITransaction Transaction
		{
			get;
			set;
		}

		public abstract DbStatementType StatementType
		{
			get;
			set;
		}

		public abstract StatementState State
		{
			get;
			set;
		}

		#endregion
		
		#region Protected Fields

		protected TransactionUpdateEventHandler TransactionUpdate;

		protected byte[] DescribePlanInfoItems;
		protected byte[] RecordsAffectedInfoItems;
		protected byte[] DescribeSelectInfoItems;
		protected byte[] DescribeBindInfoItems;
		protected byte[] SqlPrepareInfoItems;
		protected byte[] StatementTypeInfoItems;

		#endregion

		#region Abstract Methods

		public abstract void Allocate();
		public abstract void Describe();
		public abstract void DescribeParameters();
		public abstract void Prepare();
		public abstract void Execute();
		public abstract void ExecuteImmediate();
		public abstract void ExecuteImmediate(string commandText);
		public abstract DbValue[] Fetch();
		public abstract void UpdateRecordsAffected();
		public abstract void Free(int option);
		public abstract void SetCursorName(string cursorName, int type);
		public abstract byte[] GetSqlInfo(byte[] items, int bufferLength);

		#endregion

		#region Protected Abstract Methods
		
		protected abstract void TransactionUpdated(object sender, EventArgs e);
		protected abstract DbStatementType GetStatementType();

		#endregion

		#region Methods

		public string GetExecutionPlan()
		{
			string plan = String.Empty;
			
			try
			{		        
				byte[] buffer = this.GetSqlInfo(
					this.DescribePlanInfoItems,
					IscCodes.MAX_BUFFER_SIZE);

				int len = buffer[1];
				len += buffer[2] << 8;
												
				plan = Encoding.Default.GetString(buffer, 4, --len);
			}
			catch(IscException ge)
			{
				throw ge;
			}

			return plan;
		}

		public virtual void Close()
		{
			if (this.State == StatementState.Executed ||
				this.State == StatementState.Error)
			{
				if (this.StatementType == DbStatementType.Select			||
					this.StatementType == DbStatementType.SelectForUpdate	||
					this.StatementType == DbStatementType.StoredProcedure)
				{				
					this.Free(IscCodes.DSQL_close);
					this.State = StatementState.Closed;
				}
			}
		}

		public virtual void Drop()
		{
			if (this.TransactionUpdate != null)
			{
				this.Transaction.Update -= this.TransactionUpdate;
				this.TransactionUpdate = null;
			}

			this.Free(IscCodes.DSQL_drop);
			this.State			= StatementState.Deallocated;
			this.StatementType	= DbStatementType.None;			
		}

		#endregion

		#region Protected Methods

		protected int GetRecordsAffected()
		{
			int insertCount		= 0;
			int updateCount		= 0;
			int deleteCount		= 0;
			int selectCount		= 0;
			int pos				= 0;
			int length			= 0;
			int type			= 0;

			byte[] buffer = this.GetSqlInfo(
				this.RecordsAffectedInfoItems, 
				IscCodes.MAX_BUFFER_SIZE);

			while ((type = buffer[pos++]) != IscCodes.isc_info_end) 
			{
				length = this.DB.VaxInteger(buffer, pos, 2);
				pos += 2;
				switch (type) 
				{
					case IscCodes.isc_info_sql_records:
						int l;
						int t;
						while ((t = buffer[pos++]) != IscCodes.isc_info_end) 
						{
							l = this.DB.VaxInteger(buffer, pos, 2);
							pos += 2;
							switch (t) 
							{
								case IscCodes.isc_info_req_insert_count:
									insertCount = this.DB.VaxInteger(
										buffer, pos, l);
									break;
								
								case IscCodes.isc_info_req_update_count:
									updateCount = this.DB.VaxInteger(
										buffer, pos, l);
									break;
								
								case IscCodes.isc_info_req_delete_count:
									deleteCount = this.DB.VaxInteger(
										buffer, pos, l);
									break;
								
								case IscCodes.isc_info_req_select_count:
									selectCount = this.DB.VaxInteger(
										buffer, pos, l);
									break;
							}
							pos += l;
						}
						break;
										
					default:
						pos += length;
						break;
				}
			}

			if (this.StatementType == DbStatementType.Select			||
				this.StatementType == DbStatementType.SelectForUpdate	||
				this.StatementType == DbStatementType.StoredProcedure)
			{
				return -1;
			}
			else
			{
				return insertCount + updateCount + deleteCount;
			}
		}

		protected void InitializeInfoItems()
		{
			// Plan information items
			this.DescribePlanInfoItems = new byte[] 
			{ 
				IscCodes.isc_info_sql_get_plan,
				IscCodes.isc_info_end 
			};

			// Records affected items
			this.RecordsAffectedInfoItems = new byte[]
			{
				IscCodes.isc_info_sql_records,
				IscCodes.isc_info_end
			};

			// Describe information items
			this.DescribeSelectInfoItems = new byte[] 
			{ 
				IscCodes.isc_info_sql_select,
				IscCodes.isc_info_sql_describe_vars,
				IscCodes.isc_info_sql_sqlda_seq,
				IscCodes.isc_info_sql_type,
				IscCodes.isc_info_sql_sub_type,
				IscCodes.isc_info_sql_scale,
				IscCodes.isc_info_sql_length,
				IscCodes.isc_info_sql_field,
				IscCodes.isc_info_sql_relation,
				IscCodes.isc_info_sql_owner,
				IscCodes.isc_info_sql_alias,
				IscCodes.isc_info_sql_describe_end
			};

			this.DescribeBindInfoItems = new byte[] 
			{ 
				IscCodes.isc_info_sql_bind,
				IscCodes.isc_info_sql_describe_vars,
				IscCodes.isc_info_sql_sqlda_seq,
				IscCodes.isc_info_sql_type,
				IscCodes.isc_info_sql_sub_type,
				IscCodes.isc_info_sql_scale,
				IscCodes.isc_info_sql_length,
				IscCodes.isc_info_sql_field,
				IscCodes.isc_info_sql_relation,
				IscCodes.isc_info_sql_owner,
				IscCodes.isc_info_sql_alias,
				IscCodes.isc_info_sql_describe_end 
			};

			this.SqlPrepareInfoItems = new byte[] 
			{ 
				IscCodes.isc_info_sql_select,
				IscCodes.isc_info_sql_describe_vars,
				IscCodes.isc_info_sql_sqlda_seq,
				IscCodes.isc_info_sql_type,
				IscCodes.isc_info_sql_sub_type,
				IscCodes.isc_info_sql_scale,
				IscCodes.isc_info_sql_length,
				IscCodes.isc_info_sql_field,
				IscCodes.isc_info_sql_relation,
				IscCodes.isc_info_sql_owner,
				IscCodes.isc_info_sql_alias,
				IscCodes.isc_info_sql_describe_end
			};

			this.StatementTypeInfoItems = new byte[]
			{
				IscCodes.isc_info_sql_stmt_type	,
				IscCodes.isc_info_end
			};
		}

		#endregion
	}
}
