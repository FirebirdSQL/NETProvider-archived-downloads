//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class DbValue
	{
		#region Fields

		private StatementBase	statement;
		private DbField		field;
		private object			value;

		#endregion

		#region Properties

		public DbField Field
		{
			get { return this.field; }
		}

		public object Value
		{
			get { return this.getValue(); }
		}

		#endregion
		
		#region Constructor

		public DbValue(
			StatementBase statement, 
			DbField field, 
			object value)
		{
			this.statement	= statement;
			this.field		= field;
			this.value		= value == null ? System.DBNull.Value : value;
		}

		public DbValue(
			StatementBase statement, 
			DbField field)
		{
			this.statement	= statement;
			this.field		= field;
			this.value		= this.convertValue(field);
		}

		#endregion

		#region Private Methods

		private object convertValue(DbField field)
		{
			byte[] buffer = (byte[])field.Value;

			if (buffer == null || field.NullFlag == -1)
			{
				return System.DBNull.Value;
			}
			
			switch (field.SqlType)
			{
				case IscCodes.SQL_TEXT:
				case IscCodes.SQL_VARYING:
					return this.field.Charset.Encoding.GetString(
						buffer, 0, buffer.Length);

				case IscCodes.SQL_SHORT:
					if (field.NumericScale < 0)
					{
						return TypeDecoder.DecodeDecimal(
							BitConverter.ToInt16(buffer, 0),
							field.NumericScale,
							field.DataType);
					}
					else
					{
						return BitConverter.ToInt16(buffer, 0);
					}

				case IscCodes.SQL_LONG:
					if (field.NumericScale < 0)
					{
						return TypeDecoder.DecodeDecimal(
							BitConverter.ToInt32(buffer, 0),
							field.NumericScale,
							field.DataType);
					}
					else
					{
						return BitConverter.ToInt32(buffer, 0);
					}
				
				case IscCodes.SQL_FLOAT:
					return BitConverter.ToSingle(buffer, 0);
									
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					return BitConverter.ToDouble(buffer, 0);
				
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
				case IscCodes.SQL_BLOB:
				case IscCodes.SQL_ARRAY:
					if (field.NumericScale < 0)
					{
						return TypeDecoder.DecodeDecimal(
							BitConverter.ToInt64(buffer, 0),
							field.NumericScale,
							field.DataType);
					}
					else
					{
						return BitConverter.ToInt64(buffer, 0);
					}
									
				case IscCodes.SQL_TIMESTAMP:
					DateTime date = TypeDecoder.DecodeDate(
						BitConverter.ToInt32(buffer, 0));
					DateTime time = TypeDecoder.DecodeTime(
						BitConverter.ToInt32(buffer, 4));

					return new System.DateTime(
						date.Year, date.Month, date.Day,
						time.Hour,time.Minute, time.Second, time.Millisecond);

				case IscCodes.SQL_TYPE_TIME:
					return TypeDecoder.DecodeTime(
						BitConverter.ToInt32(buffer, 0));

				case IscCodes.SQL_TYPE_DATE:
					return TypeDecoder.DecodeDate(
						BitConverter.ToInt32(buffer, 0));
				
				default:
					throw new NotSupportedException("Unknown data type");
			}
		}

		private object getValue()
		{
			if (this.value == null || 
				this.value == System.DBNull.Value)
			{
				return System.DBNull.Value;
			}

			switch (this.field.SqlType)
			{
				case IscCodes.SQL_TEXT:
				case IscCodes.SQL_VARYING:
					return Convert.ToString(this.value);

				case IscCodes.SQL_SHORT:
					if (this.field.NumericScale < 0)
					{
						return Convert.ToDecimal(this.value);
					}
					else
					{
						return Convert.ToInt16(this.value);
					}

				case IscCodes.SQL_LONG:
					if (field.NumericScale < 0)
					{
						return Convert.ToDecimal(this.value);
					}
					else
					{
						return Convert.ToInt32(this.value);
					}
				
				case IscCodes.SQL_FLOAT:
					return Convert.ToSingle(this.value);
									
				case IscCodes.SQL_DOUBLE:
				case IscCodes.SQL_D_FLOAT:
					return Convert.ToDouble(this.value);
				
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					if (this.field.NumericScale < 0)
					{
						return Convert.ToDecimal(this.value);
					}
					else
					{
						return Convert.ToInt64(this.value);
					}
									
				case IscCodes.SQL_TIMESTAMP:
				case IscCodes.SQL_TYPE_TIME:
				case IscCodes.SQL_TYPE_DATE:
					// Timestamp, Time and Date
					return Convert.ToDateTime(this.value);
				
				case IscCodes.SQL_BLOB:
					if (this.field.SubType == 1)
					{
						// SUB_TYPE TEXT
						if (this.value is long)
						{
							this.value = this.getClobData((long)this.value);
						}
						return this.value;
					}
					else
					{
						// SUB_TYPE BINARY
						if (this.value is long)
						{
							this.value = this.getBlobData((long)this.value);
						}
						return this.value;
					}
								
				case IscCodes.SQL_ARRAY:
					if (this.value is long)
					{
						this.value = this.getArrayData((long)this.value);
					}
					return this.value;
										
				default:
					throw new NotSupportedException("Unknown data type");
			}
		}

		private string getClobData(long handle)
		{
			BlobBase clob = this.statement.DB.Factory.CreateBlob(
				this.statement.DB, 
				this.statement.Transaction, 
				handle);
			string contents = clob.ReadString();
			
			return contents;
		}

		private byte[] getBlobData(long handle)
		{
			BlobBase blob = this.statement.DB.Factory.CreateBlob(
				this.statement.DB, 
				this.statement.Transaction,
				handle);
			byte[] contents = blob.Read();
			
			return contents;
		}

		private object getArrayData(long handle)
		{
			ArrayBase gdsArray = this.statement.DB.Factory.CreateArray(
				this.statement.DB, 
				this.statement.Transaction,
				handle,
				this.Field.Relation,
				this.Field.Name);
			
			return gdsArray.Read();
		}

		#endregion
	}
}