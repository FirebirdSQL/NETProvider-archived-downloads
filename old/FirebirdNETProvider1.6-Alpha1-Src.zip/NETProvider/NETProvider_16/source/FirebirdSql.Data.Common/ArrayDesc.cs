//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Runtime.InteropServices;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	struct ArrayDesc
	{
		public byte		DataType;
		public short	Scale;			// Scale for numeric datatypes
		public short	Length;			// Legth in bytes of each array element
		public string	FieldName;		// Column name - 32
		public string	RelationName;	// Table name -32
		public short	Dimensions;		// Number of array dimensions 
		public short	Flags;			// Specifies wheter array is to be accesed in
										// row mayor or column-mayor order
		public ArrayBound[] Bounds;		// Lower and upper bounds for each dimension - 16
	}

#if (SINGLE_DLL)
	internal
#else
	public
#endif
	struct ArrayBound
	{
		public int LowerBound;
		public int UpperBound;
	}
}
