//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// This file was initially ported from JayBird <http://firebird.sourceforge.net/>
//


using System;
using System.Text;

namespace FirebirdSql.Data.Common
{
	[Serializable]
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class IscException : Exception
	{	
		#region Fields
		
		private IscErrorCollection	errors;
		private int					errorCode;
		private string				message;

		#endregion

		#region Properties
		
		public IscErrorCollection Errors
		{
			get { return this.errors; }
		}

		public new string Message
		{
			get { return this.message; }
		}

		public int ErrorCode
		{
			get { return this.errorCode; }			
		}
	    
		#endregion

		#region Constructors

		public IscException() : base()
		{
			this.errors = new IscErrorCollection();
		}

		public IscException(int errorCode) : this()
		{
			this.Errors.Add(IscCodes.isc_arg_gds, errorCode);
			this.BuildExceptionMessage();
		}

		public IscException(string strParam) : this()
		{			
			this.Errors.Add(IscCodes.isc_arg_string, strParam);
			this.BuildExceptionMessage();
		}

		public IscException(int type, string strParam) : this()
		{
			this.Errors.Add(type, strParam);
			this.BuildExceptionMessage();
		}

		public IscException(int errorCode, int intparam) : this()
		{
			this.Errors.Add(IscCodes.isc_arg_gds, errorCode);
			this.Errors.Add(IscCodes.isc_arg_number, intparam);
			this.BuildExceptionMessage();
		}
	    
		public IscException(int type, int errorCode, string strParam) : this()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(IscCodes.isc_arg_string, strParam);			
			this.BuildExceptionMessage();
		}

		public IscException(
			int type, int errorCode, int intParam, string strParam) : this()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(IscCodes.isc_arg_string, strParam);
			this.Errors.Add(IscCodes.isc_arg_number, intParam);
			this.BuildExceptionMessage();
		}
		
		#endregion

		#region Methods

		public bool IsWarning() 
		{
			if (this.errors.Count > 0)
			{
				return this.errors[0].IsWarning();
			}
			else
			{
				return false;
			}
		}

		public bool IsFatal()
		{
			bool isFatal = false;

			for (int i = 0; i < this.errors.Count; i++)
			{
				if (this.errors[0].IsFatal)
				{
					isFatal = true;
					break;
				}
			}

			return isFatal;			
		}

		public void BuildExceptionMessage()
		{
			StringBuilder	message = new StringBuilder();
			GdsMessage		gdsMessage = null;
			
			errorCode = this.errors.Count != 0 ? this.errors[0].ErrorCode : 0;

			for (int i = 0; i < this.errors.Count; i++)
			{	
				if (this.errors[i].Type == IscCodes.isc_arg_gds || 
					this.errors[i].Type == IscCodes.isc_arg_warning)
				{
					gdsMessage = IscExceptionHelper.GetMessage(
						this.errors[i].ErrorCode);

					// Add params if exist any
					int paramCount = gdsMessage.GetParamCount();

					for (int j = 1; j <= paramCount; j++)
					{
						int index = i + j;
						
						if (index >= 0 && index < errors.Count)
						{
							switch (errors[index].Type)
							{
								case IscCodes.isc_arg_interpreted:
								case IscCodes.isc_arg_string: 
								case IscCodes.isc_arg_cstring:
									gdsMessage.SetParameter(
										j, 
										this.errors[index].StrParam);
									break;

								case IscCodes.isc_arg_number:
									gdsMessage.SetParameter(
										j, 
										this.errors[index].ErrorCode.ToString());
									break;
							}
						}
					}

					errors[i].Message = gdsMessage.ToString();
					message.Append(this.errors[i].Message + "\n");

					i += paramCount;

					gdsMessage = null;
				}
			}

			this.message = message.ToString();
		}

		#endregion
	}
}
