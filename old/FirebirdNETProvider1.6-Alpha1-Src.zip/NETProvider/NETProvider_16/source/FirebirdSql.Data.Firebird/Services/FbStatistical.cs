//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird.Services
{
	#region ENUMS

	/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/overview/*'/>
	[Flags]
	public enum FbStatisticalFlags
	{
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="DataPages"]/*'/>
		DataPages				= 0x01,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="DatabaseLog"]/*'/>
		DatabaseLog				= 0x02,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="HeaderPages"]/*'/>
		HeaderPages				= 0x04,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="IndexPages"]/*'/>
		IndexPages				= 0x08,
		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/enum[@name="FbStatisticalFlags"]/field[@name="SystemTablesRelations"]/*'/>
		SystemTablesRelations	= 0x10,
	}

	#endregion

	/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/overview/*'/>
	public sealed class FbStatistical : FbService
	{
		#region Fields
		
		private FbStatisticalFlags 	options;
		
		#endregion

		#region Properties

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/property[@name="Options"]/*'/>
		public FbStatisticalFlags Options
		{
			get { return this.options; }
			set { this.options = value; }
		}
				
		#endregion

		#region Constructors

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/constructor[@name="FbStatistical"]/*'/>
		public FbStatistical() : base()
		{
		}
		
		#endregion

		#region Methods

		/// <include file='Doc/en_EN/FbStatistical.xml' path='doc/class[@name="FbStatistical"]/constructor[@name="Start"]/*'/>
		public void Start()
		{		
			// Configure Spb
			this.StartSpb = new SpbBuffer();
			this.StartSpb.Append(IscCodes.isc_action_svc_db_stats);
			this.StartSpb.Append(
				IscCodes.isc_spb_dbname, 
				this.Parameters.Database);
			this.StartSpb.Append(
				IscCodes.isc_spb_options, 
				(int)this.options);
			
			// Start execution
			this.startTask();
		}
		
		#endregion		
	}
}
