//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/overview/*'/>
	[Serializable, ListBindable(false)]
	public sealed class FbErrorCollection : ICollection, IEnumerable
	{
		#region Fields

		private ArrayList errors;

		#endregion

		#region Indexers

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/indexer[@name="Item(System.String)"]/*'/>
		public FbError this[string errorMessage] 
		{
			get { return (FbError)this.errors[IndexOf(errorMessage)]; }
			set { this.errors[IndexOf(errorMessage)] = (FbError)value; }
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/indexer[@name="Item(System.Int32)"]/*'/>
		public FbError this[int errorIndex] 
		{
			get { return (FbError)this.errors[errorIndex]; }
			set { this.errors[errorIndex] = (FbError)value; }
		}

		#endregion

		#region Constructors

		internal FbErrorCollection()
		{
			this.errors = ArrayList.Synchronized(new ArrayList());
		}

		#endregion

		#region ICollection Properties

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/property[@name="Count"]/*'/>
		public int Count 
		{
			get { return this.errors.Count; }
		}
		
		bool ICollection.IsSynchronized
		{
			get { return this.errors.IsSynchronized; }
		}

		object ICollection.SyncRoot 
		{
			get { return this.errors.SyncRoot; }
		}

		#endregion

		#region ICollection Methods

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="CopyTo(System.Array,System.Int32)"]/*'/>	
		public void CopyTo(Array array, int index)
		{
			this.errors.CopyTo(array, index);
		}
		
		#endregion

		#region IEnumerable Methods

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.errors.GetEnumerator();
		}

		#endregion

		#region Methods

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Contains(System.String)"]/*'/>	
		internal bool Contains(string errorMessage)
		{
			return (-1 != this.IndexOf(errorMessage));
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="IndexOf(System.String)"]/*'/>		
		internal int IndexOf(string errorMessage)
		{
			int index = 0;
			foreach (FbError item in this)
			{
				if (this.cultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}

			return -1;
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="RemoveAt(System.String)"]/*'/>
		internal void RemoveAt(string errorMessage)
		{
			this.errors.RemoveAt(this.IndexOf(errorMessage));
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Add(FbError)"]/*'/>
		internal FbError Add(FbError error)
		{
			this.errors.Add(error);

			return error;
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Add(System.String,System.Int32)"]/*'/>
		internal FbError Add(string errorMessage, int number)
		{
			FbError error = new FbError(errorMessage, number);			

			return this.Add(error);
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Add(System.Byte,System.Int32,System.String,System.Int32)"]/*'/>
		internal FbError Add(
			byte	classError, 
			int		line, 
			string	errorMessage, 
			int		number)
		{
			FbError error = new FbError(
				classError, 
				line, 
				errorMessage, 
				number);
			
			return this.Add(error);
		}
		
		private bool cultureAwareCompare(string strA, string strB)
		{
			return CultureInfo.CurrentCulture.CompareInfo.Compare(
				strA, 
				strB,
				CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth |
				CompareOptions.IgnoreCase) == 0 ? true : false;
		}

		#endregion
	}
}
