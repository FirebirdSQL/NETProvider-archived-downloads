//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbCollationsSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbCollationsSchema() : base("Collations")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$collations coll");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"coll.rdb$collation_name", 
				"COLLATION_NAME", 
				null);

			this.AddRestrictionColumn(
				"cs.rdb$character_set_name", 
				"CHARACTER_SET_NAME", 
				null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("coll.rdb$description", "DESCRIPTION");
		}

		public override void AddJoins()
		{
			this.AddJoin(
				"left join", 
				"rdb$character_sets cs", 
				"coll.rdb$character_set_id = cs.rdb$character_set_id");
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("cs.rdb$character_set_name");
			this.AddOrderBy("coll.rdb$collation_name");			
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}