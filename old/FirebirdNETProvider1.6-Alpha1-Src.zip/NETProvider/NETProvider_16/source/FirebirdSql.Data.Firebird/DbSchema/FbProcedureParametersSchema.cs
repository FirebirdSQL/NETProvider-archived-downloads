//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbProcedureParametersSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbProcedureParametersSchema() : base("ProcedureParameters")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$procedure_parameters pp");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"pp.rdb$procedure_name", 
				"PROCEDURE_NAME", 
				null);
			
			this.AddRestrictionColumn(
				"pp.rdb$parameter_name", 
				"PARAMETER_NAME", 
				null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("pp.rdb$parameter_type"	, "PARAMETER_TYPE");			
			this.AddDataColumn("pp.rdb$parameter_number", "ORDINAL_POSITION");
			this.AddDataColumn("fld.rdb$field_type"		, "DATA_TYPE");
			this.AddDataColumn("fld.rdb$field_sub_type"	, "SUB_DATA_TYPE");
			this.AddDataColumn("fld.rdb$field_length"	, "COLUMN_SIZE");
			this.AddDataColumn("fld.rdb$field_precision", "NUMERIC_PRECISION");
			this.AddDataColumn("fld.rdb$field_scale"	, "NUMERIC_SCALE");			
			this.AddDataColumn("cs.rdb$character_set_name", "CHARACTER_SET_NAME");
			this.AddDataColumn("coll.rdb$collation_name", "COLLATION_NAME");
			this.AddDataColumn("pp.rdb$description"		, "DESCRIPTION");
		}

		public override void AddJoins()
		{
			this.AddJoin(
				"left join", 
				"rdb$fields fld", 
				"pp.rdb$field_source = fld.rdb$field_name");

			this.AddJoin(
				"left join", 
				"rdb$character_sets cs", 
				"cs.rdb$character_set_id = fld.rdb$character_set_id");

			this.AddJoin(
				"left join", 
				"rdb$collations coll", 
				"coll.rdb$collation_id = fld.rdb$collation_id AND coll.rdb$character_set_id = fld.rdb$character_set_id");
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("pp.rdb$procedure_name");
			this.AddOrderBy("pp.rdb$parameter_type");
			this.AddOrderBy("pp.rdb$parameter_number");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}