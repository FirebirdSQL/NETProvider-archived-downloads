//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbForeignKeysSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbForeignKeysSchema() : base("ForeignKeys")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$relation_constraints rc");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"rc.rdb$relation_name", 
				"TABLE_NAME", 
				null);
			
			this.AddRestrictionColumn(
				"rc.rdb$constraint_name", 
				"CONSTRAINT_NAME", 
				null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("ref.rdb$match_option"	, "MATCH_OPTION");
			this.AddDataColumn("ref.rdb$update_rule"	, "UPDATE_RULE");
			this.AddDataColumn("ref.rdb$delete_rule"	, "DELETE_RULE");
			this.AddDataColumn("rc.rdb$index_name"		, "INDEX_NAME");
			this.AddDataColumn("rc.rdb$deferrable"		, "IS_DEFERRABLE");			
			this.AddDataColumn(
				"rc.rdb$initially_deferred"	, 
				"INITIALLY_DEFERRED");
		}

		public override void AddJoins()
		{
			this.AddJoin(
				"left join", 
				"rdb$ref_constraints ref", 
				"rc.rdb$constraint_name = ref.rdb$constraint_name");
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("rc.rdb$relation_name");
			this.AddOrderBy("rc.rdb$constraint_name");
		}

		public override void AddWhereFilters()
		{
			// Get Only Primary Key information
			this.AddWhereFilter("rc.rdb$constraint_type = 'FOREIGN KEY'");
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}