//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2003-2004 Abel Eduardo Pereira.
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Isql
{
	#region Delegates

	/// <summary>
	/// The event handler type trigged before a SQL statement execution.
	/// </summary>
	public delegate void CommandExecutingEventHandler(object sender, CommandExecutingEventArgs e);

	#endregion

	/// <summary>
	///	CommandExecutingEventArgs encapsulates the events arguments for the event trigged 
	///	from the <see cref="FbBatchExecution"/> during the execution. 
	/// </summary>
	/// <remarks>
	/// 
	/// </remarks>
	public class CommandExecutingEventArgs: EventArgs
	{
		#region Private

		private FbCommand sqlCommand;

		#endregion

		#region Properties

		/// <summary>
		/// Returns the <see cref="FbCommand"/> instance that created for the SQL statement that goes 
		/// for execution. 
		/// </summary>
		public FbCommand SqlCommand 
		{
			get { return this.sqlCommand; }
		}

		/// <summary>
		/// Returns the <see cref="SqlStatementType"/> of the current <see cref="SQLCommand"/>.
		/// </summary>
		public SqlStatementType StatementType 
		{
			get { return FbBatchExecution.GetStatementType(this.SqlCommand.CommandText); }
		}

		#endregion

		#region Constructors

		/// <summary>
		/// Creates an instance of CommandExecutingEventArgs class.
		/// </summary>
		/// <param name="sqlCommand">The FbCommand properly instanciated.</param>
		/// <remarks>The <b>sqlCommand</b> should be proper instanciated with a valid 
		/// <see cref="FbCommand"/> and with the SQL statement loaded in <see cref="FbCommand.CommandText"/>.
		/// </remarks>
		public CommandExecutingEventArgs(FbCommand sqlCommand)
		{
			this.sqlCommand	= sqlCommand;
		}

		#endregion

		#region Methods

		/// <summary>
		/// Overrided. Returns the SQL statement that goes for execution.
		/// </summary>
		/// <returns>The SQL statement that will be executed.</returns>
		public override string ToString() 
		{
			return this.sqlCommand.CommandText;
		}

		#endregion
	}
}
