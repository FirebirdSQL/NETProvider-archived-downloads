//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Data.Common;

using Borland.Data.Common;
using Borland.Data.Schema;

namespace FirebirdSql.Data.Firebird.BDP
{
	public class FbResolver : ISQLResolver
	{
		#region Properties

		public string[] ExcludeFilter 
		{ 
			get { throw new NotSupportedException(); }
			set	{ throw new NotSupportedException(); }
		} 

		public string QuotePrefix 
		{ 
			get { throw new NotSupportedException(); }
			set	{ throw new NotSupportedException(); }
		}

		public string QuoteSuffix
		{ 
			get { throw new NotSupportedException(); }
			set	{ throw new NotSupportedException(); }
		}

		public string[] ReadOnly 
		{ 
			get { throw new NotSupportedException(); }
			set	{ throw new NotSupportedException(); }
		}

		public DataRow Row 
		{ 
			get { throw new NotSupportedException(); }
			set	{ throw new NotSupportedException(); }
		}

		#endregion

		#region Constructors

		public FbResolver()
		{
		}

		#endregion

		#region Methods

		public string GetSelectSQL(
			IDbConnection		connection, 
			DataRowCollection	columns, 
			string				tableName) 
		{
			throw new NotSupportedException();
		}

		public string GetDeleteSQL(
			IDbConnection		connection, 
			IDbCommand			command, 
			DataRowCollection	columns, 
			string				tableName, 
			BdpUpdateMode		updateMode)
		{
			throw new NotSupportedException();
		}

		public string GetUpdateSQL(
			IDbConnection		connection, 
			IDbCommand			command, 
			DataRowCollection	columns, 
			string				tableName, 
			BdpUpdateMode		updateMode)
		{
			throw new NotSupportedException();
		}

		public string GetInsertSQL(
			IDbConnection		connection, 
			IDbCommand			command, 
			DataRowCollection	columns, 
			string				tableName)
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}
