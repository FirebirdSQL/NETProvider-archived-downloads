//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;

using Borland.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	public class FbCursor : ISQLCursor
	{
		#region Constructors

		public FbCursor()
		{
		}

		#endregion

		#region ISQLCursor

		public int GetBlob(
			short column, ref byte[] buffer, ref int index, int length)
		{
			throw new NotSupportedException();
		}

		public int GetBlobSize(
			short column, ref long blobSize, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetByte(short column, ref byte data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetChar(short column, ref char data, ref int index)
		{
			throw new NotSupportedException();
		}

		public short GetColumnCount()
		{
			throw new NotSupportedException();
		}

		public int GetColumnLength(short column, ref int length)
		{
			throw new NotSupportedException();
		}

		public int GetColumnName(short column, ref string colName)
		{
			throw new NotSupportedException();
		}

		public int GetColumnType(
			short column, ref short type, ref short subType)
		{
			throw new NotSupportedException();
		}

		public int GetColumnTypeName(short column, ref string typeName)
		{
			throw new NotSupportedException();
		}

		public int GetDecimalAsString(
			short column, StringBuilder data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetDouble(short column, ref double data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			throw new NotSupportedException();
		}

		public int GetFloat(short column, ref float data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetGuid(short column, ref Guid data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetInt64(short column, ref long data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetIsNull(short column, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetLong(short column, ref int data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetNextResult(
			out ISQLCursor cursor, ref short resultCols)
		{
			throw new NotSupportedException();
		}

		public int GetRowsAffected(ref int rowsAffected)
		{
			throw new NotSupportedException();
		}

		public int GetShort(short column, ref short data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetString(
			short column, ref StringBuilder data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetTimeStamp(
			short column, ref DateTime data, ref int index)
		{
			throw new NotSupportedException();
		}

		public int GetVarBytes(
			short column, ref byte[] buffer, ref int index, int length)
		{
			throw new NotSupportedException();
		}

		public int Next()
		{
			throw new NotSupportedException();
		}

		public int Release()
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}
