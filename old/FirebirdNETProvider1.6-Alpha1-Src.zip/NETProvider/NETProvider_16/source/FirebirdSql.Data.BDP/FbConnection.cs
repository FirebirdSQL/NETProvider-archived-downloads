//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;

using Borland.Data.Common;
using Borland.Data.Schema;

namespace FirebirdSql.Data.Bdp
{
	public class FbConnection : ISQLConnection
	{
		#region Constructors

		public FbConnection()
		{
		}

		#endregion

		#region ISQLConnection Methods

		public void GetProperty(ConnectionProps connProp, out object value)
		{
			throw new NotSupportedException();
		}

		public void SetProperty(ConnectionProps connProp, object value)
		{
			throw new NotSupportedException();
		}

		public int SetOptions(string connOptions)
		{
			throw new NotSupportedException();
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			throw new NotSupportedException();
		}

		public int BeginTransaction(int transID, short isolationLevel)
		{
			throw new NotSupportedException();
		}

		public int Commit(int transID)
		{
			throw new NotSupportedException();
		}

		public int Rollback(int transID)
		{
			throw new NotSupportedException();
		}

		public ISQLResolver GetResolver()
		{
			throw new NotSupportedException();
		}

		public ISQLMetaData GetMetaData()
		{
			throw new NotSupportedException();
		}

		public ISQLCommand GetSQLCommand()
		{
			throw new NotSupportedException();
		}

		public int ChangeDatabase(
			string	database, 
			string	user, 
			string	password, 
			bool	connected)
		{
			throw new NotSupportedException();
		}

		public int FreeConnect()
		{
			throw new NotSupportedException();
		}

		public int Disconnect()
		{
			throw new NotSupportedException();
		}

		public int Connect(
			string database, 
			string user, 
			string password, 
			string hostName)
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}