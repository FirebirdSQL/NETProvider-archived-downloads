//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Data;
using System.Text;

using Borland.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	public class FbCommand : ISQLCommand
	{
		#region Constructors

		public FbCommand()
		{
		}

		#endregion

		#region ISQLCommand Methods

		public int Close()
		{
			throw new NotSupportedException();
		}

		public int Execute(out ISQLCursor cursor, ref short resultCols)
		{
			throw new NotSupportedException();
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			throw new NotSupportedException();
		}

		public int GetParameter(
			short		paramNumber, 
			short		childPos, 
			ref object	value, 
			ref bool	isNull)
		{
			throw new NotSupportedException();
		}

		public int GetRowsAffected(ref int rowsAffected)
		{
			throw new NotSupportedException();
		}

		public int GetStoredProcedureSQL(
			StringBuilder	sql, 
			ArrayList		paramList)
		{
			throw new NotSupportedException();
		}

		public int Prepare(string sql, short paramCount)
		{
			throw new NotSupportedException();
		}

		public int PrepareProc(string spName, short paramCount)
		{
			throw new NotSupportedException();
		}

		public int Release()
		{
			throw new NotSupportedException();
		}

		public int SetParameter(
			short				paramNumber, 
			short				childPos, 
			ParameterDirection	paramDir, 
			BdpType				logType, 
			BdpType				subType, 
			int					maxPrecision, 
			int					maxScale, 
			int					length, 
			object				value, 
			bool				isNull)
		{
			throw new NotSupportedException();
		}
        
		#endregion
	}
}
