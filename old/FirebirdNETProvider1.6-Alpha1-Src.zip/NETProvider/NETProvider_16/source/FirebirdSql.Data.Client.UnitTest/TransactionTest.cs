//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using NUnit.Framework;
using System;
using System.Data;
using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Client.UnitTest
{
	[TestFixture]
	public class TransactionTest : BaseTest
	{
		[Test]
		public void BeginTransaction()
		{
			// Read Commited
			ITransaction txnRc = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadCommitted);

			txnRc.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadCommitted));
			txnRc.Commit();

			// Read Uncommited
			ITransaction txnRu = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadUncommitted);

			txnRu.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadUncommitted));
			txnRu.Commit();

			// Serializable
			ITransaction txnSe = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.Serializable);

			txnSe.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.Serializable));
			txnSe.Commit();
		}

		[Test]
		public void Commit()
		{
			// Read Commited
			ITransaction txnRc = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadCommitted);

			txnRc.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadCommitted));
			txnRc.Commit();

			// Read Uncommited
			ITransaction txnRu = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadUncommitted);

			txnRu.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadUncommitted));
			txnRu.Commit();

			// Serializable
			ITransaction txnSe = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.Serializable);

			txnSe.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.Serializable));
			txnSe.Commit();
		}

		[Test]
		public void Rollback()
		{
			// Read Commited
			ITransaction txnRc = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadCommitted);

			txnRc.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadCommitted));
			txnRc.Rollback();

			// Read Uncommited
			ITransaction txnRu = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadUncommitted);

			txnRu.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadUncommitted));
			txnRu.Rollback();

			// Serializable
			ITransaction txnSe = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.Serializable);

			txnSe.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.Serializable));
			txnSe.Rollback();
		}

		[Test]
		public void CommitRetaining()
		{
			// Read Commited
			ITransaction txnRc = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadCommitted);

			txnRc.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadCommitted));
			txnRc.CommitRetaining();
			txnRc.Commit();

			// Read Uncommited
			ITransaction txnRu = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadUncommitted);

			txnRu.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadUncommitted));
			txnRu.CommitRetaining();
			txnRu.Commit();

			// Serializable
			ITransaction txnSe = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.Serializable);

			txnSe.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.Serializable));
			txnSe.CommitRetaining();
			txnSe.Commit();
		}

		[Test]
		public void RollbackRetaining()
		{
			// Read Commited
			ITransaction txnRc = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadCommitted);

			txnRc.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadCommitted));
			txnRc.RollbackRetaining();
			txnRc.Rollback();

			// Read Uncommited
			ITransaction txnRu = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.ReadUncommitted);

			txnRu.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.ReadUncommitted));
			txnRu.RollbackRetaining();
			txnRu.Rollback();

			// Serializable
			ITransaction txnSe = this.Attachment.Factory.CreateTransaction(
				this.Attachment, IsolationLevel.Serializable);

			txnSe.BeginTransaction(BaseTest.BuildTpb(IsolationLevel.Serializable));
			txnSe.RollbackRetaining();
			txnSe.Rollback();
		}

		[Test]
		[Ignore("Not implemented")]
		public void Prepare()
		{
			/* TODO: Implement prepare test case */
		}
	}
}
