//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using NUnit.Framework;
using System;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbParameterCollectionTest : BaseTest 
	{
		public FbParameterCollectionTest() : base()
		{		
		}
		
		[Test]
		public void AddTest()
		{
			FbCommand command = new FbCommand();
						
			command.Parameters.Add(new FbParameter("@p292", 10000));			
			command.Parameters.Add("@p01", FbDbType.Integer);			
			command.Parameters.Add("@p02", 289273);
			command.Parameters.Add("#p3", FbDbType.SmallInt, 2, "sourceColumn");
		}
	}
}
