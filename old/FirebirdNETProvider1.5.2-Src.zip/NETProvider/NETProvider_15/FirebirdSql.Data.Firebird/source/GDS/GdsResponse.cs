//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsResponse
	{
		#region FIELDS

		private int		objectHandle;
		private long	blobHandle;
		private byte[]	data;

		#endregion

		#region PROPERTIES

		public int ObjectHandle
		{
			get { return objectHandle; }
		}

		public long BlobHandle
		{
			get { return blobHandle; }
		}

		public byte[] Data
		{
			get { return data; }
		}

		#endregion

		#region CONSTRUCTORS

		public GdsResponse()
		{
		}
		
		public GdsResponse(int objectHandle, long blobHandle, byte[] data)
		{
			this.objectHandle	= objectHandle;
			this.blobHandle		= blobHandle;
			this.data			= data;
		}

		#endregion
	}
}
