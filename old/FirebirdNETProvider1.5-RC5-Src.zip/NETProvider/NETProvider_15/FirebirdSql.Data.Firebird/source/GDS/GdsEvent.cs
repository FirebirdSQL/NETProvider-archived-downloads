//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird.Gds
{
	#region EVENTARGS_CLASS

	internal class EventRequestEventArgs : EventArgs
	{
		private byte[] resultBuffer;
 
		public byte[] ResultBuffer
		{
			get { return resultBuffer; } 
			set { resultBuffer = value; } 
		}

		public EventRequestEventArgs(byte[] resultBuffer)
		{
			this.resultBuffer = resultBuffer;
		}
	}

	#endregion

	#region DELEGATES

	internal delegate void EventRequestEventHandler(object sender, EventRequestEventArgs e);

	#endregion

	internal class GdsEvent
	{
		#region EVENTS

		public event EventRequestEventHandler OnEventRequest;

		#endregion

		#region FIELDS

		private int			event_rid;
		private int			local_id;

		#endregion

		#region PROPERTIES

		public int Handle
		{
			get { return event_rid; }
			set	{ event_rid = value; }
		}

		public int LocalID
		{
			get { return local_id; }
			set	{ local_id = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public GdsEvent()
		{
		}

		#endregion

		#region METHODS

		public void NotifyEvent(byte[] resultBuffer)
		{
			if (OnEventRequest != null)
			{
				OnEventRequest(this, new EventRequestEventArgs(resultBuffer));
			}
		}

		#endregion
	}
}
