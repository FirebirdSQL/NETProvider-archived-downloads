//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;

namespace FirebirdSql.Data.Firebird.Gds
{
	[Serializable]
	internal class GdsException : Exception
	{	
		#region FIELDS
		
		private GdsErrorCollection	errors;
		private int					errorCode;
		private string				message;

		#endregion

		#region PROPERTIES
		
		public GdsErrorCollection Errors
		{
			get { return errors; }
		}

		public new string Message
		{
			get { return message; }
		}

		public int ErrorCode
		{
			get { return errorCode; }			
		}
	    
		#endregion

		#region CONSTRUCTORS

		public GdsException() : base()
		{
			errors = new GdsErrorCollection();
		}

		public GdsException(int errorCode) : this()
		{
			this.Errors.Add(GdsCodes.isc_arg_gds, errorCode);
			this.BuildExceptionMessage();
		}

		public GdsException(string strParam) : this()
		{			
			this.Errors.Add(GdsCodes.isc_arg_string, strParam);
			this.BuildExceptionMessage();
		}

		public GdsException(int type, string strParam) : this()
		{
			this.Errors.Add(type, strParam);
			this.BuildExceptionMessage();
		}

		public GdsException(int errorCode, int intParam) : this()
		{
			this.Errors.Add(GdsCodes.isc_arg_gds, errorCode);
			this.Errors.Add(GdsCodes.isc_arg_number, intParam);
			this.BuildExceptionMessage();
		}
	    
		public GdsException(int type, int errorCode, string strParam) : this()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(GdsCodes.isc_arg_string, strParam);			
			this.BuildExceptionMessage();
		}
		
		public GdsException(
			int type, int errorCode, int intParam, string strParam) : this()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(GdsCodes.isc_arg_string, strParam);
			this.Errors.Add(GdsCodes.isc_arg_number, intParam);
			this.BuildExceptionMessage();
		}

		#endregion

		#region METHODS

		public bool IsWarning() 
		{
			if (errors.Count > 0)
			{
				return errors[0].IsWarning();
			}
			else
			{
				return false;
			}
		}

		public bool IsFatal()
		{
			bool isFatal = false;

			for (int i=0; i < errors.Count; i++)
			{
				if (errors[0].IsFatal)
				{
					isFatal = true;
					break;
				}
			}

			return isFatal;			
		}

		public void BuildExceptionMessage()
		{
			StringBuilder	message = new StringBuilder();
			GdsMessage		gdsMessage = null;
			
			errorCode = errors.Count != 0 ? errors[0].ErrorCode : 0;

			for(int i = 0; i < errors.Count; i++)
			{
				if (errors[i].Type == GdsCodes.isc_arg_gds || 
					errors[i].Type == GdsCodes.isc_arg_warning)
				{
					gdsMessage = GdsExceptionHelper.GetMessage(errors[i].ErrorCode);

					// Add params if exist any
					int paramCount = gdsMessage.GetParamCount();
					for(int j = 1; j <= paramCount; j++)
					{
						int index = i + j;

						if (index >= 0 && index < errors.Count)
						{
							if (errors[i+j].Type == GdsCodes.isc_arg_string)
							{
								gdsMessage.SetParameter(j, errors[i+j].StrParam);
							}
							else if (errors[i+j].Type == GdsCodes.isc_arg_number)
							{
								gdsMessage.SetParameter(j, errors[i+j].ErrorCode.ToString());
							}
						}
					}

					errors[i].Message = gdsMessage.ToString();
					message.Append(errors[i].Message + "\n");

					i += paramCount;

					gdsMessage = null;
				}
			}

			this.message = message.ToString();
		}

		#endregion
	}
}
