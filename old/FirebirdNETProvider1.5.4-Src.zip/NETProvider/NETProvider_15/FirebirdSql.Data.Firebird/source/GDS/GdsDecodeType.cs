//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Runtime.InteropServices;

namespace FirebirdSql.Data.Firebird.Gds
{
	[StructLayout(LayoutKind.Explicit)]
	internal sealed class DoubleLayout
	{
		[FieldOffset(0)] public double d;
		[FieldOffset(0)] public int i0;
		[FieldOffset(4)] public int i4;
	}

	[StructLayout(LayoutKind.Explicit)]
	internal sealed class FloatLayout
	{
		[FieldOffset(0)] public float f;
		[FieldOffset(0)] public int i0;
	}

	internal class GdsDecodeType
	{
		public static System.Decimal DecodeDecimal(object d, int scale, int sqltype)
		{
			long	divisor = 1;
			decimal returnValue;

			if (scale < 0)
			{
				int exp = scale * (-1);
				divisor = (long)System.Math.Pow(10, exp);
			}
			
			switch (sqltype & ~1)
			{
				case GdsCodes.SQL_SHORT:
				case GdsCodes.SQL_LONG:
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					returnValue = Convert.ToDecimal(d) / divisor;
					break;
											
				case GdsCodes.SQL_DOUBLE:
				default:
					returnValue = Convert.ToDecimal(d);
					break;
			}

			return returnValue;
		}

		public static System.DateTime DecodeTime(int sql_time) 
		{
			return new System.DateTime((sql_time / 10000) * 1000 * 10000L + 621355968000000000);
		}

		public static System.DateTime DecodeDate(int sql_date) 
		{
			int year, month, day, century;

			sql_date	-= 1721119 - 2400001;
			century		= (4 * sql_date - 1) / 146097;
			sql_date	= 4 * sql_date - 1 - 146097 * century;
			day			= sql_date / 4;

			sql_date	= (4 * day + 3) / 1461;
			day			= 4 * day + 3 - 1461 * sql_date;
			day			= (day + 4) / 4;

			month		= (5 * day - 3) / 153;
			day			= 5 * day - 3 - 153 * month;
			day			= (day + 5) / 5;

			year		= 100 * century + sql_date;

			if (month < 10) 
			{
				month += 3;
			} 
			else 
			{
				month	-= 9;
				year	+= 1;
			}

			DateTime date = new System.DateTime(year, month, day);		

			return date.Date;
		}
	}
}
