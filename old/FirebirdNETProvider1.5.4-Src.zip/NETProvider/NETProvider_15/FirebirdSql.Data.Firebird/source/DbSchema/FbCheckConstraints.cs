//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbCheckConstraintsSchema : FbAbstractDbSchema
	{
		#region CONSTRUCTORS

		public FbCheckConstraintsSchema() : base("CheckConstraints")
		{
		}

		#endregion

		#region ADD_METHODS

		public override void AddTables()
		{
			AddTable("RDB$CHECK_CONSTRAINTS chk");
		}

		public override void AddRestrictionColumns()
		{
			AddRestrictionColumn("chk.rdb$constraint_name", "CONSTRAINT_NAME", null);			
		}

		public override void AddDataColumns()
		{
			AddDataColumn("trig.rdb$trigger_source"	, "CHECK_CLAUSULE");
			AddDataColumn("trig.rdb$description"	, "DESCRIPTION");
		}

		public override void AddJoins()
		{
			AddJoin("left join", "rdb$triggers trig", "chk.rdb$trigger_name = trig.rdb$trigger_name");
		}

		public override void AddOrderByColumns()
		{
			AddOrderBy("chk.rdb$constraint_name");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region PARSE_METHODS

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			if (parsed != null)
			{
				if (parsed.Length == 7 && parsed[6] != null)
				{
					switch (parsed[6].ToString().ToUpper())
					{
						case "UNIQUE":
							parsed[3] = "u";
							break;

						case "PRIMARY KEY":
							parsed[3] = "p";
							break;

						case "FOREIGN KEY":
							parsed[3] = "f";
							break;

						case "CHECK":
							parsed[3] = "c";
							break;
					}
				}
			}

			return parsed;
		}

		#endregion
	}
}