//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbInfoMessageEventArgs.xml' path='doc/delegate[@name="FbInfoMessageEventHandler"]/overview/*'/>
	public delegate void FbInfoMessageEventHandler(object sender, FbInfoMessageEventArgs e);

	/// <include file='Doc/en_EN/FbInfoMessageEventArgs.xml' path='doc/class[@name="FbInfoMessageEventArgs"]/overview/*'/>
	public sealed class FbInfoMessageEventArgs : EventArgs
	{
		#region FIELDS

		private FbErrorCollection errors = new FbErrorCollection();
		private string			  message = String.Empty;

		#endregion

		#region PROPERTIES

		/// <include file='Doc/en_EN/FbInfoMessageEventArgs.xml' path='doc/class[@name="FbInfoMessageEventArgs"]/property[@name="Errors"]/*'/>
		public FbErrorCollection Errors
		{
			get { return errors; }
		}

		/// <include file='Doc/en_EN/FbInfoMessageEventArgs.xml' path='doc/class[@name="FbInfoMessageEventArgs"]/property[@name="Message"]/*'/>
		public string Message
		{
			get { return message; }
		}

		#endregion

		#region CONSTRUCTORS

		internal FbInfoMessageEventArgs(GdsException ex)
		{
			this.message = ex.Message;
			
			foreach (GdsError error in ex.Errors)
			{
				errors.Add(error.Message, error.ErrorCode);
			}
		}

		#endregion
	}
}
