//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbForeignKeysSchema : FbAbstractDbSchema
	{
		#region Constructors

		public FbForeignKeysSchema() : base("ForeignKeys")
		{
		}

		#endregion

		#region Add Methods

		public override void AddTables()
		{
			this.AddTable("rdb$relation_constraints rc");
		}

		public override void AddRestrictionColumns()
		{
			this.AddRestrictionColumn(
				"pidx.rdb$relation_name", 
				"PK_TABLE_NAME", 
				null);
			
			this.AddRestrictionColumn(
				"rc.rdb$relation_name", 
				"FK_TABLE_NAME", 
				null);
		}

		public override void AddDataColumns()
		{
			this.AddDataColumn("fidx.rdb$foreign_key"	, "PK_NAME");
			this.AddDataColumn("pseg.rdb$field_name"	, "PK_COLUMN_NAME");
			this.AddDataColumn("rc.rdb$constraint_name"	, "FK_NAME");
			this.AddDataColumn("fseg.rdb$field_name"	, "FK_COLUMN_NAME");
			this.AddDataColumn("fseg.rdb$field_position", "ORDINAL");
			this.AddDataColumn("ref.rdb$match_option"	, "MATCH_OPTION");
			this.AddDataColumn("ref.rdb$update_rule"	, "UPDATE_RULE");
			this.AddDataColumn("ref.rdb$delete_rule"	, "DELETE_RULE");
			this.AddDataColumn("rc.rdb$index_name"		, "INDEX_NAME");
			this.AddDataColumn("rc.rdb$deferrable"		, "IS_DEFERRABLE");			
			this.AddDataColumn(
				"rc.rdb$initially_deferred"	, 
				"INITIALLY_DEFERRED");
		}

		public override void AddJoins()
		{
			this.AddJoin(
				"inner join", 
				"rdb$indices fidx", 
				"(rc.rdb$index_name = fidx.rdb$index_name AND rc.rdb$constraint_type = 'FOREIGN KEY')");

			this.AddJoin(
				"inner join", 
				"rdb$ref_constraints ref", 
				"rc.rdb$constraint_name = ref.rdb$constraint_name");

			this.AddJoin(
				"inner join", 
				"rdb$index_segments fseg", 
				"fidx.rdb$index_name = fseg.rdb$index_name");
			
			this.AddJoin(
				"inner join", 
				"rdb$indices pidx", 
				"fidx.rdb$foreign_key = pidx.rdb$index_name");

			this.AddJoin(
				"inner join", 
				"rdb$index_segments pseg", 
				"(fidx.rdb$index_name = pseg.rdb$index_name AND pseg.rdb$field_position=fseg.rdb$field_position)");
		}

		public override void AddOrderByColumns()
		{
			this.AddOrderBy("rc.rdb$relation_name");
			this.AddOrderBy("rc.rdb$constraint_name");
			this.AddOrderBy("fseg.rdb$field_position");
		}

		public override void AddWhereFilters()
		{
		}

		#endregion

		#region Parse Methods

		public override object[] ParseRestrictions(object[] restrictions)
		{
			object[] parsed = restrictions;

			return parsed;
		}

		#endregion
	}
}