﻿/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

#if (NET)

using System;
using System.ComponentModel;
using System.ComponentModel.Design;

using FirebirdSql.WizardFramework;

namespace FirebirdSql.Data.Firebird.Design
{
    internal sealed class FbDataAdapterWizardSettings
    {
        #region Constants Fields

        public const string SettingsKey     = "FbDataAdapterConfigurationWizardSettings";
        public const string DesignerHostKey = "DesignerHost";
        public const string DataAdapterKey  = "DataAdapter";
        public const string ConnectionKey   = "Connection";
        public const string CommandTypeKey  = "CommandType";
        public const string CommandTextKey  = "CommandText";
        public const string DmlGenerationKey= "DMLGeneration";
        public const string InsertStmtKey   = "InsertStmt";
        public const string UpdateStmtKey   = "UpdateStmt";        
        public const string DeleteStmtKey   = "DeleteStmt";

        #endregion

        #region Constructors

        private FbDataAdapterWizardSettings()
        {
        }

        #endregion

        #region Static Methods

        public static WizardSettings Register()
        {
            return WizardSettingsManager.Instance.RegisterSettings(SettingsKey);
        }

        public static void Unregister()
        {
            WizardSettingsManager.Instance.UnregisterSettings(SettingsKey);
        }

        public static WizardSettings GetSettings()
        {
            WizardSettings s = WizardSettingsManager.Instance.GetSettings(SettingsKey);

            return s;
        }

        public static object GetSetting(string name)
        {
            if (!FindSetting(name))
            {
                return null;
            }
            return GetSettings()[name];
        }

        public static bool FindSetting(string name)
        {
            return GetSettings().Contains(name);
        }

        public static void UpdateSetting(string name, object value)
        {
            WizardSettings settings = WizardSettingsManager.Instance.GetSettings(SettingsKey);

            if (!settings.Contains(name))
            {
                settings.Add(name);
            }

            settings["name"] = value;
        }

        #endregion

        #region Specific Setting Methods Handling

        public static IDesignerHost GetDesignerHost()
        {
            return (IDesignerHost)GetSetting(DesignerHostKey);
        }

        public static FbDataAdapter GetDataAdapter()
        {
            return (FbDataAdapter)GetSetting(DataAdapterKey);
        }

        public static FbConnection GetConnection()
        {
            return (FbConnection)GetSetting(ConnectionKey);
        }

        public static void UpdateConnection(object connection)
        {
            UpdateSetting(ConnectionKey, (FbConnection)connection);
        }

        public static FbConnection GetCommandType()
        {
            return (FbConnection)GetSetting(CommandTypeKey);
        }

        public static void UpdateCommandType(object commandType)
        {
            UpdateSetting(CommandTypeKey, (int)commandType);
        }

        public static string GetCommandText()
        {
            return GetSetting(CommandTextKey).ToString();
        }

        public static void UpdateCommandText(string commandText)
        {
            UpdateSetting(CommandTextKey, commandText);
        }

        public static bool GetDmlGeneration()
        {
            return (bool)GetSetting(DmlGenerationKey);
        }

        public static void UpdateDmlGeneration(bool generate)
        {
            UpdateSetting(DmlGenerationKey, generate);
        }

        #endregion
    }
}

#endif