﻿/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

#if (NET)

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FirebirdSql.Data.Firebird.Design
{
    internal class FbDataAdapterDataSetGenerator : System.Windows.Forms.Form
    {
        #region Designer Fields

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbExisting;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RadioButton rbNew;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstTables;
        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox chkDesignerAdd;
        private System.Windows.Forms.TextBox textBox1;

        #endregion

        #region Fields

        private FbDataAdapter adapter;
        private IDesignerHost designerHost;

        #endregion

        #region Constructors

        public FbDataAdapterDataSetGenerator(IDesignerHost designerHost, FbDataAdapter dataAdapter)
        {
            if (designerHost == null)
            {
                throw new ArgumentNullException("designerHost cannot be null");
            }
            if (dataAdapter == null)
            {
                throw new ArgumentNullException("dataAdapter cannot be null");
            }

            this.designerHost   = designerHost;
            this.adapter        = dataAdapter;            

            InitializeComponent();
        }

        #endregion

        #region Overriden Methods

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #endregion

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.rbExisting = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.rbNew = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstTables = new System.Windows.Forms.ListBox();
            this.cmdOk = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.chkDesignerAdd = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
// 
// label1
// 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Generate a DataSet that includes the specified tables";
// 
// rbExisting
// 
            this.rbExisting.Location = new System.Drawing.Point(24, 30);
            this.rbExisting.Name = "rbExisting";
            this.rbExisting.Size = new System.Drawing.Size(60, 24);
            this.rbExisting.TabIndex = 2;
            this.rbExisting.Text = "Existing:";
// 
// comboBox1
// 
            this.comboBox1.Enabled = false;
            this.comboBox1.Location = new System.Drawing.Point(91, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(315, 21);
            this.comboBox1.TabIndex = 3;
// 
// rbNew
// 
            this.rbNew.Checked = true;
            this.rbNew.Location = new System.Drawing.Point(24, 75);
            this.rbNew.Name = "rbNew";
            this.rbNew.Size = new System.Drawing.Size(60, 17);
            this.rbNew.TabIndex = 4;
            this.rbNew.TabStop = true;
            this.rbNew.Text = "New:";
// 
// groupBox1
// 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.rbExisting);
            this.groupBox1.Controls.Add(this.rbNew);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Location = new System.Drawing.Point(13, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(444, 110);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose a DataSet";
// 
// textBox1
// 
            this.textBox1.Location = new System.Drawing.Point(91, 75);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(315, 20);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "DataSet1";
// 
// groupBox2
// 
            this.groupBox2.Controls.Add(this.lstTables);
            this.groupBox2.Location = new System.Drawing.Point(13, 179);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(444, 131);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Choose which table(s) to include";
// 
// lstTables
// 
            this.lstTables.Location = new System.Drawing.Point(15, 25);
            this.lstTables.Name = "lstTables";
            this.lstTables.Size = new System.Drawing.Size(415, 95);
            this.lstTables.TabIndex = 0;
// 
// cmdOk
// 
            this.cmdOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.cmdOk.Enabled = false;
            this.cmdOk.Location = new System.Drawing.Point(277, 357);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.TabIndex = 7;
            this.cmdOk.Text = "OK";
// 
// button2
// 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(360, 357);
            this.button2.Name = "button2";
            this.button2.TabIndex = 8;
            this.button2.Text = "Cancel";
// 
// chkDesignerAdd
// 
            this.chkDesignerAdd.Checked = true;
            this.chkDesignerAdd.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDesignerAdd.Location = new System.Drawing.Point(13, 328);
            this.chkDesignerAdd.Name = "chkDesignerAdd";
            this.chkDesignerAdd.Size = new System.Drawing.Size(177, 17);
            this.chkDesignerAdd.TabIndex = 9;
            this.chkDesignerAdd.Text = "Add this DataSet to the Designer";
// 
// FbDataAdapterDataSetGenerator
// 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(469, 404);
            this.Controls.Add(this.chkDesignerAdd);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cmdOk);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FbDataAdapterDataSetGenerator";
            this.Text = "Generate DataSet";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}

#endif