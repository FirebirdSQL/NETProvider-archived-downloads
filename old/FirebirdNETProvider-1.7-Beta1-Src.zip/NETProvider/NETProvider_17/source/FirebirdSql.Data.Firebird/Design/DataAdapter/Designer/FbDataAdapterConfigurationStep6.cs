﻿/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

#if (NET)

using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Windows.Forms;

using FirebirdSql.WizardFramework;

namespace FirebirdSql.Data.Firebird.Design
{
    /// <summary>
    /// Step 6 of the Firebird Data Adapter Configuration Wizard
    /// </summary>
    internal class FbDataAdapterConfigurationStep6 : ActionStep
    {
        private Label label1;
        private ComboBox cboDeleteSP;
        private Label label4;
        private ComboBox cboUpdateSP;
        private Label label5;
        private ComboBox cboInsertSP;
        private Label label3;
        private ComboBox cboSelectSP;
        private Label label2;
        private DataGrid dataGrid1;
        private System.Data.DataSet selectList;
        private System.Data.DataSet updateList;
        private System.Data.DataSet deleteList;
        private System.Data.DataSet insertList;
        private DataSet spParameters;
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <b>WizardStep</b> class.
        /// </summary>
        public FbDataAdapterConfigurationStep6()
        {
            InitializeComponent();
        }

        #endregion

        #region Overriden methods

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        public override void ShowStep()
        {
            if (this.selectList.Tables.Count == 0)
            {
                this.FillTables();
            }
        }

        #endregion

        #region Private Methods

        private void FillTables()
        {
            FbConnection connection = (FbConnection)((ICloneable)FbDataAdapterWizardSettings.GetConnection()).Clone();

            FbConnectionStringBuilder cs = new FbConnectionStringBuilder(connection.ConnectionString);
            cs.Pooling = false;

            connection.ConnectionString = cs.ToString();

            try
            {
                connection.Open();

                DataTable sp = connection.GetSchema("Procedures");
                DataTable spParameters = connection.GetSchema("ProcedureParameters");

                connection.Close();

                // Add tables
                this.selectList.Tables.Add(sp.Copy());
                this.insertList.Tables.Add(sp.Copy());
                this.updateList.Tables.Add(sp.Copy());
                this.deleteList.Tables.Add(sp.Copy());
                this.spParameters.Tables.Add(spParameters.Copy());

                // Condigure DataBinding
                this.cboSelectSP.DisplayMember  = "Procedures.PROCEDURE_NAME";
                this.cboSelectSP.ValueMember    = "Procedures.PROCEDURE_NAME";
                this.cboInsertSP.DisplayMember  = "Procedures.PROCEDURE_NAME";
                this.cboInsertSP.ValueMember    = "Procedures.PROCEDURE_NAME";
                this.cboUpdateSP.DisplayMember  = "Procedures.PROCEDURE_NAME";
                this.cboUpdateSP.ValueMember    = "Procedures.PROCEDURE_NAME";
                this.cboDeleteSP.DisplayMember  = "Procedures.PROCEDURE_NAME";
                this.cboDeleteSP.ValueMember    = "Procedures.PROCEDURE_NAME";
            }
            catch
            {
                MessageBox.Show("Failed to obtain the Stored procedure list.");
            }
        }

        #endregion

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboSelectSP = new System.Windows.Forms.ComboBox();
            this.selectList = new System.Data.DataSet();
            this.cboInsertSP = new System.Windows.Forms.ComboBox();
            this.insertList = new System.Data.DataSet();
            this.label3 = new System.Windows.Forms.Label();
            this.cboDeleteSP = new System.Windows.Forms.ComboBox();
            this.deleteList = new System.Data.DataSet();
            this.label4 = new System.Windows.Forms.Label();
            this.cboUpdateSP = new System.Windows.Forms.ComboBox();
            this.updateList = new System.Data.DataSet();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.spParameters = new System.Data.DataSet();
            this.designArea.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selectList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.insertList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deleteList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updateList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spParameters)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCaption
            // 
            this.lblCaption.Size = new System.Drawing.Size(323, 22);
            this.lblCaption.Text = "Use existing Stored Procedures";
            // 
            // lblDescription
            // 
            this.lblDescription.Location = new System.Drawing.Point(29, 33);
            this.lblDescription.Size = new System.Drawing.Size(332, 25);
            this.lblDescription.Text = "Choose the Stored Procedures to call and  specifcy any required parameters.";
            // 
            // designArea
            // 
            this.designArea.Controls.Add(this.dataGrid1);
            this.designArea.Controls.Add(this.cboDeleteSP);
            this.designArea.Controls.Add(this.label4);
            this.designArea.Controls.Add(this.cboUpdateSP);
            this.designArea.Controls.Add(this.label5);
            this.designArea.Controls.Add(this.cboInsertSP);
            this.designArea.Controls.Add(this.label3);
            this.designArea.Controls.Add(this.cboSelectSP);
            this.designArea.Controls.Add(this.label2);
            this.designArea.Controls.Add(this.label1);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(9, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(470, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select the stored procedure for each operation.  If the procedure requires parame" +
                "ters, specify which column in the data row  contains the parameter value.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select";
            // 
            // cboSelectSP
            // 
            this.cboSelectSP.DataSource = this.selectList;
            this.cboSelectSP.Location = new System.Drawing.Point(66, 89);
            this.cboSelectSP.Name = "cboSelectSP";
            this.cboSelectSP.Size = new System.Drawing.Size(165, 21);
            this.cboSelectSP.TabIndex = 2;
            // 
            // selectList
            // 
            this.selectList.DataSetName = "selectList";
            // 
            // cboInsertSP
            // 
            this.cboInsertSP.DataSource = this.insertList;
            this.cboInsertSP.Location = new System.Drawing.Point(65, 125);
            this.cboInsertSP.Name = "cboInsertSP";
            this.cboInsertSP.Size = new System.Drawing.Size(165, 21);
            this.cboInsertSP.TabIndex = 4;
            // 
            // insertList
            // 
            this.insertList.DataSetName = "insertList";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Insert";
            // 
            // cboDeleteSP
            // 
            this.cboDeleteSP.DataSource = this.deleteList;
            this.cboDeleteSP.Location = new System.Drawing.Point(64, 197);
            this.cboDeleteSP.Name = "cboDeleteSP";
            this.cboDeleteSP.Size = new System.Drawing.Size(165, 21);
            this.cboDeleteSP.TabIndex = 8;
            // 
            // deleteList
            // 
            this.deleteList.DataSetName = "deleteList";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Delete";
            // 
            // cboUpdateSP
            // 
            this.cboUpdateSP.DataSource = this.updateList;
            this.cboUpdateSP.Location = new System.Drawing.Point(65, 161);
            this.cboUpdateSP.Name = "cboUpdateSP";
            this.cboUpdateSP.Size = new System.Drawing.Size(165, 21);
            this.cboUpdateSP.TabIndex = 6;
            // 
            // updateList
            // 
            this.updateList.DataSetName = "updateList";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Update";
            // 
            // dataGrid1
            // 
            this.dataGrid1.DataMember = "";
            this.dataGrid1.DataSource = this.spParameters;
            this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid1.Location = new System.Drawing.Point(245, 89);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ReadOnly = true;
            this.dataGrid1.Size = new System.Drawing.Size(233, 129);
            this.dataGrid1.TabIndex = 9;
            // 
            // spParameters
            // 
            this.spParameters.DataSetName = "NewDataSet";
            // 
            // FbDataAdapterConfigurationStep6
            // 
            this.Name = "FbDataAdapterConfigurationStep6";
            this.designArea.ResumeLayout(false);
            this.designArea.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selectList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.insertList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deleteList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updateList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spParameters)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}

#endif