﻿/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.firebirdsql.org/index.php?op=doc&id=idpl
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

#if (NET)

using System;
using System.ComponentModel;
using System.Collections;

namespace FirebirdSql.WizardFramework
{
    /// <summary>
    /// Represents a collection of Wizard Steps
    /// </summary>
    [ListBindable(false)]
    internal class WizardStepCollection : CollectionBase
    {
        #region Indexers

        /// <summary>
        /// Gets or sets the step at the specified index.
        /// </summary>
        /// <param name="index">The zero-based index of the element to get or set. </param>
        /// <returns>The element at the specified index</returns>
        public WizardStep this[int index]
        {
            get { return ((WizardStep)this.List[index]); }
            set { this.List[index] = value; }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <b>WizardStepCollection</b> class.
        /// </summary>
        public WizardStepCollection()
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds a new stpe to the collection
        /// </summary>
        /// <param name="step"></param>
        /// <returns></returns>
        public int Add(WizardStep step)
        {
            return this.List.Add(step);
        }

        /// <summary>
        /// Returns the zero-based index of the requested step.
        /// </summary>
        /// <param name="step">A <see cref="WizardStep"/> object.</param>
        /// <returns>The zero-based index of the requested step.</returns>
        public int IndexOf(WizardStep step)
        {
            return this.List.IndexOf(step);
        }

        /// <summary>
        /// Inserts a new step in the collection at the specified index.
        /// </summary>
        /// <param name="index">the zero-based index at which the step should be inserted.</param>
        /// <param name="step">The step to insert. The step cannot be null</param>
        public void Insert(int index, WizardStep step)
        {
            this.List.Insert(index, step);
        }

        /// <summary>
        /// Removes the requestion step from the collection.
        /// </summary>
        /// <param name="step">An <see cref="WizardStep"/> object.</param>
        public void Remove(WizardStep step)
        {
            this.List.Remove(step);
        }

        /// <summary>
        /// Determines wheter an step is in the collection.
        /// </summary>
        /// <param name="step">An <see cref="WizardStep"/> object.</param>
        /// <returns><b>true</b> if the step exists; or <b>false</b> if not.</returns>
        public bool Contains(WizardStep step)
        {
            return List.Contains(step);
        }

        #endregion
    }
}

#endif