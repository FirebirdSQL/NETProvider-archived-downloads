//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsField
	{
		#region FIELDS

		private int			sqlType;	
		private int			sqlScale;
		private int			sqlSubType;	
		private int			sqlLen;	
		private object		sqlData;
		private int			sqlInd;
		private string		sqlName;
		private string		relName;
		private string		ownerName;
		private string		aliasName;
		private Encoding	encoding;

		#endregion

		#region PROPERTIES

		public int SqlType
		{
			get { return sqlType; }
			set { sqlType = value; }
		}

		public int SqlScale
		{
			get { return sqlScale; }
			set { sqlScale = value; }
		}

		public int SqlSubType
		{
			get { return sqlSubType; }
			set 
			{ 
				if (IsCharacter())
				{
					// Bits 0-7 of sqlsubtype is charset_id (127 is a special value -
					// current attachment charset).
					// Bits 8-17 hold collation_id for this value.
					byte[] cs = BitConverter.GetBytes(value);

					int index = GdsDbAttachment.CharSets.IndexOf(cs[0]);
					if (index != -1)
					{
						this.encoding = GdsDbAttachment.CharSets[index].Encoding;
					}
					else
					{
						this.encoding = GdsDbAttachment.CharSets[0].Encoding;
					}
				}
								
				sqlSubType = value;
			}
		}

		public int SqlLen
		{
			get { return sqlLen; }
			set { sqlLen = value; }
		}

		public object SqlData
		{
			get { return sqlData; }
			set { sqlData = value; }
		}

		public int SqlInd
		{
			get { return sqlInd; }
			set { sqlInd = value; }
		}

		public string SqlName
		{
			get { return sqlName; }
			set { sqlName = value; }
		}

		public string RelName
		{
			get { return relName; }
			set { relName = value; }
		}

		public string OwnerName
		{
			get { return ownerName; }
			set { ownerName = value; }
		}

		public string AliasName
		{
			get { return aliasName; }
			set { aliasName = value; }
		}

		public Encoding Encoding
		{
			get { return encoding; }
		}

		#endregion

		#region CONSTRUCTORS
		
		public GdsField() 
		{
		}

		public GdsField(object sqlData)
		{
			this.sqlData = sqlData;
		}

		#endregion

		#region STATIC_METHODS

		public static FbDbType GetFbTypeFromBlr(int blrType)
		{
			switch (blrType)
			{
				case GdsCodes.blr_varying:
					return FbDbType.VarChar;

				case GdsCodes.blr_text:
					return FbDbType.Text;

				case GdsCodes.blr_double:
					return FbDbType.Double;

				case GdsCodes.blr_float:
					return FbDbType.Float;

				case GdsCodes.blr_d_float:
					return FbDbType.Double;

				case GdsCodes.blr_sql_date:
					return FbDbType.Date;

				case GdsCodes.blr_sql_time:
					return FbDbType.Time;

				case GdsCodes.blr_timestamp:
					return FbDbType.TimeStamp;

				case GdsCodes.blr_quad:				
				case GdsCodes.blr_int64:
					return FbDbType.BigInt;
				
				case GdsCodes.blr_long:
					return FbDbType.Integer;

				case GdsCodes.blr_short:
					return FbDbType.SmallInt;

				case GdsCodes.blr_blob:
					return FbDbType.Binary;

				default:
					throw new SystemException("Invalid data type");
			}
		}

		#endregion

		#region METHODS

		public string GetDataTypeName()
		{			 
			switch (sqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:
					// Char
					return "CHAR";
				
				case GdsCodes.SQL_VARYING:
					// Varchar
					return "VARCHAR";
				
				case GdsCodes.SQL_SHORT:
					// Short/Smallint
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "SMALLINT";
					}

				case GdsCodes.SQL_LONG:
					// Long
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "INTEGER";
					}
				
				case GdsCodes.SQL_FLOAT:
					// Float
					return "FLOAT";
				
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "DOUBLE";
					}
								
				case GdsCodes.SQL_BLOB:
					// Blob type text / Blob binary
					if (sqlSubType == 1)
					{
						return "BLOB SUB_TYPE 1";
					}
					else
					{
						return "BLOB";
					}
				
				case GdsCodes.SQL_ARRAY:
					// Array
					return "ARRAY";

				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return "DECIMAL";
						}
						else
						{
							return "NUMERIC";
						}
					}
					else
					{
						return "BIGINT";
					}
				
				case GdsCodes.SQL_TIMESTAMP:
					// Timestamp
					return "TIMESTAMP";

				case GdsCodes.SQL_TYPE_TIME:			
					// Hora
					return "TIME";

				case GdsCodes.SQL_TYPE_DATE:
					// Date
					return "DATE";

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public Type GetSystemType()
		{
			switch (sqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:
					// Char
					return Type.GetType("System.String");
				
				case GdsCodes.SQL_VARYING:
					// Varchar
					return Type.GetType("System.String");
				
				case GdsCodes.SQL_SHORT:
					// Short/Smallint
					if (sqlScale < 0)
					{												
						return Type.GetType("System.Decimal");												
					}
					else
					{
						return Type.GetType("System.Int16");
					}

				case GdsCodes.SQL_LONG:
					// Long
					if (sqlScale < 0)
					{
						return Type.GetType("System.Decimal");
					}
					else
					{
						return Type.GetType("System.Int32");
					}
				
				case GdsCodes.SQL_FLOAT:
					// Float
					return Type.GetType("System.Double");
				
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
					// Doble
					if (sqlScale < 0)
					{
						return Type.GetType("System.Decimal");
					}
					else
					{
						return Type.GetType("System.Double");
					}
								
				case GdsCodes.SQL_BLOB:
					// Blob binary
					if (sqlSubType == 1)
					{
						return Type.GetType("System.String");
					}
					else
					{
						return Type.GetType("System.Object");
					}
				
				case GdsCodes.SQL_ARRAY:
					// Array
					return Type.GetType("System.Array");

				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					if (sqlScale < 0)
					{
						return Type.GetType("System.Decimal");
					}
					else
					{
						return Type.GetType("System.Int64");
					}
				
				case GdsCodes.SQL_TIMESTAMP:
				case GdsCodes.SQL_TYPE_TIME:			
				case GdsCodes.SQL_TYPE_DATE:
					return Type.GetType("System.DateTime");

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public FbDbType GetFbDbType()
		{
			switch (sqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:
					// Char
					return FbDbType.Char;
				
				case GdsCodes.SQL_VARYING:
					// Varchar
					return FbDbType.VarChar;
				
				case GdsCodes.SQL_SHORT:
					// Short/Smallint
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return FbDbType.Decimal;
						}
						else
						{
							return FbDbType.Numeric;
						}
					}
					else
					{
						return FbDbType.SmallInt;
					}

				case GdsCodes.SQL_LONG:
					// Long
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return FbDbType.Decimal;
						}
						else
						{
							return FbDbType.Numeric;
						}
					}
					else
					{
						return FbDbType.Integer;
					}
				
				case GdsCodes.SQL_FLOAT:
					// Float
					return FbDbType.Float;
				
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
					// Doble
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return FbDbType.Decimal;
						}
						else
						{
							return FbDbType.Numeric;
						}
					}
					else
					{
						return FbDbType.Double;
					}
								
				case GdsCodes.SQL_BLOB:
					// Blob type text / Blob binary
					if (sqlSubType == 1)
					{
						return FbDbType.Text;
					}
					else
					{
						return FbDbType.LongVarBinary;
					}
				
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					if (sqlScale < 0)
					{
						if (sqlSubType == 2)
						{
							return FbDbType.Decimal;
						}
						else
						{
							return FbDbType.Numeric;
						}
					}
					else
					{
						return FbDbType.BigInt;
					}
				
				case GdsCodes.SQL_TIMESTAMP:
					// Timestamp
					return FbDbType.TimeStamp;

				case GdsCodes.SQL_TYPE_TIME:			
					// Hora
					return FbDbType.Time;

				case GdsCodes.SQL_TYPE_DATE:
					// Date
					return FbDbType.Date;

				case GdsCodes.SQL_ARRAY:
					// Array
					return FbDbType.Array;

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public bool IsNumeric()
		{
			switch (sqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:				
				case GdsCodes.SQL_VARYING:
				case GdsCodes.SQL_BLOB:				
				case GdsCodes.SQL_ARRAY:
				case GdsCodes.SQL_TIMESTAMP:
				case GdsCodes.SQL_TYPE_TIME:			
				case GdsCodes.SQL_TYPE_DATE:
					return false;
				
				case GdsCodes.SQL_SHORT:
				case GdsCodes.SQL_LONG:
				case GdsCodes.SQL_FLOAT:
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					return true;

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public bool IsLong()
		{
			switch (sqlType & ~1)
			{
				case GdsCodes.SQL_BLOB:
					return true;

				case GdsCodes.SQL_ARRAY:
				case GdsCodes.SQL_TEXT:
				case GdsCodes.SQL_VARYING:
				case GdsCodes.SQL_TIMESTAMP:
				case GdsCodes.SQL_TYPE_TIME:			
				case GdsCodes.SQL_TYPE_DATE:
				case GdsCodes.SQL_SHORT:
				case GdsCodes.SQL_LONG:
				case GdsCodes.SQL_FLOAT:
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					return false;

				default:
					throw new SystemException("Invalid data type");
			}
		}

		public bool IsCharacter()
		{
			switch (sqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:
				case GdsCodes.SQL_VARYING:
					return true;

				case GdsCodes.SQL_ARRAY:
				case GdsCodes.SQL_BLOB:
				case GdsCodes.SQL_TIMESTAMP:
				case GdsCodes.SQL_TYPE_TIME:			
				case GdsCodes.SQL_TYPE_DATE:
				case GdsCodes.SQL_SHORT:
				case GdsCodes.SQL_LONG:
				case GdsCodes.SQL_FLOAT:
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					return false;

				default:
					throw new SystemException("Invalid data type");
			}
		}

		#endregion
	}
}
