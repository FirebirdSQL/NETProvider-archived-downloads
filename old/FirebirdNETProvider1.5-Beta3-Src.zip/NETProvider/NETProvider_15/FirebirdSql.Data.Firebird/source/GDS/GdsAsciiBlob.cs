//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;
using System.Collections;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsAsciiBlob : GdsBlob
	{
		#region CONSTRUCTORS
	
		public GdsAsciiBlob(GdsDbAttachment db, GdsTransaction transaction, long handle):
				base(db, transaction, handle)
		{
		}

		public GdsAsciiBlob(GdsDbAttachment db, GdsTransaction transaction):
			base(db, transaction)
		{
		}

		#endregion

		#region METHODS

		public string Read()
		{			
			StringBuilder data = new StringBuilder();

			Open();
		
			while (!EOF)
			{
				byte[] clobData = GetSegment();

				data.Append(DB.Parameters.Encoding.GetString(clobData));
			}

			return data.ToString();
		}

		public void Write(string data)
		{
			Create();

			byte[]	buffer	  = DB.Parameters.Encoding.GetBytes(data);
			byte[]	tmpBuffer = null;

			int	length	= buffer.Length;
			int	offset	= 0;
			int	chunk	= length >= DB.Parameters.PacketSize ? 
									DB.Parameters.PacketSize : length;

			tmpBuffer = new byte[chunk];				
			while (length > 0)
			{					
				if (chunk > length) 
				{
					chunk	  = (int)length;
					tmpBuffer = new byte[chunk];
				}					
				System.Array.Copy(buffer, offset, tmpBuffer, 0, chunk);					
				PutSegment(tmpBuffer);
				
				offset += chunk;					
				length -= chunk;
			}
		}

		#endregion
	}
}
