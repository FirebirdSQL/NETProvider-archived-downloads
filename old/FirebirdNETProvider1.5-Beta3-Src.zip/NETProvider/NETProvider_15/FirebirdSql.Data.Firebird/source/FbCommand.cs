//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Text;
using System.Text.RegularExpressions;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird
{		
	/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/overview/*'/>
	[ToolboxBitmap(typeof(FbCommand), "Resources.ToolboxBitmaps.FbCommand.bmp")]
	public sealed class FbCommand : Component, IDbCommand, ICloneable
	{				
		#region FIELDS
		
		private FbConnection			connection;
		private FbTransaction			transaction;
		private FbParameterCollection	parameters;
		private UpdateRowSource			updatedRowSource;
		private CommandBehavior			commandBehavior;
		private GdsStatement			statement;
		private bool					disposed;
		private int						actualCommand;
		private string[]				commands;
		private string					commandText;
		private CommandType				commandType;
		private bool					designTimeVisible;
		private int						commandTimeout;
		private Regex					search;
		private MatchCollection			namedParameters;
		private bool					returnsSet;

		#endregion

		#region PROPERTIES

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandText"]/*'/>
		[Category("Data"),
		DefaultValue(""),
		RefreshProperties(RefreshProperties.All)]
		#if (!_MONO)
		[Editor(typeof(Design.CommandTextUIEditor), typeof(System.Drawing.Design.UITypeEditor))]
		#endif
		public string CommandText
		{
			get { return this.commandText; }
			set 
			{ 				
				if (this.statement != null && this.commandText != value && 
					this.commandText != null && this.commandText.Length != 0)
				{
					this.statement.Drop();
					this.statement = null;
				}
				
				this.commandText	= value;
				this.actualCommand	= 0;
				this.splitBatchCommands();
			}
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandType"]/*'/>
		[Category("Data"),
		DefaultValue(CommandType.Text),
		RefreshProperties(RefreshProperties.All)]		
		public CommandType CommandType
		{
			get { return this.commandType; }
			set { this.commandType = value; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandTimeout"]/*'/>
		[ReadOnly(true),		
		DefaultValue(30)]		
		public int CommandTimeout
		{
			get { return this.commandTimeout; }
			set
			{
				if (value < 0) 
				{
					throw new ArgumentException("The property value assigned is less than 0.");
				}
				else
				{					
					throw new NotSupportedException();
				}
			}
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="CommandPlan"]/*'/>
		[Browsable(false)]		
		public string CommandPlan
		{
			get 
			{
				if (this.statement != null)
				{
					return this.statement.GetExecutionPlan();
				}
				else
				{
					return String.Empty;
				}
			}
		}

		IDbConnection IDbCommand.Connection
		{
			get { return this.Connection; }
			set { this.Connection = (FbConnection)value; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="Connection"]/*'/>
		[Category("Behavior"), DefaultValue(null)]
		public FbConnection Connection
		{
			get { return this.connection; }
			set
			{
				if (this.connection != null && 
					this.connection.DataReader != null)
				{
					throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");
				}

				if (this.transaction != null &&
					!this.transaction.IsUpdated)
				{
					throw new InvalidOperationException("The Connection property was changed while a transaction was in progress.");
				}

				/*
				 * The connection is associated with the transaction
				 * so set the transaction object to return a null reference 
				 * if the connection is reset.
				 */
				if (this.connection != value)
				{										
					if (this.Transaction != null)
					{
						this.Transaction = null;
					}

					if (this.statement != null)
					{
						this.statement.Drop();
						this.statement = null;
					}
				}

				this.connection = value;
			}
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="DesignTimeVisible"]/*'/>
		[Browsable(false),
		DesignOnly(true),
		DefaultValue(true)]
		public bool DesignTimeVisible
		{
			get { return designTimeVisible; }
			set { designTimeVisible = value; }
		}

		IDataParameterCollection IDbCommand.Parameters
		{
			get { return this.Parameters; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="Parameters"]/*'/>
		[Category("Data"),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public FbParameterCollection Parameters
		{
			get { return this.parameters; }
		}

		IDbTransaction IDbCommand.Transaction
		{
			get { return this.Transaction; }
			set { this.Transaction = (FbTransaction)value; }
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="Transaction"]/*'/>
		[Browsable(false),
		DataSysDescription("Tansaction context used by the command."),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]		
		public FbTransaction Transaction
		{
			get { return this.transaction; }
			set
			{
				if (this.connection != null && 
					this.connection.DataReader != null)
				{
					throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");
				}

				if (this.transaction != null)
				{
					if (this.transaction.IsUpdated)
					{
						this.transaction = value; 
					}
				}
				else
				{
					this.transaction = value;
				}
			}
		}
		
		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/property[@name="UpdatedRowSource"]/*'/>
		[Category("Behavior"), DefaultValue(UpdateRowSource.Both)]
		public UpdateRowSource UpdatedRowSource
		{
			get { return this.updatedRowSource; }
			set { this.updatedRowSource = value; }
		}
		
		internal CommandBehavior CommandBehavior
		{
			get { return this.commandBehavior; }
		}

		internal GdsStatement Statement
		{
			get { return this.statement; }
			set { this.statement = value; }
		}

		internal int RecordsAffected
		{
			get { return this.statement.RecordsAffected; }
		}

		internal bool IsDisposed
		{
			get { return this.disposed; }
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor"]/*'/>
		public FbCommand()
		{
			this.parameters			= new FbParameterCollection();
			this.updatedRowSource	= UpdateRowSource.Both;
			this.commandBehavior	= CommandBehavior.Default;
			this.actualCommand		= -1;
			this.commandText		= String.Empty;
			this.commandType		= CommandType.Text;		
			this.designTimeVisible	= true;
			this.commandTimeout		= 30;
			this.search				= new Regex("(@([a-zA-Z-$][a-zA-Z0-9_$]*))");
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor(System.String)"]/*'/>
		public FbCommand(string cmdText) : this()
		{
			this.CommandText = cmdText;
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor(System.String,FbConnection)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection) : this()
		{
			this.CommandText = cmdText;
			this.Connection	 = connection;
		}
		
		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/constructor[@name="ctor(System.String,FbConnection,Transaction)"]/*'/>
		public FbCommand(string cmdText, FbConnection connection, FbTransaction transaction) : this()
		{
			this.CommandText = cmdText;
			this.Connection  = connection;
			this.Transaction = transaction;
		}				 

		#endregion

		#region DESTRUCTORS

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if (!disposed)
			{
				try
				{
					if (disposing)
					{
						// Clear active commands
						if (connection.ActiveCommands != null)
						{
							connection.ActiveCommands.Remove(this);
						}

						// release any managed resources
						if (statement != null)
						{
							statement.Drop();
							statement = null;
						}

						commandText		= String.Empty;
						actualCommand	= -1;
						search			= null;
						namedParameters	= null;
						commands		= null;
					}
					
					// release any unmanaged resources
					
					disposed = true;
				}
				finally 
				{
					base.Dispose(disposing);
				}
			}
		}

		#endregion

		#region ICLONEABLE_METHODS

		object ICloneable.Clone()
		{
			FbCommand command = new FbCommand(CommandText, Connection, Transaction);

			command.CommandType	= this.CommandType;

			return command;
		}

		#endregion

		#region METHODS

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="Cancel"]/*'/>
		public void Cancel()
		{			
			throw new NotSupportedException();
		}
		
		IDbDataParameter IDbCommand.CreateParameter()
		{
			return CreateParameter();
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="CreateParameter"]/*'/>
		public FbParameter CreateParameter()
		{
			return new FbParameter();
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteNonQuery"]/*'/>
		public int ExecuteNonQuery()
		{
			checkCommand();

			try
			{
				actualCommand	= 0;
				returnsSet		= false;

				InternalPrepare();
				InternalExecute();
				
				// Retrive information about records affected by command execution
				statement.UpdateRecordsAffected();
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
			
			InternalSetOutputParameters();

			return statement.RecordsAffected;
		}
				
		IDataReader IDbCommand.ExecuteReader()
		{	
			return ExecuteReader();			
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteReader"]/*'/>
		public FbDataReader ExecuteReader()
		{	
			return ExecuteReader(CommandBehavior.Default);			
		}
		
		IDataReader IDbCommand.ExecuteReader(CommandBehavior behavior)
		{
			return ExecuteReader(behavior);
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteReader(System.Data.CommandBehavior)"]/*'/>
		public FbDataReader ExecuteReader(CommandBehavior behavior)
		{
			checkCommand();

			try
			{
				commandBehavior = behavior;
				returnsSet		= true;

				InternalPrepare();

				if ((commandBehavior & System.Data.CommandBehavior.SequentialAccess) == System.Data.CommandBehavior.SequentialAccess ||
					(commandBehavior & System.Data.CommandBehavior.SingleResult) == System.Data.CommandBehavior.SingleResult ||
					(commandBehavior & System.Data.CommandBehavior.SingleRow) == System.Data.CommandBehavior.SingleRow ||
					(commandBehavior & System.Data.CommandBehavior.CloseConnection) == System.Data.CommandBehavior.CloseConnection ||
					commandBehavior == System.Data.CommandBehavior.Default)				
				{
					InternalExecute();

					// Retrive information about records affected by command execution
					statement.UpdateRecordsAffected();
				}
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			return new FbDataReader(this);
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="ExecuteScalar"]/*'/>
		public object ExecuteScalar()
		{
			checkCommand();
			
			object val = null;

			try
			{
				actualCommand	= 0;
				returnsSet		= true;

				InternalPrepare();
				InternalExecute();

				// Gets only the values of the first row
				GdsValue[] values;
				if ((values = statement.Fetch()) != null)
				{
					val = values[0].Value;
				}

				// Retrive information about records affected by command execution
				statement.UpdateRecordsAffected();
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			return val;
		}

		/// <include file='Doc/en_EN/FbCommand.xml' path='doc/class[@name="FbCommand"]/method[@name="Prepare"]/*'/>
		public void Prepare()
		{
			checkCommand();

			try
			{
				returnsSet = false;

				InternalPrepare();
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		#endregion

		#region INTERNAL_METHODS

		internal void InternalPrepare()
		{
			if (statement == null)
			{
				if (commandType == CommandType.StoredProcedure)
				{
					commands[actualCommand] = parseSPCommandText();
				}
				if (transaction != null)
				{
					statement = connection.DbConnection.DB.CreateStatement(
						commands[actualCommand],
						Transaction.Transaction);
				}
				else
				{
					statement = connection.DbConnection.DB.CreateStatement(
						commands[actualCommand]);
				}
			}
			if (!statement.IsPrepared)
			{
				namedParameters = search.Matches(commands[actualCommand]);
				parseCommandText();

				statement.Allocate();				
				statement.Prepare();
				if (parameters.Count > 0)
				{
					statement.DescribeParameters();
				}

				// Add this command to the active command list
				if (connection.ActiveCommands != null)
				{
					if (!connection.ActiveCommands.Contains(this))
					{
						connection.ActiveCommands.Add(this);
					}
				}
			}
			else
			{
				// Close statement for subsequently executions
				statement.Close();
			}
		}

		internal void InternalExecute()
		{
			if (parameters.Count > 0)
			{
				parseParameters();
			}

			switch (CommandType)
			{
				case CommandType.Text:
				case CommandType.TableDirect:
					statement.Execute();
					break;

				case CommandType.StoredProcedure:
					statement.ExecuteStoredProc();
					break;
			}
		}

		internal bool NextResult()
		{
			bool returnValue = false;

			if (commandBehavior != CommandBehavior.SingleResult)
			{
				actualCommand++;

				if (actualCommand >= commands.Length)
				{
					actualCommand--;
				}
				else
				{
					string commandText = commands[actualCommand];

					if (commandText != null && commandText.Trim().Length > 0)
					{
						statement.Drop();
						statement = null;

						InternalPrepare();
						InternalExecute();

						returnValue = true;
					}
				}
			}		

			return returnValue;
		}
			
		internal void InternalSetOutputParameters()
		{
			if (this.CommandType == CommandType.StoredProcedure &&
				parameters.Count > 0)
			{
				IEnumerator paramEnumerator = Parameters.GetEnumerator();
				int i = 0;

				if (statement.Rows.Count > 0)
				{
					GdsValue[] values = (GdsValue[])statement.Rows[0];

					while (paramEnumerator.MoveNext())
					{
						FbParameter parameter = (FbParameter)paramEnumerator.Current;

						if (parameter.Direction == ParameterDirection.Output ||
							parameter.Direction == ParameterDirection.InputOutput ||
							parameter.Direction == ParameterDirection.ReturnValue)
						{
							parameter.Value = values[i].Value;
							i++;
						}
					}
				}
			}
		}

		#endregion

		#region PRIVATE_METHODS

		private string parseSPCommandText()
		{
			string	result = commands[actualCommand];

			if (!commandText.Trim().ToLower().StartsWith("execute procedure ") &&
				!commandText.Trim().ToLower().StartsWith("select "))
			{
				StringBuilder paramsText = new StringBuilder();

				// Append the stored proc parameter name
				paramsText.Append(commands[actualCommand]);
				if (parameters.Count > 0)
				{
					paramsText.Append("(");
					for (int i = 0; i < parameters.Count; i++)
					{
						if (parameters[i].Direction == ParameterDirection.Input ||
							parameters[i].Direction == ParameterDirection.InputOutput)
						{
							// Append parameter name to parameter list
							paramsText.Append(parameters[i].ParameterName);
							if (i != parameters.Count - 1)
							{
								paramsText = paramsText.Append(",");
							}
						}
					}
					paramsText.Append(")");
					paramsText.Replace(",)", ")");
					paramsText.Replace("()", "");
				}
				
				if (returnsSet)
				{
					result = "select * from "  + paramsText.ToString();
				}
				else
				{
					result = "execute procedure " + paramsText.ToString();
				}
			}

			return result;
		}

		private void parseParameters()
		{
			GdsRowDescription	gdsParams		= statement.Parameters;			
			string				parameterName	= String.Empty;
			
			if (gdsParams != null)
			{
				for (int i = 0; i < gdsParams.SqlD; i++)
				{
					parameterName = parameters[i].ParameterName;
					if (namedParameters.Count != 0)
					{
						try
						{
							parameterName = namedParameters[i].Value.Trim();
						}
						catch
						{
							parameterName = parameters[i].ParameterName;
						}
					}

					int index = parameters.IndexOf(parameterName);

					if (parameters[index].Value == System.DBNull.Value)
					{
						if ((gdsParams.SqlVar[i].SqlType & 1 ) == 0)
						{
							throw new InvalidOperationException("Input parameter value cannot be null.");
						}
						else
						{
							gdsParams.SqlVar[i].SqlInd	= -1;
							gdsParams.SqlVar[i].SqlData	= null;
						}
					}
					else
					{
						// Parameter value is not null
						gdsParams.SqlVar[i].SqlInd	= 0;

						Encoding encoding = gdsParams.SqlVar[i].Encoding;
						switch (gdsParams.SqlVar[i].SqlType & ~1)
						{
							case GdsCodes.SQL_TEXT:
							case GdsCodes.SQL_VARYING:
								string s = Convert.ToString(parameters[index].Value);
								// Check parameter value length
								if (encoding.GetByteCount(s) > gdsParams.SqlVar[i].SqlLen)
								{
									StringBuilder msg = new StringBuilder();

									msg.AppendFormat("Invalid length of {0} bytes, max length allowed {1} bytes, for parameter {2} index {3}", 
										encoding.GetByteCount(s),
										gdsParams.SqlVar[i].SqlLen,
										parameterName,
										index);

									throw new InvalidOperationException(msg.ToString());
								}
								gdsParams.SqlVar[i].SqlData = encoding.GetBytes(s);
								break;

							case GdsCodes.SQL_SHORT:
								if (gdsParams.SqlVar[i].SqlScale < 0)
								{
									decimal paramValue = Convert.ToDecimal(parameters[index].Value);
									gdsParams.SqlVar[i].SqlData = 
										Convert.ToInt16(
											GdsEncodeType.EncodeDecimal(									
												paramValue,
												gdsParams.SqlVar[i].SqlScale,
												gdsParams.SqlVar[i].SqlType));
								}
								else
								{										
									gdsParams.SqlVar[i].SqlData = Convert.ToInt16(parameters[index].Value);
								}
								break;

							case GdsCodes.SQL_LONG:
								if (gdsParams.SqlVar[i].SqlScale < 0)
								{
									decimal paramValue = Convert.ToDecimal(parameters[index].Value);
									gdsParams.SqlVar[i].SqlData = 
										Convert.ToInt32(
											GdsEncodeType.EncodeDecimal(
												paramValue,
												gdsParams.SqlVar[i].SqlScale,
												gdsParams.SqlVar[i].SqlType));
								}
								else
								{
									gdsParams.SqlVar[i].SqlData = Convert.ToInt32(parameters[index].Value);
								}
								break;

							case GdsCodes.SQL_QUAD:
							case GdsCodes.SQL_INT64:
								if (gdsParams.SqlVar[i].SqlScale < 0)
								{
									decimal paramValue = Convert.ToDecimal(parameters[index].Value);
									gdsParams.SqlVar[i].SqlData = 
										Convert.ToInt64(
											GdsEncodeType.EncodeDecimal(
													paramValue,
													gdsParams.SqlVar[i].SqlScale,
													gdsParams.SqlVar[i].SqlType));
								}
								else
								{										
									gdsParams.SqlVar[i].SqlData = Convert.ToInt64(parameters[index].Value);
								}
								break;

							case GdsCodes.SQL_FLOAT:
								gdsParams.SqlVar[i].SqlData = Convert.ToSingle(parameters[index].Value);
								break;

							case GdsCodes.SQL_DOUBLE:
							case GdsCodes.SQL_D_FLOAT:
								gdsParams.SqlVar[i].SqlData = Convert.ToDouble(parameters[index].Value);
								break;

							case GdsCodes.SQL_BLOB:
							{
								GdsTransaction txn = null;
								if (transaction != null)
								{
									// Get the command explicit transaction
									txn = transaction.Transaction;
								}
								else
								{
									// Get the command implicit transaction
									txn = statement.Transaction;
								}

								if (gdsParams.SqlVar[i].SqlSubType == 1)
								{
									GdsAsciiBlob clob = new GdsAsciiBlob(
										connection.DbConnection.DB,
										txn);
									clob.Write(Convert.ToString(parameters[index].Value));
									gdsParams.SqlVar[i].SqlData = clob.Handle;
									clob.Close();
								}
								else
								{
									GdsBinaryBlob blob = new GdsBinaryBlob(
										connection.DbConnection.DB,
										txn);
									blob.Write((byte[])parameters[index].Value);
									gdsParams.SqlVar[i].SqlData = blob.Handle;
									blob.Close();
								}
							}
							break;

							case GdsCodes.SQL_ARRAY:
							{
								GdsTransaction txn = null;
								if (transaction != null)
								{
									// Get the command explicit transaction
									txn = transaction.Transaction;
								}
								else
								{
									// Get the command implicit transaction
									txn = statement.Transaction;
								}

								GdsArray array = new GdsArray(
									connection.DbConnection.DB,
									txn,
									0,
									gdsParams.SqlVar[i].RelName,
									gdsParams.SqlVar[i].SqlName);
						
								array.Write((System.Array)parameters[index].Value);
								gdsParams.SqlVar[i].SqlData = array.Handle;
							}
							break;

							case GdsCodes.SQL_TYPE_DATE:
							case GdsCodes.SQL_TYPE_TIME:
							case GdsCodes.SQL_TIMESTAMP:
								gdsParams.SqlVar[i].SqlData = Convert.ToDateTime(parameters[index].Value);
								break;

							default:
								throw new NotSupportedException("Unknown data type");
						}							
					}
				}

				statement.Parameters = gdsParams;
			}
		}

		private void parseCommandText()
		{
			string sqlText = commands[actualCommand];

			if (namedParameters.Count != 0)
			{
				sqlText = search.Replace(sqlText, "?");
			}

			statement.CommandText = sqlText;
		}

		private void checkCommand()
		{
			if (connection == null || connection.State != ConnectionState.Open)
			{
				throw new InvalidOperationException("Connection must valid and open");
			}

			if (connection.DataReader != null)
			{
				throw new InvalidOperationException("There is already an open DataReader associated with this Connection which must be closed first.");
			}

			if (connection.ActiveTransaction != null &&
				!connection.ActiveTransaction.IsUpdated &&
				this.Transaction == null)
			{
				throw new InvalidOperationException("Execute requires the Command object to have a Transaction object when the Connection object assigned to the command is in a pending local transaction.  The Transaction property of the Command has not been initialized.");
			}

			if (transaction != null &&
				!connection.Equals(transaction.Connection))
			{
				throw new InvalidOperationException("Command Connection is not equal to Transaction Connection.");
			}

			if (commandText == String.Empty || commandText == null)
			{
				throw new InvalidOperationException ("The command text for this Command has not been set.");
			}
		}

		private void splitBatchCommands()
		{
			MatchCollection matches = Regex.Matches(
				this.commandText,
				"([^';]+('[^']*'))*[^';]*(?=;*)");

			commands = new string[matches.Count/2];
			int count = 0;
			for (int i = 0; i < matches.Count; i++)
			{
				if (matches[i].Value.Trim() != String.Empty)
				{
					this.commands[count] = matches[i].Value.Trim();
					count++;
				}
			}
		}

		#endregion
	}
}
