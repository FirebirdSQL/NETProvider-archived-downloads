FirebirdClient ADO.NET 2.0 Data provider for .NET and Mono 
==========================================================

This project is supported by:
---- ------- -- --------- ---

	Sean Leyne ( Broadview Software )


Developement list
-----------------

You can subscribe to the developement list at:

	http://lists.sourceforge.net/lists/listinfo/firebird-net-provider


You can access to the lastest developement sources through CVS, see:

	http://sourceforge.net/cvs/?group_id=9028


Reporting Bugs
--------------

Yo can report bugs using two ways:

1. Sending it to the developement list.
2. If you have a Sourceforge ID you can send it using the Bugs section of the Firebird Project web page (category .Net Provider):


	http://sourceforge.net/tracker/?group_id=9028&atid=109028


