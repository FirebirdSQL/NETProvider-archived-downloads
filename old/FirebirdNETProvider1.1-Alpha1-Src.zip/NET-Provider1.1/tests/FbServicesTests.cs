//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using NUnit.Framework;

using System;
using System.IO;
using System.Data;

using FirebirdSql.Data.Firebird;
using FirebirdSql.Data.Firebird.Services;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbServicesTest : BaseTest 
	{	
		[Test]
		public void BackupTest()
		{
			FbBackup backupSvc = new FbBackup();
			
			backupSvc.UserName 		= User;
			backupSvc.UserPassword 	= Password;
			
			backupSvc.Database = Database;
			backupSvc.BackupFiles.Add(new FbBackupFile(@"c:\testdb.gbk", 2048));
			backupSvc.Verbose = true;
			
			backupSvc.Options = FbBackupFlags.IgnoreLimbo;
			
			backupSvc.Start();

			string lineOutput;
			while((lineOutput = backupSvc.GetNextLine()) != null)
			{
				Console.WriteLine(lineOutput);
			}

			backupSvc.Close();
		}
		
		[Test]
		public void RestoreTest()
		{
			FbRestore restoreSvc = new FbRestore();
			
			restoreSvc.UserName 		= User;
			restoreSvc.UserPassword 	= Password;
			
			restoreSvc.Database = @"c:\testdb.gdb";
			restoreSvc.BackupFiles.Add(new FbBackupFile(@"c:\testdb.gbk", 2048));
			restoreSvc.Verbose	= true;
			restoreSvc.PageSize = 4096;
			restoreSvc.Options	= FbRestoreFlags.Create | FbRestoreFlags.Replace; 

			restoreSvc.Start();

			string lineOutput;
			while((lineOutput = restoreSvc.GetNextLine()) != null)
			{
				Console.WriteLine(lineOutput);
			}

			restoreSvc.Close();
		}

		[Test]
		public void ValidationTest()
		{
			FbValidation validationSvc = new FbValidation();
			
			validationSvc.UserName 		= User;
			validationSvc.UserPassword 	= Password;
			
			validationSvc.Database 	= Database;
			validationSvc.Options	= FbValidationFlags.ValidateDatabase; 

			validationSvc.Start();

			string lineOutput;
			while((lineOutput = validationSvc.GetNextLine()) != null)
			{
				Console.WriteLine(lineOutput);
			}

			validationSvc.Close();
		}		
		
		[Test]
		public void SetPropertiesTest()
		{
			FbConfiguration configurationSvc = new FbConfiguration();
			
			configurationSvc.UserName 		= User;
			configurationSvc.UserPassword 	= Password;
			
			configurationSvc.Database 	= Database;
						
			configurationSvc.SetSweepInterval(1000);
			configurationSvc.SetReserveSpace(true);
			configurationSvc.SetForcedWrites(true);
			configurationSvc.DatabaseShutdown(FbShutdownMode.Forced, 1000);
			configurationSvc.DatabaseOnline();
		}		
		
		[Test]
		public void StatisticsTest()
		{
			FbStatistical statisticalSvc = new FbStatistical();
			
			statisticalSvc.UserName 	= User;
			statisticalSvc.UserPassword = Password;
			
			statisticalSvc.Database = Database;
			statisticalSvc.Options	= FbStatisticalFlags.SystemTablesRelations;
						
			statisticalSvc.Start();

			string lineOutput;
			while((lineOutput = statisticalSvc.GetNextLine()) != null)
			{
				Console.WriteLine(lineOutput);
			}

			statisticalSvc.Close();
		}
		
		[Test]
		public void FbLogTest()
		{
			FbLog logSvc = new FbLog();
			
			logSvc.UserName 		= User;
			logSvc.UserPassword 	= Password;
									
			logSvc.Start();

			string lineOutput;
			while((lineOutput = logSvc.GetNextLine()) != null)
			{
				Console.WriteLine(lineOutput);
			}

			logSvc.Close();
		}

		[Test]
		public void AddUserTest()
		{
			FbSecurity securitySvc = new FbSecurity();
			
			securitySvc.UserName 		= User;
			securitySvc.UserPassword 	= Password;
			
			FbUserData user = new FbUserData();
			
			user.UserName 		= "new_user";
			user.UserPassword 	= "1";
			
			securitySvc.AddUser(user);
		}
		
		[Test]
		public void DeleteUser()
		{
			FbSecurity securitySvc = new FbSecurity();
			
			securitySvc.UserName 		= User;
			securitySvc.UserPassword 	= Password;
			
			FbUserData user = new FbUserData();
			
			user.UserName = "new_user";
						
			securitySvc.DeleteUser(user);
		}

		[Test]
		public void DisplayUsers()
		{
			FbSecurity securitySvc = new FbSecurity();
			
			securitySvc.UserName 		= User;
			securitySvc.UserPassword 	= Password;
											
			FbUserData[] users = securitySvc.DisplayUsers();
		}
		
		[Test]
		public void ServerPropertiesTest()
		{
			FbServerProperties serverProp = new FbServerProperties();
			
			serverProp.UserName 		= User;
			serverProp.UserPassword 	= Password;
						
			FbServerConfig 	serverConfig	= serverProp.ServerConfig;
			FbDatabasesInfo databasesInfo	= serverProp.DatabasesInfo;
			string			messageFile		= serverProp.MessageFile;
			string			lockManager		= serverProp.LockManager;
			string			rootDirectory	= serverProp.RootDirectory;
			string			implementation	= serverProp.Implementation;
			string 			serverVersion	= serverProp.ServerVersion;
			int				version			= serverProp.Version;						
		}
	}
}
