SET SQL DIALECT 3;

SET NAMES ISO8859_1;



SET TERM ^ ; 



/******************************************************************************/
/***                           Stored Procedures                            ***/
/******************************************************************************/

CREATE PROCEDURE GETVARCHARFIELD (
    ID INTEGER)
RETURNS (
    VARCHAR_FIELD VARCHAR(100))
AS
BEGIN
  EXIT;
END^



SET TERM ; ^


/******************************************************************************/
/***                                 Tables                                 ***/
/******************************************************************************/

CREATE TABLE TEST_TABLE_01 (
    INT_FIELD        INTEGER DEFAULT 0 NOT NULL,
    CHAR_FIELD       CHAR(30),
    VARCHAR_FIELD    VARCHAR(100),
    BIGINT_FIELD     BIGINT,
    SMALLINT_FIELD   SMALLINT,
    DOUBLE_FIELD     DOUBLE PRECISION,
    NUMERIC_FIELD    NUMERIC(15,2),
    DECIMAL_FIELD    DECIMAL(15,2),
    DATE_FIELD       DATE,
    TIME_FIELD       TIME,
    TIMESTAMP_FIELD  TIMESTAMP,
    CLOB_FIELD       BLOB SUB_TYPE 1 SEGMENT SIZE 80,
    BLOB_FIELD       BLOB SUB_TYPE 0 SEGMENT SIZE 80,
    IARRAY_FIELD     INTEGER [1:4],
    SARRAY_FIELD     SMALLINT [1:5],
    LARRAY_FIELD     BIGINT [1:6],
    FARRAY_FIELD     FLOAT [1:4],
    BARRAY_FIELD     DOUBLE PRECISION [1:4],
    NARRAY_FIELD     NUMERIC(10,6) [1:4],
    DARRAY_FIELD     DATE [1:4],
    TARRAY_FIELD     TIME [1:4],
    TSARRAY_FIELD    TIMESTAMP [1:4],
    CARRAY_FIELD     CHAR(20) [1:4],
    VARRAY_FIELD     VARCHAR(30) [1:4]
);



/******************************************************************************/
/***                              Primary Keys                              ***/
/******************************************************************************/

ALTER TABLE TEST_TABLE_01 ADD CONSTRAINT PK_TEST_TABLE_01 PRIMARY KEY (INT_FIELD);


/******************************************************************************/
/***                           Stored Procedures                            ***/
/******************************************************************************/


SET TERM ^ ;

ALTER PROCEDURE GETVARCHARFIELD (
    ID INTEGER)
RETURNS (
    VARCHAR_FIELD VARCHAR(100))
AS
begin
    for select varchar_field from test_table_01 where int_field = :id into :varchar_field
    do
        suspend;
end
^


SET TERM ; ^
