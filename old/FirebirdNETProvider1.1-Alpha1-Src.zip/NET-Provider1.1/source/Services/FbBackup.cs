//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird.Services
{	
	/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="T:FbBackupFlags"]/*'/>	
    [Flags] 
    public enum FbBackupFlags
    {
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.IgnoreChecksums"]/*'/>
		IgnoreChecksums		= 0x01,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.IgnoreLimbo"]/*'/>	
		IgnoreLimbo			= 0x02,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlagsMetaDataOnly"]/*'/>
		MetaDataOnly		= 0x04,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.NoGarbageCollect"]/*'/>	
		NoGarbageCollect	= 0x08,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.OldDescriptions"]/*'/>
		OldDescriptions		= 0x10,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.NonTransportable"]/*'/>
		NonTransportable	= 0x20,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.Convert"]/*'/>		
		Convert				= 0x40,
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFlags.Expand"]/*'/>
		Expand				= 0x80
    }

	/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="T:FbBackupFile"]/*'/>	
	public struct FbBackupFile
	{
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:FbBackupFile.BackupFile"]/*'/>	
		public string	BackupFile;
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:FbBackupFile.BackupLength"]/*'/>	
		public int		BackupLength;
		
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:FbBackupFile.#ctor"]/*'/>	
		public FbBackupFile(string fileName, int fileLength)
		{
			BackupFile		= fileName;
			BackupLength	= fileLength;
		}
	}

	/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="T:FbBackup"]/*'/>	
	public sealed class FbBackup : FbService
	{
		#region FIELDS
		
		private string			database;
		private bool			verbose;
		
		private ArrayList		backupFiles;
		
		private int				factor;
		
		private FbBackupFlags	options;
		
		#endregion
		
		#region PROPERTIES

		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get { return database; }
			set { database = value; }
		}
		
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:BackupFiles"]/*'/>
		public ArrayList BackupFiles
		{
			get { return backupFiles; }
			set { backupFiles = value; }
		}

		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:Verbose"]/*'/>
		public bool	Verbose
		{
			get { return verbose; }
			set { verbose = value; }
		}

		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:Factor"]/*'/>
		public int Factor
		{
			get { return factor; }
			set { factor = value; }
		}
		
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="P:Options"]/*'/>
		public FbBackupFlags Options
		{
			get { return options; }
			set { options = value; }
		}
		
		#endregion
		
		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbBackup() : base()
		{			
			database 		= String.Empty;
			verbose			= false;			
			backupFiles		= new ArrayList();			
			factor			= 0;
		}
		
		#endregion
		
		#region METHODS
		
		/// <include file='xmldoc/fbbackup.xml' path='doc/member[@name="M:Start"]/*'/>		
		public void Start()
		{
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_backup);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			foreach(FbBackupFile bkpFile in backupFiles)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_bkp_file, bkpFile.BackupFile);
				startSpb.SetSpbProperty(GdsCodes.isc_spb_bkp_length, bkpFile.BackupLength);
			}
			if (verbose)
			{
				startSpb.SetProperty(GdsCodes.isc_spb_verbose);
			}
			startSpb.SetSpbProperty(GdsCodes.isc_spb_options, (int)options);
			
			// Start execution
			startTask();
			
			// Reset ParameterBlock
			startSpb.Reset();
		}
				
		#endregion
	}
}
