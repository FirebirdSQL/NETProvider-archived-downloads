//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird.Services
{	
	/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="T:FbRestoreFlags"]/*'/>
    [Flags] 
    public enum FbRestoreFlags
    {
    	/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.DeactivateIndexes"]/*'/>
		DeactivateIndexes			= 0x0100,
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.NoShadow"]/*'/>
		NoShadow					= 0x0200,
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.NoValidity"]/*'/>
		NoValidity					= 0x0400,
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.IndividualCommit"]/*'/>
		IndividualCommit			= 0x0800,
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.Replace"]/*'/>
		Replace						= 0x1000,
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.Create"]/*'/>
		Create						= 0x2000,
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:FbRestoreFlags.UseAllSpace"]/*'/>
		UseAllSpace					= 0x4000
    }
		
	/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="T:FbRestore"]/*'/>
	public sealed class FbRestore : FbService
	{
		#region FIELDS

		private	string				database;
		private ArrayList			backupFiles;
		private bool				verbose;
		private int					pageBuffers;
		private int					pageSize;
		private FbRestoreFlags		options;
		
		#endregion
		
		#region PROPERTIES
		
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get { return database; }
			set { database = value; }
		}
		
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="P:BackupFiles"]/*'/>
		public ArrayList BackupFiles
		{
			get { return backupFiles; }
			set { backupFiles = value; }
		}

		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="P:Verbose"]/*'/>
		public bool	Verbose
		{
			get { return verbose; }
			set { verbose = value; }
		}		

		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="P:Pagebuffers"]/*'/>
		public int PageBuffers
		{
			get { return pageSize; }
			set { pageSize = value; }
		}
		
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="P:PageSize"]/*'/>
		public int PageSize
		{
			get { return pageSize; }
			set 
			{
				if (pageSize != 1024 && pageSize != 2048 && pageSize != 4096 &&
				    pageSize != 8192 && pageSize != 16384)
				{
					throw new InvalidOperationException("Invalid page size.");    	
				}
				pageSize = value; 
			}
		}

		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="P:Options"]/*'/>
		public FbRestoreFlags Options
		{
			get { return options; }
			set { options = value; }
		}
		
		#endregion
		
		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:#ctor"]/*'/>		
		public FbRestore() : base()
		{
			database		= String.Empty;				
			backupFiles		= new ArrayList();			
			verbose			= false;		
			pageSize		= 4096;
			pageBuffers		= 2048;
		}
		
		#endregion
		
		#region METHODS
		
		/// <include file='xmldoc/fbrestore.xml' path='doc/member[@name="M:Start"]/*'/>
		public void Start()
		{			
			// Configure Spb
			startSpb = new FbParameterBlock();
			startSpb.SetProperty(GdsCodes.isc_action_svc_restore);			
			foreach(FbBackupFile bkpFile in backupFiles)
			{
				startSpb.SetSpbProperty(GdsCodes.isc_spb_bkp_file, bkpFile.BackupFile);
			}
			startSpb.SetSpbProperty(GdsCodes.isc_spb_dbname, database);
			if (verbose)
			{
				startSpb.SetProperty(GdsCodes.isc_spb_verbose);
			}
			startSpb.SetSpbProperty(GdsCodes.isc_spb_res_buffers, pageBuffers);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_res_page_size, pageSize);
			startSpb.SetSpbProperty(GdsCodes.isc_spb_options, (int)options);
			
			// Start execution
			startTask();
			
			// Reset ParameterBlock
			startSpb.Reset();
		}
				
		#endregion		
	}
}
