//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Logging
{	
	/// <summary>
	/// Describe class <code>Logger</code> here.
	/// </summary>
	internal abstract class Logger
	{	
		abstract public bool isDebugEnabled();
	
		abstract public void debug(object message);
	
		abstract public void debug(object message, Exception ex);
	
		abstract public bool isInfoEnabled();
	
		abstract public void info(object message);
	
		abstract public void info(object message, Exception ex);
	
		abstract public bool isWarnEnabled();
	
		abstract public void warn(object message);
	
		abstract public void warn(object message, Exception ex);
	
		abstract public bool isErrorEnabled();
	
		abstract public void error(object message);
	
		abstract public void error(object message, Exception ex);
	
		abstract public bool isFatalEnabled();
	
		abstract public void fatal(object message);
	
		abstract public void fatal(object message, Exception ex);
	}
}
