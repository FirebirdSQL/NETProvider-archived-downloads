//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Reflection;

namespace FirebirdSql.Logging
{
	/// <summary>
	/// Describe class <code>LoggerFactory</code> here.
	/// </summary>
	internal class LoggerFactory
	{
		#region FIELDS

		private static bool _checked = false;
		private static bool log4j = false;

		#endregion
    
		#region METHODS

		public static Logger GetLogger(string name, bool def) 
		{
			if (!_checked)
			{
				try 
				{
					Type verify = Type.GetType("Firebird.Log4CSharp");
					log4j = true;
				}
				catch (TypeLoadException)
				{
					log4j = false;
				}
				_checked = true;
			}
			
			if (log4j)
				return new Log4jLogger(name);
			else
				return null;
		}		
    
		public static Logger GetLogger(System.Type clazz, bool def) 
		{
			return GetLogger(clazz.Name, def);
		}

		#endregion
	}
}
