//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Net;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/parameterbuffer.xml' path='doc/member[@name="T:ParameterBuffer"]/*'/>
	internal class ParameterBuffer : IParameterBuffer
	{
		#region FIELDS

		private BinaryWriter 	buffer;
		
		#endregion
		
		#region FIELDS
		
		public int Length
		{
			get { return GetContents().Length; }
		}
		
		#endregion
		
		#region CONSTRUCTORS
		
		public ParameterBuffer()
		{
			buffer = new BinaryWriter(new MemoryStream());
		}
		
		#endregion			
		
		#region METHODS
				
		public void Append(int type)
		{
			buffer.Write((byte)type);
		}

		public void Append(int type, byte content)
		{						
			buffer.Write((byte)type);
			buffer.Write((byte)1);
			buffer.Write(content);
		}

		public void Append(int type, short content)
		{						
			buffer.Write((byte)type);
			buffer.Write((byte)2);
			buffer.Write((short)IPAddress.NetworkToHostOrder(content));
		}

		public void Append(int type, int content)
		{
			buffer.Write((byte)type);
			buffer.Write((byte)4);
			buffer.Write((int)IPAddress.NetworkToHostOrder(content));
		}

		public void Append(int type, byte[] content)
		{						
			buffer.Write((byte)type);
			buffer.Write((byte)content.Length);
			buffer.Write(content);
		}

		public void AppendSpb(int type, byte[] content)
		{						
			buffer.Write((byte)type);
			buffer.Write((short)content.Length);
			buffer.Write(content);
		}

		public void AppendSpb(int type, byte content)
		{						
			buffer.Write((byte)type);
			buffer.Write(content);
		}

		public void AppendSpb(int type, int content)
		{						
			buffer.Write((byte)type);
			buffer.Write(content);			
		}

		public byte[] GetContents()
		{
			return ((MemoryStream)(buffer.BaseStream)).ToArray();
		}

		public void Close()
		{
			buffer.Close();		
		}
				
		#endregion
	}
}
