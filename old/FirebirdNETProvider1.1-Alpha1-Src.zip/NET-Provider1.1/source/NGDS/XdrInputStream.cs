//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Text;
using System.Net;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/xdrinputstream.xml' path='doc/member[@name="T:XdrInputStream"]/*'/>
	internal class XdrInputStream : BinaryReader
	{
		#region FIELDS

		private byte[] pad = new byte[4];

		#endregion

		#region CONSTRUCTORS

		public XdrInputStream(Stream input) : base(input)
		{			
		}

		#endregion 

		#region METHODS
			
		public byte[] ReadOpaque(int len)
		{
			byte[] buffer = new byte[len];

			int readed = 0;
			while (readed < len)
			{
				readed += Read(buffer, readed, len-readed);
			}
			Read(pad, 0, ((4 - len) & 3));

			return buffer;
		}

		public byte[] ReadBuffer()
		{
			int 	len 	= this.ReadInt();
			byte[] 	buffer 	= new byte[len];
			
			int readed = 0;
			while (readed < len)
			{				
				readed += Read(buffer, readed, len - readed);
			}
			Read(pad, 0, ((4 - len) & 3));
			
			return buffer;
		}

		public byte[] ReadSlice(ISC_ARRAY_DESC desc)
		{
			int realLength 		= ReadInt();
			int totalElements	= (realLength + ((4 - desc.array_desc_length) & 3)) / desc.array_desc_length;
			int	currentElement	= 0;
			int readed 			= 0;
			
			// Skip Length bytes
			ReadBytes(4);
			
			if (desc.array_desc_dtype == GdsCodes.blr_short)
			{
				realLength = realLength * desc.array_desc_length;
			}

			byte[] slice = new byte[realLength];
			
			while (readed < realLength)
			{
				switch (desc.array_desc_dtype)
				{
					case GdsCodes.blr_text:
					case GdsCodes.blr_text2:
					case GdsCodes.blr_cstring:
					case GdsCodes.blr_cstring2:
					{												
						// Skip fill bytes
						if (((4 - desc.array_desc_length) & 3) != 0)
						{
							readed += Read(slice, readed, desc.array_desc_length);
							Read(pad, 0, ((4 - desc.array_desc_length) & 3));
						}
						else
						{
							readed += Read(slice, readed, realLength);	
						}
					}
					break;

					case GdsCodes.blr_varying:
					case GdsCodes.blr_varying2:
					{						
						byte[] tmp = ReadBytes(4);												
						tmp.CopyTo(slice, readed);
						readed += 4;
						
						int itemLength = BitConverter.ToInt32(tmp, 0);						
						itemLength = IPAddress.HostToNetworkOrder(itemLength);
						
						if (itemLength != 0)
						{
							readed += Read(slice, readed, itemLength);
							
							// Skip fill bytes
							if (((4 - itemLength) & 3) != 0)
							{
								Read(pad, 0, ((4 - itemLength) & 3));
							}
						}
						currentElement++;
						
						if (currentElement == totalElements)
						{
							readed = realLength;
						}
					}
					break;
									
					default:
						readed += Read(slice, readed, realLength - readed);
						break;
				}
			}
						
			return slice;
		}

		public override string ReadString()
		{
			int len = this.ReadInt();
			byte[] buffer = new byte[len];
						
			Read(buffer, 0, len);
			Read(pad, 0, ((4 - len) & 3));
			
			return Encoding.Default.GetString(buffer);
		}

		public int ReadInt()
		{
			return IPAddress.HostToNetworkOrder(base.ReadInt32());
		}

		public long ReadLong()
		{
			return IPAddress.HostToNetworkOrder(base.ReadInt64());
		}

		public override float ReadSingle()
		{			
			FloatLayout floatValue = new FloatLayout();

			floatValue.f  = base.ReadSingle();
			floatValue.i0 = IPAddress.HostToNetworkOrder(floatValue.i0);

			return floatValue.f;
		}
		
		public override double ReadDouble()
		{			
			DoubleLayout doubleValue = new DoubleLayout();
			int temp;			

			doubleValue.d = base.ReadDouble();
			doubleValue.i0 = IPAddress.HostToNetworkOrder(doubleValue.i0);
			doubleValue.i4 = IPAddress.HostToNetworkOrder(doubleValue.i4);

			temp = doubleValue.i0;
			doubleValue.i0 = doubleValue.i4;
			doubleValue.i4 = temp;

			return doubleValue.d;
		}		

		#endregion
	}
}
