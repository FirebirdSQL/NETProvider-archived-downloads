//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Net;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/xdroutputstream.xml' path='doc/member[@name="T:XdrOutputStream"]/*'/>
	internal class XdrOutputStream : BinaryWriter
	{	
		#region FIELDS

		private byte[] fill = new byte[32767];
		private byte[] pad 	= {0,0,0,0};

		#endregion 

		#region CONSTRUCTORS

		public XdrOutputStream(Stream output) : base(output)
		{
			for (int i = 0; i < fill.Length; i++)
			{
				fill[i] = 32;
			}
		}		

		#endregion

		#region METHODS
		 
		public void WriteOpaque(byte[] buffer, int len)
		{
			if (buffer != null && len > 0) 
			{
				Write(buffer, 0, buffer.Length);
				Write(fill, 0, len - buffer.Length);
				Write(pad, 0, ((4 - len) & 3));
			}
		}

		public void WriteBuffer(byte[] buffer, int len)
		{
			WriteInt(len);
			if (buffer != null && len > 0) 
			{
				Write(buffer, 0, len);
				Write(pad, 0, ((4 - len) & 3));
			}
		}

		public void WriteBlobBuffer(byte[] buffer)
		{
			int len = buffer.Length ; // 2 for short for buffer length
			
			if (len > short.MaxValue) 
			{
				throw(new IOException()); //Need a value???
			}
			WriteInt(len + 2);
			WriteInt(len + 2); //bizarre but true! three copies of the length
			Write((byte)((len >> 0) & 0xff));
			Write((byte)((len >> 8) & 0xff));
			Write(buffer, 0, len);
						
			Write(pad, 0, ((4 - len + 2) & 3));
		}

		public void WriteString(string s)
		{							
			WriteString(s, Encoding.Default);
		}
	    
		public void WriteString(string s, Encoding encoding)
		{	        				        
			byte[] buffer;
	        
			buffer = encoding.GetBytes(s);

			WriteBuffer(buffer, encoding.GetByteCount(s));
		}
	    
		public void WriteSet(int type, ArrayList s)
		{
			if (s == null) 
			{
				WriteInt(1);
				Write((byte)type); //e.g. gds.isc_tpb_version3
			}
			else 
			{
				WriteInt(s.Count + 1);
				Write((byte)type);
				IEnumerator i = s.GetEnumerator();
				while (i.MoveNext()) 
				{
					int n = (int)i.Current;
					Write((byte)n);
				}
				Write(pad, 0, ((4 - (s.Count + 1)) & 3));
			}
		}
				
		public void WriteSlice(IGDS gds, ISC_ARRAY_DESC desc, System.Array source_array, int sliceLength, Encoding encoding)
		{
			IEnumerator i 		= source_array.GetEnumerator();
			int			written = 0;
						
			WriteInt(sliceLength);
			
			while(i.MoveNext())
			{
				switch (desc.array_desc_dtype)
				{
					case GdsCodes.blr_text:
					case GdsCodes.blr_text2:
					case GdsCodes.blr_cstring:
					case GdsCodes.blr_cstring2:
					{
						// Char
						int len = encoding.GetMaxByteCount(desc.array_desc_length);
						WriteOpaque(
							encoding.GetBytes((string)i.Current),
							len);
						
						written += len + ((4 - len) & 3);
					}
					break;

					case GdsCodes.blr_varying:
					case GdsCodes.blr_varying2:
					{	
						// VarChar
						int len = encoding.GetByteCount((string)i.Current);
						WriteInt(len);
						WriteOpaque(
							encoding.GetBytes((string)i.Current),
							len);
						
						written += encoding.GetMaxByteCount(desc.array_desc_length) +
									((4 - encoding.GetMaxByteCount(desc.array_desc_length)) & 3);
					}
					break;
	
					case GdsCodes.blr_short:
					{
						// Short/Smallint
						if (desc.array_desc_scale < 0)
						{				
							short svalue = (short)gds.EncodeDecimal(
												(decimal)i.Current,
												desc.array_desc_scale,
												GdsCodes.SQL_SHORT);
							WriteShort(svalue);
						}
						else
						{
							WriteShort((short)i.Current);
						}
						
						written += desc.array_desc_length;
					}
					break;
	
					case GdsCodes.blr_long:
					{
						// Integer
						if (desc.array_desc_scale < 0)
						{
							int ivalue = (int)gds.EncodeDecimal(
												(decimal)i.Current,
												desc.array_desc_scale,
												GdsCodes.SQL_LONG);
							WriteInt(ivalue);
						}
						else
						{
							WriteInt((int)i.Current);
						}
						
						written += desc.array_desc_length;
					}
					break;
					
					case GdsCodes.blr_float:
					{
						// Float
						WriteFloat((float)i.Current);
						
						written += desc.array_desc_length;
					}
					break;
										
					case GdsCodes.blr_double:
					case GdsCodes.blr_d_float:
					{
						// Double
						WriteDouble((double)i.Current);
						
						written += desc.array_desc_length;
					}
					break;
													
					case GdsCodes.blr_quad:
					case GdsCodes.blr_int64:
					{
						// Long/Quad
						if (desc.array_desc_scale < 0)
						{
							long lvalue = (long)gds.EncodeDecimal(
												(decimal)i.Current,
												desc.array_desc_scale,
												GdsCodes.SQL_INT64);
							WriteLong(lvalue);
						}
						else
						{
							WriteLong((long)i.Current);
						}
						
						written += desc.array_desc_length;
					}
					break;
					
					case GdsCodes.blr_timestamp:
					{
						// TimeStamp
						WriteInt(gds.EncodeDate((DateTime)i.Current));	// Date
						WriteInt(gds.EncodeTime((DateTime)i.Current));	// Time
						
						written += desc.array_desc_length;
					}
					break;
					
					case GdsCodes.blr_sql_time:			
					{
						// Time
						WriteInt(gds.EncodeTime((DateTime)i.Current));
						
						written += desc.array_desc_length;
					}
					break;

					case GdsCodes.blr_sql_date:
					{
						// Date
						WriteInt(gds.EncodeDate((DateTime)i.Current));
						
						written += desc.array_desc_length;
					}
					break;
					
					default:
						throw new NotSupportedException("Unknown data type");
				}
			}

			// Check partial update
			if (written != sliceLength)
			{
				int fillBytes = 0;

				fillBytes = sliceLength - written;
				
				switch (desc.array_desc_dtype)
				{
					case GdsCodes.blr_short:
						fillBytes *= 2;
						break;
					
					case GdsCodes.blr_varying:
					case GdsCodes.blr_varying2:
						int elements = (fillBytes + ((4 - desc.array_desc_length) & 3)) / desc.array_desc_length;
						fillBytes = elements * 4;
						break;					
				}
				
				byte[] dif = new byte[fillBytes];
				
				// For char datatypes we need to send spaces instead of 0
				switch (desc.array_desc_dtype)
				{
					case GdsCodes.blr_text:
					case GdsCodes.blr_text2:
					case GdsCodes.blr_cstring:
					case GdsCodes.blr_cstring2:
						System.Array.Copy(fill, dif, fillBytes);
						break;
				}
				
				Write(dif, 0, dif.Length);
			}
		}

		internal void WriteTyped(int type, IParameterBuffer buffer)
		{
			int size;

			if (buffer == null) 
			{
				WriteInt(1);
				Write((byte)type);
				size = 1;
			}
			else 
			{
				size = buffer.Length + 1;
				WriteInt(size);
				Write((byte)type);
				Write(buffer.GetContents());
			}
			Write(pad, 0, ((4 - size) & 3));
		}

		public void WriteShort(short val)
		{
			Write((int)IPAddress.NetworkToHostOrder((int)val));
		}

		public void WriteInt(int val)
		{
			Write((int)IPAddress.NetworkToHostOrder(val));
		}

		public void WriteLong(long val)
		{
			Write((long)IPAddress.NetworkToHostOrder(val));
		}

		public void WriteFloat(float val)
		{
			FloatLayout floatValue = new FloatLayout();			

			floatValue.f = val;
			floatValue.i0 = IPAddress.NetworkToHostOrder(floatValue.i0);

			Write(floatValue.f);
		}

		public void WriteDouble(double val)
		{
			DoubleLayout doubleValue = new DoubleLayout();
			int temp;			

			doubleValue.d = val;
			doubleValue.i0 = IPAddress.NetworkToHostOrder(doubleValue.i0);
			doubleValue.i4 = IPAddress.NetworkToHostOrder(doubleValue.i4);

			temp = doubleValue.i0;
			doubleValue.i0 = doubleValue.i4;
			doubleValue.i4 = temp;

			Write(doubleValue.d);
		}

		#endregion
	}
}
