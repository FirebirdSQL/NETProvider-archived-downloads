//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Net;
using System.Collections;
using System.Net.Sockets;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{	
	internal class isc_svc_handle_impl : isc_svc_handle 
	{
		#region FIELDS
		
		private int 				handle;
		private string 				service;
		private Socket				socket;
		private NetworkStream		networkStream;
		private XdrOutputStream		output;
		private XdrInputStream		input;
		
		private int					serverPort;
		private	int 				op;
		private ArrayList 			warnings;

		#endregion

		#region PROPERTIES

		public int Handle
		{
			get { return handle; }
			set { handle = value; }			
		}

		public string Service
		{
			get { return service; }
			set { service = value; }
		}

		public XdrOutputStream Output
		{
			get { return output; }
			set { output = value; }
		}

		public XdrInputStream Input
		{
			get { return input; }
			set { input = value; }
		}

		public int Op
		{
			get { return op; }
			set { op = value; }
		}

		public int ServerPort
		{
			get { return serverPort; }
			set { serverPort = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public isc_svc_handle_impl()
		{
			warnings	= new ArrayList();
			service		= String.Empty;
			serverPort 	= 3050;
			op			= -1;
		}
		
		public void Connect()
		{
			string server = service.Split(':')[0];
			
			try 
			{
				try 
				{					
					IPAddress	hostadd = Dns.Resolve(server).AddressList[0];
					IPEndPoint	EPhost	= new IPEndPoint(hostadd, serverPort);
					socket = new Socket(AddressFamily.InterNetwork,
											SocketType.Stream,
											ProtocolType.IP);
					
					// Make the socket to connect to the Server
					socket.Connect(EPhost);
					networkStream = new NetworkStream(socket, true);
				} 
				catch (SocketException)
				{
					string message = "Cannot resolve host " + server;
					throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_network_error, server);
				}

				output = new XdrOutputStream(new BufferedStream(networkStream));
				input  = new XdrInputStream(new BufferedStream(networkStream));				
			} 
			catch (IOException) 
			{
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_network_error, server);
			}
		}
		
		public void Disconnect()
		{
			try
			{
				if (input != null)
				{
					input.Close();
					input = null;
				}
				if (output != null)
				{
					output.Close();
					output = null;
				}
				if (networkStream != null)
				{					
					networkStream.Close();
					networkStream = null;
				}
				if (socket != null)
				{
					socket.Close();
					socket = null;
				}			     				
			}
			catch(IOException ioe)
			{
				throw new GDSException(GdsCodes.isc_arg_gds, GdsCodes.isc_net_read_err, ioe.Message);
			}			
		}

		public void AddWarning(GDSException warning) 
		{
			lock (warnings) 
			{
				warnings.Add(warning);
			}

			/*
			if (DbWarningMessage != null)
			{
				DbWarningMessage(this, new DbWarningMessageEventArgs(warning));
			}
			*/
		}
		
		public void ClearWarnings() 
		{
			lock (warnings) 
			{
				warnings.Clear();
			}
		}

		#endregion
	}
}
