//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Resources;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: CLSCompliant(true)]

//
// La informacin general de un ensamblado se controla mediante el siguiente 
// conjunto de atributos. Cambie estos atributos para modificar la informacin
// asociada con un ensamblado.
//
[assembly: AssemblyTitle(".NET Data Provider for Firebird")]
[assembly: AssemblyDescription(".NET Data Provider for Firebird")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("FirebirdSQL")]
[assembly: AssemblyProduct(".NET Data Provider for Firebird")]
[assembly: AssemblyCopyright("(c) 2002. FirebirdSQL")]

//
// La informacin de versin de un ensamblado consta de los siguientes cuatro valores:
//
//      Versin principal
//      Versin secundaria 
//      Versin de compilacin
//      Revisin
//
// Puede especificar todos los valores o usar los valores predeterminados (nmero de versin de compilacin y de revisin) 
// usando el smbolo '*' como se muestra a continuacin:

[assembly: AssemblyVersion("1.1.*")]

//
// Si desea firmar el ensamblado, debe especificar una clave para su uso. Consulte la documentacin de 
// Microsoft .NET Framework para obtener ms informacin sobre la firma de ensamblados.
//
// Utilice los atributos siguientes para controlar qu clave desea utilizar para firmar. 
//
// Notas: 
//   (*) Si no se especifica ninguna clave, el ensamblado no se firma.
//   (*) KeyName se refiere a una clave instalada en el Proveedor de servicios
//       de cifrado (CSP) en el equipo. KeyFile se refiere a un archivo que contiene
//       una clave.
//   (*) Si se especifican los valores KeyFile y KeyName, tendr 
//       lugar el siguiente proceso:
//       (1) Si KeyName se puede encontrar en el CSP, se utilizar dicha clave.
//       (2) Si KeyName y KeyFile no existen, se instalar 
//           y utilizar la clave de KeyFile en el CSP.
//   (*) Para crear KeyFile, puede ejecutar la utilidad sn.exe (Strong Name).
//       Cuando se especifica KeyFile, la ubicacin de KeyFile debe ser
//       relativa al directorio de resultados del proyecto, que es
//       %Directorio del proyecto%\obj\<configuracin>. Por ejemplo, si KeyFile
//       se encuentra en el directorio del proyecto, el atributo AssemblyKeyFile se especifica 
//       como [assembly: AssemblyKeyFile("..\\..\\mykey.snk")]
//   (*) Firma retardada es una opcin avanzada; consulte la documentacin de
//       Microsoft .NET Framework para obtener ms informacin.
//
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("FirebirdSql.Data.Firebird.snk")]
[assembly: AssemblyKeyName("")]
