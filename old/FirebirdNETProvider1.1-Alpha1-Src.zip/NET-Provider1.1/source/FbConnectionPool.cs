//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
//
// Author: Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Collections;
using System.Threading;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	internal class FbConnectionPool : MarshalByRefObject
	{
		#region FIELDS

		private static ConnectionPool pool = null;

		#endregion
    
		#region METHODS

		public static void Init()
		{
			if (pool ==  null)
			{
				pool = new ConnectionPool();
			}
		}

		public static FbIscConnection GetConnection(string connectionString)
		{
			Init();

			return ((FbIscConnection)pool.CheckOut(connectionString));
		}
    
		public static void FreeConnection(FbIscConnection c) 
		{
			pool.CheckIn(c);
		}

		#endregion
	}
	
	internal class ConnectionPool
	{
		#region FIELDS

		private ArrayList	locked;
		private ArrayList	unlocked;
		private Thread		cleanUpThread;

		#endregion

		#region CONSTRUCTORS

		public ConnectionPool()		
		{			
			locked	 = ArrayList.Synchronized(new ArrayList());
			unlocked = ArrayList.Synchronized(new ArrayList());

			cleanUpThread		= new Thread(new ThreadStart(RunCleanUp));
			cleanUpThread.Name	= "CleanUp Thread";			
			cleanUpThread.Start();
			cleanUpThread.IsBackground = true;
		}

		#endregion

		#region METHODS
		
		public FbIscConnection CheckOut(string connectionString)
		{
			FbIscConnection newConnection	= null;
			long			now				= System.DateTime.Now.Ticks;

			lock (typeof(FbConnectionPool))
			{
				if (unlocked.Count > 0)
				{
					/*
					IEnumerator e = unlocked.GetEnumerator();
					while (e.MoveNext())
					{
						FbIscConnection connection = (FbIscConnection)e.Current;
					*/

					FbIscConnection[] list = new FbIscConnection[unlocked.Count];
					unlocked.CopyTo(0, list, 0, list.Length);

					foreach(FbIscConnection connection in list)
					{
						if (Validate(connection, connectionString))
						{
							if (connection.Lifetime != 0)
							{
								if ((now - connection.Created) > connection.Lifetime)
								{
									unlocked.Remove(connection);
									Expire(connection);
								}
								else
								{
									unlocked.Remove(connection);
									locked.Add(connection);
									
									return(connection);
								}
							}
							else
							{
								unlocked.Remove(connection);
								locked.Add(connection);
								
								return(connection);
							}
						}
						else
						{						
							unlocked.Remove(connection);
							Expire(connection);
						}
					}			
				}

				newConnection			= Create(connectionString);		
				newConnection.Created	= System.DateTime.Now.Ticks;

				locked.Add(newConnection);
			}
			
			return(newConnection);
		}	

		public void CheckIn(FbIscConnection connection)
		{			
			lock (typeof(FbConnectionPool))
			{				
				connection.Created = System.DateTime.Now.Ticks;

				locked.Remove(connection);
				unlocked.Add(connection);
			}
		}

		private void RunCleanUp()
		{		
			TimeSpan interval = new TimeSpan(0, 0, 10);

			while (true)
			{
				CleanUp(null);

				Thread.Sleep(interval);
			}
		}

		private FbIscConnection Create(string connectionString)
		{
			try 
			{
				FbIscConnection connection = new FbIscConnection(connectionString);
				connection.Open();

				return connection;
			}
			catch (Exception ex) 
			{
				throw ex;
			}
		}
    
		private bool Validate(FbIscConnection connection, string connectionString)
		{
			try 
			{								
				return (connection.ConnectionString == connectionString &&
						connection.VerifyAttachedDB());
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		private void Expire(FbIscConnection connection)
		{
			try 
			{
				if (connection.VerifyAttachedDB())
				{
					connection.Close();
				}
			}
			catch (Exception)
			{
				throw new FbException("Error closing database connection.");
			}
		}
		
		private void CleanUp(object State)
		{
			long	now = System.DateTime.Now.Ticks;
			
			lock (unlocked.SyncRoot)
			{
				FbIscConnection[] list = new FbIscConnection[unlocked.Count];
				
				unlocked.CopyTo(0, list, 0, list.Length);
				foreach(FbIscConnection connection in list)
				{
					if (connection.Lifetime != 0)
					{
						if ((now - connection.Created) > connection.Lifetime)
						{
							unlocked.Remove(connection);
							Expire(connection);
						}
					}
				}
			}
		}

		#endregion
	}
}
