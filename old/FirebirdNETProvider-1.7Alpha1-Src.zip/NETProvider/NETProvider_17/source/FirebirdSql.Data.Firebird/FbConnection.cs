/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;

using FirebirdSql.Data.Common;
using FirebirdSql.Data.Firebird.DbSchema;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/overview/*'/>
	[ToolboxItem(true),
	ToolboxBitmap(typeof(FbConnection), "Resources.FbConnection.bmp"),    
	DefaultEvent("InfoMessage")]
	public sealed class FbConnection : Component, IDbConnection, ICloneable
	{	
		#region Events

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/event[@name="StateChange"]/*'/>
		public event StateChangeEventHandler StateChange;

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/event[@name="InfoMessage"]/*'/>
		public event FbInfoMessageEventHandler InfoMessage;
		
		#endregion

		#region Fields

		private FbDbConnection		innerConn;
		private ConnectionState		state;
		private bool				disposed;
		private FbDataReader		dataReader;
		private FbTransaction		activeTransaction;
		private ArrayList			activeCommands;
		private FbConnectionString	csManager;
		private string				connectionString;

		#endregion
		
		#region Properties

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="ConnectionString"]/*'/>
		[Category("Data"), 
		RecommendedAsConfigurableAttribute(true),
		RefreshProperties(RefreshProperties.All),
		DefaultValue("")]
		#if (!MONO)
		[Editor(typeof(Design.FbConnectionStringUIEditor), typeof(System.Drawing.Design.UITypeEditor))]
		#endif
		public string ConnectionString
		{
			get { return this.connectionString; }
			set
			{
				lock (this)
				{
					if (this.state == ConnectionState.Closed)
					{
						this.csManager.Load(value);
						this.connectionString = value;
					}
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="ConnectionTimeout"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int ConnectionTimeout
		{
			get { return this.csManager.ConnectionTimeout; }
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="Database"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string Database
		{
			get { return this.csManager.Database; }
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="DataSource"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string DataSource
		{
			get { return this.csManager.DataSource; }
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="ServerVersion"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string ServerVersion
		{
			get
			{
				if (this.state == ConnectionState.Closed)
				{
					throw new InvalidOperationException("The connection is closed.");
				}

				if (this.innerConn != null)
				{
					return this.innerConn.Database.ServerVersion;
				}

				return String.Empty;
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="State"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public ConnectionState State
		{
			get { return this.state; }
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="PacketSize"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int PacketSize
		{
			get { return this.csManager.PacketSize; }
		}
				
		#endregion		

		#region Internal Properties

		internal IDatabase IscDatabase
		{
			get { return this.innerConn.Database; }
		}

		internal FbDataReader DataReader
		{
			get { return this.dataReader; }
			set { this.dataReader = value; }
		}

		internal FbTransaction ActiveTransaction
		{
			get { return this.activeTransaction; }
			set { this.activeTransaction = value; }
		}

		internal ArrayList ActiveCommands
		{
			get { return this.activeCommands; }
		}

		#endregion

		#region Constructors

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/constructor[@name="ctor"]/*'/>
		public FbConnection() : this(null)
		{
		}

    	/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/constructor[@name="ctor(System.String)"]/*'/>	
		public FbConnection(string connectionString) : base()
		{
			this.csManager	= new FbConnectionString();
			this.state		= ConnectionState.Closed;

			if (connectionString != null)
			{
				this.ConnectionString = connectionString;
			}

//			GC.SuppressFinalize(this);			
		}		

		#endregion

		#region IDisposable Methods

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			lock (this)
			{
				if (!this.disposed)
				{
					try
					{
						// release any unmanaged resources
						this.Close();

						if (disposing)
						{
							// release any managed resources
							this.innerConn = null;
						}
						
						this.disposed = true;
					}
					finally
					{
						base.Dispose(disposing);
					}
				}
			}
		}

		#endregion

		#region ICloneable Methods

		object ICloneable.Clone()
		{
			return new FbConnection(this.ConnectionString);
		}

		#endregion

		#region Static Methods

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="ClearAllPools"]/*'/>
		public static void ClearAllPools()
		{
			FbPoolManager manager = FbPoolManager.Instance;

			manager.ClearAllPools();
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="ClearPool(FbConnection)"]/*'/>
		public static void ClearPool(FbConnection connection)
		{
			FbPoolManager manager = FbPoolManager.Instance;

			manager.ClearPool(connection.ConnectionString);
		}

        /// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateDatabase(System.String)"]/*'/>
        public static void CreateDatabase(string connectionString)
		{
			FbConnection.CreateDatabase(connectionString, 4096, true, false);
		}

        /// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateDatabase(System.String,System.Int32,System.Boolean,System.Boolean)"]/*'/>
        public static void CreateDatabase(
			string  connectionString,
			int     pageSize,
			bool    forcedWrites,
			bool    overwrite)
		{
			FbConnectionString cs = new FbConnectionString(connectionString);
			cs.Validate();

			try
			{
				// DPB configuration
				DpbBuffer dpb = new DpbBuffer();

				// Dpb version
				dpb.Append(IscCodes.isc_dpb_version1);

				// Dummy packet interval
				dpb.Append(IscCodes.isc_dpb_dummy_packet_interval,
					new byte[] { 120, 10, 0, 0 });

				// User name
				dpb.Append(IscCodes.isc_dpb_user_name,
					cs.UserName);

				// User password
				dpb.Append(IscCodes.isc_dpb_password,
					cs.UserPassword);

				// Database dialect
				dpb.Append(IscCodes.isc_dpb_sql_dialect,
					new byte[] { cs.Dialect, 0, 0, 0 });

				// Page Size
				if (pageSize > 0)
				{
					dpb.Append(IscCodes.isc_dpb_page_size, pageSize);
				}

				// Forced writes
				dpb.Append(IscCodes.isc_dpb_force_write,
					(short)(forcedWrites ? 1 : 0));

				// Character set
				if (cs.Charset.Length > 0)
				{
					int index = Charset.SupportedCharsets.IndexOf(cs.Charset);

					if (index == -1)
					{
						throw new ArgumentException("Character set is not valid.");
					}
					else
					{
						dpb.Append(
							IscCodes.isc_dpb_set_db_charset,
							Charset.SupportedCharsets[index].Name);
					}
				}

				if (!overwrite)
				{
					// Check if the database exists
					try
					{
						IDatabase test      = ClientFactory.CreateDatabase(cs.ServerType);
						DpbBuffer testDpb   = cs.BuildDpb(test.IsLittleEndian);

						test.Attach(testDpb, cs.DataSource, cs.Port, cs.Database);
						test.Detach();

						IscException ex = new IscException(IscCodes.isc_db_or_file_exists);

						throw new FbException(ex.Message, ex);
					}
					catch (FbException ex)
					{
						throw ex;
					}
					catch (Exception)
					{
					}
				}

				IDatabase db = ClientFactory.CreateDatabase(cs.ServerType);

				db.CreateDatabase(dpb, cs.DataSource, cs.Port, cs.Database);
			}
			catch (IscException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

        /// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="DropDatabase(System.String)"]/*'/>
        public static void DropDatabase(string connectionString)
		{
			// Configure Attachment
			FbConnectionString cs = new FbConnectionString(connectionString);
			cs.Validate();

			try
			{
				// Drop the database			
				IDatabase db = ClientFactory.CreateDatabase(cs.ServerType);

				db.Attach(cs.BuildDpb(db.IsLittleEndian), cs.DataSource, cs.Port, cs.Database);
				db.DropDatabase();
			}
			catch (IscException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

        /// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateDatabase(System.Collections.Hashtable)"]/*'/>
        [Obsolete]		
		public static void CreateDatabase(Hashtable values)
		{
			bool		overwrite	= false;
			int			index		= 0;
			byte		dialect		= 3;
			IDatabase	db			= null;
			int			serverType	= 0;

			if (!values.ContainsKey("User")		||
				!values.ContainsKey("Password") ||
				!values.ContainsKey("Database"))
			{
				throw new ArgumentException("CreateDatabase requires a user name, password and database path.");
			}

			if (values.ContainsKey("ServerType"))
			{
				serverType = Convert.ToInt32(values["ServerType"], CultureInfo.InvariantCulture.NumberFormat);
			}

			if (!values.ContainsKey("DataSource"))
			{
				values.Add("DataSource", "localhost");
			}

			if (!values.ContainsKey("Port"))
			{
				values.Add("Port", 3050);
			}

			if (values.ContainsKey("Dialect"))
			{
				dialect = Convert.ToByte(values["Dialect"], CultureInfo.InvariantCulture.NumberFormat);
			}

			if (dialect < 1 || dialect > 3)
			{
				throw new ArgumentException("Incorrect database dialect it should be 1, 2, or 3.");
			}

			if (values.ContainsKey("Overwrite"))
			{
				overwrite = (bool)values["Overwrite"];
			}

			try 
			{
				// Configure Attachment
				FbConnectionString cs = new FbConnectionString();

				cs.DataSource	= values["DataSource"].ToString();
				cs.UserName		= values["User"].ToString();
				cs.UserPassword	= values["Password"].ToString();
				cs.Database		= values["Database"].ToString();
				cs.Port			= Convert.ToInt32(values["Port"], CultureInfo.InvariantCulture.NumberFormat);
			
				// DPB configuration
				DpbBuffer dpb = new DpbBuffer();
				
				// Dpb version
				dpb.Append(IscCodes.isc_dpb_version1);

				// Dummy packet interval
				dpb.Append(IscCodes.isc_dpb_dummy_packet_interval, 
					new byte[] {120, 10, 0, 0});

				// User name
				dpb.Append(IscCodes.isc_dpb_user_name, 
					values["User"].ToString());

				// User password
				dpb.Append(IscCodes.isc_dpb_password, 
					values["Password"].ToString());

				// Database dialect
				dpb.Append(IscCodes.isc_dpb_sql_dialect, 
					new byte[] {dialect, 0, 0, 0});

				// Page Size
				if (values.ContainsKey("PageSize"))
				{
					dpb.Append(IscCodes.isc_dpb_page_size, Convert.ToInt32(values["PageSize"], CultureInfo.InvariantCulture.NumberFormat));
				}

				// Forced writes
				if (values.ContainsKey("ForcedWrite"))
				{
					dpb.Append(IscCodes.isc_dpb_force_write, 
						(short)((bool)values["ForcedWrite"] ? 1 : 0));
				}

				// Character set
				if (values.ContainsKey("Charset"))
				{
					index = Charset.SupportedCharsets.IndexOf(values["Charset"].ToString());

					if (index == -1)
					{
						throw new ArgumentException("Character set is not valid.");
					}
					else
					{
						dpb.Append(
							IscCodes.isc_dpb_set_db_charset, 
							Charset.SupportedCharsets[index].Name);
					}
				}

				db = ClientFactory.CreateDatabase(serverType);

				if (!overwrite)
				{
					// Check if the database exists
					try
					{
						IDatabase test		= ClientFactory.CreateDatabase(serverType);
						DpbBuffer testDpb	= cs.BuildDpb(test.IsLittleEndian);

						test.Attach(testDpb, cs.DataSource, cs.Port, cs.Database);
						test.Detach();

						IscException ex = new IscException(IscCodes.isc_db_or_file_exists);

						throw new FbException(ex.Message, ex);
					}
					catch(FbException ex)
					{
						throw ex;
					}
					catch (Exception)
					{
					}
				}
				
				db.CreateDatabase(dpb, cs.DataSource, cs.Port, cs.Database);
			}
			catch (IscException ex) 
			{
				throw new FbException(ex.Message, ex);
			}
		}

        /// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="DropDatabase(System.Collections.Hashtable)"]/*'/>
        [Obsolete]
		public static void DropDatabase(Hashtable values)
		{
			IDatabase	db			= null;
			int			serverType	= 0;

			if (!values.ContainsKey("User")		||
				!values.ContainsKey("Password") ||
				!values.ContainsKey("Database"))
			{
				throw new ArgumentException("CreateDatabase requires a user name, password and database path.");
			}

			if (!values.ContainsKey("DataSource"))
			{
				values.Add("DataSource", "localhost");
			}

			if (!values.ContainsKey("Port"))
			{
				values.Add("Port", 3050);
			}

			if (values.ContainsKey("ServerType"))
			{
				serverType = Convert.ToInt32(values["ServerType"], CultureInfo.InvariantCulture.NumberFormat);
			}

			try 
			{
				// Configure Attachment
				FbConnectionString cs = new FbConnectionString();

				cs.DataSource	= values["DataSource"].ToString();
				cs.Port			= Convert.ToInt32(values["Port"], CultureInfo.InvariantCulture.NumberFormat);
				cs.Database		= values["Database"].ToString();
				cs.UserName		= values["User"].ToString();
				cs.UserPassword	= values["Password"].ToString();

				// Drop the database			
				db = ClientFactory.CreateDatabase(serverType);

				db.Attach(cs.BuildDpb(db.IsLittleEndian), cs.DataSource, cs.Port, cs.Database);
				db.DropDatabase();
			}
			catch (IscException ex) 
			{
				throw new FbException(ex.Message, ex);
			}
		}

		#endregion

		#region Methods

		IDbTransaction IDbConnection.BeginTransaction()
		{
			return this.BeginTransaction();
		}

		IDbTransaction IDbConnection.BeginTransaction(IsolationLevel level)
		{
			return this.BeginTransaction(level);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction"]/*'/>
		public FbTransaction BeginTransaction()
		{
			return this.BeginTransaction(IsolationLevel.ReadCommitted, null);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(System.String)"]/*'/>
		public FbTransaction BeginTransaction(string transactionName)
		{
			return this.BeginTransaction(IsolationLevel.ReadCommitted, transactionName);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level)
		{
			return this.BeginTransaction(level, null);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(System.Data.IsolationLevel,System.String)"]/*'/>
		public FbTransaction BeginTransaction(
			IsolationLevel	level, 
			string			transactionName)
		{
			lock (this)
			{
				if (this.state == ConnectionState.Closed)
				{
					throw new InvalidOperationException("BeginTransaction requires an open and available Connection.");
				}

				if (this.activeTransaction != null && 
					!activeTransaction.IsUpdated)
				{
					throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
				}

				if (this.DataReader != null)
				{
					throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
				}

				try
				{
					this.activeTransaction = new FbTransaction(this, level);
					this.activeTransaction.BeginTransaction();
					if (transactionName != null)
					{
						this.activeTransaction.Save(transactionName);
					}
				}
				catch(IscException ex)
				{
					throw new FbException(ex.Message, ex);
				}
			}

			return this.activeTransaction;			
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(FbTransactionOptions)"]/*'/>
		public FbTransaction BeginTransaction(FbTransactionOptions options)
		{
			return this.BeginTransaction(options, null);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(FbTransactionOptions, System.String)"]/*'/>
		public FbTransaction BeginTransaction(
			FbTransactionOptions	options, 
			string					transactionName)
		{
			lock (this)
			{
				if (this.state == ConnectionState.Closed)
				{
					throw new InvalidOperationException("BeginTransaction requires an open and available Connection.");
				}

				if (this.activeTransaction != null && 
					!activeTransaction.IsUpdated)
				{
					throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
				}

				if (this.DataReader != null)
				{
					throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
				}

				try
				{
					this.activeTransaction = new FbTransaction(
						this, 
						IsolationLevel.Unspecified);
					this.activeTransaction.BeginTransaction(options);
					if (transactionName != null)
					{
						this.activeTransaction.Save(transactionName);
					}
				}
				catch(IscException ex)
				{
					throw new FbException(ex.Message, ex);
				}
			}

			return this.activeTransaction;			
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="ChangeDatabase(System.String)"]/*'/>
		public void ChangeDatabase(string db)
		{
			lock (this)
			{
				if (this.state == ConnectionState.Closed)
				{
					throw new InvalidOperationException("ChangeDatabase requires an open and available Connection.");
				}

				if (db == null || db.Trim().Length == 0)
				{
					throw new InvalidOperationException("Database name is not valid.");
				}

				if (this.DataReader != null)
				{
					throw new InvalidOperationException("ChangeDatabase requires an open and available Connection. The connection's current state is Open, Fetching.");
				}

				string oldDb = this.csManager.Database;

				try
				{
					/* Close current connection	*/
					this.Close();

					/* Set up the new Database	*/
					this.csManager.Database = db;

					/* Open new connection	*/
					this.Open();
				}
				catch (IscException ex)
				{
					this.csManager.Database = oldDb;
					throw new FbException(ex.Message, ex);
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="Open"]/*'/>
		public void Open()
		{
			lock (this)
			{
				if (this.connectionString == null ||
					this.connectionString.Length == 0)
				{
					throw new InvalidOperationException("Connection String is not initialized.");
				}
				if (this.state != ConnectionState.Closed && 
					this.state != ConnectionState.Connecting)
				{
					throw new InvalidOperationException("Connection already Open.");
				}

				try
				{
					this.state		= ConnectionState.Connecting;
					this.innerConn	= new FbDbConnection();
					this.innerConn.Pooled	= false;
					this.innerConn.Lifetime = this.csManager.ConnectionLifeTime;
									
					if (this.csManager.Pooling)
					{
						FbPoolManager poolManager = FbPoolManager.Instance;
						FbConnectionPool pool = poolManager.FindPool(this.connectionString);

						// If there are no pool created yet
						// create one
						if (pool == null)
						{
							pool = poolManager.CreatePool(this.connectionString);
						}
					
						// Use Connection Pooling
						this.innerConn = pool.CheckOut(this.innerConn);
					}
					else
					{
						// Do not use Connection Pooling
						this.innerConn.Connect(this.csManager);
					}

					// Bind Warning messages event
					this.innerConn.Database.WarningMessage = new WarningMessageCallback(this.OnWarningMessage);
				
					this.state = ConnectionState.Open;
					if (this.StateChange != null)
					{
						this.StateChange(
							this, 
							new StateChangeEventArgs(
								ConnectionState.Closed, state));
					}

					this.activeCommands = new ArrayList();
				}
				catch(IscException ex)
				{
					this.state = ConnectionState.Closed;
					throw new FbException(ex.Message, ex);
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="Close"]/*'/>
		public void Close()
		{
			if (this.state != ConnectionState.Open)
			{
				return;
			}
				
			lock (this)
			{
				try
				{		
					lock (this.innerConn)
					{
						// Unbind Warning messages event
						this.innerConn.Database.WarningMessage = null;

						// Dispose active DataReader if exists
						if (this.dataReader != null && !this.dataReader.IsClosed)
						{
							this.dataReader.Close();
							this.dataReader = null;
						}						

						// Dispose Transaction
						if (this.activeTransaction != null)
						{
							this.activeTransaction.Dispose();
							this.activeTransaction = null;
						}						

						// Dispose all active statemenets
						this.DisposeActiveCommands();

						// Close connection or send it back to the pool
						if (this.innerConn.Pooled)
						{
							// Get Connection Pool
							FbConnectionPool pool = 
								FbPoolManager.Instance.FindPool(this.connectionString);

							// Send connection to the Pool
							pool.CheckIn(this.innerConn);
						}
						else
						{
							this.innerConn.Disconnect();
						}
					}

					// Update state
					this.state = ConnectionState.Closed;

					// Raise event
					if (this.StateChange != null)
					{
						this.StateChange(
							this, 
							new StateChangeEventArgs(ConnectionState.Open, state));
					}
				}
				catch(IscException ex)
				{
					throw new FbException(ex.Message, ex);
				}
			}
		}

		IDbCommand IDbConnection.CreateCommand()
		{
			return this.CreateCommand();
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateCommand"]/*'/>
		public FbCommand CreateCommand()
		{
			FbCommand command = new FbCommand();

			lock (this)
			{
				command.Connection = this;
			}
	
			return command;
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="GetDbSchemaTable"]/*'/>
		public DataTable GetDbSchemaTable(
			FbDbSchemaType	schema, 
			object[]		restrictions)
		{
			FbDbSchema dbSchema = FbDbSchemaFactory.GetSchema(schema);

			lock (this)
			{
				if (DataReader != null)
				{
					throw new InvalidOperationException("GetDbSchemaTable requires an open and available Connection. The connection's current state is Open, Fetching.");
				}
				
				if (dbSchema == null)
				{
					throw new NotSupportedException("Specified schema type is not supported.");
				}
			}

			return dbSchema.GetDbSchemaTable(this, restrictions);
		}

		#endregion

		#region Remote Events Methods

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="QueueEvents(FbEvent)"]/*'/>
		public void QueueEvents(FbEvent events)
		{
			this.IscDatabase.QueueEvents(events.EventHandle);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CancelEvents(FbEvent)"]/*'/>
		public void CancelEvents(FbEvent events)
		{
			this.IscDatabase.CancelEvents(events.EventHandle);
		}

		#endregion

		#region Private Methods

		private void DisposeActiveCommands()
		{
			if (this.activeCommands != null)
			{
				if (this.activeCommands.Count > 0)
				{
					foreach (FbCommand command in activeCommands)
					{
						// Rollback implicit transaction
						command.RollbackImplicitTransaction();

						// Release statement handle
						command.Release();
					}
				}

				this.activeCommands.Clear();
				this.activeCommands = null;				
			}
		}

		private void OnWarningMessage(IscException warning)
		{
			if (this.InfoMessage != null)
			{
				this.InfoMessage(this, new FbInfoMessageEventArgs(warning));
			}
		}

		#endregion
	}
}
