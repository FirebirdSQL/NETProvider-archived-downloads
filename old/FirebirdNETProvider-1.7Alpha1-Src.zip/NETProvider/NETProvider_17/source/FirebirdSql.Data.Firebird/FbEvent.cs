/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird
{
	#region Delegates

	/// <include file='Doc/en_EN/FbEvent.xml' path='doc/delegate[@name="FbEventCountsCallback"]/overview/*'/>
	public delegate void FbEventCountsCallback(FbEvent sender, int[] counts);

	#endregion

	/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/overview/*'/>
	public sealed class FbEvent
	{
		#region Callbacks

		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/callback[@name="EventCountsCallback"]/*'/>
		public FbEventCountsCallback EventCountsCallback
		{
			get { return this.eventCountsCallback; }
			set { this.eventCountsCallback = value; }
		}

		#endregion

		#region Fields

		private FbEventCountsCallback eventCountsCallback;

		private FbConnection	connection;
		private	RemoteEvent		revent;

		#endregion

		#region Indexers

		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/indexer[@name="Item(System.Int32)"]/*'/>
		public string this[int index]
		{
			get { return this.revent.Events[index]; }
		}
		
		#endregion

		#region Properties

		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/property[@name="Connection"]/*'/>
		public FbConnection Connection
		{
			get { return this.connection; }
			set { this.connection = value; }
		}

		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/property[@name="HasChanges"]/*'/>
		public bool HasChanges
		{
			get { return this.revent.HasChanges; }
		}

		#endregion

		#region Internal Properties

		internal RemoteEvent EventHandle
		{
			get { return this.revent; }
		}

		#endregion

		#region Constructors
		
		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/constructor[@name="ctor(FbConnection)"]/*'/>
		public FbEvent(FbConnection connection) : this(connection, null)
		{
		}

		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/constructor[@name="ctor(FbConnection, System.Array)"]/*'/>
		public FbEvent(FbConnection connection, string[] events)
		{
			this.connection = connection;
			this.revent		= connection.IscDatabase.CreateEvent();
			this.revent.EventCountsCallback = new EventCountsCallback(this.EventCounts);

			if (events != null)
			{
				this.AddEvents(events);
			}
		}

		#endregion

		#region Methods

		/// <include file='Doc/en_EN/FbEvent.xml' path='doc/class[@name="FbEvent"]/method[@name="AddEvents(System.Array)"]/*'/>
		public void AddEvents(string[] events)
		{
			if (events == null)
			{
				throw new ArgumentNullException("events cannot be null.");
			}
			if (events.Length > 15)
			{
				throw new ArgumentException("Max number of events for request interest is 15");
			}

			this.revent.Events.Clear();

			for (int i = 0; i < events.Length; i++)
			{
				this.revent.Events.Add(events[i]);
			}
		}

		#endregion

		#region Callbacks methods

		private void EventCounts()
		{
			if (this.eventCountsCallback != null)
			{
				this.eventCountsCallback(this, this.revent.ActualCounts);
			}
		}

		#endregion
	}
}
