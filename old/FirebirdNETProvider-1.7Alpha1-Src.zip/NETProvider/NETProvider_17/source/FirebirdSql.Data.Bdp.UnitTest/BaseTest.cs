/*
 *  Firebird BDP - Borland Data provider Firebird
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using NUnit.Framework;
using System;
using System.Text;
using System.Configuration;
using System.Collections;
using System.Security.Cryptography;

using Borland.Data.Provider;

namespace FirebirdSql.Data.Bdp.Tests
{
	public class BaseTest
	{
		#region Fields

		private BdpConnection	connection;
		private BdpTransaction	transaction;
		private bool			withTransaction;

		#endregion

		#region Properties

		public BdpConnection Connection
		{
			get { return connection; }
		}

		public BdpTransaction Transaction
		{
			get { return transaction; }
			set { transaction = value; }
		}

		#endregion

		#region Constructors
				
		public BaseTest()
		{
			this.withTransaction = false;
		}

		public BaseTest(bool withTransaction)
		{
			this.withTransaction = withTransaction;
		}

		#endregion

		#region NUnit Methods

		[SetUp]
		public virtual void SetUp()
		{
			// Build the connection string
			StringBuilder connectionString = new StringBuilder();
			connectionString.AppendFormat(
				"Assembly={0};UserName={1};Password={2};Database={3}",
				ConfigurationSettings.AppSettings["Assembly"],
				ConfigurationSettings.AppSettings["UserName"],
				ConfigurationSettings.AppSettings["Password"],
				ConfigurationSettings.AppSettings["Database"]);

			StringBuilder connOptions = new StringBuilder();
			connOptions.AppendFormat(
				"Charset={0};Dialect={1};Server Type={2}",
				ConfigurationSettings.AppSettings["Charset"],
				ConfigurationSettings.AppSettings["Dialect"],
				ConfigurationSettings.AppSettings["ServerType"]);

			this.connection						= new BdpConnection();
			this.connection.ConnectionString	= connectionString.ToString();
			this.connection.ConnectionOptions	= connOptions.ToString();
			this.connection.Open();

			if (this.withTransaction)
			{
				this.transaction = this.connection.BeginTransaction();
			}
		}

		[TearDown]
		public virtual void TearDown()
		{			
			if (this.withTransaction)
			{
				try
				{
					transaction.Commit();
				}
				catch
				{
				}
			}
			connection.Close();
		}

		#endregion

		#region Methods

		public int GetId()
		{
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();

			byte[] buffer = new byte[4];
			
			rng.GetBytes(buffer);

			return BitConverter.ToInt32(buffer, 0);
		}

		#endregion
	}
}
