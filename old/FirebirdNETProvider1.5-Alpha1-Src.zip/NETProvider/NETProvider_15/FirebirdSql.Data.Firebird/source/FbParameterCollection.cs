//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.ComponentModel;
using System.Collections;
using System.Globalization;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/overview/*'/>
	[ListBindable(false)]
	public sealed class FbParameterCollection : MarshalByRefObject, IList, ICollection, IDataParameterCollection
	{	
		#region FIELDS

		private ArrayList parameters = new ArrayList();

		#endregion

		#region PROPERTIES

		object IDataParameterCollection.this[string parameterName] 
		{
			get { return this[parameterName]; }
			set { this[parameterName] = (FbParameter)value; }
		}

		object IList.this[int parameterIndex]
		{
			get { return (FbParameter)parameters[parameterIndex]; }
			set { parameters[parameterIndex] = (FbParameter)value; }
		}
		
		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/indexer[@name="Item(System.String)"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public FbParameter this[string parameterName]
		{
			get { return (FbParameter)this[IndexOf(parameterName)]; }
			set { this[IndexOf(parameterName)] = (FbParameter)value; }
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/indexer[@name="Item(System.Int32)"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public FbParameter this[int parameterIndex]
		{
			get { return (FbParameter)parameters[parameterIndex]; }
			set { parameters[parameterIndex] = (FbParameter)value; }
		}
		
		#endregion

		#region CONSTRUCTORS

		internal FbParameterCollection()
		{
		}

		#endregion

		#region ILIST_PROPERTIES

		bool IList.IsFixedSize
		{
			get { return parameters.IsFixedSize; }
		}

		bool IList.IsReadOnly
		{
			get { return parameters.IsReadOnly; }
		}

		#endregion

		#region ICOLLECTION_PROPERTIES

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/property[@name="Count"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int Count 
		{
			get { return parameters.Count; }
		}
		
		bool ICollection.IsSynchronized 
		{
			get { return parameters.IsSynchronized; }
		}

		object ICollection.SyncRoot 
		{
			get { return parameters.SyncRoot; }
		}

		#endregion

		#region ICOLLECTION_METHODS

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="CopyTo(System.Array,System.Int32)"]/*'/>
		public void CopyTo(Array array, int index)
		{
			parameters.CopyTo(array, index);
		}

		#endregion

		#region ILIST_METHODS

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Clear"]/*'/>
		public void Clear()
		{
			parameters.Clear();
		}

		#endregion

		#region IENUMERABLE_METHODS

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="GetEnumerator"]/*'/>
		public IEnumerator GetEnumerator()
		{
			return parameters.GetEnumerator();
		}

		#endregion

		#region METHODS

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Contains(System.Object)"]/*'/>
		public bool Contains(object value)
		{
			return parameters.Contains(value);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Contains(System.String)"]/*'/>
		public bool Contains(string parameterName)
		{
			return(-1 != IndexOf(parameterName));
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="IndexOf(System.Object)"]/*'/>
		public int IndexOf(object value)
		{
			return parameters.IndexOf(value);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="IndexOf(System.String)"]/*'/>
		public int IndexOf(string parameterName)
		{
			int index = 0;
			foreach(FbParameter item in this.parameters)
			{
				if (cultureAwareCompare(item.ParameterName, parameterName))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Insert(System.Int32,System.Object)"]/*'/>
		public void Insert(int index, object value)			
		{
			parameters.Insert(index, value);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Remove(System.Object)"]/*'/>
		public void Remove(object value)
		{
			if (!(value is FbParameter))
			{
				throw new InvalidCastException("The parameter passed was not a FbParameter.");
			}

			if (!Contains(value))
			{
				throw new SystemException("The parameter does not exist in the collection.");
			}

			parameters.Remove(value);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="RemoveAt(System.Int32)"]/*'/>
		public void RemoveAt(int index)
		{
			RemoveAt(this[index].ParameterName);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="RemoveAt(System.String)"]/*'/>
		public void RemoveAt(string parameterName)
		{
			RemoveAt(IndexOf(parameterName));
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Add(System.Object)"]/*'/>
		public int Add(object value)
		{
			if (!(value is FbParameter))
			{
				throw new InvalidCastException("The parameter passed was not a FbParameter.");
			}

			return parameters.Add((FbParameter)value);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Add(FbParameter)"]/*'/>
		public FbParameter Add(FbParameter param)
		{
			if (param.ParameterName != null)
			{
				parameters.Add(param);
				
				return param;
			}
			else
			{
				throw new ArgumentException("Parameter must be named");
			}
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Add(System.String,System.Object)"]/*'/>
		public FbParameter Add(string parameterName, object value)
		{
			FbParameter param = new FbParameter(parameterName, value);

			return Add(param);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Add(System.String,FbDbType)"]/*'/>
		public FbParameter Add(string parameterName, FbDbType type)
		{
			FbParameter param = new FbParameter(parameterName, type);			
			
			return Add(param);
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Add(System.String,FbDbType,System.Int32)"]/*'/>
		public FbParameter Add(string parameterName, FbDbType fbType, int size)
		{
			FbParameter param = new FbParameter(parameterName, fbType, size);

			return Add(param);		
		}

		/// <include file='Doc/en_EN/FbParameterCollection.xml' path='doc/class[@name="FbParameterCollection"]/method[@name="Add(System.String,FbDbType,System.Int32,System.String)"]/*'/>
		public FbParameter Add(string parameterName, FbDbType fbType, int size, string sourceColumn)
		{
			FbParameter param = new FbParameter(parameterName, fbType, size, sourceColumn);

			return Add(param);		
		}

		private bool cultureAwareCompare(string strA, string strB)
		{
			try
			{
				return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB,
						CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth |
						CompareOptions.IgnoreCase) == 0 ? true : false;
			}
			catch (NotSupportedException)
			{
				return strA.ToUpper() == strB.ToUpper() ? true : false;
			}
		}

		#endregion
	}
}