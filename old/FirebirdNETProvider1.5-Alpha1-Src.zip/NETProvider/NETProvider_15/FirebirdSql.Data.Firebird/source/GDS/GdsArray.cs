//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Net;
using System.Text;
using System.Collections;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsArray : GdsSlice
	{
		#region CONSTRUCTORS

		public GdsArray(
			GdsDbAttachement db, 
			GdsTransaction transaction,
			long handle, 
			string tableName, 
			string fieldName) : base(db, transaction, handle, fieldName, tableName)
		{
		}

		#endregion

		#region METHODS

		public System.Array Read()
		{
			GdsArrayDesc desc = LookupBounds();
						
			byte[] slice = GetSlice(desc, getSliceLength(desc, true));
			
			return decodeSlice(desc, slice);
		}

		public void Write(System.Array source_array)
		{
			GdsArrayDesc desc = LookupBounds();
							
			PutSlice(desc, source_array, getSliceLength(desc, false));
		}

		#endregion

		#region PRIVATE_METHODS
				
		private int getSliceLength(GdsArrayDesc desc, bool read)
		{
			Encoding	encoding		= DB.Parameters.Encoding;
			int 		length 			= 0;
			int			elements		= 0;

			for (int i = 0; i < desc.Dimensions; i++)
			{
				GdsArrayBound bound = desc.Bounds[i];
				
				elements += bound.LowerBound * bound.UpperBound;
			}

			switch (desc.DataType)
			{
				case GdsCodes.blr_text:
				case GdsCodes.blr_text2:
				case GdsCodes.blr_cstring:
				case GdsCodes.blr_cstring2:
				case GdsCodes.blr_varying:
				case GdsCodes.blr_varying2:
					// Char & VarChar
					length =  elements * encoding.GetMaxByteCount(desc.Length);
					length += elements * ((4 - encoding.GetMaxByteCount(desc.Length)) & 3);
					break;

				case GdsCodes.blr_short:
					length = elements * desc.Length;
					if (read)
					{
						length *= 2;
					}
					break;
				
				default:
					length = elements * desc.Length;
					break;
			}						
			
			return length;
		}
						
		private System.Array decodeSlice(GdsArrayDesc desc, byte[] slice)
		{
			System.Array 	sliceData		= null;			
			int				slicePosition	= 0;
			FbDbType			type			= FbDbType.Array;
			Type			systemType		= null;
			int 			temp 			= 0;
			Encoding		encoding		= DB.Parameters.Encoding;
			int[]			lengths 		= new int[desc.Dimensions];
			int[]			lowerBounds		= new int[desc.Dimensions];			

			// Get upper and lower bounds of each dimension
			for (int i = 0; i < desc.Dimensions; i++)
			{
				lowerBounds[i] 	= desc.Bounds[i].LowerBound;
				lengths[i] 		= desc.Bounds[i].UpperBound;
			}
			
			sliceData = getArrayFromDesc(desc, ref type, ref systemType, lengths, lowerBounds);

			System.Array tempData = System.Array.CreateInstance(systemType, sliceData.Length);

			for (int i = 0; i < tempData.Length; i++)
			{
				if (slicePosition >= slice.Length)
				{
					break;
				}
				int item_length = desc.Length;
				
				switch(type)
				{							
					case FbDbType.Text:
					{
						// Char
						string strValue = encoding.GetString(slice, slicePosition, item_length);
												
						tempData.SetValue(strValue, i);
					}
					break;
					
					case FbDbType.VarChar:
					{
						// VarChar						
						item_length 	= BitConverter.ToInt32(slice, slicePosition);
						item_length 	= IPAddress.HostToNetworkOrder(item_length);
						slicePosition 	+= 4;
						
						string strValue = encoding.GetString(slice, slicePosition, item_length);
												
						tempData.SetValue(strValue, i);
					}
					break;
					
					case FbDbType.SmallInt:
					{
						// Smallint
						int sintValue = BitConverter.ToInt32(slice, slicePosition);
						sintValue = IPAddress.HostToNetworkOrder(sintValue);
	
						slicePosition += 2;
	
						if (desc.Scale < 0)		
						{
							decimal dvalue = GdsDecodeType.DecodeDecimal(
														sintValue, 
														desc.Scale,
														GdsCodes.SQL_SHORT);
							tempData.SetValue(dvalue, i);
						}
						else
						{							
							tempData.SetValue(Convert.ToInt16(sintValue), i);
						}
					}
					break;
	
					case FbDbType.Integer:
					{
						// Integer
						int intValue = BitConverter.ToInt32(slice, slicePosition);
						intValue = IPAddress.HostToNetworkOrder(intValue);
					
						if (desc.Scale < 0)		
						{								
							decimal dvalue = GdsDecodeType.DecodeDecimal(
														intValue, 
														desc.Scale,
														GdsCodes.SQL_LONG);
							tempData.SetValue(dvalue, i);
						}
						else
						{							
							tempData.SetValue(intValue, i);
						}
					}
					break;
	
					case FbDbType.BigInt:
					{
						// BigInt/Long
						long bintValue = BitConverter.ToInt64(slice, slicePosition);
						bintValue = IPAddress.HostToNetworkOrder(bintValue);
					
						if (desc.Scale < 0)		
						{
							decimal dvalue = GdsDecodeType.DecodeDecimal(
														bintValue, 
														desc.Scale,
														GdsCodes.SQL_INT64);
							tempData.SetValue(dvalue, i);
						}
						else
						{							
							tempData.SetValue(bintValue, i);
						}
					}
					break;
					
					case FbDbType.Double:
					{
						// Double						
						DoubleLayout dlayout = new DoubleLayout();
			
						dlayout.d	= BitConverter.ToDouble(slice, slicePosition);
						dlayout.i0	= IPAddress.HostToNetworkOrder(dlayout.i0);
						dlayout.i4	= IPAddress.HostToNetworkOrder(dlayout.i4);
			
						temp 		= dlayout.i0;
						dlayout.i0 	= dlayout.i4;
						dlayout.i4 	= temp;
			
						tempData.SetValue(dlayout.d, i);
					}
					break;
	
					case FbDbType.Float:
					{
						// Float
						FloatLayout flayout = new FloatLayout();								
																	
						flayout.f  = BitConverter.ToSingle(slice, slicePosition);
						flayout.i0 = IPAddress.HostToNetworkOrder(flayout.i0);
					
						tempData.SetValue(flayout.f, i);
					}
					break;
										
					case FbDbType.TimeStamp:
					{
						// TimeStamp
						int idate	= BitConverter.ToInt32(slice, slicePosition);
						idate		= IPAddress.HostToNetworkOrder(idate);
						
						int itime	= BitConverter.ToInt32(slice, slicePosition + 4);
						itime		= IPAddress.HostToNetworkOrder(itime);
					
						DateTime date = GdsDecodeType.DecodeDate(idate);
						DateTime time = GdsDecodeType.DecodeTime(itime);

						DateTime timestamp = new System.DateTime(
										date.Year, date.Month, date.Day,
										time.Hour,time.Minute, time.Second, time.Millisecond);
					
						
						tempData.SetValue(timestamp, i);
					}
					break;
					
					case FbDbType.Time:
					{
						// Time
						int itime 	= BitConverter.ToInt32(slice, slicePosition);
						itime		= IPAddress.HostToNetworkOrder(itime);
					
						DateTime time = GdsDecodeType.DecodeTime(itime);					
						
						tempData.SetValue(time, i);
					}
					break;
					
					case FbDbType.Date:
					{
						// Date
						int idate 	= BitConverter.ToInt32(slice, slicePosition);
						idate		= IPAddress.HostToNetworkOrder(idate);
					
						DateTime date = GdsDecodeType.DecodeDate(idate);
						
						tempData.SetValue(date, i);
					}
					break;
				}
				
				slicePosition += item_length;
			}
			
			if (systemType.IsPrimitive)
			{
				// For primitive types we can use System.Buffer to copy generated data to destination array
				System.Buffer.BlockCopy(tempData, 0, sliceData, 0, System.Buffer.ByteLength(tempData));
			}
			else
			{
				sliceData = tempData;	
			}
			
			return sliceData;
		}		
						
		private System.Array getArrayFromDesc(GdsArrayDesc desc, ref FbDbType type, ref Type systemType, int[] lengths, int[] lowerBounds)
		{
			switch (desc.DataType)
			{
				case GdsCodes.blr_text:
				case GdsCodes.blr_text2:
				case GdsCodes.blr_cstring:
				case GdsCodes.blr_cstring2:
					// Char
					type 		= FbDbType.Text;
					systemType 	= typeof(System.String);
					break;

				case GdsCodes.blr_varying:
				case GdsCodes.blr_varying2:
					// VarChar
					type = FbDbType.VarChar;
					systemType 	= typeof(System.String);
					break;

				case GdsCodes.blr_short:
					// Short/Smallint
					type = FbDbType.SmallInt;
					if (desc.Scale < 0)
					{
						systemType 	= typeof(System.Decimal);
					}
					else
					{
						systemType 	= typeof(System.Int16);
					}
					break;

				case GdsCodes.blr_long:
					// Integer
					type = FbDbType.Integer;
					if (desc.Scale < 0)
					{
						systemType 	= typeof(System.Decimal);
					}
					else
					{
						systemType 	= typeof(System.Int32);
					}
					break;
				
				case GdsCodes.blr_float:
					// Float
					type = FbDbType.Float;
					systemType 	= typeof(System.Single);
					break;
									
				case GdsCodes.blr_double:
				case GdsCodes.blr_d_float:
					// Double
					type = FbDbType.Double;
					systemType 	= typeof(System.Double);
					break;
												
				case GdsCodes.blr_quad:
				case GdsCodes.blr_int64:
					// Long/Quad
					type = FbDbType.BigInt;
					if (desc.Scale < 0)
					{
						systemType 	= typeof(System.Decimal);
					}
					else
					{
						systemType 	= typeof(System.Int64);
					}
					break;
				
				case GdsCodes.blr_timestamp:
					// Timestamp
					type = FbDbType.TimeStamp;
					systemType 	= typeof(System.DateTime);
					break;

				case GdsCodes.blr_sql_time:			
					// Time
					type = FbDbType.Time;
					systemType 	= typeof(System.DateTime);
					break;

				case GdsCodes.blr_sql_date:				
					// Date
					type = FbDbType.Date;
					systemType 	= typeof(System.DateTime);
					break;
				
				default:
					throw new NotSupportedException("Unknown data type");
			}
			
			return System.Array.CreateInstance(systemType, lengths, lowerBounds);
		}

		#endregion
	}	
}
