//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Globalization;
using System.ComponentModel;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/overview/*'/>
	public sealed class FbDataReader : MarshalByRefObject, IDataReader, IEnumerable, IDisposable, IDataRecord
	{		
		#region FIELDS
		
		private const int	STARTPOS = -1;
		private bool		disposed;
		private bool		open;
		private int			position;
		private int			recordsAffected;
		private int			fieldCount;
		private DataTable	schemaTable;
		private FbCommand	command;
		private object[]	row;

		#endregion

		#region PROPERTIES

		internal FbCommand Command
		{
			get { return command; }
		}

		#endregion

		#region CONSTRUCTORS

		internal FbDataReader()
		{
			open			= true;
			position		= STARTPOS;
			recordsAffected = -1;						
			fieldCount		= -1;
		}

		internal FbDataReader(FbCommand command) : this()
		{
			this.command						= command;
			this.command.Connection.DataReader	= this;

			fieldCount = this.command.Statement.Fields.SqlD;
		}

		#endregion

		#region DESTRUCTORS

		~FbDataReader()
		{
			Dispose(false);
		}

		void IDisposable.Dispose() 
		{
			this.Dispose(true);
			System.GC.SuppressFinalize(this);
		}

		private void Dispose(bool disposing)
		{
			if (!disposed)
			{
				try
				{
					if (disposing)
					{
						// release any managed resources
						Close();
					}

					// release any unmanaged resources
				}
				finally
				{
				}
							
				disposed = true;
			}
		}

		#endregion

		#region IDATAREADER_PROPERTIES_METHODS

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/property[@name="Depth"]/*'/>
		public int Depth 
		{
			get { return 0; }
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/property[@name="IsClosed"]/*'/>
		public bool IsClosed
		{
			get { return !open; }
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/property[@name="RecordsAffected"]/*'/>
		public int RecordsAffected 
		{
			get { return IsClosed ? recordsAffected : -1; }
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/property[@name="HasRows"]/*'/>
		public bool HasRows
		{
			get 
			{ 
				return true;
			}
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="Close"]/*'/>
		public void Close()
		{
			if (!open)
			{
				return;
			}

			updateRecordsAffected();

			if (command != null)
			{
				if (!command.IsDisposed)
				{
					command.Connection.DataReader = null;

					if (command.Statement != null)
					{
						// Set values of output parameters
						command.SetOutputParameters();

						// Close statement
						command.Statement.Drop();
						command.Statement = null;
			
						if ((command.CommandBehavior & CommandBehavior.CloseConnection) == CommandBehavior.CloseConnection)
						{
							command.Connection.Close();
						}
					}
				}
			}

			open	 = false;			
			position = STARTPOS;
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="NextResult"]/*'/>
		public bool NextResult()
		{
			if (IsClosed)
			{
				throw new InvalidOperationException("The datareader must be opened.");
			}

			updateRecordsAffected();

			bool returnValue = command.NextResult();

			if (returnValue)
			{
				position  = STARTPOS;				
			}
			else
			{
				row = null;
			}

			return returnValue;
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="Read"]/*'/>
		public bool Read()
		{
			if (command.CommandBehavior == CommandBehavior.SingleRow && 
				position != STARTPOS)
			{
				return false;
			}

			try
			{
				row = command.Statement.Fetch();
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			if (row == null)
			{
				if (position == STARTPOS)
				{
					fieldCount = 0;
				}

				return false;
			}
			else
			{
				fieldCount = command.Statement.Fields.SqlD;

				position++;

				return true;
			}
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetSchemaTable"]/*'/>
		public DataTable GetSchemaTable()
		{
			if (schemaTable != null)
			{
				return schemaTable;
			}

			DataRow	 schemaRow;

			schemaTable = getSchemaTableStructure();

			/* Prepare statement for schema fields information	*/
			FbCommand schemaCmd = new FbCommand(
								this.getSchemaCommandText(),
								this.command.Connection);

			schemaCmd.Parameters.Add("@TABLE_NAME", FbDbType.VarChar);
			schemaCmd.Parameters.Add("@COLUMN_NAME", FbDbType.VarChar);
			schemaCmd.InternalPrepare();

			schemaTable.BeginLoadData();			
			for (int i = 0; i < FieldCount; i++)
			{
				/* Get Schema data for the field	*/
				schemaCmd.Parameters[0].Value = getBaseTableName(i);
				schemaCmd.Parameters[1].Value = getBaseColumnName(i);
				
				schemaCmd.InternalExecute();

				object[] row = schemaCmd.Statement.Fetch();

				/* Create new row for the Schema Table	*/
				schemaRow = schemaTable.NewRow();

				schemaRow["ColumnName"]		= GetName(i);
				schemaRow["ColumnOrdinal"]	= i;
				schemaRow["ColumnSize"]		= getSize(i);
				if (isNumeric(i))
				{
					schemaRow["NumericPrecision"]= getSize(i);
					schemaRow["NumericScale"]	 = getScale(i);
				}
				else
				{
					schemaRow["NumericPrecision"]= System.DBNull.Value;
					schemaRow["NumericScale"]	 = System.DBNull.Value;
				}
				schemaRow["DataType"]		= GetFieldType(i);
				schemaRow["ProviderType"]	= getProviderType(i);
				schemaRow["IsLong"]			= isLong(i);
				if ((bool)schemaRow["IsLong"])
				{
					schemaRow["ColumnSize"]	= System.Int32.MaxValue;
				}
				schemaRow["AllowDBNull"]	= allowDBNull(i);
				schemaRow["IsRowVersion"]	= false;
				schemaRow["IsAutoIncrement"]= false;
				if (row != null)
				{
					// Is Table Field
					schemaRow["IsReadOnly"]	= (Convert.ToInt32(row[9]) == 0) ? true : false;
					schemaRow["IsKey"]		= (Convert.ToInt32(row[11]) == 1) ? true : false;
					schemaRow["IsUnique"]	= (Convert.ToInt32(row[12]) == 1) ? true : false;
				}
				else
				{
					// Isn't Table Field
					schemaRow["IsReadOnly"]	= true;
					schemaRow["IsKey"]		= false;
					schemaRow["IsUnique"]	= false;
				}
				schemaRow["IsAliased"]		= isAliased(i);
				schemaRow["IsExpression"]	= isExpression(i);
				schemaRow["BaseSchemaName"]	= DBNull.Value;
				schemaRow["BaseCatalogName"]= DBNull.Value;
				schemaRow["BaseTableName"]	= getBaseTableName(i);
				schemaRow["BaseColumnName"]	= getBaseColumnName(i);

				schemaTable.Rows.Add(schemaRow);

				/* Close statement	*/
				schemaCmd.Statement.Close();
			}
			schemaTable.EndLoadData();

			/* Drop statement	*/
			schemaCmd.Statement.Drop();

			return schemaTable;
		}

		#endregion

		#region IDATARECORD_PROPERTIES_METHODS

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/indexer[@name="Item(System.Int32)"]/*'/>
		public object this[int i]
		{
			get { return GetValue(i); }
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/indexer[@name="Item(System.String)"]/*'/>
		public object this[String name]
		{			
			get { return GetValue(GetOrdinal(name)); }
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/property[@name="FieldCount"]/*'/>
		public int FieldCount
		{			
			get { return fieldCount; }
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetName(System.Int32)"]/*'/>
		public string GetName(int i)
		{
			if (i < 0 || i >= FieldCount)
			{
				throw new IndexOutOfRangeException("Could not find specified column in results.");
			}

			if (command.Statement.Fields.SqlVar[i].AliasName.Length > 0)
			{
				return command.Statement.Fields.SqlVar[i].AliasName;
			}
			else
			{
				return command.Statement.Fields.SqlVar[i].SqlName;
			}
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetDataTypeName(System.Int32)"]/*'/>
		public String GetDataTypeName(int i)
		{
			if (i < 0 || i >= FieldCount)
			{
				throw new IndexOutOfRangeException("Could not find specified column in results.");
			}

			return command.Statement.Fields.SqlVar[i].GetDataTypeName();
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetFieldType(System.Int32)"]/*'/>
		public Type GetFieldType(int i)
		{
			checkIndex(i);

			return command.Statement.Fields.SqlVar[i].GetSystemType();
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetValue(System.Int32)"]/*'/>
		public Object GetValue(int i)
		{
			checkIndex(i);

			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			if (row[i] == null)
			{
				return System.DBNull.Value;
			}

			switch (command.Statement.Fields.SqlVar[i].SqlType & ~1)
			{
				case GdsCodes.SQL_TEXT:
				case GdsCodes.SQL_VARYING:
					// Char
					// Varchar
					return Convert.ToString(row[i]);

				case GdsCodes.SQL_SHORT:
					// Short/Smallint
					if (command.Statement.Fields.SqlVar[i].SqlScale < 0)
					{
						return Convert.ToDecimal(row[i]);
					}
					else
					{
						return Convert.ToInt16(row[i]);
					}

				case GdsCodes.SQL_LONG:
					// Long
					if (command.Statement.Fields.SqlVar[i].SqlScale < 0)
					{
						return Convert.ToDecimal(row[i]);
					}
					else
					{
						return Convert.ToInt32(row[i]);
					}
				
				case GdsCodes.SQL_FLOAT:
					// Float
					return Convert.ToSingle(row[i]);
									
				case GdsCodes.SQL_DOUBLE:
				case GdsCodes.SQL_D_FLOAT:
					// Doble
					return Convert.ToDouble(row[i]);
								
				case GdsCodes.SQL_BLOB:
					// Blob binary
					if (command.Statement.Fields.SqlVar[i].SqlSubType < 0)
					{
						if (row[i] is long)
						{
							row[i] = getBlobData((long)row[i]);
						}
						return row[i];
					}
					else
					{
						if (row[i] is long)
						{
							row[i] = getClobData((long)row[i]);							
						}
						return row[i];
					}
				
				case GdsCodes.SQL_QUAD:
				case GdsCodes.SQL_INT64:
					if (command.Statement.Fields.SqlVar[i].SqlScale < 0)
					{
						return Convert.ToDecimal(row[i]);
					}
					else
					{
						return Convert.ToInt64(row[i]);
					}
									
				case GdsCodes.SQL_TIMESTAMP:
				case GdsCodes.SQL_TYPE_TIME:			
				case GdsCodes.SQL_TYPE_DATE:				
					// Timestamp, Time and Date
					return Convert.ToDateTime(row[i]);
				
				case GdsCodes.SQL_ARRAY:
					return getArrayData(i, (long)row[i]);
										
				default:
					throw new NotSupportedException("Unknown data type");
			}
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetValues(System.Array)"]/*'/>
		public int GetValues(object[] values)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}
			
			for(int i = 0; i < FieldCount; i++)
			{
				values[i] = GetValue(i);
			}

			return values.Length;
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetOrdinal(System.String)"]/*'/>
		public int GetOrdinal(string name)
		{
			if (IsClosed)
			{
				throw new InvalidOperationException("Reader closed");
			}

			GdsRowDescription rowDesc = command.Statement.Fields;

			for (int i = 0; i < FieldCount; i++)
			{
				if (cultureAwareCompare(name, rowDesc.SqlVar[i].AliasName))
				{
					return i;
				}
			}
						
			throw new IndexOutOfRangeException("Could not find specified column in results.");
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetBoolean(System.Int32)"]/*'/>
		public bool GetBoolean(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToBoolean(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetByte(System.Int32)"]/*'/>
		public byte GetByte(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToByte(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetBytes(System.Int32,System.Int64,System.Byte[],System.Int32,System.Int32)"]/*'/>
		public long GetBytes(int i, long dataIndex, byte[] buffer, int bufferIndex, int length)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			checkIndex(i);

			int bytesRead	= 0;
			int realLength	= length;

			if (buffer == null)
			{
				return command.Statement.Fields.SqlVar[i].SqlLen;
			}
			
			byte[] byteArray = (byte[])GetValue(i);

			if (length > (byteArray.Length - dataIndex))
			{
				realLength = byteArray.Length - (int)dataIndex;
			}
            					
			Array.Copy(byteArray, (int)dataIndex, buffer, bufferIndex, realLength);

			if ((byteArray.Length - dataIndex) < length)
			{
				bytesRead = byteArray.Length - (int)dataIndex;
			}
			else
			{
				bytesRead = length;
			}

			return bytesRead;
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetChar(System.Int32)"]/*'/>
		[EditorBrowsable(EditorBrowsableState.Never)]
		public char GetChar(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}
			
			return Convert.ToChar(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetChars(System.Int32,System.Int64,System.Char[],System.Int32,System.Int32)"]/*'/>
		public long GetChars(int i, long dataIndex, char[] buffer, int bufferIndex, int length)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			checkIndex(i);

			if (buffer == null)
			{
				return command.Statement.Fields.SqlVar[i].SqlLen;
			}
			
			int charsRead	= 0;
			int realLength	= length;
			
			char[] charArray = ((string)GetValue(i)).ToCharArray();

			if (length > (charArray.Length - dataIndex))
			{
				realLength = charArray.Length - (int)dataIndex;
			}
            					
			System.Array.Copy(charArray, (int)dataIndex, buffer, 
				bufferIndex, realLength);

			if ( (charArray.Length - dataIndex) < length)
			{
				charsRead = charArray.Length - (int)dataIndex;
			}
			else
			{
				charsRead = length;
			}

			return charsRead;
		}
		
		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetGuid(System.Int32)"]/*'/>
		public Guid GetGuid(int i)
		{
			throw new NotSupportedException("Guid data type is not supported.");
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetInt16(System.Int32)"]/*'/>
		public Int16 GetInt16(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToInt16(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetInt32(System.Int32)"]/*'/>
		public Int32 GetInt32(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToInt32(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetInt64(System.Int32)"]/*'/>		
		public Int64 GetInt64(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToInt64(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetFloat(System.Int32)"]/*'/>
		public float GetFloat(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToSingle(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetDouble(System.Int32)"]/*'/>
		public double GetDouble(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}
			
			return Convert.ToDouble(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetString(System.Int32)"]/*'/>
		public String GetString(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToString(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetDecimal(System.Int32)"]/*'/>
		public Decimal GetDecimal(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToDecimal(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetDateTime(System.Int32)"]/*'/>
		public DateTime GetDateTime(int i)
		{
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			return Convert.ToDateTime(GetValue(i));
		}

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="GetData(System.Int32)"]/*'/>
		[EditorBrowsable(EditorBrowsableState.Never)]
		public IDataReader GetData(int i)
		{
			throw new NotSupportedException("GetData not supported.");
		}		

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="IsDBNull(System.Int32)"]/*'/>
		public bool IsDBNull(int i)
		{	
			if (position == STARTPOS)
			{
				throw new InvalidOperationException("There are no data to read.");
			}

			if (i < 0 || i >= FieldCount)
			{
				throw new IndexOutOfRangeException("Could not find specified column in results.");
			}
						
			return (row[i] == null || 
					row[i] == System.DBNull.Value) ? true : false;
		}

		#endregion

		#region IENUMERABLE_METHODS

		/// <include file='Doc/en_EN/FbDataReader.xml' path='doc/class[@name="FbDataReader"]/method[@name="IEnumerable.GetEnumerator"]/*'/>
		IEnumerator IEnumerable.GetEnumerator()
		{
			return new DbEnumerator(this);
		}

		#endregion

		#region PRIVATE_METHODS

		private string getClobData(long handle)
		{
			GdsAsciiBlob clob = new GdsAsciiBlob(
								this.command.Connection.DbConnection.DB, 
								this.command.Statement.Transaction, 
								handle);
			string contents = clob.Read();
			clob.Close();
			
			return contents;
		}

		private byte[] getBlobData(long handle)
		{
			GdsBinaryBlob blob = new GdsBinaryBlob(
				this.command.Connection.DbConnection.DB, 
				this.command.Statement.Transaction,
				handle);
			byte[] contents = blob.Read();
			blob.Close();
			
			return contents;
		}

		private object getArrayData(int index, long handle)
		{
			GdsArray gdsArray = new GdsArray(
					command.Connection.DbConnection.DB, 
					this.command.Statement.Transaction,
					handle,
					getBaseTableName(index),
					getBaseColumnName(index));
			
			return gdsArray.Read();
		}

		private void checkIndex(int i)
		{
			if (i < 0 || i >= FieldCount)
			{
				throw new IndexOutOfRangeException("Could not find specified column in results.");
			}
		}

		private FbDbType getProviderType(int i)
		{
			return command.Statement.Fields.SqlVar[i].GetFbDbType();
		}

		private int getSize(int i)
		{
			return command.Statement.Fields.SqlVar[i].SqlLen;
		}

		private int getScale(int i)
		{
			return command.Statement.Fields.SqlVar[i].SqlScale;
		}

		private String getBaseTableName(int i)
		{
			return command.Statement.Fields.SqlVar[i].RelName;
		}

		private String getBaseColumnName(int i)
		{
			return command.Statement.Fields.SqlVar[i].AliasName;
		}

		private bool isNumeric(int i)
		{			
			return command.Statement.Fields.SqlVar[i].IsNumeric();
		}

		private bool isLong(int i)
		{			
			return command.Statement.Fields.SqlVar[i].IsLong();
		}

		private bool allowDBNull(int i)
		{	
			GdsField field = command.Statement.Fields.SqlVar[i];

			return (field.SqlType & 1) == 1 ? true : false;
		}

		private bool isAliased(int i)
		{
			GdsField field = command.Statement.Fields.SqlVar[i];

			return field.SqlName != field.AliasName ? true : false;
		}

		private bool isExpression(int i)
		{	
			GdsField field = command.Statement.Fields.SqlVar[i];

			return field.SqlName.Length == 0 ? true : false;
		}

		private DataTable getSchemaTableStructure()
		{
			DataTable schema = new DataTable("Schema");			

			// Schema table structure
			schema.Columns.Add("ColumnName"		, System.Type.GetType("System.String"));
			schema.Columns.Add("ColumnOrdinal"	, System.Type.GetType("System.Int32"));
			schema.Columns.Add("ColumnSize"		, System.Type.GetType("System.Int32"));
			schema.Columns.Add("NumericPrecision", System.Type.GetType("System.Int32"));
			schema.Columns.Add("NumericScale"	, System.Type.GetType("System.Int32"));
			schema.Columns.Add("DataType"		, System.Type.GetType("System.Type"));
			schema.Columns.Add("ProviderType"	, System.Type.GetType("System.Int32"));
			schema.Columns.Add("IsLong"			, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("AllowDBNull"	, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsReadOnly"		, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsRowVersion"	, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsUnique"		, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsKey"			, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsAutoIncrement", System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsAliased"		, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("IsExpression"	, System.Type.GetType("System.Boolean"));
			schema.Columns.Add("BaseSchemaName"	, System.Type.GetType("System.String"));
			schema.Columns.Add("BaseCatalogName", System.Type.GetType("System.String"));
			schema.Columns.Add("BaseTableName"	, System.Type.GetType("System.String"));
			schema.Columns.Add("BaseColumnName"	, System.Type.GetType("System.String"));
			
			return schema;
		}

		private string getSchemaCommandText()
		{
			System.Text.StringBuilder sql = new System.Text.StringBuilder();
			sql.AppendFormat(
				"SELECT rfr.rdb$relation_name     as table_name,\n"	+
				"rfr.rdb$field_name        as colum_name,\n"	+
				"rfr.rdb$field_position    as column_ordinal,\n"+
				"fld.rdb$field_length      as column_size,\n"	+
				"fld.rdb$field_precision   as numeric_precision,\n"	+
				"fld.rdb$field_scale       as numeric_scale,\n"	+
				"fld.rdb$field_type        as data_type,\n"		+
				"fld.rdb$field_sub_type    as data_sub_type,\n"	+
				"rfr.rdb$null_flag         as nullable,\n"		+
				"rfr.rdb$update_flag       as is_readonly,\n"	+
				"rfr.rdb$default_value     as column_def,\n"	+
				"(select count(*)\n"							+
				"from rdb$relation_constraints rel, rdb$indices idx, rdb$index_segments seg\n"	+
				"where rel.rdb$constraint_type = 'PRIMARY KEY'\n"	+
				"and rel.rdb$index_name = idx.rdb$index_name\n"	+
				"and idx.rdb$index_name = seg.rdb$index_name\n"	+
				"and rel.rdb$relation_name = rfr.rdb$relation_name\n"	+
				"and seg.rdb$field_name = rfr.rdb$field_name) as primary_key,\n"	+
				"(select count(*)\n"	+
				"from rdb$relation_constraints rel, rdb$indices idx, rdb$index_segments seg\n"	+
				"where rel.rdb$constraint_type = 'UNIQUE'\n"	+
				"and rel.rdb$index_name = idx.rdb$index_name\n"	+
				"and idx.rdb$index_name = seg.rdb$index_name\n"	+
				"and rel.rdb$relation_name = rfr.rdb$relation_name\n"	+
				"and seg.rdb$field_name = rfr.rdb$field_name) as unique_key\n"	+
				"from rdb$relation_fields rfr, rdb$fields fld\n"	+
				"where rfr.rdb$field_source = fld.rdb$field_name");
				
			sql.Append("\n and rfr.rdb$relation_name = ?");	
			sql.Append("\n and rfr.rdb$field_name = ?");
			sql.Append("\n order by rfr.rdb$relation_name, rfr.rdb$field_position");

			return sql.ToString();			
		}

		private void updateRecordsAffected()
		{
			if (command != null && !command.IsDisposed)
			{
				if (command.RecordsAffected != -1)
				{
					recordsAffected = recordsAffected == -1 ? 0 : recordsAffected;
					recordsAffected += command.RecordsAffected;
				}
			}
		}

		private bool cultureAwareCompare(string strA, string strB)
		{
			try
			{
				return CultureInfo.CurrentCulture.CompareInfo.Compare(
					strA, 
					strB, 
					CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth | 
					CompareOptions.IgnoreCase) == 0 ? true : false;
			}
			catch (NotSupportedException)
			{
				return strA.ToUpper() == strB.ToUpper() ? true : false;
			}
		}

		#endregion
	}
}
