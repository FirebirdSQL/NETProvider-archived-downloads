//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/overview/*'/>
	[Serializable, ListBindable(false)]
	public sealed class FbErrorCollection : ICollection, IEnumerable
	{
		#region FIELDS

		private ArrayList errors = new ArrayList();

		#endregion

		#region INDEXERS

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/indexer[@name="Item(System.String)"]/*'/>
		public FbError this[string errorMessage] 
		{
			get { return (FbError)errors[IndexOf(errorMessage)]; }
			set { errors[IndexOf(errorMessage)] = (FbError)value; }
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/indexer[@name="Item(System.Int32)"]/*'/>
		public FbError this[int errorIndex] 
		{
			get { return (FbError)errors[errorIndex]; }
			set { errors[errorIndex] = (FbError)value; }
		}

		#endregion

		#region CONSTRUCTORS

		internal FbErrorCollection()
		{
		}

		#endregion

		#region ICOLLECTION_PROPERTIES

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/property[@name="Count"]/*'/>
		public int Count 
		{
			get { return errors.Count; }
		}
		
		bool ICollection.IsSynchronized
		{
			get { return errors.IsSynchronized; }
		}

		object ICollection.SyncRoot 
		{
			get { return errors.SyncRoot; }
		}

		#endregion

		#region ICOLLECTION_METHODS

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="CopyTo(System.Array,System.Int32)"]/*'/>	
		public void CopyTo(Array array, int index)
		{
			errors.CopyTo(array, index);
		}
		
		#endregion

		#region IENUMERABLE_METHODS

		IEnumerator IEnumerable.GetEnumerator()
		{
			return errors.GetEnumerator();
		}

		#endregion

		#region METHODS

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Contains(System.String)"]/*'/>	
		internal bool Contains(string errorMessage)
		{
			return(-1 != IndexOf(errorMessage));
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="IndexOf(System.String)"]/*'/>		
		internal int IndexOf(string errorMessage)
		{
			int index = 0;
			foreach(FbError item in this)
			{
				if (cultureAwareCompare(item.Message, errorMessage))
				{
					return index;
				}
				index++;
			}
			return -1;
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="RemoveAt(System.String)"]/*'/>
		internal void RemoveAt(string errorMessage)
		{
			errors.RemoveAt(IndexOf(errorMessage));
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Add(FbError)"]/*'/>
		internal FbError Add(FbError error)
		{
			errors.Add(error);

			return error;
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Add(System.String,System.Int32)"]/*'/>
		internal FbError Add(string errorMessage, int number)
		{
			FbError error = new FbError(errorMessage, number);			

			return Add(error);
		}

		/// <include file='Doc/en_EN/FbErrorCollection.xml' path='doc/class[@name="FbErrorCollection"]/method[@name="Add(System.Byte,System.Int32,System.String,System.Int32)"]/*'/>
		internal FbError Add(byte classError, int line, string errorMessage, int number)
		{
			FbError error = new FbError(classError, line, errorMessage, number);
			
			return Add(error);
		}
		
		private bool cultureAwareCompare(string strA, string strB)
		{
			try
			{
				return CultureInfo.CurrentCulture.CompareInfo.Compare(strA, strB,
						CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth |
						CompareOptions.IgnoreCase) == 0 ? true : false;
			}
			catch (NotSupportedException)
			{
				return strA.ToUpper() == strB.ToUpper() ? true : false;
			}
		}

		#endregion
	}
}
