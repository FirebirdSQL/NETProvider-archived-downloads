/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.Collections;
using System.Data;
using System.Globalization;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/overview/*'/>
	public sealed class FbConnectionString
	{
		#region Private fields

		private Hashtable	options;
		private bool		allowEmptyDatabase;

		#endregion

		#region Properties

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="IsValid"]/*'/>
		public bool IsValid
		{
			get
			{
				try
				{
					this.Validate();

					return true;
				}
				catch 
				{
					return false;
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="UserName"]/*'/>
		public string UserName
		{
			get { return this.options["UserName"].ToString(); }
			set 
			{ 
				if (value == null)
				{
					value = String.Empty;
				}
				this.options["UserName"] = value; 
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="UserPassword"]/*'/>
		public string UserPassword
		{
			get { return this.options["Password"].ToString(); }
			set 
			{ 
				if (value == null)
				{
					value = String.Empty;
				}
				this.options["Password"] = value; 
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="DataSource"]/*'/>
		public string DataSource
		{
			get { return this.options["DataSource"].ToString(); }
			set 
			{ 
				if (value == null)
				{
					value = String.Empty;
				}
				this.options["DataSource"] = value; 
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="Port"]/*'/>
		public int Port
		{
			get { return Convert.ToInt32(this.options["Port"]); }
			set { this.options["Port"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="Database"]/*'/>
		public string Database
		{
			get { return this.options["Database"].ToString(); }
			set 
			{ 
				if (value == null)
				{
					value = String.Empty;
				}
				this.options["Database"] = value; 
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="PacketSize"]/*'/>
		public short PacketSize
		{
			get { return Int16.Parse(this.options["PacketSize"].ToString()); }
			set { this.options["PacketSize"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="Role"]/*'/>
		public string Role
		{
			get { return this.options["Role"].ToString(); }
			set 
			{ 
				if (value == null)
				{
					value = String.Empty;
				}
				this.options["Role"] = value; 
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="Dialect"]/*'/>
		public byte Dialect
		{
			get { return Byte.Parse(this.options["Dialect"].ToString()); }
			set { this.options["Dialect"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="Charset"]/*'/>
		public string Charset
		{
			get { return this.options["Charset"].ToString(); }
			set 
			{ 
				if (value == null)
				{
					value = String.Empty;
				}
				this.options["Charset"] = value; 
			}
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="ConnectionTimeout"]/*'/>
		public int ConnectionTimeout
		{
			get { return Convert.ToInt32(this.options["ConnectionTimeout"]); }
			set { this.options["ConnectionTimeout"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="Pooling"]/*'/>
		public bool Pooling
		{
			get { return Convert.ToBoolean(this.options["Pooling"]); }
			set { this.options["Pooling"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="ConnectionLifeTime"]/*'/>
		public long ConnectionLifeTime
		{
			get { return Convert.ToInt64(this.options["ConnectionLifetime"]); }
			set { this.options["ConnectionLifetime"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="MinPoolSize"]/*'/>
		public int MinPoolSize
		{
			get { return Convert.ToInt32(this.options["MinPoolSize"]); }
			set { this.options["MinPoolSize"] = value; }
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="MaxPoolSize"]/*'/>
		public int MaxPoolSize
		{
			get { return Convert.ToInt32(this.options["MaxPoolSize"]); }
			set { this.options["MaxPoolSize"] = value; }
		}

        /// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="FetchSize"]/*'/>
        public int FetchSize
        {
            get { return Convert.ToInt32(this.options["FetchSize"]); }
            set { this.options["FetchSize"] = value; }
        }

        /// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/property[@name="ServerType"]/*'/>
		public int ServerType
		{
			get { return Convert.ToInt32(this.options["ServerType"]); }
			set { this.options["ServerType"] = value; }
		}

		#endregion

		#region Constructors

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/constructor[@name="ctor"]/*'/>
		public FbConnectionString() : this(null)
		{
		}

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/constructor[@name="ctor(System.String,System.String,System.String)"]/*'/>
		public FbConnectionString(string user, string password, string database) : this(null)
		{
            this.UserName       = user;
            this.UserPassword   = password;
            this.Database       = database;
        }

        /// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/constructor[@name="ctor(System.String,System.String,System.String,System.String,System.Int32)"]/*'/>
        public FbConnectionString(string user, string password, string database, string dataSource, int port) : this(null)
        {
            this.UserName		= user;
			this.UserPassword	= password;
			this.Database		= database;
			this.DataSource		= dataSource;
			this.Port			= port;
		}

        /// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/constructor[@name="ctor(System.String)"]/*'/>
        public FbConnectionString(string connectionString)
        {
            this.Load(connectionString);
        }

		#endregion

		#region Internal constructors

		internal FbConnectionString(bool allowEmptyDatabase) : this()
		{
			this.allowEmptyDatabase = allowEmptyDatabase;
		}

		#endregion

		#region Public methods

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/method[@name="Load(System.String)"]/*'/>
		public void Load(string connectionString)
		{
			this.SetDefaultOptions();

            if (connectionString != null && connectionString.Length > 0)
            {
                this.ParseConnectionString(connectionString);
            }
        }

		/// <include file='Doc/en_EN/FbConnectionString.xml' path='doc/class[@name="FbConnectionString"]/method[@name="Validate()"]/*'/>
		public void Validate()
		{
			if ((this.UserName == null || this.UserName.Length == 0) ||
				(this.UserPassword == null || this.UserPassword.Length == 0) ||
				((this.Database == null || this.Database.Length == 0) && !allowEmptyDatabase) ||
				(this.DataSource == null || this.DataSource.Length == 0) ||
				(this.Charset == null || this.Charset.Length == 0) ||
				this.Port == 0 ||
				(this.ServerType != 0 && this.ServerType  != 1)	||
				(this.MinPoolSize > this.MaxPoolSize))
			{
				throw new ArgumentException("An invalid connection string argument has been supplied or a required connection string argument has not been supplied.");
			}
			else
			{
				if (this.Dialect < 1 || this.Dialect > 3)
				{
					throw new ArgumentException("Incorrect database dialect it should be 1, 2, or 3.");
				}
				if (this.PacketSize < 512 || this.PacketSize > 32767)
				{
					throw new ArgumentException(String.Format("'Packet Size' value of {0} is not valid.\r\nThe value should be an integer >= 512 and <= 32767.", this.PacketSize));
				}
			}
		}

		#endregion

		#region Overriden methods

		/// <summary>
		/// Overrided method, returns the Firebird connection string.
		/// </summary>
		/// <returns>The Firebird connection string.</returns>
		public override string ToString()
		{
            this.Validate();

            return String.Format(
				"Data Source={0};Database={1};User Id={2};Password={3};" +
				"Dialect={4};Charset={5};Pooling={6};Connection Lifetime={7};" +
				"Role={8};PacketSize={9};Connection Timeout={10};" +
				"Pooling={11};Min pool size={12};Max pool size={13};" +
				"Fetch Size={14};ServerType={15}",
				this.options["DataSource"],
				this.options["Database"],
				this.options["UserName"],
				this.options["Password"],
				this.options["Dialect"],
				this.options["Charset"],
				this.options["Pooling"],
				this.options["ConnectionLifetime"],
				this.options["Role"],
				this.options["PacketSize"],
				this.options["ConnectionTimeout"],
				this.options["Pooling"],
				this.options["MinPoolSize"],
				this.options["MaxPoolSize"],
                this.options["FetchSize"],
                this.options["ServerType"]);
		}

		#endregion

		#region Private Methods

		private void SetDefaultOptions()
		{
            if (this.options == null)
            {
                this.options = new Hashtable();
            }

            this.options.Clear();

			// Add default key pairs values
			this.options.Add("DataSource"			, "localhost");
			this.options.Add("Port"					, 3050);
			this.options.Add("UserName"				, "SYSDBA");
			this.options.Add("Password"				, "masterkey");
			this.options.Add("Role"					, String.Empty);
			this.options.Add("Database"				, String.Empty);
			this.options.Add("Charset"				, "None");
			this.options.Add("Dialect"				, 3);
			this.options.Add("PacketSize"			, 8192);
			this.options.Add("Pooling"				, true);
			this.options.Add("ConnectionLifetime"	, 0);
			this.options.Add("Min pool size"		, 0);
			this.options.Add("Max pool size"		, 100);
			this.options.Add("Connection timeout"	, 15);
            this.options.Add("FetchSize"            , 200);
            this.options.Add("ServerType"			, 0);
		}

		#endregion

		#region Connection String parse

		private void ParseConnectionString(string connectionString)
		{
			bool dataSourceSet = false;
			
			string[] keyPairs = connectionString.Split(';');

			foreach (string keyPair in keyPairs)
			{
				string[] values = keyPair.Split('=');

				if (values.Length == 2 &&
					values[0] != null && values[0].Length > 0 &&
					values[1] != null && values[1].Length > 0)
				{
					values[0] = values[0].Trim().ToLower(CultureInfo.CurrentCulture);
					values[1] = values[1].Trim();

					switch (values[0])
					{
						case "database":
							this.options["Database"] = values[1];
							break;

						case "datasource":
						case "data source":
						case "server":
						case "host":
							this.options["DataSource"] = values[1];
							if (this.DataSource.Length > 0)
							{
								dataSourceSet = true;
							}
							break;

						case "user name":
						case "user":
						case "userid":
						case "user id":
							this.options["UserName"] = values[1];
							break;

						case "user password":
						case "password":
							this.options["Password"] = values[1];
							break;

						case "port":
							this.options["Port"] = Int32.Parse(values[1], NumberStyles.Any);
							break;

						case "connection lifetime":
							this.options["ConnectionLifetime"] = Int32.Parse(values[1], NumberStyles.Any);
							break;

						case "min pool size":
							this.options["MinPoolSize"] = Int32.Parse(values[1], NumberStyles.Any);
							break;

						case "max pool size":
							this.options["MaxPoolSize"] = Int32.Parse(values[1], NumberStyles.Any);
							break;

						case "timeout":
						case "connection timeout":
							this.options["ConnectionTimeout"] = Int32.Parse(values[1], NumberStyles.Any);
							break;

						case "packet size":
							this.options["PacketSize"] = Int16.Parse(values[1], NumberStyles.Any);
							break;

						case "pooling":
							this.options["Pooling"] = Boolean.Parse(values[1]);
							break;

						case "dialect":
							this.options["Dialect"] = byte.Parse(values[1], NumberStyles.Any);
							break;

						case "charset":
							this.options["Charset"] = values[1];
							break;

						case "role":
						case "rolename":
						case "role name":
							this.options["Role"] = values[1];
							break;

						case "servertype":
						case "server type":
							this.options["ServerType"] = Int32.Parse(values[1], NumberStyles.Any);
							break;
                        
                        case "fetchsize":
                        case "fetch size":
                            this.options["FetchSize"] = Int32.Parse(values[1], NumberStyles.Any);
                            break;
                    }
                }
			}

			if (this.Database != null && this.Database.Length > 0 && !dataSourceSet)
			{
				this.ParseConnectionInfo(this.options["Database"].ToString());
			}

			this.Validate();
		}

		private void ParseConnectionInfo(string connectInfo)
		{
			// allows standard syntax //host:port/....
			// and old fb syntax host/port:....
			connectInfo = connectInfo.Trim();
			char hostSepChar;
			char portSepChar;
			if (connectInfo.StartsWith("//"))
			{
				connectInfo = connectInfo.Substring(2);
				hostSepChar = '/';
				portSepChar = ':';
			}
			else 
			{
				hostSepChar = ':';
				portSepChar = '/';
			}

			int sep = connectInfo.IndexOf(hostSepChar);
			if (sep == 0 || sep == connectInfo.Length - 1) 
			{
				throw new ArgumentException("An invalid connection string argument has been supplied or a required connection string argument has not been supplied.");
			}
			else if (sep > 0) 
			{
				this.options["DataSource"]	= connectInfo.Substring(0, sep);
				this.options["Database"]	= connectInfo.Substring(sep + 1);
				int portSep = this.options["DataSource"].ToString().IndexOf(portSepChar);
				if (portSep == 0 || portSep == this.options["DataSource"].ToString().Length - 1) 
				{
					throw new ArgumentException("An invalid connection string argument has been supplied or a required connection string argument has not been supplied.");
				}
				else if (portSep > 0) 
				{
					this.options["Port"]		= int.Parse(this.options["DataSource"].ToString().Substring(portSep + 1), NumberStyles.Any);
					this.options["DataSource"]	= this.options["DataSource"].ToString().Substring(0, portSep);
				}
				else if (portSep < 0 && this.options["DataSource"].ToString().Length == 1)
				{
					this.options["DataSource"]	= "localhost";
					this.options["Database"]	= connectInfo;
				}
			}
			else if (sep == -1) 
			{
				this.options["Database"] = connectInfo;
			}
		}

		#endregion

		#region Database parameter buffer

		internal DpbBuffer BuildDpb(bool littleEndian)
		{
			DpbBuffer dpb = new DpbBuffer(littleEndian);

			dpb.Append(IscCodes.isc_dpb_version1);
			dpb.Append(IscCodes.isc_dpb_dummy_packet_interval, 
				new byte[] {120, 10, 0, 0});
			dpb.Append(IscCodes.isc_dpb_sql_dialect, 
				new byte[] {Convert.ToByte(this.Dialect), 0, 0, 0});
			dpb.Append(IscCodes.isc_dpb_lc_ctype, this.Charset);
			if (this.Role != null)
			{
				if (this.Role.Length > 0)
				{
					dpb.Append(IscCodes.isc_dpb_sql_role_name, this.Role);
				}
			}
			dpb.Append(IscCodes.isc_dpb_connect_timeout, this.ConnectionTimeout);
			dpb.Append(IscCodes.isc_dpb_user_name, this.UserName);
			dpb.Append(IscCodes.isc_dpb_password, this.UserPassword);

			return dpb;
		}

		#endregion

		#region Service Parameter Buffer

		internal SpbBuffer BuildSpb(bool littleEndian)
		{
			SpbBuffer spb = new SpbBuffer(littleEndian);

			// SPB configuration				
			spb.Append(IscCodes.isc_spb_version);
			spb.Append(IscCodes.isc_spb_current_version);
			spb.Append((byte)IscCodes.isc_spb_user_name, this.UserName);
			spb.Append((byte)IscCodes.isc_spb_password, this.UserPassword);
			if (this.Role != null && this.Role.Length > 0)
			{
				spb.Append((byte)IscCodes.isc_spb_sql_role_name, this.Role);
			}
			spb.Append((byte)IscCodes.isc_spb_dummy_packet_interval, new byte[] {120, 10, 0, 0});

			return spb;
		}

		#endregion
	}
}
