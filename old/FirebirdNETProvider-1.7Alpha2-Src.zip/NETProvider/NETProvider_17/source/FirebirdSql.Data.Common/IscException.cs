/*
 *  Firebird ADO.NET Data provider for .NET and Mono 
 * 
 *     The contents of this file are subject to the Initial 
 *     Developer's Public License Version 1.0 (the "License"); 
 *     you may not use this file except in compliance with the 
 *     License. You may obtain a copy of the License at 
 *     http://www.ibphoenix.com/main.nfs?a=ibphoenix&l=;PAGES;NAME='ibp_idpl'
 *
 *     Software distributed under the License is distributed on 
 *     an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either 
 *     express or implied.  See the License for the specific 
 *     language governing rights and limitations under the License.
 * 
 *  Copyright (c) 2002, 2004 Carlos Guzman Alvarez
 *  All Rights Reserved.
 */

using System;
using System.Collections;
using System.Globalization;
using System.Text;
using System.Reflection;
using System.Resources;

namespace FirebirdSql.Data.Common
{
	internal sealed class IscException : Exception
	{	
		#region Fields
		
		private IscErrorCollection	errors;
		private int					errorCode;
		private string				message;

		#endregion

		#region Properties
		
		public IscErrorCollection Errors
		{
			get { return this.errors; }
		}

		public new string Message
		{
			get { return this.message; }
		}

		public int ErrorCode
		{
			get { return this.errorCode; }			
		}

		public bool IsWarning
		{
			get
			{
				if (this.errors.Count > 0)
				{
					return this.errors[0].IsWarning;
				}
				else
				{
					return false;
				}
			}
		}

		#endregion

		#region Constructors

		public IscException() : base()
		{
			this.errors = new IscErrorCollection();
		}

		public IscException(int errorCode) : this()
		{
			this.Errors.Add(IscCodes.isc_arg_gds, errorCode);
			this.BuildExceptionMessage();
		}

		public IscException(string strParam) : this()
		{			
			this.Errors.Add(IscCodes.isc_arg_string, strParam);
			this.BuildExceptionMessage();
		}

		public IscException(int type, string strParam) : this()
		{
			this.Errors.Add(type, strParam);
			this.BuildExceptionMessage();
		}

		public IscException(int errorCode, int intparam) : this()
		{
			this.Errors.Add(IscCodes.isc_arg_gds, errorCode);
			this.Errors.Add(IscCodes.isc_arg_number, intparam);
			this.BuildExceptionMessage();
		}
	    
		public IscException(int type, int errorCode, string strParam) : this()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(IscCodes.isc_arg_string, strParam);			
			this.BuildExceptionMessage();
		}

		public IscException(
			int type, int errorCode, int intParam, string strParam) : this()
		{
			this.Errors.Add(type, errorCode);
			this.Errors.Add(IscCodes.isc_arg_string, strParam);
			this.Errors.Add(IscCodes.isc_arg_number, intParam);
			this.BuildExceptionMessage();
		}
		
		#endregion

		#region Methods

		public void BuildExceptionMessage()
		{
			string				resources	= "FirebirdSql.Data.Common.Resources.isc_error_msg";
			StringBuilder		builder		= new StringBuilder();
			ResourceManager		rm			= new ResourceManager(resources, Assembly.GetExecutingAssembly());
			
			this.errorCode = (this.errors.Count != 0) ? this.errors[0].ErrorCode : 0;

			for (int i = 0; i < this.errors.Count; i++)
			{	
				if (this.errors[i].Type == IscCodes.isc_arg_gds || 
					this.errors[i].Type == IscCodes.isc_arg_warning)
				{
					string message = rm.GetString(this.errors[i].ErrorCode.ToString());

					ArrayList param = new ArrayList();

					int index = i + 1;

					while (index < this.errors.Count && this.errors[index].IsArgument)
					{
						param.Add(this.errors[index++].StrParam);
						i++;
					}

					object[] args = (object[])param.ToArray(typeof(object));

					IscError error = new IscError(this.Errors[i].ErrorCode);
					error.Message = String.Format(message, args);
					
					builder.Append(error.Message + "\n");
                }
			}

			// Update error collection only with the main error
			IscError mainError = new IscError(this.errorCode);
			mainError.Message = builder.ToString();

			this.errors = new IscErrorCollection();
			this.errors.Add(mainError);

			// Update exception message
			this.message = builder.ToString();
		}

		#endregion
	}
}
