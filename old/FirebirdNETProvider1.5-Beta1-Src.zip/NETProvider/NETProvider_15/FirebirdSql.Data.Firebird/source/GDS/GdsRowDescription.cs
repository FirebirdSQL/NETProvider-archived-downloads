//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// This file was initially ported from JayBird <http://firebird.sourceforge.net/>
//

using System;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsRowDescription
	{
		#region FIELDS

		private int			version;
		private int			sqln;
		private int			sqld;
		private GdsField[]	sqlvar;
		
		#endregion

		#region PROPERTIES

		public int Version
		{
			get { return version; }
			set { version = value; }
		}

		public int SqlN
		{
			get { return sqln; }
			set { sqln = value; }
		}

		public int SqlD
		{
			get { return sqld; }
			set { sqld = value; }
		}

		public GdsField[] SqlVar
		{
			get { return sqlvar; }
			set { sqlvar = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public GdsRowDescription() 
		{
			version = GdsCodes.SQLDA_VERSION1;
		}

		public GdsRowDescription(int n) : this()
		{
			sqln	= n;
			sqld	= n;
			sqlvar	= new GdsField[n];
		}

		#endregion
	}
}
