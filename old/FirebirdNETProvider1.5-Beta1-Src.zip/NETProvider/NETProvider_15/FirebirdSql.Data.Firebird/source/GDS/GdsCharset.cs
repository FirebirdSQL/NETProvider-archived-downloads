//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsCharset
	{
		#region FIELDS

		private int			id;
		private string		charSet;
		private Encoding	encoding;

		#endregion

		#region PROPERTIES

		public int ID
		{
			get { return id; }
		}

		public string CharSet
		{
			get { return charSet; }
		}

		public Encoding Encoding
		{
			get { return encoding; }
		}

		#endregion

		#region CONSTRUCTORS

		public GdsCharset()
		{
		}

		public GdsCharset(int id, string charSet, string systemCharSet)
		{
			this.id			= id;
			this.charSet	= charSet;			
			this.encoding	= Encoding.GetEncoding(systemCharSet);
		}

		public GdsCharset(int id, string charSet, int cp)
		{
			this.id			= id;
			this.charSet	= charSet;			
			this.encoding	= Encoding.GetEncoding(cp);
		}

		#endregion
	}
}
