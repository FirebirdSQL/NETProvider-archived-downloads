//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;
using System.Text;

namespace FirebirdSql.Data.Firebird.Gds
{
	internal class GdsAttachParams
	{
		#region FIELDS

		private string		userName;
		private string		userPassword;
		private string		server;
		private int			port;
		private string		fileName;
		private int			packetSize;
		private	byte		dialect;
		private string		charset;
		private string		role;
		private Encoding	encoding;		
		private int			timeout;
		private bool		pooling;

		#endregion

		#region PROPERTIES

		public string UserName
		{
			get { return userName; }
			set { userName = value; }
		}

		public string UserPassword
		{
			get { return userPassword; }
			set { userPassword = value; }
		}

		public string Server
		{
			get { return server; }
			set { server = value; }
		}

		public int Port
		{
			get { return port; }
			set { port = value; }
		}

		public string FileName
		{
			get { return fileName; }
			set { fileName = value; }
		}

		public int PacketSize
		{
			get { return packetSize; }
			set { packetSize = value; }
		}

		public string Role
		{
			get { return role; }
			set { role = value; }
		}

		public byte Dialect
		{
			get { return dialect; }
			set { dialect = value; }
		}

		public string Charset
		{
			get { return charset; }
			set 
			{ 
				charset	 = value; 
				if (value != "NONE")
				{
					if (GdsDbAttachment.CharSets == null)
					{
						GdsDbAttachment.InitializeCharSets();
					}
					encoding = GdsDbAttachment.CharSets[charset].Encoding;
				}
				else
				{
					encoding = Encoding.Default;
				}
			}
		}

		public int Timeout
		{
			get { return timeout; }
			set { timeout = value; }
		}

		public Encoding Encoding
		{
			get { return encoding; }
			set { 
				encoding = value; 
			}
		}

		public bool Pooling
		{
			get { return pooling; }
			set { pooling = value; }
		}

		#endregion

		#region CONSTRUCTORS

		public GdsAttachParams()
		{
			userName	= String.Empty;
			userPassword= String.Empty;
			fileName	= String.Empty;
			role		= String.Empty;		
			charset		= "NONE";			
			server		= "localhost";
			port		= 3050;
			dialect		= 3;			
			packetSize	= 8192;
			timeout		= 15;
			encoding	= Encoding.Default;
		}

		public GdsAttachParams(string connectInfo) : this()
		{
			if (connectInfo == null) 
			{
				throw new GdsException("Connection string missing");
			}

			/* allows standard syntax //host:port/....
			 * and old fb syntax host/port:....
			 */
			connectInfo = connectInfo.Trim();
			char hostSepChar;
			char portSepChar;
			if (connectInfo.StartsWith("//"))
			{
				connectInfo = connectInfo.Substring(2);
				hostSepChar = '/';
				portSepChar = ':';
			}
			else 
			{
				hostSepChar = ':';
				portSepChar = '/';
			}

			int sep = connectInfo.IndexOf(hostSepChar);
			if (sep == 0 || sep == connectInfo.Length - 1) 
			{
				throw new GdsException("Bad connection string: '"+hostSepChar+"' at beginning or end of:" + connectInfo +  GdsCodes.isc_bad_db_format);
			}
			else if (sep > 0) 
			{
				server = connectInfo.Substring(0, sep);
				fileName = connectInfo.Substring(sep + 1);
				int portSep = server.IndexOf(portSepChar);
				if (portSep == 0 || portSep == server.Length - 1) 
				{
					throw new GdsException("Bad server string: '"+portSepChar+"' at beginning or end of: " + server +  GdsCodes.isc_bad_db_format);
				}
				else if (portSep > 0) 
				{
					port = int.Parse(server.Substring(portSep + 1));							
					server = server.Substring(0, portSep);
				}
			}
			else if (sep == -1) 
			{
				fileName = connectInfo;
			}
		}

		public GdsAttachParams(string server, int port, string fileName, int packetSize) : this()
		{
			if (fileName == null || fileName.Equals(String.Empty)) 
			{
				throw new GdsException("null filename in DbAttachInfo");
			}
			if (server != null) 
			{
				this.server = server;
			}
			this.fileName	= fileName;
			this.port		= port;
			this.packetSize	= packetSize;
		}

		#endregion
	}
}
