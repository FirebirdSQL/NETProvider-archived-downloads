//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using FirebirdSql.Data.Firebird.Gds;
using FirebirdSql.Data.Firebird.DbSchema;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/overview/*'/>
	[ToolboxBitmap(typeof(FbConnection), "Resources.ToolboxBitmaps.FbConnection.bmp"),    
	DefaultEvent("InfoMessage")]
	public sealed class FbConnection : Component, IDbConnection, ICloneable
	{	
		#region EVENTS

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/event[@name="StateChange"]/*'/>
		public event StateChangeEventHandler StateChange;

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/event[@name="InfoMessage"]/*'/>
		public event FbInfoMessageEventHandler InfoMessage;
		
		#endregion

		#region FIELDS

		private FbDbConnection	dbConnection;
		private ConnectionState state;
		private bool			disposed;
		private FbDataReader	dataReader;
		private FbTransaction	activeTxn;
		private ArrayList		activeCommands;

		private GdsWarningMessageEventHandler dbWarningHandler;

		#endregion
		
		#region PROPERTIES

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="ConnectionString"]/*'/>
		[Category("Data"), 
		RecommendedAsConfigurableAttribute(true),
		RefreshProperties(RefreshProperties.All),
		DefaultValue("")]
		#if (!_MONO)
		[Editor(typeof(DesingTime.ConnectionStringUIEditor), typeof(System.Drawing.Design.UITypeEditor))]
		#endif
		public string ConnectionString
		{
			get { return dbConnection.ConnectionString; }
			set
			{ 
				if (state == ConnectionState.Closed)
				{
					dbConnection.ConnectionString = value;
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="ConnectionTimeout"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int ConnectionTimeout
		{
			get 
			{ 
				if (dbConnection != null)
				{
					return dbConnection.Parameters.Timeout;
				}
				else
				{
					return 15; 
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="Database"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string Database
		{
			get { return dbConnection.Parameters.FileName; }
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="DataSource"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string DataSource
		{
			get 
			{ 
				if (dbConnection != null)
				{
					return dbConnection.Parameters.FileName;
				}
				else
				{
					return String.Empty; 
				}
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="ServerVersion"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public string ServerVersion
		{
			get
			{
				if (state == ConnectionState.Closed)
				{
					throw new InvalidOperationException("The connection is closed.");
				}

				FbDatabaseInfo info = new FbDatabaseInfo(this);

				return info.IscVersion;
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="State"]/*'/>
		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public ConnectionState State
		{
			get { return state; }
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/property[@name="PacketSize"]/*'/>
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public int PacketSize
		{
			get 
			{
				int packetSize = 8192;
				if (dbConnection != null)
				{
					return dbConnection.Parameters.PacketSize;
				}

				return packetSize; 
			}
		}

		internal Encoding Encoding
		{
			get { return dbConnection.Parameters.Encoding; }
		}

		internal ArrayList ActiveCommands
		{
			get { return activeCommands; }
		}
				
		internal FbDataReader DataReader
		{
			get { return dataReader; }
			set { dataReader = value; }
		}

		internal FbDbConnection DbConnection
		{
			get { return dbConnection; }
			set { dbConnection = value; }
		}

		#endregion		

		#region CONSTRUCTORS

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/constructor[@name="ctor"]/*'/>
		public FbConnection()
		{			
			dbConnection	= new FbDbConnection();
			state			= ConnectionState.Closed;
		}

    	/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/constructor[@name="ctor(System.String)"]/*'/>	
		public FbConnection(string connString) : this()
		{
			this.ConnectionString	= connString;
		}		

		#endregion

		#region DESTRUCTORS

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if (!disposed)
			{
				try
				{	
					if (disposing)
					{
						// release any managed resources
						Close();
						dbConnection = null;
					}

					// release any unmanaged resources					
				}
				finally
				{
					base.Dispose(disposing);
				}

				disposed = true;
			}			
		}

		#endregion

		#region ICLONEABLE_METHODS

		object ICloneable.Clone()
		{
			return new FbConnection(ConnectionString);
		}

		#endregion

		#region STATIC_METHODS

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateDatabase(System.String)"]/*'/>
		public static void CreateDatabase(string connectionString)
		{
			FbDbConnection dbConnection = new FbDbConnection(connectionString);

			FbConnection.CreateDatabase(
				dbConnection.Parameters.Server,
				dbConnection.Parameters.Port,
				dbConnection.Parameters.FileName,
				dbConnection.Parameters.UserName,
				dbConnection.Parameters.UserPassword, 
				dbConnection.Parameters.Dialect, 
				true, 
				4096,
				dbConnection.Parameters.Charset);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateDatabase(System.String,System.Int32,System.String,System.String,System.Byte,System.Boolean,System.Int16,System.String)"]/*'/>
		public static void CreateDatabase(string dataSource, int port, string database, string user, string password, byte dialect, bool forceWrite, short pageSize, string charset)
		{										
			try 
			{
				// Configure Attachment
				GdsAttachParams p = new GdsAttachParams(dataSource, port, database, 8192);

				// New instance for Database handler
				GdsDbAttachment db = new GdsDbAttachment(p);
			
				// DPB configuration
				GdsDpbBuffer dpb = new GdsDpbBuffer();
				dpb.Append(GdsCodes.isc_dpb_dummy_packet_interval, 
					new byte[] {120, 10, 0, 0});
				dpb.Append(GdsCodes.isc_dpb_sql_dialect, 
					new byte[] {dialect, 0, 0, 0});
				dpb.Append(GdsCodes.isc_dpb_user_name, user);
				dpb.Append(GdsCodes.isc_dpb_password, password);
				dpb.Append(GdsCodes.isc_dpb_page_size, (int)pageSize);
				dpb.Append(GdsCodes.isc_dpb_force_write, (short)(forceWrite ? 1 : 0));
				dpb.Append(GdsCodes.isc_dpb_lc_ctype, charset);
												
				db.CreateDatabase(p, dpb);
				db.Detach();				
			}
			catch (Exception ex) 
			{
				throw new FbException(ex.Message);
			}
		}

		#endregion

		#region METHODS

		IDbTransaction IDbConnection.BeginTransaction()
		{
			return BeginTransaction();
		}

		IDbTransaction IDbConnection.BeginTransaction(IsolationLevel level)
		{
			return BeginTransaction(level);
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction"]/*'/>
		public FbTransaction BeginTransaction()
		{
			if (state == ConnectionState.Closed)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection.");
			}

			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}
			
			try
			{
				activeTxn = new FbTransaction(this);
				activeTxn.BeginTransaction();				 
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			return this.activeTxn;
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(System.String)"]/*'/>
		public FbTransaction BeginTransaction(string transactionName)
		{
			if (state == ConnectionState.Closed)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection.");
			}

			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}
			
			try
			{
				activeTxn = new FbTransaction(this);
				activeTxn.BeginTransaction();
				activeTxn.Save(transactionName);
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			return this.activeTxn;
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level)
		{
			if (state == ConnectionState.Closed)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection.");
			}

			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			try
			{
				activeTxn = new FbTransaction(this, level);
				activeTxn.BeginTransaction();
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			return this.activeTxn;			
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="BeginTransaction(System.Data.IsolationLevel,System.String)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level, string transactionName)
		{
			if (state == ConnectionState.Closed)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection.");
			}

			if (activeTxn != null && !activeTxn.IsUpdated)
			{
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");
			}

			if (DataReader != null)
			{
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			try
			{
				activeTxn = new FbTransaction(this, level);
				activeTxn.BeginTransaction();
				activeTxn.Save(transactionName);
			}
			catch(GdsException ex)
			{
				throw new FbException(ex.Message, ex);
			}

			return this.activeTxn;			
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="ChangeDatabase(System.String)"]/*'/>
		public void ChangeDatabase(string db)
		{
			if (state == ConnectionState.Closed)
			{
				throw new InvalidOperationException("ChangeDatabase requires an open and available Connection.");
			}

			if (db == null || db.Trim().Length == 0)
			{
				throw new InvalidOperationException("Database name is not valid.");
			}

			if (this.DataReader != null)
			{
				throw new InvalidOperationException("ChangeDatabase requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			string oldDb = dbConnection.Parameters.FileName;

			try
			{
				/* Close current connection	*/
				Close();

				/* Set up the new Database	*/
				dbConnection.Parameters.FileName = db;

				/* Open new connection	*/
				Open();
			}
			catch (FbException ex)
			{
				dbConnection.Parameters.FileName = oldDb;
				throw ex;
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="Open"]/*'/>
		public void Open()
		{
			if (ConnectionString == String.Empty)
			{
				throw new InvalidOperationException("Connection String is not initialized.");
			}
			if (state != ConnectionState.Closed && state != ConnectionState.Connecting)
			{
				throw new InvalidOperationException("Connection already Open.");
			}

			try
			{
				state = ConnectionState.Connecting;
				
				if (dbConnection.Parameters.Pooling)
				{		
					// Use Connection Pooling
					dbConnection = FbConnectionPool.GetConnection(dbConnection.ConnectionString);
				}
				else
				{
					// Do not use Connection Pooling
					dbConnection.Pooled = false;
					dbConnection.Connect();
				}

				dbWarningHandler = new GdsWarningMessageEventHandler(OnDbWarningMessage);
				dbConnection.DB.DbWarningMessage += dbWarningHandler;
				
				state = ConnectionState.Open;
				if (StateChange != null)
				{
					StateChange(this, new StateChangeEventArgs(ConnectionState.Closed,state));
				}

				activeCommands = new ArrayList();
			}
			catch(GdsException ex)
			{
				state = ConnectionState.Closed;
				throw new FbException(ex.Message, ex);
			}
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="Close"]/*'/>
		public void Close()
		{
			if (state == ConnectionState.Open)
			{
				try
				{		
					lock (dbConnection)
					{
						// Stop event thread if running
						dbConnection.CancelEvents();

						// Unbind Warning messages event
						dbConnection.DB.DbWarningMessage -= dbWarningHandler;

						// Dispose active DataReader if exists
						if (dataReader != null)
						{
							dataReader.Close();
						}

						// Dispose all active statemenets
						DisposeActiveCommands();

						if (activeTxn != null)
						{
							// Dispose Transaction
							activeTxn.Dispose();
							activeTxn = null;
						}

						if (dbConnection.Parameters.Pooling)
						{
							// Send connection to the Pool
							FbConnectionPool.FreeConnection(dbConnection);
						}
						else
						{
							dbConnection.Disconnect();
						}
					}

					// Update state
					state = ConnectionState.Closed;

					// Raise event
					if (StateChange != null)
					{
						StateChange(this, new StateChangeEventArgs(ConnectionState.Open,state));
					}
				}
				catch(GdsException ex)
				{
					throw new FbException(ex.Message, ex);
				}
			}
		}

		IDbCommand IDbConnection.CreateCommand()
		{			
			return CreateCommand();
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="CreateCommand"]/*'/>
		public FbCommand CreateCommand()
		{		
			FbCommand command = new FbCommand();

			command.Connection = this;
	
			return command;
		}

		/// <include file='Doc/en_EN/FbConnection.xml' path='doc/class[@name="FbConnection"]/method[@name="GetDbSchemaTable"]/*'/>
		public DataTable GetDbSchemaTable(FbDbSchemaType schema, object[] restrictions)
		{
			if (DataReader != null)
			{
				throw new InvalidOperationException("GetDbSchemaTable requires an open and available Connection. The connection's current state is Open, Fetching.");
			}

			IDbSchema dbSchema = FbDbSchemaFactory.GetSchema(schema);

			if (dbSchema == null)
			{
				throw new NotSupportedException("Specified schema type is not supported.");
			}
			if (restrictions != null)
			{
				if (restrictions.Length > dbSchema.RestrictionColumns.Count)
				{
					throw new InvalidOperationException("The number of specified restrictions is not valid.");
				}
			}

			return dbSchema.GetDbSchemaTable(this, restrictions);
		}

		#endregion

		#region PRIVATE_METHODS

		private void DisposeActiveCommands()
		{
			if (activeCommands != null)
			{
				if (activeCommands.Count > 0)
				{
					foreach (FbCommand command in activeCommands)
					{
						if (command.Statement != null)
						{
							command.Statement.Drop();
							command.Statement = null;
						}
					}
				}

				activeCommands.Clear();
				activeCommands = null;				
			}
		}

		private void OnDbWarningMessage(object sender, GdsWarningMessageEventArgs e)
		{
			if (InfoMessage != null)
			{
				InfoMessage(this, new FbInfoMessageEventArgs(e.Exception));
			}
		}

		#endregion
	}
}
