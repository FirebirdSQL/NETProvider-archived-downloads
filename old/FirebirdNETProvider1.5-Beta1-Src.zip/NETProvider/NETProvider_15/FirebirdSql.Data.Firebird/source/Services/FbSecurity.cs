//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using FirebirdSql.Data.Firebird.Gds;

namespace FirebirdSql.Data.Firebird.Services
{
	/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/overview/*'/>
	public sealed class FbSecurity : FbService
	{				
		#region PROPERTIES

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/property[@name="UsersDbPath"]/*'/>
		public string UsersDbPath
		{
			get
			{
				byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_user_dbpath});
				System.Collections.ArrayList info = base.parseQueryInfo(buffer);
			
				return info.Count != 0 ? (string)info[0] : null;
			}			
		}
		
		#endregion

		#region CONSTRUCTORS

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/constructor[@name="FbSecurity"]/*'/>
		public FbSecurity() : base()
		{
		}
		
		#endregion		
		
		#region METHODS

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/method[@name="AddUser(FbUserData)"]/*'/>
		public void AddUser(FbUserData user)
		{
			if (user.UserName.Length == 0)
			{
				throw new InvalidOperationException("Invalid user name.");
			}
			if (user.UserPassword.Length == 0)
			{
				throw new InvalidOperationException("Invalid user password.");
			}
			// Configure Spb
			startSpb = new GdsSpbBuffer();
			startSpb.Append(GdsCodes.isc_action_svc_add_user);
						
			startSpb.Append(GdsCodes.isc_spb_sec_username, user.UserName);
			startSpb.Append(GdsCodes.isc_spb_sec_password, user.UserPassword);
			if (user.FirstName != null && user.FirstName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_firstname, user.FirstName);
			}
			if (user.MiddleName != null && user.MiddleName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_middlename, user.MiddleName);
			}
			if (user.LastName != null && user.LastName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_lastname, user.LastName);
			}
			if (user.UserID != 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_userid, user.UserID);
			}			
			if (user.GroupID != 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_groupid, user.GroupID);
			}
			if (user.GroupName != null && user.GroupName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_groupname, user.GroupName);
			}
			if (user.RoleName != null && user.RoleName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sql_role_name, user.RoleName);
			}
			
			// Start execution
			startTask();
						
			Close();
		}

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/method[@name="DeleteUser(FbUserData)"]/*'/>
		public void DeleteUser(FbUserData user)
		{
			if (user.UserName.Length == 0)
			{
				throw new InvalidOperationException("Invalid user name.");
			}
			
			// Configure Spb
			startSpb = new GdsSpbBuffer();
			startSpb.Append(GdsCodes.isc_action_svc_delete_user);

			startSpb.Append(GdsCodes.isc_spb_sec_username, user.UserName);
			if (user.RoleName != null && user.RoleName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sql_role_name, user.RoleName);
			}
			
			// Start execution
			startTask();
						
			Close();			
		}

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/method[@name="ModifyUser(FbUserData)"]/*'/>
		public void ModifyUser(FbUserData user)
		{
			if (user.UserName.Length == 0)
			{
				throw new InvalidOperationException("Invalid user name.");
			}
			if (user.UserPassword.Length == 0)
			{
				throw new InvalidOperationException("Invalid user password.");
			}

			// Configure Spb
			startSpb = new GdsSpbBuffer();
			startSpb.Append(GdsCodes.isc_action_svc_modify_user);

			startSpb.Append(GdsCodes.isc_spb_sec_username, user.UserName);
			if (user.UserPassword.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_password, user.UserPassword);
			}
			if (user.FirstName != null)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_firstname, user.FirstName);
			}
			if (user.MiddleName != null)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_middlename, user.MiddleName);
			}
			if (user.LastName != null)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_lastname, user.LastName);
			}
			startSpb.Append(GdsCodes.isc_spb_sec_userid, user.UserID);				
			startSpb.Append(GdsCodes.isc_spb_sec_groupid, user.GroupID);
			if (user.GroupName != null && user.GroupName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sec_groupname, user.GroupName);
			}
			if (user.RoleName != null && user.RoleName.Length > 0)
			{
				startSpb.Append(GdsCodes.isc_spb_sql_role_name, user.RoleName);
			}
			
			// Start execution
			startTask();
						
			Close();			
		}

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/method[@name="DisplayUser(System.String)"]/*'/>
		public FbUserData DisplayUser(string userName)
		{
			// Configure Spb
			startSpb = new GdsSpbBuffer();
			startSpb.Append(GdsCodes.isc_action_svc_display_user);			
			startSpb.Append(GdsCodes.isc_spb_sec_username, userName);
						
			// Start execution
			startTask();

			byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_users});
			System.Collections.ArrayList info = base.parseQueryInfo(buffer);
			
			Close();
		
			FbUserData userData = (FbUserData)info[0];
			
			return userData;
		}

		/// <include file='Doc/en_EN/FbSecurity.xml' path='doc/class[@name="FbSecurity"]/method[@name="DisplayUsers"]/*'/>
		public FbUserData[] DisplayUsers()
		{
			// Configure Spb
			startSpb = new GdsSpbBuffer();
			startSpb.Append(GdsCodes.isc_action_svc_display_user);			
						
			// Start execution
			startTask();

			byte[] buffer = queryService(new byte[] {GdsCodes.isc_info_svc_get_users});
			System.Collections.ArrayList info = base.parseQueryInfo(buffer);
			
			Close();
		
			return (FbUserData[])info[0];
		}
		
		#endregion
	}
}
