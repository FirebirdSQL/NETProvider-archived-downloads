//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='Doc/en_EN/FbError.xml' path='doc/class[@name="FbError"]/overview/*'/>
	[Serializable]
	public sealed class FbError
	{
		#region FIELDS

		private byte	classError;
		private int		lineNumber;
		private string	message;
		private int		number;
		
		#endregion

		#region PROPERTIES
		
		/// <include file='Doc/en_EN/FbError.xml' path='doc/class[@name="FbError"]/property[@name="Class"]/*'/>
		public byte Class
		{
			get { return classError; }
		}

		/// <include file='Doc/en_EN/FbError.xml' path='doc/class[@name="FbError"]/property[@name="LineNumber"]/*'/>		
		public int LineNumber
		{
			get { return lineNumber; }
		}

		/// <include file='Doc/en_EN/FbError.xml' path='doc/class[@name="FbError"]/property[@name="Message"]/*'/>
		public string Message
		{
			get { return message; }
		}

		/// <include file='Doc/en_EN/FbError.xml' path='doc/class[@name="FbError"]/property[@name="Number"]/*'/>
		public int Number
		{
			get { return number; }
		}

		#endregion

		#region CONSTRUCTORS
		
		internal FbError(string message,int number)
		{			
			this.number		= number;
			this.message	= message;
		}

		internal FbError(byte classError, string message, int number)
		{			
			this.classError = classError;
			this.number		= number;
			this.message	= message;
		}

		internal FbError(byte classError, int line, string message, int number)
		{			
			this.classError = classError;
			this.lineNumber = line;
			this.number		= number;
			this.message	= message;
		}

		#endregion
	}
}
