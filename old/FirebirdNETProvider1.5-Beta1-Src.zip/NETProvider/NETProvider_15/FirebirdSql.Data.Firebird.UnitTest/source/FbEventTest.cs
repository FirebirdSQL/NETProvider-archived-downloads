//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2003  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using NUnit.Framework;
using System;
using System.Data;
using FirebirdSql.Data.Firebird;
using FirebirdSql.Data.Firebird.Events;

namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbEventTest : BaseTest 
	{
		FbConnection	connection;
		FbTransaction	transaction;
				
		public FbEventTest() : base()
		{		
		}

		[SetUp]
		public void Setup()
		{		
			connection = new FbConnection(GetConnectionString());
			connection.Open();

			transaction = connection.BeginTransaction();
		}
		
		[TearDown]
		public void TearDown()
		{
			connection.Close();
		}

		[Test]
		public void EventsTest()
		{							
			FbEvent FbEvent = new FbEvent(connection);

			FbEventAlertEventHandler e = new FbEventAlertEventHandler(processEvent);

			FbEvent.EventAlert += e;
			FbEvent.RegisterEvents("new row", "updated row");
			
			FbEvent.QueEvents();

			FbCommand command = new FbCommand("UPDATE test_table_01 SET char_field = 'events test'", connection , transaction);			

			command.ExecuteNonQuery();

			transaction.Commit();

			FbEvent.QueEvents();
		}

		private void processEvent(object sender, FbEventAlertEventArgs e)
		{
			for (int i = 0; i < e.Counts.Length; i++)
			{
				Console.WriteLine("{0} Event - Counts : {1}", i, e.Counts[i]);
			}
		}
	}
}
