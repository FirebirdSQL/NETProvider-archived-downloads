//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Runtime.Serialization;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbexception.xml' path='doc/member[@name="T:FbException"]/*'/>	
	[Serializable]
	public sealed class FbException : SystemException
	{
		#region FIELDS
		
		private FbErrorCollection	errors = new FbErrorCollection();
		private int					errorCode;
		
		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/fbexception.xml' path='doc/member[@name="P:Errors"]/*'/>
		public FbErrorCollection Errors
		{
			get { return errors; }
		}

		/// <include file='xmldoc/fbexception.xml' path='doc/member[@name="P:ErrorCode"]/*'/>
		public int ErrorCode
		{
			get { return errorCode; }
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbexception.xml' path='doc/member[@name="M:#ctor"]/*'/>
		internal FbException() : base()
		{
		}

		/// <include file='xmldoc/fbexception.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		internal FbException(string message) : base(message)
		{
		}

		internal FbException(SerializationInfo info, StreamingContext context) 
								: base(info, context)
		{
		}

		/// <include file='xmldoc/fbexception.xml' path='doc/member[@name="M:#ctor(System.String,FirebirdSql.Data.INGDS.GDSException)"]/*'/>
		internal FbException(string message, GDSException ex) : base(message, ex)
		{
			errorCode = ex.ErrorCode;
			Source	  = ex.Source;

			GetGdsExceptionErrors((GDSException)ex);
		}

		#endregion

		#region METHODS

		internal void GetGdsExceptionErrors(GDSException ex)
		{
			foreach(GDSError error in ex.Errors)
			{
				errors.Add(error.Message, error.ErrorCode);
			}
		}

		#endregion
	}
}
