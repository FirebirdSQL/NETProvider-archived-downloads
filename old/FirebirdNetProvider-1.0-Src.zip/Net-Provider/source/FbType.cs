//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="T:FbType"]/*'/>
	public enum FbType
	{
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Array"]/*'/>
		Array			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:BigInt"]/*'/>
		BigInt			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Binary"]/*'/>
		Binary			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Char"]/*'/>
		Char			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Date"]/*'/>
		Date			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Decimal"]/*'/>
		Decimal			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Double"]/*'/>
		Double			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Float"]/*'/>
		Float			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Integer"]/*'/>
		Integer			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:LongVarBinary"]/*'/>
		LongVarBinary	,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:NChar"]/*'/>
		NChar			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:NVarChar"]/*'/>
		NVarChar		,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:NText"]/*'/>
		NText			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Numeric"]/*'/>
		Numeric			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:SmallInt"]/*'/>
		SmallInt		,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Text"]/*'/>
		Text			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:Time"]/*'/>
		Time			,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:TimeStamp"]/*'/>
		TimeStamp		,
		/// <include file='xmldoc/fbtype.xml' path='doc/member[@name="F:VarChar"]/*'/>
		VarChar
	}
}
