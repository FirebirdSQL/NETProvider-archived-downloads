//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{	
	/// <include file='xmldoc/isc_blob_handle_impl.xml' path='doc/member[@name="T:isc_blob_handle_impl"]/*'/>
	internal class isc_blob_handle_impl : isc_blob_handle 
	{
		#region FIELDS

		internal isc_db_handle_impl	 db;
		internal isc_tr_handle_impl	 tr;
		
		internal int	rbl_id;
		internal long	blob_id;		
		private	 int	rbl_flags;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/isc_blob_handle_impl.xml' path='doc/member[@name="P:BlobId"]/*'/>
		public long BlobId
		{
			get { return blob_id; }
			set { blob_id = value; }			
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/isc_blob_handle_impl.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public bool IsEof()
		{		
			return (rbl_flags & GdsCodes.RBL_eof_pending) != 0;
		}

		public void RBLAddValue(int rblValue)
		{
			this.rbl_flags |= rblValue;
		}

		public void RBLRemoveValue(int rblValue)
		{
			this.rbl_flags &= ~rblValue;
		}

		#endregion
	}
}
