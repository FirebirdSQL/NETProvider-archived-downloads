//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="T:GDSFactory"]/*'/>
	internal class GDSFactory 
	{
		#region METHODS

		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:NewGDS"]/*'/>
		public static IGDS NewGDS() 
		{
			return new GDS();
		}
		
		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:NewClumplet(System.Int32,System.String)"]/*'/>
		public static IClumplet NewClumplet(int type, string content) 
		{
			return GDS.NewClumplet(type, content);
		}

		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:NewClumplet(System.Int32)"]/*'/>
		public static IClumplet NewClumplet(int type)
		{
			return GDS.NewClumplet(type);
		}
		
		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:NewClumplet(System.Int32,System.Int32)"]/*'/>
		public static IClumplet NewClumplet(int type, int c)
		{
			return GDS.NewClumplet(type, c);
		}

		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:NewClumplet(System.Int32,System.Int16)"]/*'/>
		public static IClumplet NewClumplet(int type, short c)
		{
			return GDS.NewClumplet(type, c);
		}

		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:NewClumplet(System.Int32,System.Array)"]/*'/>
		public static IClumplet NewClumplet(int type, byte[] content) 
		{
			return GDS.NewClumplet(type, content);
		}

		/// <include file='xmldoc/gdsfactory.xml' path='doc/member[@name="M:CloneClumplet(FirebirdSql.Data.INGDS.IClumplet)"]/*'/>
		public static IClumplet CloneClumplet(IClumplet c) 
		{
			return GDS.CloneClumplet(c);
		}

		#endregion
	}
}
