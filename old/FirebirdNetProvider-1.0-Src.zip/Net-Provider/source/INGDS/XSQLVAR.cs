//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="T:XSQLVAR"]/*'/>
	internal class XSQLVAR 
	{
		#region FIELDS

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqltype"]/*'/>
		public int sqltype;
		
		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqlscale"]/*'/>
		public int sqlscale;

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqlsubtype"]/*'/>
		public int sqlsubtype;
		
		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqllen"]/*'/>
		public int sqllen;
		
		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqldata"]/*'/>
		public object sqldata;

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqlind"]/*'/>
		public int sqlind;

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:sqlname"]/*'/>
		public string sqlname;

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:relname"]/*'/>
		public string relname;

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:ownname"]/*'/>
		public string ownname;

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="P:aliasname"]/*'/>
		public string aliasname;

		#endregion

		#region CONSTRUCTORS
		
		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public XSQLVAR() 
		{
		}

		/// <include file='xmldoc/xsqlvar.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public XSQLVAR(object sqldata) 
		{
			this.sqldata = sqldata;
		}

		#endregion
	}
}
