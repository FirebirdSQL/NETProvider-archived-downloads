//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="T:isc_tr_handle_impl"]/*'/>
	internal class isc_tr_handle_impl : isc_tr_handle
	{
		#region FIELDS

		private int					rtr_id;
		private isc_db_handle_impl	rtr_rdb;
		private ArrayList			blobs = new ArrayList();		

		private TxnState			state = TxnState.NOTRANSACTION;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="P:DbHandle"]/*'/>
		public isc_db_handle DbHandle
		{
			get{return rtr_rdb;}
			set
			{
				this.rtr_rdb = (isc_db_handle_impl)value;
				rtr_rdb.AddTransaction(this);
			}
		}

		/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="P:State"]/*'/>
		public TxnState State
		{
			get{return state;}
			set{state=value;}
		}
	
		/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="P:TransactionId"]/*'/>
		public int TransactionId
		{
			get{return rtr_id;}
			set{rtr_id=value;}
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="M:UnsetDbHandle"]/*'/>
		public void UnsetDbHandle()
		{
			rtr_rdb.RemoveTransaction(this);
			rtr_rdb = null;
		}

		/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="M:AddBlob(FirebirdSql.Data.NGDS.isc_blob_handle_impl)"]/*'/>
		public void AddBlob(isc_blob_handle_impl blob) 
		{
			blobs.Add(blob);
		}

		/// <include file='xmldoc/isc_tr_handle_impl.xml' path='doc/member[@name="M:RemoveBlob(FirebirdSql.Data.NGDS.isc_blob_handle_impl)"]/*'/>
		public void RemoveBlob(isc_blob_handle_impl blob) 
		{
			blobs.Remove(blob);
		}

		#endregion
	}
}
