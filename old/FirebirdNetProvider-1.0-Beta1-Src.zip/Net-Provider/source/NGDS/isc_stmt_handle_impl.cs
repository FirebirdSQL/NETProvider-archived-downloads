//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Collections;
using FirebirdSql.Data.INGDS;

using FirebirdSql.Data.Firebird;

namespace FirebirdSql.Data.NGDS
{	
	/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="T:isc_stmt_handle_impl"]/*'/>
	internal class isc_stmt_handle_impl : isc_stmt_handle
	{
		#region FIELDS

		internal int				rsr_id;
		internal isc_db_handle_impl rsr_rdb;
		internal XSQLDA				in_sqlda  = null;
		internal XSQLDA				out_sqlda = null;
		internal ArrayList			rows = new ArrayList();
		internal bool				allRowsFetched	  = false;
		internal bool				isSingletonResult = false;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:DbHandle"]/*'/>
		public isc_db_handle DbHandle
		{
			get{return rsr_rdb;}
			set
			{
				this.rsr_rdb = (isc_db_handle_impl)value;
			}
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="T:InSqlda"]/*'/>
		public XSQLDA InSqlda
		{
			get{return in_sqlda;}
		}

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="P:OutSqlda"]/*'/>
		public XSQLDA OutSqlda
		{
			get{return out_sqlda;}
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/isc_stmt_handle_impl.xml' path='doc/member[@name="M:ClearRows"]/*'/>
		public void ClearRows() 
		{
			rows.Clear();
			allRowsFetched = false;
		}

		#endregion
	}
}
