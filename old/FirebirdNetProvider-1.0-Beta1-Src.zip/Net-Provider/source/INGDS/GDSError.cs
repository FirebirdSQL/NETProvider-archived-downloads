//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Data.INGDS
{
	/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="T:GDSError"]/*'/>
	internal sealed class GDSError
	{
		#region FIELDS

		private string	message;
		private int		type;
		private int		errorCode;
		private string	strParam;
		private bool	isFatal;
		
		#endregion

		#region PROPERTIES
		
		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="P:Message"]/*'/>
		public string Message
		{
			get{return message;}
			set{message=value;}
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="P:ErrorCode"]/*'/>
		public int ErrorCode
		{
			get{return errorCode;}
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="P:StrParam"]/*'/>
		public string StrParam
		{
			get
			{
				if ((type == GdsCodes.isc_arg_interpreted) || (type == GdsCodes.isc_arg_string))
				{
					return strParam;
				}
				else
				{
					if (type == GdsCodes.isc_arg_number)
					{
						return errorCode.ToString();
					}				
					else
					{
						return "";
					}
				}
			}
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="P:Type"]/*'/>
		public int Type
		{
			get{return type;}
		}

		public bool IsFatal
		{
			get{return isFatal;}
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="M:#ctor(System.Int32)"]/*'/>
		internal GDSError(int errorCode)
		{						
			this.errorCode	= errorCode;
			this.isFatal = CheckIfIsFatal();
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		internal GDSError(string strParam)
		{
			this.strParam	= strParam;
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="M:#ctor(System.Int32,System.String)"]/*'/>
		internal GDSError(int type, string strParam)
		{
			this.type		= type;
			this.strParam	= strParam;
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="M:#ctor(System.Int32,System.Int32)"]/*'/>
		internal GDSError(int type, int errorCode)
		{
			this.type		= type;
			this.errorCode	= errorCode;

			if (type == GdsCodes.isc_arg_number)
			{
				this.isFatal = CheckIfIsFatal();
			}
		}

		/// <include file='xmldoc/gdserror.xml' path='doc/member[@name="M:#ctor(System.Int32,System.Int32,System.String)"]/*'/>
		internal GDSError(int type, int errorCode, string strParam)
		{
			this.type		= type;
			this.errorCode	= errorCode;
			this.strParam	= strParam;

			if (type == GdsCodes.isc_arg_number)
			{
				this.isFatal = CheckIfIsFatal();
			}
		}

		#endregion

		#region METHODS

		public bool IsWarning() 
		{
			return (Type == GdsCodes.isc_arg_warning);
		}

		private bool CheckIfIsFatal()
		{
			for (int i = 0; i < GdsCodes.FATAL_ERRORS.Length 
				&& ErrorCode >= GdsCodes.FATAL_ERRORS[i]; i++)
			{
				if (ErrorCode == GdsCodes.FATAL_ERRORS[i]) 
				{
					return true;
				}
            
			}
			return false;
		}

		#endregion
	}
}
