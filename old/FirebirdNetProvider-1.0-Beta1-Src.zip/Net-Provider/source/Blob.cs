//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Text;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/blob.xml' path='doc/member[@name="T:Blob"]/*'/>
	internal class Blob
	{
		#region FIELDS

		protected FbConnection  connection	= null;
		protected FbTransaction transaction	= null;

		protected int maxSegmentSize = 1024 * 16;

		protected long blob_id;

		protected Encoding encoding;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="P:MaxSegmentSize"]/*'/>
		public virtual int MaxSegmentSize
		{
			get{return maxSegmentSize;}
			set{maxSegmentSize = value;}
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="P:BlobId"]/*'/>
		public long BlobId
		{
			get{return blob_id;}
			set{blob_id = value;}
		}

		#endregion

		#region CONSTRUCTORS
	
		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction,System.Int64)"]/*'/>
		public Blob(FbConnection connection, FbTransaction transaction, long blob_id)
		{
			this.connection		= connection;
			this.transaction	= transaction;
			this.BlobId			= blob_id;

			this.encoding		= connection.Encoding;
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction)"]/*'/>
		public Blob(FbConnection connection, FbTransaction transaction)
		{
			this.connection		= connection;
			this.transaction	= transaction;
			
			this.encoding	= connection.Encoding;
				// Encodings.GetFromFirebirdEncoding(this.connection.Charset);
		}		
		#endregion

		#region METHODS

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:Create()"]/*'/>
		protected virtual isc_blob_handle_impl Create()
		{
			 isc_blob_handle_impl blob_handle = null;

			try
			{
				blob_handle = 
					(isc_blob_handle_impl)FbIscConnection.gds.get_new_isc_blob_handle();
				
				FbIscConnection.gds.isc_create_blob2(connection.IscConnection.db, transaction.IscTransaction, blob_handle, null);
			}
			catch(GDSException ex)
			{
				throw ex;
			}

			return blob_handle;
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:Open"]/*'/>
		protected virtual isc_blob_handle_impl Open()
		{
			isc_blob_handle_impl blob_handle = null;

			try
			{
				blob_handle = 
					(isc_blob_handle_impl)FbIscConnection.gds.get_new_isc_blob_handle ();

				blob_handle.BlobId = BlobId;

				FbIscConnection.gds.isc_open_blob2(connection.IscConnection.db, transaction.IscTransaction, blob_handle, null);
			}
			catch(GDSException ex)
			{
				throw ex;
			}

			return blob_handle;
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:GetSegment(FirebirdSql.Data.INGDS.isc_blob_handle)"]/*'/>
		protected virtual byte[] GetSegment(isc_blob_handle_impl blob_handle)
		{
			try
			{
				return FbIscConnection.gds.isc_get_segment(blob_handle, MaxSegmentSize);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:PutSegment(FirebirdSql.Data.INGDS.isc_blob_handle,byte[])"]/*'/>
		protected virtual void PutSegment(isc_blob_handle_impl blob_handle, byte[] data)
		{
			try
			{
				FbIscConnection.gds.isc_put_segment(blob_handle, data);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}

		/// <include file='xmldoc/blob.xml' path='doc/member[@name="M:Close(FirebirdSql.Data.INGDS.isc_blob_handle)"]/*'/>
		protected virtual void Close(isc_blob_handle_impl blob_handle)
		{
			try
			{
				FbIscConnection.gds.isc_close_blob(blob_handle);
			}
			catch(GDSException ex)
			{
				throw ex;
			}
		}		

		#endregion
	}
}
