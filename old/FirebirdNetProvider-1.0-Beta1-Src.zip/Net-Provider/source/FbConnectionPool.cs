//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author: Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Collections;
using System.Threading;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	internal class FbConnectionPool : MarshalByRefObject
	{
		#region FIELDS

		private static ConnectionPool pool = null;

		#endregion
    
		#region METHODS

		public static void Init()
		{
			if(pool ==  null)
			{
				pool = new ConnectionPool();
			}
		}

		public static FbIscConnection GetConnection(byte dialect,
			string charset,
			string role,
			string user,
			string password,
			string database,
			long   lifetime)
		{
			Init();

			return ((FbIscConnection)pool.CheckOut(dialect, charset, role, user, password, database, lifetime));
		}
    
		public static void FreeConnection(FbIscConnection c) 
		{
			pool.CheckIn(c);
		}

		#endregion
	}

	internal struct ConnectionData
	{
		public long created;
		public long	lifetime;
	}
	
	internal class ConnectionPool
	{
		#region FIELDS

		private int				checkTimer;

		private Hashtable		locked	 = Hashtable.Synchronized(new Hashtable());
		private Hashtable		unlocked = Hashtable.Synchronized(new Hashtable());

		protected Timer			IdleTimer;

		#endregion

		#region CONSTRUCTORS

		public ConnectionPool()		
		{
			this.checkTimer = 15*1000;
			this.IdleTimer  = new System.Threading.Timer(new TimerCallback(this.CleanUp), null, checkTimer, checkTimer);
		}

		#endregion

		#region METHODS
			
		public Object Create(byte dialect,
			string charset,
			string role,
			string user,
			string password,
			string database)
		{
			try 
			{
				FbIscConnection connection = new FbIscConnection();
				connection.Open(dialect, charset, role, user, password, database);

				return connection;
			}
			catch(Exception ex) 
			{
				throw ex;
			}
		}
    
		public bool Validate(Object o, 
			byte   dialect,
			string charset,
			string role,
			string user,
			string password,
			string database)
		{
			try 
			{								
				return(
					((FbIscConnection)o).Dialect == dialect		&&
					((FbIscConnection)o).Charset == charset		&&
					((FbIscConnection)o).Role == role			&&
					((FbIscConnection)o).User == user			&&
					((FbIscConnection)o).Password == password	&&
					((FbIscConnection)o).Database == database	&&
					((FbIscConnection)o).VerifyAttachedDB()
					);
			}
			catch(Exception ex)
			{
				throw ex;
			}
		}

		public void Expire(Object o)
		{
			try 
			{
				if (((FbIscConnection)o).VerifyAttachedDB())
				{
					((FbIscConnection)o).Close();
				}
			}
			catch(Exception)
			{
				throw new FbException("Error closing database connection.");
			}
		}
		
		public Object CheckOut(	byte dialect,
			string charset,
			string role,
			string user,
			string password,
			string database,
			long   lifetime)
		{
			ConnectionData data;
			Object o = null;

			data.created  = System.DateTime.Now.Ticks;
			data.lifetime = lifetime;

			lock(unlocked.SyncRoot)
			{
				if(unlocked.Count > 0)
				{			
					IDictionaryEnumerator e = unlocked.GetEnumerator();
					while(e.MoveNext())
					{
						o = e.Key;
					
						if(Validate(o, dialect, charset, role, user, password, database))
						{
							if(((ConnectionData)e.Value).lifetime != 0)
							{
								if((data.created - ((ConnectionData)e.Value).created) > ((ConnectionData)e.Value).lifetime)
								{
									unlocked.Remove(o);
									Expire(o);
									o = null;
								}
								else
								{
									unlocked.Remove(o);
									locked.Add(o, data);
									return(o);
								}
							}
							else
							{
								unlocked.Remove(o);
								locked.Add(o, data);
								return(o);
							}
						}
						else
						{						
							unlocked.Remove(o);
							Expire(o);
							o = null;
						}

						e = unlocked.GetEnumerator();
					}			
				}
			}

			o = Create(dialect, charset, role, user, password, database);			
			locked.Add(o, data);

			GC.SuppressFinalize(o);
			
			return(o);
		}	

		public void CheckIn(Object o)
		{
			ConnectionData data;

			lock(unlocked.SyncRoot)
			{
				data = (ConnectionData)locked[o];
				data.created = System.DateTime.Now.Ticks;

				locked.Remove(o);
				unlocked.Add(o, data);
			}
		}

		public void CleanUp(object State)
		{
			long now = System.DateTime.Now.Ticks;
			Object o;			

			lock(unlocked.SyncRoot)
			{
				IDictionaryEnumerator e = unlocked.GetEnumerator();
				while(e.MoveNext())
				{
					o = e.Key;
					if(((ConnectionData)e.Value).lifetime != 0)
					{
						if((now - ((ConnectionData)e.Value).created) > ((ConnectionData)e.Value).lifetime)
						{
							unlocked.Remove(o);
							Expire(o);
							o = null;

							// Rebuild Enumeration
							e = unlocked.GetEnumerator();
						}
					}
				}
			}

			// Force the Garbage Collection
			GC.Collect();
		}

		#endregion
	}
}