using System;
//using System.Data;
using System.Collections;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="T:FbIscConnection"]/*'/>
	internal class FbIscConnection
	{
		#region FIELDS

		public static IGDS				 gds = GDSFactory.NewGDS();

		internal isc_db_handle_impl		 db;
		internal FbConnectionRequestInfo cri;
		
		private byte	dialect	 = 3;
		private string	charset	 = "";
		private string	role	 = "";		
		private string	user	 = "";
		private string	password = "";
		private string	database = "";

		private FbDatabaseInfo	dbInfo;

		#endregion

		#region PROPERTIES

		public byte		Dialect
		{ 
			get{return dialect;} 
		}
		public string	Charset
		{ 
			get{return charset;} 
		}
		public string	Role
		{ 
			get{return role;} 
		}
		public string	User
		{ 
			get{return user;} 
		}
		public string	Password
		{ 
			get{return password;} 
		}
		public string	Database
		{ 
			get{return database;} 
		}
		public FbDatabaseInfo DatabaseInfo
		{
			get{return dbInfo;}
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:Open"]/*'/>
		public void Open(byte dialect,
			string charset,
			string role,
			string user,
			string password,
			string database)
		{				
			// New instance of RequestConnectionInfo class
			cri = new FbConnectionRequestInfo();
			// New instance for Database handler
			db	= (isc_db_handle_impl)gds.get_new_isc_db_handle();				
			
			// DPB configuration
			cri.SetProperty(GdsCodes.isc_dpb_dummy_packet_interval, new byte[] {120, 10, 0, 0});
			cri.SetProperty(GdsCodes.isc_dpb_sql_dialect, new byte[] {dialect, 0, 0, 0});
			cri.SetProperty(GdsCodes.isc_dpb_lc_ctype, charset);
			if (role != null)
			{
				if (role.Length > 0)
				{
					cri.SetProperty(GdsCodes.isc_dpb_sql_role_name, role);
				}
			}					

			cri.SetUser(user);
			cri.SetPassword(password);

			// Connect to database
			gds.isc_attach_database(database, db, cri.Dpb);

			this.dialect  = dialect;
			this.charset  = charset;
			this.role	  = role;
			this.user     = user;
			this.password = password;
			this.database = database;

			this.dbInfo	  = new FbDatabaseInfo(db);
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:ClearWarnings"]/*'/>
		public void ClearWarnings()
		{
			db.ClearWarnings();
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:Close"]/*'/>
		public void Close()
		{	
			ClearWarnings();
			gds.isc_detach_database(db);
				
			cri			= null;
			db			= null;
		}

		/// <include file='xmldoc/fbiscconnection.xml' path='doc/member[@name="M:VerifyAttachedDB"]/*'/>
		public bool VerifyAttachedDB()
		{
			int INFO_SIZE = 16;
			
			byte[] buffer = new byte[INFO_SIZE];
			
			// Do not actually ask for any information
			byte[] databaseInfo  = new byte[]
			{
				GdsCodes.isc_info_end
			};


			try 
			{
				gds.isc_database_info(db, databaseInfo.Length, databaseInfo, INFO_SIZE,buffer);

				return true;
			}
			catch
			{
				return false;
			}
		}

		#endregion
	}
}