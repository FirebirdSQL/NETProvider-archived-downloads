//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using NUnit.Framework;

using System;
using System.Data;

using FirebirdSql.Data.Firebird;


namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbDataReaderTest : BaseTest 
	{
		FbConnection conn;
		
		public FbDataReaderTest() : base()
		{		
		}

		[SetUp]
		public void Setup()
		{		
			conn = new FbConnection(GetConnectionString());
			conn.Open();
		}
		
		[TearDown]
		public void TearDown()
		{
			conn.Close();
		}

		[Test]
		public void ReadTest()
		{
			FbTransaction transaction = conn.BeginTransaction();
						
			FbCommand cmd = new FbCommand("select * from EMPLOYEE", conn, transaction);
			
			Console.WriteLine("DataReader - Read - Test");
			
			IDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				for(int i = 0; i < reader.FieldCount; i++)
				{
					Console.Write(reader.GetValue(i) + "\t");					
				}
			
				Console.WriteLine();
			}

			transaction.Rollback();
	
			reader.Close();
		}

		[Test]
		public void GetSchemaTableTest()
		{
			FbTransaction transaction	= (FbTransaction)conn.BeginTransaction();
			FbCommand	  cmd			= new FbCommand("SELECT * FROM CUSTOMER", conn, transaction);
	
			FbDataReader reader = cmd.ExecuteReader(CommandBehavior.SchemaOnly);		
		
			DataTable schema = reader.GetSchemaTable();
			
			Console.WriteLine("DataReader - GetSchemaTable - Test");

			DataRow[] currRows = schema.Select(null, null, DataViewRowState.CurrentRows);

			foreach (DataColumn myCol in schema.Columns)
			{
				Console.Write("{0}\t\t", myCol.ColumnName);
			}

			Console.WriteLine();
			
			foreach (DataRow myRow in currRows)
			{
				foreach (DataColumn myCol in schema.Columns)
				{
					Console.Write("{0}\t\t", myRow[myCol]);
				}
				
				Console.WriteLine();
			}
			
			transaction.Rollback();
			
			reader.Close();
		}
		
		[Test]
		public void NextResultTest()
		{
			string querys = "select * from employee order by emp_no;" +
							"select * from department order by dept_no";

			FbTransaction	transaction = (FbTransaction)conn.BeginTransaction();
			FbCommand		cmd			= new FbCommand(querys, conn, transaction);
	
			FbDataReader reader = cmd.ExecuteReader();		

			Console.WriteLine("DataReader - NextResult - Test - First Result");

			while (reader.Read())
			{
				for(int i = 0; i < reader.FieldCount; i++)
				{
					Console.Write(reader.GetValue(i) + "\t");					
				}
			
				Console.WriteLine();
			}

			if(reader.NextResult())
			{				
				Console.WriteLine("DataReader - GetSchemaTable - Test - Last Result");
		
				while (reader.Read())
				{
					for(int i = 0; i < reader.FieldCount; i++)
					{
						Console.Write(reader.GetValue(i) + "\t");					
					}
				
					Console.WriteLine();
				}
			}

			transaction.Rollback();
			
			reader.Close();
		}
	}
}
