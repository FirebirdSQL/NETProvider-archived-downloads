//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	internal class FbDatabaseInfo
	{
		#region FIELDS

		private FbIscConnection connection;

		// Database info
		private static byte[] databaseInfo  = new byte[]
		{
			GdsCodes.isc_info_firebird_version,
			GdsCodes.isc_info_end
		};

		// Statement info size
		private static int INFO_SIZE = 1024;

		private string			iscVersion;
		private string			firebirdVersion;
		private int				serverClass;
		private int				odsMajorVersion;
		private int				odsMinorVersion;
		private int				pageSize;
		private int				sqlDialect;
		private string			charset;
		private int				numBuffers;
		private bool			isReadOnly;		
		private int				currentMemory;
		private int				maxMemory;

		#endregion

		#region PROPERTIES

		public string FirebirdVersion
		{
			get { return firebirdVersion; }
		}

		#endregion

		#region CONSTRUCTORS

		public FbDatabaseInfo(FbIscConnection connection)
		{
			this.connection	= connection;
			GetInfo();
		}

		#endregion

		#region METHODS

		public void GetInfo()
		{
			byte[] buffer = new byte[INFO_SIZE];

			connection.GDS.isc_database_info(
				connection.db,
				databaseInfo.Length,
				databaseInfo,
				INFO_SIZE,
				buffer);

			int pos = 0;
			int length;
			int type;
			while ((type = buffer[pos++]) != GdsCodes.isc_info_end)
			{
				length = connection.GDS.isc_vax_integer(buffer, pos, 2);
				pos += 2;
				switch (type) 
				{					
					case GdsCodes.isc_info_isc_version:
						iscVersion = Encoding.Default.GetString(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_firebird_version:
						firebirdVersion = Encoding.Default.GetString(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_db_class:
						serverClass = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_ods_version:
						odsMajorVersion = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_ods_minor_version:
						odsMinorVersion = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_page_size:
						pageSize = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_db_sql_dialect:
						sqlDialect = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.frb_info_att_charset:
						charset = Encoding.Default.GetString(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_num_buffers:
						numBuffers = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_db_read_only:
						isReadOnly = buffer[pos] == 1 ? true : false;
						pos += length;
						break;
					
					case GdsCodes.isc_info_current_memory:
						currentMemory = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					case GdsCodes.isc_info_max_memory:
						maxMemory = connection.GDS.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;

					default:
						pos += length;
						break;
				}
			}
		}

		#endregion
	}
}
