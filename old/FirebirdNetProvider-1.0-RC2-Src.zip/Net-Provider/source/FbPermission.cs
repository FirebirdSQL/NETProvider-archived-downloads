//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Security.Permissions;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="T:FbPermission"]/*'/>	
	[Serializable]	
	public sealed class FbPermission : DBDataPermission
	{		
		#region FIELDS

		private PermissionState state;
		private string			connectionString;

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbPermission()
		{
			state				= PermissionState.None;
			connectionString	= String.Empty;
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:#ctor(System.Security.Permissions.PermissionState)"]/*'/>
		public FbPermission(PermissionState state) : this()
		{			
			this.state = state;
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:#ctor(System.Security.Permissions.PermissionState,System.Boolean)"]/*'/>
		public FbPermission(PermissionState state, bool allowBlankPassword) : this()
		{
			this.AllowBlankPassword = allowBlankPassword;
			this.state				= state;
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:Copy"]/*'/>
		public override IPermission Copy()
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:FromXml(System.Security.SecurityElement)"]/*'/>
		public override void FromXml(SecurityElement securityElement)
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:Intersect(System.Security.IPermission)"]/*'/>
		public override IPermission Intersect(IPermission target)
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:IsSubsetOf(System.Security.IPermission)"]/*'/>
		public override bool IsSubsetOf(IPermission target)
		{
			// TODO: implementar
			// throw new NotImplementedException ();
			return base.IsSubsetOf(target);
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:ToString"]/*'/>
		public override string ToString()
		{					
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:ToXml"]/*'/>
		public override SecurityElement ToXml()
		{
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbpermission.xml' path='doc/member[@name="M:Union(System.Security.IPermission)"]/*'/>
		public override IPermission Union(IPermission target)
		{
			throw new NotImplementedException ();
		}

		#endregion
	}
}
