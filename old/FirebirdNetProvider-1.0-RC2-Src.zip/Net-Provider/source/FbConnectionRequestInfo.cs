//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbconnectionrequestinfo.xml' path='doc/member[@name="T:FbConnectionRequestInfo"]/*'/>
	internal class FbConnectionRequestInfo
	{
		#region FIELDS

		private IClumplet c;

		#endregion

		#region PROPERTIES

		internal IClumplet Dpb
		{
			get { return c; }
		}

		#endregion

		#region CONSTRUCTORS
		
		/// <include file='xmldoc/fbconnectionrequestinfo.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbConnectionRequestInfo() 
		{
			c = null;
		}

		/// <include file='xmldoc/fbconnectionrequestinfo.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnectionRequestInfo)"]/*'/>
		public FbConnectionRequestInfo(FbConnectionRequestInfo src) 
		{
			c = GDSFactory.CloneClumplet(src.c);
		}

		#endregion

		#region PROPERTIES

		public void SetProperty(int type, string content) 
		{
			Append(GDSFactory.NewClumplet(type, content));
		}

		public void SetProperty(int type) 
		{
			Append(GDSFactory.NewClumplet(type));
		}

		public void SetProperty(int type, int content) 
		{
			Append(GDSFactory.NewClumplet(type, content));
		}

		public void SetProperty(int type, byte[] content) 
		{
			Append(GDSFactory.NewClumplet(type, content));
		}

		public string GetStringProperty(int type)
		{
			if (c == null) 
			{
				return null;        
			}

			if (c.Find(type) == null) 
			{
				return null;        
			}

			return Encoding.Default.GetString(c.Find(type));
		}

		private void Append(IClumplet newc) 
		{
			if (c == null) 
			{
				c = newc;
			}
			else 
			{
				c.Append(newc);
			}
		}

		public void SetUser(string user) 
		{
			SetProperty(GdsCodes.isc_dpb_user_name, user);
		}

		public string GetUser()
		{
			return GetStringProperty(GdsCodes.isc_dpb_user_name);
		}

		public void SetPassword(string password) 
		{
			SetProperty(GdsCodes.isc_dpb_password, password);
		}

		public string GetPassword()
		{
			return GetStringProperty(GdsCodes.isc_dpb_password);
		}

		/// <include file='xmldoc/fbconnectionrequestinfo.xml' path='doc/member[@name="M:Equals(System.Object)"]/*'/>
		public override bool Equals(Object other) 
		{
			if ((other == null) || !(other is FbConnectionRequestInfo)) 
			{
			  return false;
			}
			IClumplet otherc = ((FbConnectionRequestInfo)other).c;
			if (c == null) 
			{
				return (otherc == null);
			}
			return c.Equals(otherc);
		}

		/// <include file='xmldoc/fbconnectionrequestinfo.xml' path='doc/member[@name="M:GetHashCode"]/*'/>
		public override int GetHashCode() 
		{
			if (c == null) 
			{
				return 0;
			}
			return c.GetHashCode();
		}

		#endregion
	}
}