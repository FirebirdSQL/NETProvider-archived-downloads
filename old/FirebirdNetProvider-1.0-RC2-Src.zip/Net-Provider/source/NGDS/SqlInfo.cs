//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.NGDS
{	
	/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="T:SqlInfo"]/*'/>
	internal class SqlInfo 
	{
		#region FIELDS

		private int statementType;
		private int insertCount;
		private int updateCount;
		private int deleteCount;
		private int selectCount;

		#endregion

		#region PROPERTIES

		/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="P:SqlInfo"]/*'/>	
		public int StatementType
		{
			get { return statementType; }
		}

		/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="P:SqlInfo"]/*'/>	
		public int InsertCount
		{
			get { return insertCount; }
		}

		/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="P:SqlInfo"]/*'/>	
		public int UpdateCount
		{
			get { return updateCount; }
		}

		/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="P:SqlInfo"]/*'/>	
		public int DeleteCount
		{
			get { return deleteCount; }
		}

		/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="P:SqlInfo"]/*'/>	
		public int SelectCount
		{
			get { return selectCount; }
		}

		#endregion

		#region CONSTRUCTORS

		/// <include file='xmldoc/sqlinfo.xml' path='doc/member[@name="M:#ctor(System.Array,FirebirdSql.Data.INGDS.IGDS)"]/*'/>			
		public SqlInfo(byte[] buffer, IGDS gds) 
		{
			int pos = 0;
			int length;
			int type;
			while ((type = buffer[pos++]) != GdsCodes.isc_info_end) 
			{
				length = gds.isc_vax_integer(buffer, pos, 2);
				pos += 2;
				switch (type) 
				{
					case GdsCodes.isc_info_sql_records:
						int l;
						int t;
						while ((t = buffer[pos++]) != GdsCodes.isc_info_end) 
						{
							l = gds.isc_vax_integer(buffer, pos, 2);
							pos += 2;
							switch (t) 
							{
								case GdsCodes.isc_info_req_insert_count:
									insertCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								case GdsCodes.isc_info_req_update_count:
									updateCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								case GdsCodes.isc_info_req_delete_count:
									deleteCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								case GdsCodes.isc_info_req_select_count:
									selectCount = gds.isc_vax_integer(buffer, pos, l);
									break;
								
								default:
									break;
							}
							pos += l;
						}
						break;
					
					case GdsCodes.isc_info_sql_stmt_type:
						statementType = gds.isc_vax_integer(buffer, pos, length);
						pos += length;
						break;
					
					default:
						pos += length;
						break;
				}
			}
		}
		
		#endregion 
	}
}
