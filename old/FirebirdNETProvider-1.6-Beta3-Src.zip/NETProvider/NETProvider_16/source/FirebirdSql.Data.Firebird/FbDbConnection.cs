//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Text;
using System.Collections;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird
{	
	internal class FbDbConnection : MarshalByRefObject
	{
		#region Fields

		private IDbAttachment		db;
		private AttachmentParams	parameters;
		private long				created;
		private long				lifetime;
		private bool				pooled;
		
		#endregion

		#region Properties

		public IDbAttachment DB
		{
			get { return this.db; }
		}

		public long Lifetime
		{
			get { return this.lifetime; }
		}

		public long Created
		{
			get { return this.created; }
			set { this.created = value; }
		}
		
		public bool Pooled
		{
			get { return this.pooled; }
			set { this.pooled = value; }
		}

		public AttachmentParams Parameters
		{
			get { return this.parameters; }
		}

		#endregion

		#region Constructors

		public FbDbConnection(AttachmentParams parameters)
		{
			this.parameters			= parameters;
			this.lifetime			= this.parameters.LifeTime;
		}

		#endregion

		#region Methods

		public void Connect()
		{							
			try
			{
				FactoryBase factory = ClientFactory.GetInstance(
					this.parameters.ServerType);
				this.db = factory.CreateDbConnection(this.parameters);
				this.db.Attach();
			}
			catch (IscException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}
		
		public void Disconnect()
		{	
			try
			{
				this.db.Detach();
			}
			catch (IscException ex)
			{
				throw new FbException(ex.Message, ex);
			}
		}

		public bool Verify()
		{
			int INFO_SIZE = 16;
			
			byte[] buffer = new byte[INFO_SIZE];
			
			// Do not actually ask for any information
			byte[] items  = new byte[]
			{
				IscCodes.isc_info_end
			};

			try 
			{
				this.db.GetDatabaseInfo(items, buffer);

				return true;
			}
			catch
			{
				return false;
			}
		}

		#endregion
	}
}
