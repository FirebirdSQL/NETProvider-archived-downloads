//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird.Services
{
	/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/overview/*'/>
	public sealed class FbServerProperties : FbService
	{
		#region Properties

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="Version"]/*'/>
		public int Version
		{
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_version});
						
				return info.Count != 0 ? (int)info[0] : 0;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="ServerVersion"]/*'/>
		public string ServerVersion
		{
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_server_version});

				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="Implementation"]/*'/>
		public string Implementation
		{
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_implementation});

				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="RootDirectory"]/*'/>
		public string RootDirectory
		{			
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_get_env});
			
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="LockManager"]/*'/>
		public string LockManager
		{
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_get_env_lock});

				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="MessageFile"]/*'/>
		public string MessageFile
		{			
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_get_env_msg});
							
				return info.Count != 0 ? (string)info[0] : null;
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="DatabasesInfo"]/*'/>
		public FbDatabasesInfo DatabasesInfo
		{
			get
			{
				ArrayList info	= getInfo(
					new byte[] {IscCodes.isc_info_svc_svr_db_info});

				return info.Count != 0 ? (FbDatabasesInfo)info[0] : new FbDatabasesInfo();
			}
		}

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/property[@name="ServerConfig"]/*'/>
		public FbServerConfig ServerConfig
		{
			get
			{
				ArrayList info = getInfo(
					new byte[] {IscCodes.isc_info_svc_get_config});

				return info.Count != 0 ? (FbServerConfig)info[0] : new FbServerConfig();
			}
		}

		#endregion

		#region Constructors

		/// <include file='Doc/en_EN/FbServerProperties.xml' path='doc/class[@name="FbServerProperties"]/constructor[@name="FbServerProperties"]/*'/>
		public FbServerProperties() : base()
		{
		}
		
		#endregion

		#region Private Methods

		private ArrayList getInfo(byte[] items)
		{
			byte[] buffer = this.QueryService(items);

			return this.ParseQueryInfo(buffer);
		}

		#endregion
	}
}
