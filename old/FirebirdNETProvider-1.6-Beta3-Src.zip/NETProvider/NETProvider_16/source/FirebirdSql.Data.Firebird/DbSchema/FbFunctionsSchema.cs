//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbFunctionsSchema : FbDbSchema
	{
		#region Constructors

		public FbFunctionsSchema() : base("Functions", 2)
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
					"rdb$function_name AS FUNCTION_NAME, " +
					"rdb$system_flag AS SYSTEM_FUNCTION, " +
					"rdb$function_type AS FUNCTION_TYPE, " +
					"rdb$query_name AS QUERY_NAME, " +
					"rdb$module_name AS FUNCTION_MODULE_NAME, " +
					"rdb$entrypoint AS FUNCTION_ENTRY_POINT, " +
					"rdb$return_argument AS RETURN_ARGUMENT, " +
					"rdb$description AS DESCRIPTION " +
				"FROM rdb$functions");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat("rdb$function_name = @p{0}", index++);
				}

				if (restrictions.Length >= 2 && restrictions[1] != null)
				{
					if (where.Length > 0)
					{
						where.Append(" AND ");
					}

					where.AppendFormat("rdb$system_flag = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rdb$function_name");

			return sql;
		}

		#endregion
	}
}