//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Text;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Firebird.DbSchema
{
	internal class FbColumnsSchema : FbDbSchema
	{
		#region Constructors

		public FbColumnsSchema() : base("Columns", 2)
		{
		}

		#endregion

		#region Protected Methods

		protected override StringBuilder GetCommandText(object[] restrictions)
		{
			StringBuilder sql	= new StringBuilder();
			StringBuilder where = new StringBuilder();

			sql.Append(
				@"SELECT " +
				"rfr.rdb$relation_name AS TABLE_NAME, " +
				"rfr.rdb$field_name AS COLUMN_NAME, " +
				"fld.rdb$field_type AS COLUMN_DATA_TYPE, " +
				"fld.rdb$field_sub_type AS COLUMN_SUB_TYPE, " +
				"fld.rdb$field_length AS COLUMN_SIZE, " +
				"fld.rdb$field_precision AS NUMERIC_PRECISION, " +
				"fld.rdb$field_scale AS NUMERIC_SCALE, " +
				"rfr.rdb$field_position AS COLUMN_ORDINAL, " +
				"fld.rdb$default_source AS COLUMN_DEFAULT, " +
				"fld.rdb$computed_source AS COMPUTED_SOURCE, " +
				"rfr.rdb$null_flag AS IS_NULLABLE, " +
				"0 AS IS_READONLY, " +
				"(select " +
				"count(*) " +
				"from " +
				"rdb$relation_constraints rel, " +
				"rdb$indices idx, " +
				"rdb$index_segments seg " +
				"where " +
				"rel.rdb$constraint_type = 'PRIMARY KEY' " +
				"and rel.rdb$index_name = idx.rdb$index_name " +
				"and idx.rdb$index_name = seg.rdb$index_name " +
				"and rel.rdb$relation_name = rfr.rdb$relation_name " +
				"and seg.rdb$field_name = rfr.rdb$field_name) AS PRIMARY_KEY, " +
				"(select " +
				"count(*) " +
				"from " +
				"rdb$relation_constraints rel, " +
				"rdb$indices idx, " +
				"rdb$index_segments seg " +
				"where " +
				"rel.rdb$constraint_type = 'UNIQUE' " +
				"and rel.rdb$index_name = idx.rdb$index_name " +
				"and idx.rdb$index_name = seg.rdb$index_name " +
				"and rel.rdb$relation_name = rfr.rdb$relation_name " +
				"and seg.rdb$field_name = rfr.rdb$field_name) AS UNIQUE_KEY, " +
				"cs.rdb$character_set_name AS CHARACTER_SET_NAME, " +
				"coll.rdb$collation_name AS COLLATION_NAME, " +
				"rfr.rdb$description AS DESCRIPTION " +
				"FROM " +
				"rdb$relation_fields rfr " +
				"left join rdb$fields fld ON rfr.rdb$field_source = fld.rdb$field_name " +
				"left join rdb$character_sets cs ON cs.rdb$character_set_id = fld.rdb$character_set_id " +
				"left join rdb$collations coll ON (coll.rdb$collation_id = fld.rdb$collation_id AND coll.rdb$character_set_id = fld.rdb$character_set_id)");

			if (restrictions != null)
			{
				int index = 0;

				if (restrictions.Length >= 1 && restrictions[0] != null)
				{
					where.AppendFormat("rfr.rdb$relation_name = @p{0}", index++);
				}

				if (restrictions.Length >= 2 && restrictions[1] != null)
				{
					if (where.Length > 0)
					{
						where.Append(" AND ");
					}

					where.AppendFormat("rfr.rdb$field_name = @p{0}", index++);
				}
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rfr.rdb$relation_name, rfr.rdb$field_position");

			return sql;
		}

		protected override DataTable ProcessResult(DataTable schema)
		{
			DataColumn providerType = new DataColumn("PROVIDER_TYPE");
			providerType.Caption	= "Provider Type";
			providerType.DataType	= typeof(FbDbType);

			schema.Columns.Add(providerType);

			schema.BeginLoadData();

			foreach (DataRow row in schema.Rows)
			{
				int blrType = Convert.ToInt32(row["COLUMN_DATA_TYPE"]);
				
				int subType	= 0;
				if (row["COLUMN_SUB_TYPE"] != System.DBNull.Value)
				{
					subType	= Convert.ToInt32(row["COLUMN_SUB_TYPE"]);
				}
				
				int scale = 0 ;
				if (row["NUMERIC_SCALE"] != System.DBNull.Value)
				{
					scale = Convert.ToInt32(row["NUMERIC_SCALE"]);
				}

				if (row["IS_NULLABLE"] == DBNull.Value)
				{
					row["IS_NULLABLE"] = true;
				}
				else
				{
					row["IS_NULLABLE"] = false;
				}

				row["PROVIDER_TYPE"] = (FbDbType)TypeHelper.GetDbDataType(
					blrType, subType, scale);
			}

			schema.EndLoadData();
			schema.AcceptChanges();
            
			return schema;
		}

		#endregion
	}
}
