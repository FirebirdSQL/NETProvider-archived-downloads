//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using NUnit.Framework;

using System;
using System.Text;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Client.UnitTest
{
	[TestFixture]
	public class BlobTest : BaseTest
	{
		[Test]
		public void ReadAsciiBlob()
		{
			string sql = "select clob_field from test where int_field = ?";

			// Start a new Transaction
			ITransaction transaction = this.Attachment.BeginTransaction(BaseTest.BuildTpb());

			// Create a new statement
			StatementBase stmt = this.Attachment.CreateStatement(transaction);

			// Prepare statement & Describve parameters
			stmt.Prepare(sql);
			stmt.DescribeParameters();

			// Check Statement Type
			Assertion.AssertEquals(
				"Invalid statement type",
				DbStatementType.Select,
				stmt.StatementType);

			// Set parameter value
			stmt.Parameters[0].Value = 1;

			// Execute statement
			stmt.Execute();

			// Fetch data row
			DbValue[] row	= stmt.Fetch();

			Assertion.AssertNotNull("Fetched row values are not valid", row);
			Assertion.AssertNotNull("Fetched row values are not valid", row[0]);

			Assertion.AssertEquals(
				"Indvalid value fetched for field clob_field",
				"IRow Number1",
				row[0].Value.ToString());

			// Commit changes
			transaction.Commit();
		
			// Drop the statement
			stmt.Release();
		}

		[Test]
		public void ReadBinaryBlob()
		{
			string sql = "select blob_field from test where int_field = ?";

			// Start a new Transaction
			ITransaction transaction = this.Attachment.BeginTransaction(BaseTest.BuildTpb());

			// Create a new statement
			StatementBase stmt = this.Attachment.CreateStatement(transaction);

			// Prepare statement & Describve parameters
			stmt.Prepare(sql);
			stmt.DescribeParameters();

			// Check Statement Type
			Assertion.AssertEquals(
				"Invalid statement type",
				DbStatementType.Select,
				stmt.StatementType);

			// Set parameter value
			stmt.Parameters[0].Value = 1;

			// Execute statement
			stmt.Execute();

			// Fetch data row
			DbValue[] row	= stmt.Fetch();

			Assertion.AssertNotNull("Fetched row values are not valid", row);
			Assertion.AssertNotNull("Fetched row values are not valid", row[0]);

			byte[] bytes = (byte[])row[0].Value;

			Assertion.AssertEquals(
				"Indvalid value fetched for field blob_field",
				"IRow Number1",
				Encoding.Default.GetString(bytes));

			// Commit changes
			transaction.Commit();
		
			// Drop the statement
			stmt.Release();
		}
	}
}
