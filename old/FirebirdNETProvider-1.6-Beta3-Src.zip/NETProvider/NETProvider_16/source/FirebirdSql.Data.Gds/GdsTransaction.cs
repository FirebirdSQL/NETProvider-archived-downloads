//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.IO;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Gds
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class GdsTransaction : ITransaction
	{
		#region Events

		public event TransactionUpdateEventHandler Update;

		#endregion

		#region Fields

		private int					handle;
		private GdsDbAttachment		db;		
		private TransactionState	state;

		#endregion

		#region Properties

		public int Handle
		{
			get { return this.handle; }
		}

		public TransactionState State
		{
			get { return this.state; }
		}

		#endregion

		#region Constructors

		public GdsTransaction(IDbAttachment db)			
		{
			if (!(db is GdsDbAttachment))
			{
				throw new ArgumentException("Specified argument is not of GdsDbAttachment type.");
			}
			this.db		= (GdsDbAttachment)db;
			this.state	= TransactionState.NoTransaction;
		}

		#endregion

		#region Methods

		public void BeginTransaction(DpbBuffer tpb)
		{			
			lock (this.db) 
			{
				if (this.state != TransactionState.NoTransaction)
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state, 
						this.handle,
						"no valid");
				}
				
				this.state = TransactionState.TrasactionStarting;

				try 
				{
					this.db.Send.Write(IscCodes.op_transaction);
					this.db.Send.Write(this.db.Handle);
					this.db.Send.WriteBuffer(tpb.ToArray());
					this.db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();
					this.handle = r.ObjectHandle;

					this.state = TransactionState.TransactionStarted;

					this.db.TransactionCount++;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}				
			}
		}

		public void Commit()
		{
			lock (this.db) 
			{
				if (this.state != TransactionState.TransactionStarted && 
					this.state != TransactionState.TransactionPrepared)
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state, 
						this.handle,
						"no valid");
				}
				
				this.state = TransactionState.TransactionCommiting;

				try 
				{					
					this.db.Send.Write(IscCodes.op_commit);
					this.db.Send.Write(this.handle);
					this.db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();

					this.db.TransactionCount--;

					if (this.Update != null)
					{
						this.Update(this, new EventArgs());
					}

					this.state = TransactionState.NoTransaction;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}
			}
		}

		public void Rollback()
		{
			lock (this.db)
			{
				if (this.state == TransactionState.NoTransaction)
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state,
						this.handle,
						"no valid");
				}

				this.state = TransactionState.TransactionRollbacking;

				try 
				{
					this.db.Send.Write(IscCodes.op_rollback);
					this.db.Send.Write(this.handle);
					this.db.Send.Flush();            

					GdsResponse r = db.ReceiveResponse();

					this.db.TransactionCount--;

					if (this.Update != null)
					{
						this.Update(this, new EventArgs());
					}

					this.state = TransactionState.NoTransaction;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}
			}
		}

		public void CommitRetaining()
		{
			lock (this.db) 
			{
				if (this.state != TransactionState.TransactionStarted && 
					this.state != TransactionState.TransactionPrepared)
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state, 
						this.handle,
						"no valid");
				}

				this.state = TransactionState.TransactionCommiting;

				try 
				{
					this.db.Send.Write(IscCodes.op_commit_retaining);
					this.db.Send.Write(this.handle);
					this.db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();

					this.state = TransactionState.TransactionStarted;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}				
			}
		}

		public void RollbackRetaining()
		{
			lock (this.db) 
			{
				if (this.state != TransactionState.TransactionStarted && 
					this.state != TransactionState.TransactionPrepared)
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state, 
						this.handle,
						"no valid");
				}

				this.state = TransactionState.TransactionRollbacking;

				try 
				{
					this.db.Send.Write(IscCodes.op_rollback_retaining);
					this.db.Send.Write(this.handle);
					this.db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();

					this.state = TransactionState.TransactionStarted;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}				
			}
		}

		public void Prepare()
		{
			lock (this.db)
			{
				if (this.state != TransactionState.TransactionStarted) 
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state, 
						this.handle,
						"no valid");
				}

				this.state = TransactionState.TransactionPreparing;

				try 
				{
					this.db.Send.Write(IscCodes.op_prepare);
					this.db.Send.Write(this.handle);
					this.db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();

					this.state = TransactionState.TransactionPrepared;
				} 
				catch (IOException)
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}				
			}
		}

		public void Prepare(byte[] buffer)
		{
			lock (this.db) 
			{
				if (this.state != TransactionState.TransactionStarted) 
				{
					throw new IscException(
						IscCodes.isc_arg_gds, 
						IscCodes.isc_tra_state, 
						this.handle,
						"no valid");
				}

				this.state = TransactionState.TransactionPreparing;

				try 
				{
					this.db.Send.Write(IscCodes.op_prepare2);
					this.db.Send.Write(this.handle);
					this.db.Send.WriteBuffer(buffer, buffer.Length);
					this.db.Send.Flush();

					GdsResponse r = db.ReceiveResponse();

					this.state = TransactionState.TransactionStarted;
				} 
				catch (IOException) 
				{
					throw new IscException(IscCodes.isc_net_read_err);
				}				
			}
		}

		#endregion
	}
}
