//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Gds
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class GdsFactory : FactoryBase
	{
		#region Static Properties

		private static readonly GdsFactory instance = new GdsFactory();

		public static FactoryBase Instance
		{
			get { return instance; }
		}

		#endregion

		#region Constructors

		private GdsFactory()
		{
		}

		#endregion

		#region Array Creation

		public override ArrayBase CreateArray(
			IDbAttachment	db,
			ITransaction	transaction,
			string			tableName, 
			string			fieldName)
		{
			return new GdsArray(db, transaction, tableName, fieldName);
		}

		public override ArrayBase CreateArray(
			IDbAttachment	db,
			ITransaction	transaction,
			long			handle,
			string			tableName,
			string			fieldName)
		{
			return new GdsArray(db, transaction, handle, tableName, fieldName);
		}

		#endregion

		#region Blob Creation

		public override BlobBase CreateBlob(
			IDbAttachment	db, 
			ITransaction	transaction)
		{
			return new GdsBlob(db, transaction);
		}

		public override BlobBase CreateBlob(
			IDbAttachment	db, 
			ITransaction	transaction, 
			long			handle)
		{
			return new GdsBlob(db, transaction, handle);
		}

		#endregion

		#region Connection Creation

		public override IDbAttachment CreateDbConnection(
			AttachmentParams parameters)
		{
			return new GdsDbAttachment(parameters);
		}
				
		public override ISvcAttachment CreateSvcConnection(
			AttachmentParams parameters)
		{
			return new GdsSvcAttachment(parameters);
		}

		#endregion
	}
}
