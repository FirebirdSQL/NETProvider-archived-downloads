//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Text;

using FirebirdSql.Data.Common;
using Borland.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	public class FbCommand : ISQLCommand
	{
		#region Fields

		private FbConnection	connection;
		private StatementBase	statement;
		private IscException	lastError;
		private int				transactionId;

		#endregion

		#region Internal Properties

		internal int RowsAffected
		{
			get 
			{
				if (this.statement != null)
				{
					return this.statement.RecordsAffected; 
				}
				return -1;
			}
		}

		internal int TransactionId
		{
			get { return this.transactionId; }
			set { this.transactionId = value; }
		}

		internal FbConnection Connection
		{
			get { return this.connection; }
		}

		#endregion

		#region Constructors

		public FbCommand(FbConnection connection)
		{
			this.connection	= connection;
		}

		#endregion

		#region ISQLCommand Methods

		public int Prepare(string sql, short paramCount)
		{
			Debug.WriteLine("Prepare " + sql);

			try
			{
				if (this.statement != null)
				{
					this.Release();
				}

				this.transactionId = this.connection.GetTransactionId();
				if (this.transactionId < 0)
				{
					this.connection.BeginTransaction(this.transactionId, (int)(IsolationLevel.ReadCommitted));
				}

				ITransaction transaction = (ITransaction)this.connection.Transactions[this.transactionId];

				this.statement = this.connection.IscDb.CreateStatement(transaction);
				
				this.statement.Prepare(sql);
				this.statement.Describe();
				this.statement.DescribeParameters();
			}
			catch (IscException e)
			{
				this.lastError = e;
				if (this.transactionId < 0)
				{
					this.connection.Rollback(this.transactionId);
					this.transactionId = 0;
				}
			}

			return this.getErrorCode();
		}

		public int PrepareProc(string spName, short paramCount)
		{
			try
			{
				if (this.statement != null)
				{
					this.Release();
				}

				this.transactionId = this.connection.GetTransactionId();
				if (this.transactionId < 0)
				{
					this.connection.BeginTransaction(this.transactionId, (int)(IsolationLevel.ReadCommitted));
				}

				ITransaction transaction = (ITransaction)this.connection.Transactions[this.transactionId];

				this.statement = this.connection.IscDb.CreateStatement(transaction);

				this.statement.Prepare(spName);
				this.statement.Describe();
				this.statement.DescribeParameters();
			}
			catch (IscException e)
			{
				this.lastError = e;
				if (this.transactionId < 0)
				{
					this.connection.Rollback(this.transactionId);
					this.transactionId = 0;
				}
			}

			return this.getErrorCode();
		}

		public int Execute(out ISQLCursor cursor, ref short resultCols)
		{
			try
			{
				if (this.statement == null)
				{
					throw new InvalidOperationException("Command needs to be prepared before execution.");
				}

				this.statement.Execute();
			}
			catch (IscException e)
			{
				this.lastError = e;
				if (this.transactionId < 0)
				{
					this.connection.Rollback(this.transactionId);
					this.transactionId = 0;
				}
			}

			cursor		= new FbCursor(this);
			resultCols	= this.statement.Fields.Count;

			return this.getErrorCode();
		}

		public int Close()
		{
			try
			{
				if (this.statement != null)
				{
					this.statement.Close();
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int Release()
		{
			try
			{
				if (this.transactionId < 0)
				{
					this.connection.Rollback(this.transactionId);
					this.transactionId = 0;
				}
				if (this.statement != null)
				{
					this.statement.Release();
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetStoredProcedureSQL(StringBuilder sql, ArrayList paramList)
		{
			try
			{
				sql.Insert(0, "SELECT * FROM ");

				if (paramList.Count > 0)
				{
					sql.Append("(");
					foreach (BdpSPParam parameter in paramList)
					{
						if (parameter.Direction == ParameterDirection.Input ||
							parameter.Direction == ParameterDirection.InputOutput)
						{
							sql.Append("?, ");
						}
					}
					sql.Remove(sql.Length - 2, 2);
					sql.Append(")");
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetRowsAffected(ref int rowsAffected)
		{
			try
			{
				if (this.statement != null)
				{
					rowsAffected = this.statement.RecordsAffected;
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetParameter(
			short		index, 
			short		childPos, 
			ref object	value, 
			ref bool	isNull)
		{
			try
			{
				value	= this.statement.Parameters[index].Value;
				isNull	= this.statement.Parameters[index].DbValue.IsDBNull();
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int SetParameter(
			short				index, 
			short				childPos, 
			ParameterDirection	paramDir, 
			BdpType				bdpType, 
			BdpType				subType, 
			int					maxPrecision, 
			int					maxScale, 
			int					length, 
			object				value, 
			bool				isNullable)
		{
			try
			{
				this.statement.Parameters[index].Value		= value;
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			if (this.lastError != null)
			{
				errorMessage.Append(this.lastError.Message);

				this.lastError = null;
			}

			return 0;
		}
        
		#endregion

		#region Internal Methods

		internal DbValue[] Fetch()
		{
			return this.statement.Fetch();			
		}

		internal RowDescriptor GetFieldsDescriptor()
		{
			if (this.statement != null)
			{
				return this.statement.Fields;
			}

			return null;
		}

		#endregion

		#region Private

		private int getErrorCode()
		{
			return (this.lastError != null ? this.lastError.ErrorCode : 0);
		}

		#endregion
	}
}
