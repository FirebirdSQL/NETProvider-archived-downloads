//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Collections;
using System.Data;
using System.Text;
using System.Diagnostics;

using Borland.Data.Common;
using Borland.Data.Schema;

namespace FirebirdSql.Data.Bdp
{
	public class FbMetaData : ISQLMetaData
	{
		#region Fields

		private FbConnection	connection;
		private Hashtable		metadataProps;

		#endregion

		#region Constructors

		public FbMetaData(FbConnection connection)
		{
			this.connection	= connection;
		}

		#endregion

		#region ISQLMetaData Methods

		public void GetProperty(MetaDataProps property, out object value)
		{
			if (this.metadataProps == null)
			{
				this.metadataProps = new Hashtable();
			}

			switch (property)
			{
				case MetaDataProps.QualifiedName:
					value = this.metadataProps[MetaDataProps.ObjectName];
					break;
			
				default:
					value = this.metadataProps[property];
					break;
			}			

			Debug.WriteLine(String.Format("FbMetaData.GetProperty ({0},{1})", property, value));
		}

		public void SetProperty(MetaDataProps property, object value)
		{
			if (this.metadataProps == null)
			{
				this.metadataProps = new Hashtable();
			}

			if (this.metadataProps.ContainsKey(property))
			{
				this.metadataProps[property] = value;
			}
			else
			{
				this.metadataProps.Add(property, value);
			}

			Debug.WriteLine(String.Format("FbMetaData.SetProperty ({0},{1})", property, value));
		}

		public DataTable GetSchemaTable(IDataReader reader, IDbCommand command)
		{
			Debug.WriteLine("FbMetaData.GetSchemaTable()");
			
			throw new NotSupportedException();
		}

		public DataTable GetTables(string tableName, TableType tableType)
		{
			StringBuilder	sql			= new StringBuilder();
			StringBuilder	where		= new StringBuilder();
			FbCommand		select		= new FbCommand(this.connection);
			ISQLCursor		cursor		= null;
			DataTable		schema		= BdpMetaDataHelper.CreateTableTable();
			short			resultCols	= 0;

			sql.Append(
				@"SELECT " +
				"rdb$relation_name AS TableName "	+
				/*
				"rdb$view_source AS TableType, "	+
				"rdb$system_flag AS SystemTable, "	+
				*/
				"FROM " +
				"rdb$relations");
			
			if (tableName != null && tableName.Length > 0)
			{
				where.AppendFormat("rdb$relation_name = '{0}'", tableName);
			}

			if (where.Length > 0)
			{
				where.Append(" AND ");
			}

			switch (tableType)
			{
				case TableType.SystemTable:
					where.Append("rdb$view_source IS null AND rdb$system_flag = 1");
					break;

				case TableType.View:
					where.Append("rdb$view_source IS NOT null AND rdb$system_flag = 0");
					break;

				case TableType.Table:
				default:
					where.Append("rdb$view_source IS NULL AND rdb$system_flag = 0");
					break;
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rdb$system_flag, rdb$owner_name, rdb$relation_name");

			// Prepare and execute the command
			select.Prepare(sql.ToString(), 0);
			select.Execute(out cursor, ref resultCols);

			int recno = 0;

			while (cursor.Next() != -1)
			{
				DataRow row = schema.NewRow();

				row["Recno"]		= recno++;
				row["CatalogName"]	= null;
				row["SchemaName"]	= null;
				row["TableName"]	= ((FbCursor)cursor).GetValue(0).ToString().Trim();
				row["TableType"]	= tableType;

				schema.Rows.Add(row);
			}

			cursor.Release();
			select.Release();

			return schema;
		}

		public DataTable GetColumns(
			string tableName, 
			string columnName, 
			ColumnType columnType)
		{
			StringBuilder	sql			= new StringBuilder();
			StringBuilder	where		= new StringBuilder();
			FbCommand		select		= new FbCommand(this.connection);
			ISQLCursor		cursor		= null;
			DataTable		schema		= BdpMetaDataHelper.CreateColumnTable();
			short			resultCols	= 0;

			sql.Append(
				@"SELECT " +
				"rfr.rdb$relation_name AS TableName, " +
				"rfr.rdb$field_name AS ColumName, " +
				"rfr.rdb$field_position AS ColumnPosition, " +
				"fld.rdb$field_type AS ColumnDataType, " +
				"fld.rdb$field_sub_type AS ColumnSubType, " +
				"fld.rdb$field_length AS ColumnSize, " +
				"fld.rdb$field_precision AS ColumnPrecision, " +
				"fld.rdb$field_scale AS ColumnScale, " +
				"rfr.rdb$null_flag AS ColumnNullable " +
				"FROM " +
				"rdb$relation_fields rfr " +
				"left join rdb$fields fld ON rfr.rdb$field_source = fld.rdb$field_name ");

			if (tableName != null && tableName.Length > 0)
			{
				where.AppendFormat("rfr.rdb$relation_name = '{0}'", tableName);
			}

			if (columnName != null && columnName.Length > 0)
			{
				if (where.Length > 0)
				{
					where.Append(" AND ");
				}

				where.AppendFormat("rfr.rdb$field_name = '{0}'", columnName);
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rfr.rdb$relation_name, rfr.rdb$field_position");

			// Prepare and execute the command
			select.Prepare(sql.ToString(), 0);
			select.Execute(out cursor, ref resultCols);

			int recno = 0;

			while (cursor.Next() != -1)
			{
				DataRow row = schema.NewRow();

				row["Recno"]			= recno++;
				row["CatalogName"]		= null;
				row["SchemaName"]		= null;
				row["TableName"]		= ((FbCursor)cursor).GetValue(0).ToString().Trim();
				row["ColumnName"]		= ((FbCursor)cursor).GetValue(1).ToString().Trim();
				row["ColumnPosition"]	= ((FbCursor)cursor).GetValue(2);
				row["ColumnType"]		= columnType;
				row["ColumnDataType"]	= ((FbCursor)cursor).GetValue(3);
				row["ColumnTypeName"]	= String.Empty;
				row["ColumnSubtype"]	= ((FbCursor)cursor).GetValue(4);
				row["ColumnLength"]		= ((FbCursor)cursor).GetValue(5);
				row["ColumnPrecision"]	= ((FbCursor)cursor).GetValue(6);
				row["ColumnScale"]		= ((FbCursor)cursor).GetValue(7);
				if (((FbCursor)cursor).GetValue(8) == DBNull.Value)
				{
					row["ColumnNullable"] = true;
				}
				else
				{
					row["ColumnNullable"] = false;
				}


				schema.Rows.Add(row);
			}

			cursor.Release();
			select.Release();

			return schema;
		}

		public DataTable GetIndices(string tableName, IndexType indexType)
		{
			Debug.WriteLine("GetIndices");
			
			throw new NotSupportedException();
		}

		public DataTable GetProcedures(string spName, ProcedureType procType)
		{
			StringBuilder	sql			= new StringBuilder();
			StringBuilder	where		= new StringBuilder();
			FbCommand		select		= new FbCommand(this.connection);
			ISQLCursor		cursor		= null;
			DataTable		schema		= BdpMetaDataHelper.CreateProcedureTable();
			short			resultCols	= 0;

			sql.Append(
				@"SELECT " +
				"rdb$procedure_name AS ProcName, " +
				"rdb$procedure_inputs AS Inputs, " +
				"rdb$procedure_outputs AS Outputs " +
				"FROM " +
				"rdb$procedures");

			if (spName != null && spName.Length > 0)
			{
				where.AppendFormat("rdb$procedure_name = '{0}'", spName);
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			sql.Append(" ORDER BY rdb$procedure_name");

			// Prepare and execute the command
			select.Prepare(sql.ToString(), 0);
			select.Execute(out cursor, ref resultCols);

			int recno = 0;

			while (cursor.Next() != -1)
			{
				DataRow row = schema.NewRow();

				row["Recno"]		= recno++;
				row["CatalogName"]	= null;
				row["SchemaName"]	= null;
				row["ProcName"]		= ((FbCursor)cursor).GetValue(0).ToString().Trim();
				row["ProcType"]		= procType;
				row["InParams"]		= ((FbCursor)cursor).GetValue(1);
				row["OutParams"]	= ((FbCursor)cursor).GetValue(2);
				
				schema.Rows.Add(row);
			}

			cursor.Release();
			select.Release();

			return schema;
		}

		public DataTable GetProcedureParams(string spName, string paramName)
		{
			StringBuilder	sql			= new StringBuilder();
			StringBuilder	where		= new StringBuilder();
			FbCommand		select		= new FbCommand(this.connection);
			ISQLCursor		cursor		= null;
			DataTable		schema		= BdpMetaDataHelper.CreateProcedureParamsTable();
			short			resultCols	= 0;

			sql.Append(
				@"SELECT " +
				"pp.rdb$procedure_name AS ProcName, " +
				"pp.rdb$parameter_name AS ParamName, " +
				"pp.rdb$parameter_type AS ParamType, " +
				"pp.rdb$parameter_number AS ParamPosition, " +
				"fld.rdb$field_type AS ParamDataType, " +
				"fld.rdb$field_sub_type AS ParamSubType, " +
				"fld.rdb$field_length AS ParamSize, " +
				"fld.rdb$field_precision AS ParamPrecision, " +
				"fld.rdb$field_scale AS ParamScale " +
				"FROM " +
				"rdb$procedure_parameters pp " +
				"left join rdb$fields fld ON pp.rdb$field_source = fld.rdb$field_name " +
				"left join rdb$character_sets cs ON cs.rdb$character_set_id = fld.rdb$character_set_id " +
				"left join rdb$collations coll ON (coll.rdb$collation_id = fld.rdb$collation_id AND coll.rdb$character_set_id = fld.rdb$character_set_id) ");

			if (spName != null && spName.Length > 0)
			{
				where.AppendFormat("pp.rdb$procedure_name = '{0}'", spName);
			}

			if (paramName != null && paramName.Length > 0)
			{
				if (where.Length > 0)
				{
					where.Append(" AND ");
				}

				where.AppendFormat("pp.rdb$parameter_name = '{0}'", paramName);
			}

			if (where.Length > 0)
			{
				sql.AppendFormat(" WHERE {0} ", where.ToString());
			}

			// Prepare and execute the command
			select.Prepare(sql.ToString(), 0);
			select.Execute(out (ISQLCursor)cursor, ref resultCols);

			int recno = 0;

			while (cursor.Next() != -1)
			{
				DataRow row = schema.NewRow();

				row["Recno"]		= recno++;
				row["CatalogName"]	= null;
				row["SchemaName"]	= null;
				row["ProcName"]		= ((FbCursor)cursor).GetValue(0).ToString().Trim();
				row["ParamName"]	= ((FbCursor)cursor).GetValue(1).ToString().Trim();
				row["ParamType"]	= ((FbCursor)cursor).GetValue(2);
				row["ParamPosition"]= ((FbCursor)cursor).GetValue(3);
				row["ParamDataType"]= ((FbCursor)cursor).GetValue(4);
				row["ParamSubType"]	= ((FbCursor)cursor).GetValue(5);
				row["ParamTypeName"]= "";
				row["ParamPrecision"]= ((FbCursor)cursor).GetValue(7);
				row["ParamScale"]	= ((FbCursor)cursor).GetValue(8);
				row["ParamLength"]	= ((FbCursor)cursor).GetValue(6);
				row["ParamNullable"]= true;

				schema.Rows.Add(row);
			}

			cursor.Release();
			select.Release();

            return schema;
		}

		public DataTable GetObjectList(ObjectType type)
		{
			Debug.WriteLine("FbMetaData.GetObjectList()");

			throw new NotSupportedException();
		}

		#endregion
	}
}
