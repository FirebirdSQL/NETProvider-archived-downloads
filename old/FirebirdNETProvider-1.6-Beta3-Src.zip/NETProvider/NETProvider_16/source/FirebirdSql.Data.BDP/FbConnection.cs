//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Data;
using System.Collections;
using System.Diagnostics;
using System.Text;

using Borland.Data.Common;
using Borland.Data.Schema;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	public class FbConnection : ISQLConnection
	{
		#region Fields

		private IDbAttachment		db;
		private AttachmentParams	parameters;
		private string				connectionOptions;
		private IscException		lastError;
		private Hashtable			transactions;
		private Hashtable			connectionProps;
		private int					internalTransactionId;
		private int					transactionId;

		#endregion

		#region Internal Properties

		internal FactoryBase Factory
		{
			get { return this.db.Factory; }
		}

		internal IDbAttachment IscDb
		{
			get { return this.db; }
		}

		public Hashtable Transactions
		{
			get { return this.transactions; }
		}

		#endregion
		
		#region Constructors

		public FbConnection()
		{
			Debug.Listeners.Add(new TextWriterTraceListener(@"c:\bdp.log"));
			Debug.AutoFlush = true;
			Debug.Indent();

			this.db				= null;
			this.transactionId	= -1;
		}

		#endregion

		#region ISQLConnection Methods

		public int Connect(
			string database, 
			string user,
			string password,
			string hostName)
		{
			string connectionString =
				String.Format(
					"{0}={1};{2}={3};{4}={5};{6}={7};{8}",
					"DataSource", hostName,
					"Database", database,
					"User", user,
					"Password", password,
					this.connectionOptions);
			
			this.parameters	= new AttachmentParams(connectionString);

			FactoryBase factory = ClientFactory.GetInstance(parameters.ServerType);

			try
			{
				this.db = factory.CreateDbConnection(this.parameters);
				this.db.Attach();
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int Disconnect()
		{
			try
			{
				this.db.Detach();
				
				this.lastError	= null;
				this.db			= null;
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int BeginTransaction(int transID, int isolationLevel)
		{
			IsolationLevel isolLevel = (IsolationLevel)isolationLevel;

			try
			{
				ITransaction transaction = this.db.BeginTransaction(this.buildTpb(isolLevel));
				
				if (this.transactions == null)
				{
					this.transactions = new Hashtable();
				}
                
				transactions.Add(transID, transaction);

				if (transID > 0)
				{
					this.transactionId = transID;
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int Commit(int transID)
		{
			if (this.transactions == null)
			{
				throw new InvalidOperationException();
			}

			try
			{
				if (this.transactions.ContainsKey(transID))
				{
					ITransaction transaction = (ITransaction)this.transactions[transID];
					transaction.Commit();

					this.transactions.Remove(transID);

					if (transID > 0)
					{
						this.transactionId = -1;
					}
				}
				else
				{
					throw new InvalidOperationException();
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}

			return this.getErrorCode();
		}

		public int Rollback(int transID)
		{
			if (this.transactions == null)
			{
				throw new InvalidOperationException();
			}

			try
			{
				if (this.transactions.ContainsKey(transID))
				{
					ITransaction transaction = (ITransaction)this.transactions[transID];
					transaction.Rollback();
				}
				else
				{
					throw new InvalidOperationException();
				}
			}
			catch (IscException e)
			{
				this.lastError = e;
			}
			finally
			{
				this.transactions.Remove(transID);

				if (transID > 0)
				{
					this.transactionId = -1;
				}
			}

			return this.getErrorCode();
		}

		public int ChangeDatabase(
			string	database, 
			string	user, 
			string	password, 
			bool	connected)
		{
			throw new NotSupportedException();
		}

		public int FreeConnect()
		{
			this.lastError = null;

			return 0;
		}

		public void GetProperty(ConnectionProps property, out object value)
		{
			if (this.connectionProps == null)
			{
				this.connectionProps = new Hashtable();
			}

			value = this.connectionProps[property];
		}

		public void SetProperty(ConnectionProps property, object value)
		{
			if (this.connectionProps == null)
			{
				this.connectionProps = new Hashtable();
			}

			if (this.connectionProps.ContainsKey(property))
			{
				this.connectionProps[property] = value;
			}
			else
			{
				this.connectionProps.Add(property, value);
			}
		}

		public int SetOptions(string connOptions)
		{
			this.connectionOptions = connOptions;
			
			return 0;
		}

		public ISQLResolver GetResolver()
		{
			Debug.WriteLine("FbConnection.GetResolver()");

			return new FbResolver(this);
		}

		public ISQLMetaData GetMetaData()
		{
			Debug.WriteLine("FbConnection.GetMetaData()");

			return new FbMetaData(this);
		}

		public ISQLCommand GetSQLCommand()
		{
			Debug.WriteLine("FbConnection.GetSqlCommand()");

			return new FbCommand(this);
		}

		public int GetErrorMessage(ref StringBuilder errorMessage)
		{
			if (this.lastError != null)
			{
				errorMessage.Append(this.lastError.Message);

				this.lastError = null;
			}

			return 0;
		}

		#endregion

		#region Internal Methods

		internal int GetTransactionId()
		{
			lock (this)
			{
				if (this.transactionId < 0)
				{
					return --this.internalTransactionId;
				}
				else
				{
					return this.transactionId;
				}
			}
		}

		#endregion

		#region Private

		private int getErrorCode()
		{
			return (this.lastError != null ? this.lastError.ErrorCode : 0);
		}

		private DpbBuffer buildTpb(IsolationLevel isolationLevel)
		{
			DpbBuffer tpb = new DpbBuffer();

			tpb.Append(IscCodes.isc_tpb_version3);
			tpb.Append(IscCodes.isc_tpb_write);
			tpb.Append(IscCodes.isc_tpb_wait);

			/* Isolation level */
			switch (isolationLevel)
			{
				case IsolationLevel.Serializable:
					tpb.Append(IscCodes.isc_tpb_consistency);
					break;

				case IsolationLevel.RepeatableRead:			
					tpb.Append(IscCodes.isc_tpb_concurrency);
					break;

				case IsolationLevel.ReadUncommitted:
					tpb.Append(IscCodes.isc_tpb_read_committed);
					tpb.Append(IscCodes.isc_tpb_rec_version);
					break;

				case IsolationLevel.ReadCommitted:
				default:					
					tpb.Append(IscCodes.isc_tpb_read_committed);
					tpb.Append(IscCodes.isc_tpb_no_rec_version);
					break;
			}

			return tpb;
		}

		#endregion
	}
}