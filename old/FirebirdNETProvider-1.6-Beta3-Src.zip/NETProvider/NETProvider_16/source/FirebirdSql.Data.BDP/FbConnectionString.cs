//
// Firebird BDP - Borland Data Provider for Firebird
// Copyright (C) 2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.ComponentModel;
using Borland.Data.Common;

namespace FirebirdSql.Data.Bdp
{
	// References:
	//	http://www.distribucon.com/bdp/BDP-DE.html
	public class FbConnectionString : BdpConnectionString
	{
		#region Protected Fields

		// Property Names
		protected const string SRoleName	= "RoleName";
		protected const string SServerType	= "ServerType";
		protected const string SPacketSize	= "PacketSize";
		protected const string SDialect		= "Dialect";
		protected const string SCharset		= "Charset";
		
		// Property Values
		protected new const string SProvider	= "Firebird";
		protected const int DefServerType		= 0;
		protected const int DefDialect			= 3;
		protected const int DefPacketSize		= 8192;
		protected const string DefRoleName		= "";
		protected const string DefCharset		= "NONE";
		
		#endregion

		#region Properties

		[Category(OptionsCat)]
		[DefaultValue(DefRoleName)]
		public string RoleName
		{
			get { return base.OptionsDictionary[SRoleName]; } 
			set { base.OptionsDictionary[SRoleName] = value; }
		}

		[Category(OptionsCat)]
		[DefaultValue(DefDialect)]
		public int Dialect
		{
			get { return Convert.ToInt32(base.OptionsDictionary[SDialect]); } 
			set { base.OptionsDictionary[SDialect] = value.ToString(); }
		}

		[Category(OptionsCat)]
		[DefaultValue(DefCharset)]
		public string Charset
		{
			get { return base.OptionsDictionary[SCharset]; } 
			set { base.OptionsDictionary[SCharset] = value; }
		}

		[Category(OptionsCat)]
		[DefaultValue(DefServerType)]
		public int ServerType
		{
			get { return Convert.ToInt32(base.OptionsDictionary[SServerType]); } 
			set { base.OptionsDictionary[SServerType] = value.ToString(); }
		}

		[Category(OptionsCat)]
		[DefaultValue(DefPacketSize)]
		public int PacketSize
		{
			get { return Convert.ToInt32(base.OptionsDictionary[SPacketSize]); } 
			set { base.OptionsDictionary[SPacketSize] = value.ToString(); }
		}

		#endregion

		#region Constructors

		public FbConnectionString() : base()
		{
			this.SetProvider(SProvider);

			this.RoleName	= DefRoleName;
			this.ServerType = DefServerType;
			this.PacketSize	= DefPacketSize;
			this.Dialect	= DefDialect;
			this.Charset	= DefCharset;
		}

		#endregion
	}
}
