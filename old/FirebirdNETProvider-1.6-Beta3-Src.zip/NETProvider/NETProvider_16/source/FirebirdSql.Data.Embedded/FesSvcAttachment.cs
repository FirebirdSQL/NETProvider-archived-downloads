//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.IO;
using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Embedded
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	sealed class FesSvcAttachment : FesAttachment, ISvcAttachment
	{
		#region Constructors

		public FesSvcAttachment(AttachmentParams parameters) : base(parameters)
		{
		}

		#endregion

		#region Methods

		public void Attach(string service, SpbBuffer spb)
		{
			int[]	statusVector	= FesFactory.CreateStatusVector();
			int		svcHandle		= this.Handle;

			int status = FbClient.isc_service_attach(
				statusVector,
				(short) service.Length,
				service,
				ref svcHandle,
				(short) spb.Length,
				spb.ToArray());

			// Parse status vector
			this.ParseStatusVector(statusVector);

			// Update status vector
			this.Handle = svcHandle;
		}

		public void Detach()
		{
			int[]	statusVector	= FesFactory.CreateStatusVector();
			int		svcHandle		= this.Handle;

			int status = FbClient.isc_service_detach(
				statusVector,
				ref svcHandle);

			// Parse status vector
			this.ParseStatusVector(statusVector);

			// Update status vector
			this.Handle = svcHandle;
		}				

		public void Start(SpbBuffer spb)
		{
			int[]	statusVector	= FesFactory.CreateStatusVector();
			int		svcHandle		= this.Handle;
			int		reserved		= 0;

			int status = FbClient.isc_service_start(
				statusVector,
				ref svcHandle,
				ref reserved,
				(short) spb.Length,
				spb.ToArray());

			// Parse status vector
			this.ParseStatusVector(statusVector);
		}

		public void Query(
			SpbBuffer	spb	,
			int 		requestLength	,
			byte[] 		requestBuffer	,
			int 		bufferLength	,
			byte[] 		buffer)
		{
			int[]	statusVector	= FesFactory.CreateStatusVector();
			int		svcHandle		= this.Handle;
			int		reserved		= 0;

			int status = FbClient.isc_service_query(
				statusVector,
				ref svcHandle,
				ref reserved,
				(short) spb.Length,
				spb.ToArray(), 
				(short) requestLength,
				requestBuffer,
				(short) buffer.Length,
				buffer);

			// Parse status vector
			this.ParseStatusVector(statusVector);
		}
		
		public override void SendWarning(IscException warning) 
		{
			throw new NotSupportedException();
		}

		#endregion
	}
}
