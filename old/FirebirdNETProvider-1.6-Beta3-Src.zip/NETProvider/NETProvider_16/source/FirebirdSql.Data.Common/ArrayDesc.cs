//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Runtime.InteropServices;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
	struct ArrayDesc
	{
		#region Fields

		private byte		dataType;
		private short		scale;
		private short		length;
		private string		fieldName;
		private string		relationName;
		private short		dimensions;
		private short		flags;
		private ArrayBound[] bounds;

		#endregion

		#region Properties

		public byte	DataType
		{
			get { return this.dataType; }
			set { this.dataType = value; }
		}

		// Scale for numeric datatypes
		public short Scale
		{
			get { return this.scale; }
			set { this.scale = value; }
		}

		// Legth in bytes of each array element
		public short Length
		{
			get { return this.length; }
			set { this.length = value; }
		}

		// Column name - 32
		public string FieldName
		{
			get { return this.fieldName; }
			set { this.fieldName = value; }
		}

		// Table name -32
		public string RelationName
		{
			get { return this.relationName; }
			set { this.relationName = value; }
		}

		// Number of array dimensions 
		public short Dimensions
		{
			get { return this.dimensions; }
			set { this.dimensions = value; }
		}

		// Specifies wheter array is to be accesed in
		// row mayor or column-mayor order
		public short Flags
		{
			get { return this.flags; }
			set { this.flags = value; }
		}

		// Lower and upper bounds for each dimension - 16
		public ArrayBound[] Bounds
		{
			get { return this.bounds; }
			set { this.bounds = value; }
		}

		#endregion
	}

#if (SINGLE_DLL)
	internal
#else
	public
#endif
	struct ArrayBound
	{
		#region Fields

		private int lowerBound;
		private int upperBound;

		#endregion

		#region Properties

		public int LowerBound
		{
			get { return this.lowerBound; }
			set { this.lowerBound = value; }
		}

		public int UpperBound
		{
			get { return this.upperBound; }
			set { this.upperBound = value; }
		}

		#endregion 
	}
}
