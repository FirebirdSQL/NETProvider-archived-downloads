//
// Firebird .NET Data Provider - Firebird managed data provider for .NET and Mono
// Copyright (C) 2002-2004  Carlos Guzman Alvarez
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lesser.html
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//

using System;
using System.Globalization;

namespace FirebirdSql.Data.Common
{
#if (SINGLE_DLL)
	internal
#else
	public
#endif
		sealed class TypeEncoder
	{
		#region Constructors

		private TypeEncoder()
		{
		}

		#endregion

		#region Static Methods

		public static object EncodeDecimal(decimal d, int scale, int sqltype)
		{
			long multiplier = 1;
			
			if (scale < 0)
			{
				int exp = scale * (-1);
				multiplier = (long)System.Math.Pow(10, exp);
			}
			
			switch (sqltype & ~1)
			{
				case IscCodes.SQL_SHORT:
					return (short)(d * multiplier);
				
				case IscCodes.SQL_LONG:
					return (int)(d * multiplier);
				
				case IscCodes.SQL_QUAD:
				case IscCodes.SQL_INT64:
					return (long)(d * multiplier);
											
				case IscCodes.SQL_DOUBLE:
				default:
				{
					return d;
				}
			}
		}

		public static int EncodeTime(DateTime d) 
		{
			GregorianCalendar calendar = new GregorianCalendar();

			int millisInDay = 
				(int)(calendar.GetHour(d) * 3600000	+
				calendar.GetMinute(d) * 60000	+
				calendar.GetSecond(d) * 1000	+
				calendar.GetMilliseconds(d)) * 10;

			return millisInDay;
		}

		public static int EncodeDate(DateTime d)
		{			
			int day, month, year;
			int c, ya;

			GregorianCalendar calendar = new GregorianCalendar();

			day		= calendar.GetDayOfMonth(d);
			month	= calendar.GetMonth(d);
			year	= calendar.GetYear(d);

			if (month > 2) 
			{
				month -= 3;
			} 
			else
			{
				month	+= 9;
				year	-= 1;
			}

			c	= year / 100;
			ya	= year - 100 * c;

			return ((146097 * c) / 4	+
				(1461 * ya) / 4			+
				(153 * month + 2) / 5	+
				day + 1721119 - 2400001);
		}

		#endregion
	}
}