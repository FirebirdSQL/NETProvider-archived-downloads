//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using NUnit.Framework;

using System;
using System.Data;
using FirebirdSql.Data.Firebird;


namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbCommandTest : BaseTest 
	{
		FbConnection  conn;
		FbTransaction transaction;
		
		public FbCommandTest() : base()
		{		
		}

		[SetUp]
		public void Setup()
		{		
			conn = new FbConnection(GetConnectionString());
			conn.Open();

			transaction = conn.BeginTransaction();
		}
		
		[TearDown]
		public void TearDown()
		{
			conn.Close();
		}

		[Test]
		public void ExecuteNonQueryTest()
		{							
			FbCommand cmd = conn.CreateCommand();
			
			cmd.Transaction = transaction;
			cmd.CommandText = "UPDATE EMPLOYEE SET PHONE_EXT = ? WHERE EMP_NO = ?";
									
			cmd.Parameters.Add("@Phone_ext", "0100");
			cmd.Parameters.Add("@Emp_no", 2);
						
			int affectedRows = cmd.ExecuteNonQuery();
									
			Assertion.AssertEquals(affectedRows, 1);
		}
		
		[Test]
		public void ExecuteReaderTest()
		{							
			FbCommand cmd = conn.CreateCommand();
			
			cmd.Transaction = transaction;
			cmd.CommandText = "SELECT * FROM JOB";
						
			FbDataReader reader = cmd.ExecuteReader();
									
			reader.Close();
		}
		
		[Test]
		public void ExecuteScalarTest()
		{							
			FbCommand cmd = conn.CreateCommand();
			
			cmd.Transaction = transaction;
			cmd.CommandText = "SELECT PHONE_EXT FROM EMPLOYEE WHERE EMP_NO = ?";
									
			cmd.Parameters.Add("@Emp_no", 2);
						
			string phone_ext = cmd.ExecuteScalar().ToString();
			
			Console.WriteLine("Scalar value: {0}", phone_ext);
			
			Assertion.AssertEquals(phone_ext, "0100");
		}
		
		[Test]
		public void PrepareTest()
		{							
			FbCommand cmd = conn.CreateCommand();
			
			cmd.Transaction = transaction;
			cmd.CommandText = "UPDATE EMPLOYEE SET PHONE_EXT = ? WHERE EMP_NO = ?";
									
			cmd.Parameters.Add("@Phone_ext", "0100");
			cmd.Parameters.Add("@Emp_no", 2);
						
			cmd.Prepare();
		}

		[Test]
		public void ExecuteStoredProcTest()
		{			
			FbCommand command = new FbCommand("EXECUTE PROCEDURE ORG_CHART", conn, transaction);
				
			command.CommandType = CommandType.StoredProcedure;

			command.Parameters.Add("@param01", FbType.VarChar).Direction = ParameterDirection.Output;
			command.Parameters.Add("@param02", FbType.VarChar).Direction = ParameterDirection.Output;
			command.Parameters.Add("@param03", FbType.VarChar).Direction = ParameterDirection.Output;
			command.Parameters.Add("@param04", FbType.VarChar).Direction = ParameterDirection.Output;
			command.Parameters.Add("@param05", FbType.Integer).Direction = ParameterDirection.Output;

			// This will fill poutput parameters values
			command.ExecuteNonQuery();

			Console.WriteLine("Output Parameters");
			Console.WriteLine(command.Parameters[0].Value);
			Console.WriteLine(command.Parameters[1].Value);
			Console.WriteLine(command.Parameters[2].Value);
			Console.WriteLine(command.Parameters[3].Value);
			Console.WriteLine(command.Parameters[4].Value);
		}
	}
}
