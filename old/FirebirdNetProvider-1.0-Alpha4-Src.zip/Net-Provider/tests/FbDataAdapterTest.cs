//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using NUnit.Framework;

using System;
using System.Data;
using FirebirdSql.Data.Firebird;


namespace FirebirdSql.Data.Firebird.Tests
{
	[TestFixture]
	public class FbDataAdapterTest : BaseTest 
	{
		FbConnection	conn;
		FbTransaction	transaction;

		public FbDataAdapterTest() : base()
		{		
		}

		[SetUp]
		public void Setup()
		{		
			conn = new FbConnection(GetConnectionString());
			conn.Open();

			transaction = conn.BeginTransaction();
		}
		
		[TearDown]
		public void TearDown()
		{
			conn.Close();
		}
		
		[Test]
		public void FillTest()
		{
			FbDataAdapter adapter = new FbDataAdapter(new FbCommand("select * from SALES where PO_NUMBER = ?", conn, transaction));

			adapter.SelectCommand.Parameters.Add("@DECIM", FbType.VarChar, "DECIM").Value = "V91E0210";
			
			FbCommandBuilder cmdBuilder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "SALES");
			ds.AcceptChanges();

			Console.WriteLine("Results of Fill Test");

			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
					Console.Write(col.ColumnName + "\t\t");
				Console.WriteLine();
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
						Console.Write(row[i] + "\t\t");
					Console.WriteLine("");
				}
			}

			adapter.Dispose();
		}

		[Test]
		public void UpdateTest()
		{
			FbDataAdapter adapter = new FbDataAdapter(new FbCommand("select * from SALES where PO_NUMBER = ?", conn, transaction));

			adapter.SelectCommand.Parameters.Add("@DECIM", FbType.VarChar, "DECIM").Value = "V91E0210";
			
			FbCommandBuilder cmdBuilder = new FbCommandBuilder(adapter);

			DataSet ds = new DataSet();
			adapter.Fill(ds, "SALES");
			ds.AcceptChanges();

			Console.WriteLine("Dataset state before update");
			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
					Console.Write(col.ColumnName + "\t\t");
				Console.WriteLine();
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
						Console.Write(row[i] + "\t\t");
					Console.WriteLine("");
				}
			}

			ds.Tables["SALES"].Rows[0]["DISCOUNT"] = 1.00F;
			adapter.Update(ds, "SALES");

			Console.WriteLine("Dataset state after update");
			foreach (DataTable table in ds.Tables)
			{
				foreach (DataColumn col in table.Columns)
					Console.Write(col.ColumnName + "\t\t");
				Console.WriteLine();
				foreach (DataRow row in table.Rows)
				{
					for (int i = 0; i < table.Columns.Count; i++)
						Console.Write(row[i] + "\t\t");
					Console.WriteLine("");
				}
			}

			adapter.Dispose();
		}
	}
}
