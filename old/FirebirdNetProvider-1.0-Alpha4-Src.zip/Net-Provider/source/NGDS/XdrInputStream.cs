//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.IO;
using System.Text;
using System.Net;

namespace FirebirdSql.Data.NGDS
{
	/// <include file='xmldoc/xdrinputstream.xml' path='doc/member[@name="T:XdrInputStream"]/*'/>
	internal class XdrInputStream : BinaryReader
	{
		#region FIELDS

		private byte[] pad = new byte[4];

		#endregion

		#region CONSTRUCTORS

		public XdrInputStream(Stream input) : base(input)
		{			
		}

		#endregion 

		#region METHODS
			
		public byte[] ReadOpaque(int len)
		{
			byte[] buffer = new byte[len];

			int readed = 0;
			while(readed<len)
			{
				readed += Read(buffer, readed, len-readed);
			}
			Read(pad, 0, ((4 - len) & 3));

			return buffer;
		}

		public byte[] ReadBuffer()
		{
			int len = this.ReadInt();
			byte[] buffer = new byte[len];
			
			int readed = 0;
			while(readed<len)
			{				
				readed += Read(buffer, readed, len-readed);
			}
			Read(pad, 0, ((4 - len) & 3));
			
			return buffer;
		}

		public override string ReadString()
		{
			int len = this.ReadInt();
			byte[] buffer = new byte[len];
						
			Read(buffer, 0, len);
			Read(pad, 0, ((4 - len) & 3));
			
			return Encoding.Default.GetString(buffer);
		}

		public short ReadShort()
		{
			short hostVal = this.ReadInt16();

			return IPAddress.HostToNetworkOrder(hostVal);
		}

		public int ReadInt()
		{
			int hostVal = this.ReadInt32();

			return IPAddress.HostToNetworkOrder(hostVal);
		}

		public long ReadLong()
		{
			long hostVal = this.ReadInt64();

			return IPAddress.HostToNetworkOrder(hostVal);
		}

		public override float ReadSingle()
		{			
			FloatLayout floatValue = new FloatLayout();

			floatValue.f  = base.ReadSingle();;
			floatValue.i0 = IPAddress.HostToNetworkOrder(floatValue.i0);

			return floatValue.f;
		}
		
		public override double ReadDouble()
		{			
			DoubleLayout doubleValue = new DoubleLayout();
			int temp;			

			doubleValue.d = base.ReadDouble();
			doubleValue.i0 = IPAddress.HostToNetworkOrder(doubleValue.i0);
			doubleValue.i4 = IPAddress.HostToNetworkOrder(doubleValue.i4);

			temp = doubleValue.i0;
			doubleValue.i0 = doubleValue.i4;
			doubleValue.i4 = temp;

			return doubleValue.d;
		}		

		#endregion
	}
}