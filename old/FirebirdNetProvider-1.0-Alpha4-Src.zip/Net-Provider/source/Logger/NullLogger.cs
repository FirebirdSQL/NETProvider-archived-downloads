//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// This file was ported from JayBird <http://firebird.sourceforge.net/>
// Ported by : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

namespace FirebirdSql.Logging
{ 
	/// <summary>
	/// Describe class <code>NullLogger</code> here.
	/// </summary>
	internal class NullLogger : Logger
	{
	
		public NullLogger(string name)
		{
		}
	
		public override bool isDebugEnabled() 
		{
			return false;
		}
	
		public override void debug(object message) 
		{
		}
	
		public override void debug(object message, Exception ex) 
		{
		}
	
		public override bool isInfoEnabled() 
		{
			return false;
		}
	
		public override void info(object message) 
		{
		}
	
		public override void info(object message, Exception ex) 
		{
		}
	
		public override bool isWarnEnabled() 
		{
			return false;
		}
	
		public override void warn(object message) 
		{
		}
	
		public override void warn(object message, Exception ex) 
		{
		}
	
		public override bool isErrorEnabled() 
		{
			return false;
		}
	
		public override void error(object message) 
		{
		}
	
		public override void error(object message, Exception ex) 
		{
		}
	
		public override bool isFatalEnabled() 
		{
			return false;
		}
	
		public override void fatal(object message) 
		{
		}
	
		public override void fatal(object message, Exception ex) 
		{
		}	
	}
}
