//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;

using FirebirdSql.Data.INGDS;

namespace FirebirdSql.Data.Firebird
{
	/// <include file='xmldoc/fbblob.xml' path='doc/member[@name="T:FbArray"]/*'/>
	internal sealed class FbArray
	{
		#region FIELDS

		private FbConnection  connection	= null;
		private FbTransaction txn			= null;

		private string field_name			= null;
		private string relation_name		= null;

		private string rdb_field_name		= null;

		private long array_id;
		
		#endregion

		/// <include file='xmldoc/fbarray.xml' path='doc/member[@name="M:#ctor(FirebirdSql.Data.Firebird.FbConnection,FirebirdSql.Data.Firebird.FbTransaction,System.Int64,System.String,System.String)"]/*'/>
		public FbArray(FbConnection connection, FbTransaction transaction, 
			long array_id, string field_name, string relation_name)
		{
			this.connection = connection;
			this.txn		= transaction;
			this.array_id	= array_id;
			this.field_name = field_name;
			this.relation_name = relation_name;
		}

		public object[] Read()
		{
			FbIscConnection.gds.isc_array_get_slice(
				connection.ic.db,
				txn.Transaction	,
				array_id		,
				GetArrayBounds()	,
				new byte[15]	,
				15				);


			return new object[5];
		}

		private ISC_ARRAY_DESC GetArrayDesc()
		{
			ISC_ARRAY_DESC desc = new ISC_ARRAY_DESC();

			FbTransaction transaction = new FbTransaction(connection);
			transaction.BeginTransaction();

			FbStatement statement = FbCatalogFunctions.GetArrayDesc(
				transaction		,
				null			,
				null			,
				relation_name	,
				field_name		);

			if(statement.Resultset.Fetch())
			{								
				desc.array_desc_relation_name	= relation_name;
				desc.array_desc_field_name		= field_name;
				desc.array_desc_type			= statement.Resultset.GetByte(0);
				desc.array_desc_scale			= statement.Resultset.GetByte(1);
				desc.array_desc_length			= statement.Resultset.GetInt16(2);
				desc.array_desc_dimensions		= statement.Resultset.GetInt16(3);
				desc.array_desc_flags			= 0;

				this.rdb_field_name				= statement.Resultset.GetString(4);
			}			
			
			transaction.InternalRollback(false);

			statement.Dispose();
			statement = null;

			return desc;
		}

		private ISC_ARRAY_DESC GetArrayBounds()
		{
			int				i;
			ISC_ARRAY_DESC	desc = GetArrayDesc();

			FbTransaction transaction = new FbTransaction(connection);
			transaction.BeginTransaction();

			FbStatement statement = FbCatalogFunctions.GetArrayBounds(
				transaction			,
				null				,
				null				,				
				this.rdb_field_name	);

			i = 0;
			desc.array_desc_bounds = new ISC_ARRAY_BOUND[16];
			while(statement.Resultset.Fetch())
			{				
				desc.array_desc_bounds[i].array_bound_lower = statement.Resultset.GetInt16(0);
				desc.array_desc_bounds[i].array_bound_upper = statement.Resultset.GetInt16(1);

				i++;
			}			
			
			transaction.InternalRollback(false);

			statement.Dispose();
			statement = null;

			return desc;
		}
	}
}
