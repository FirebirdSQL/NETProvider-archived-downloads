//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Text;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;

using FirebirdSql.Data.INGDS;
using FirebirdSql.Data.NGDS;

namespace FirebirdSql.Data.Firebird
{
	#region INFO_MESSAGE_EVENT_ARGS

	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="T:FirebirdSql.Data.Firebird.FbInfoMessageEventArgs"]/*'/>
	public sealed class FbInfoMessageEventArgs : EventArgs
	{
		private FbErrorCollection errors = new FbErrorCollection();
		private string			  message = "";

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:FirebirdSql.Data.Firebird.FbInfoMessageEventArgs.Errors"]/*'/>
		public FbErrorCollection Errors
		{
			get{return errors;}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:FirebirdSql.Data.Firebird.FbInfoMessageEventArgs.Message"]/*'/>
		public string Message
		{
			get{return message;}
		}

		internal FbInfoMessageEventArgs(GDSException ex)
		{
			this.message = ex.Message;
			
			foreach(GDSError error in ex.Errors)
			{
				errors.Add(error.Message, error.ErrorCode);
			}
		}
	}

	#endregion

	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="D:FirebirdSql.Data.Firebird.FbInfoMessageEventHandler"]/*'/>
	public delegate void FbInfoMessageEventHandler(object sender, FbInfoMessageEventArgs e);
	
	/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="T:FbConnection"]/*'/>
	#if (!_MONO)
	[ToolboxBitmap(typeof(FbConnection), "Resources.ToolboxBitmaps.FbConnection.bmp")]	
	#endif
	public sealed class FbConnection : Component, IDbConnection, ICloneable
	{	
		#region EVENTS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="E:FirebirdSql.Data.Firebird.FbConnection.StateChange"]/*'/>
		public event StateChangeEventHandler StateChange;

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="E:FirebirdSql.Data.Firebird.FbConnection.InfoMessage"]/*'/>
		public event FbInfoMessageEventHandler InfoMessage;
		
		#endregion

		#region FIELDS

		private FbIscConnection iscConnection;
		private ConnectionState state;
		private string			connectionString	= "";
		private bool			autoCommit			= true;
		private int				connectionTimeout	= 15;
		private int				lifetime			= 0;
		private bool			disposed			= false;
		private bool			pooling				= false;
		private FbDataReader	dataReader			= null;
		private string			database = "";
		private string			user	 = "";
		private string			password = "";
		private string			host	 = "";
		private string			port	 = "";
		private string			role	 = "";
		private byte			dialect	 = 3;
		private string			charset	 = "";
		private Encoding		encoding = Encoding.Default;

		private FbTransaction	activeTxn = null;

		private DbWarningMessageHandler dbWarningngHandler = null;

		#endregion
		
		#region PROPERTIES

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Autocommit"]/*'/>
		public bool AutoCommit
		{
			get{ return autoCommit; }
			set{ autoCommit = value; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:State"]/*'/>
		public ConnectionState State
		{
			get { return state; }
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ConnectionString"]/*'/>
		public string ConnectionString
		{
			get{return connectionString;}
			set
			{ 
				if(state == ConnectionState.Closed)
				{
					if(ParseConnectionString(value))
					{
						connectionString = value;
					}
					else
					{
						throw new ArgumentException();
					}
				}
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Database"]/*'/>
		public string Database
		{
			get{return database;}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ServerVersion"]/*'/>
		public string ServerVersion
		{
			get{return ic.DatabaseInfo.FirebirdVersion;}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Role"]/*'/>
		internal string Role
		{
			get{return role;}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Dialect"]/*'/>
		internal byte Dialect
		{
			get{return dialect;}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Charset"]/*'/>
		internal string Charset
		{
			get{return charset;}
		}
		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:Encoding"]/*'/>
		internal Encoding Encoding
		{
			get{return encoding;}
		}
		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="P:ConnectionTimeout"]/*'/>
		public int ConnectionTimeout
		{
			get{return connectionTimeout;}
		}

		internal FbDataReader DataReader
		{
			get{return dataReader;}
			set{dataReader=value;}
		}

		internal FbIscConnection ic
		{
			get{return iscConnection;}
			set{iscConnection=value;}
		}

		#endregion		

		#region CONSTRUCTORS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbConnection()
		{
			iscConnection = new FbIscConnection();	
			state = ConnectionState.Closed;
		}
    		
		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:#ctor(System.String)"]/*'/>
		public FbConnection(string connString)
		{
			this.iscConnection		= new FbIscConnection();
			this.state				= ConnectionState.Closed;
			this.ConnectionString	= connString;			
		}		

		#endregion

		#region DESTRUCTORS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Finalize"]/*'/>
		~FbConnection() 
		{
			Dispose (false);
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Dispose(System.Boolean)"]/*'/>
		protected override void Dispose(bool disposing)
		{
			if(!disposed)
			{
				try
				{	
					if(disposing)
					{
						// release any managed resources
						Close();

						database	= null;
						charset		= null;
						user		= null;
						password	= null;
						dialect		= 0;
						encoding	= null;
					}

					// release any unmanaged resources
				}
				finally
				{
					base.Dispose(disposing);
				}

				disposed = true;
			}			
		}

		#endregion

		#region METHODS

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ICloneable#Clone"]/*'/>
		object ICloneable.Clone()
		{
			throw new NotImplementedException();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		IDbTransaction IDbConnection.BeginTransaction()
		{
			return BeginTransaction();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction"]/*'/>
		public FbTransaction BeginTransaction()
		{
			if(activeTxn != null && !activeTxn.IsUpdated)
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");

			if(DataReader != null)
				throw new InvalidOperationException(" BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");
			
			try
			{
				activeTxn = new FbTransaction(this);
				activeTxn.BeginTransaction();				 
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return this.activeTxn;
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		IDbTransaction IDbConnection.BeginTransaction(IsolationLevel level)
		{
			return BeginTransaction(level);
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:BeginTransaction(System.Data.IsolationLevel)"]/*'/>
		public FbTransaction BeginTransaction(IsolationLevel level)
		{
			if(activeTxn != null && !activeTxn.IsUpdated)
				throw new InvalidOperationException("A transaction is currently active. Parallel transactions are not supported.");

			if(DataReader != null)
				throw new InvalidOperationException("BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");

			try
			{
				activeTxn = new FbTransaction(this, level);
				activeTxn.BeginTransaction();
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}

			return this.activeTxn;			
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ChangeDatabase"]/*'/>
		public void ChangeDatabase(string db)
		{	
			if(this.DataReader != null)
				throw new InvalidOperationException(" BeginTransaction requires an open and available Connection. The connection's current state is Open, Fetching.");

			throw new NotImplementedException();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:Open"]/*'/>
		public void Open()
		{
			if(state != ConnectionState.Closed)
				throw new InvalidOperationException("Connection already Open.");

			// Validate Connection String
			if (!ParseConnectionString(connectionString))
				throw new ArgumentException("Invalid connection String");

			try
			{
				state = ConnectionState.Connecting;

				if(pooling)
				{		
					// Use Connection Pooling
					iscConnection = FbConnectionPool.GetConnection(
							dialect, 
							charset, 
							role, 
							user, 
							password, 
							GetConnectString(),
							lifetime*System.TimeSpan.TicksPerSecond);
				}
				else
				{
					// Do not use Connection Pooling
					iscConnection = new FbIscConnection();
					iscConnection.Open(dialect, charset, role, user, password, GetConnectString());
				}

				dbWarningngHandler = new DbWarningMessageHandler(OnDbWarningMessage);
				iscConnection.db.DbWarningMessage += dbWarningngHandler;
				
				// Set upda the encoding field
				encoding = Encodings.GetFromFirebirdEncoding(charset);

				state = ConnectionState.Open;
				
				if(StateChange != null)
					StateChange(this, new StateChangeEventArgs(ConnectionState.Closed,state));
			}
			catch(GDSException ex)
			{
				throw new FbException(ex);
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="Close"]/*'/>
		public void Close()
		{
			if(state == ConnectionState.Open)
			{
				try
				{		
					lock(ic)
					{
						iscConnection.db.DbWarningMessage -= dbWarningngHandler;

						if(activeTxn != null)
						{
							// Dispose Transaction
							activeTxn.Dispose();
							activeTxn = null;
						}

						if(pooling)
						{
							ic.ClearWarnings();
							FbConnectionPool.FreeConnection(ic);
						}
						else
						{	
							ic.Close();
							ic = null;
						}
					}

					// Update state
					state = ConnectionState.Closed;

					// Raise event
					if(StateChange != null)
						StateChange(this, new StateChangeEventArgs(ConnectionState.Open,state));
				}
				catch(GDSException ex)
				{
					throw new FbException(ex);
				}
			}
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:CreateCommand"]/*'/>
		IDbCommand IDbConnection.CreateCommand()
		{			
			return CreateCommand();
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:CreateCommand"]/*'/>
		public FbCommand CreateCommand()
		{		
			FbCommand command = new FbCommand();

			command.Connection = this;
	
			return command;
		}

		/// <include file='xmldoc/fbconnection.xml' path='doc/member[@name="M:ParseConnectionString"]/*'/>
		internal bool ParseConnectionString(string connStr)
		{
			string db		= null;
			string user		= null;
			string password = null;
			string server	= "localhost";
			string port     = "3050";
			string charset  = "NONE";
			string role		= null;
			byte   dialect	= 3;
			int	   lifetime = 0;
			bool   pooling  = true;

			bool returnVal = true;
			string[] elements = connStr.Split(';');			

			for(int i = 0; i < elements.Length; i++)
			{
				string[] values = elements[i].Split('=');

				if(values[0] != null && values[1] != null)
				{
					switch(values[0].ToUpper())
					{
						case "DATABASE":
							db = values[1];
							break;

						case "USER":
							user = values[1];
							break;

						case "PASSWORD":
							password = values[1];
							break;

						case "SERVER":
							server = values[1];
							break;

						case "PORT":
							port = values[1];
							break;

						case "DIALECT":
							dialect = byte.Parse(values[1]);
							break;

						case "CHARSET":
							charset = values[1];
							break;

						case "ROLE":
							role 	= values[1];
							break;

						case "CONNECTION LIFETIME":
							lifetime = Int32.Parse(values[1]);
							break;

						case "POOLING":						
							pooling = bool.Parse(values[1]);
							break;

						default:
							break;
					}
				}
			}

			if(database==null || user ==null || password==null || host==null)
			{
				returnVal = false;
			}
			else
			{
				this.database	= db;
				this.user		= user;
				this.password	= password;
				this.host		= server;
				this.port		= port;
				this.dialect	= dialect;
				this.role		= role;
				this.charset	= charset;
				this.lifetime   = lifetime;
				this.pooling	= pooling;
			}

			return returnVal;
		}

		private string GetConnectString()
		{
			return host + "/" + port + ":" + database;			
		}

		private void OnDbWarningMessage(object sender, DbWarningMessageEventArgs e)
		{
			if(InfoMessage != null)
			{
				InfoMessage(this, new FbInfoMessageEventArgs(e.Exception));
			}
		}

		#endregion
	}
}
