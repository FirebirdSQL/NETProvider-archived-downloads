//
// Firebird .Net Data Provider - Firebird managed data provider for .Net and Mono
//
// Author : Carlos Guzman Alvarez <carlosga@telefonica.net>
//
// Distributable under LGPL license.
// You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// LGPL License for more details.
//
// This file was created by members of the firebird development team.
// All individual contributions remain the Copyright (C) of those
// individuals.  Contributors to this file are either listed here or
// can be obtained from a CVS history command.
//
// All rights reserved.
//
// For more information please see http://www.firebirdsql.org
//

using System;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Security.Permissions;

namespace FirebirdSql.Data.Firebird
{	
	/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="T:FbClientPermission"]/*'/>	
	[Serializable]	
	public sealed class FbClientPermission : DBDataPermission
	{		
		private PermissionState state;

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:#ctor"]/*'/>
		public FbClientPermission()
		{
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:#ctor(System.Security.Permissions.PermissionState)"]/*'/>
		public FbClientPermission(PermissionState state)
		{			
			this.state = state;
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:#ctor(System.Security.Permissions.PermissionState,System.Boolean)"]/*'/>
		public FbClientPermission(PermissionState state, bool allowBlankPassword)
		{
			this.AllowBlankPassword = allowBlankPassword;
			this.state				= state;
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:Copy"]/*'/>
		public override IPermission Copy()
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:FromXml(System.Security.SecurityElement)"]/*'/>
		public override void FromXml(SecurityElement securityElement)
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:Intersect(System.Security.IPermission)"]/*'/>
		public override IPermission Intersect(IPermission target)
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:IsSubsetOf(System.Security.IPermission)"]/*'/>
		public override bool IsSubsetOf(IPermission target)
		{
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:ToString"]/*'/>
		public override string ToString()
		{					
			// TODO: implementar
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:ToXml"]/*'/>
		public override SecurityElement ToXml()
		{
			throw new NotImplementedException ();
		}

		/// <include file='xmldoc/fbclientpermission.xml' path='doc/member[@name="M:Union(System.Security.IPermission)"]/*'/>
		public override IPermission Union(IPermission target)
		{
			throw new NotImplementedException ();
		}
	}
}
