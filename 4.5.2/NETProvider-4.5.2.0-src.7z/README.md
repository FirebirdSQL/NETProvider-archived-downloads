Firebird ADO.NET Data Provider
==============================

Read more in readme-s in appropriate folders.

> ### [NETProvider's readme](NETProvider/readme.txt)

[![Build status](https://ci.appveyor.com/api/projects/status/1fyk5oph9f67p9i9)](https://ci.appveyor.com/project/cincura_net/netprovider)
