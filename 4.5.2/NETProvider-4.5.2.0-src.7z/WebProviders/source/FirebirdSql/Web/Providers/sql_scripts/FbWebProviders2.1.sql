IN FbDomains2.1.sql;
IN FbRoleProvider2.1.sql;
IN FbMembershipProvider2.1.sql;
IN FbProfileProvider2.1.sql;
IN FbSessionStateStore2.1.sql;