IN FbRoleProvider2.0.sql;
IN FbMembershipProvider2.0.sql;
IN FbProfileProvider2.0.sql;
IN FbSessionStateStore2.0.sql;