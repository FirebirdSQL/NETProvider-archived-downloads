Firebird ADO.NET Data Provider
==============================

Read more in readme-s in appropriate folders.

> ### [NETProvider's readme](NETProvider/readme.txt)

[![Build status](https://ci.appveyor.com/api/projects/status/1q6arda8smaokfvs?svg=true)](https://ci.appveyor.com/project/cincura_net/firebirdsql-data-firebirdclient)
