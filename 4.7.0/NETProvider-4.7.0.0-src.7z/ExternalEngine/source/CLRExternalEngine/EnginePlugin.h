#ifndef ENGINEPLUGIN_H
#define ENGINEPLUGIN_H

class ErrorObject;
class ExternalEngine;
class CLRExternalEngine;

#endif