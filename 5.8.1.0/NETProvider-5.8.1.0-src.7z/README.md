Firebird .NET Data Provider
===========================

Read more in readme in appropriate folders.

> ### [Provider's readme](Provider/readme.txt)
> ### [DDEX's readme](DDEX/readme.txt)

[![Build status](https://img.shields.io/appveyor/ci/cincura_net/firebirdsql-data-firebirdclient/master.svg)](https://ci.appveyor.com/project/cincura_net/firebirdsql-data-firebirdclient/history)
[![NuGet](https://img.shields.io/nuget/v/FirebirdSql.Data.FirebirdClient.svg)](https://www.nuget.org/packages/FirebirdSql.Data.FirebirdClient)
