Firebird ADO.NET Data Provider
==============================

Read more in readme-s in appropriate folders.

> ### [NETProvider's readme](NETProvider/readme.txt)
