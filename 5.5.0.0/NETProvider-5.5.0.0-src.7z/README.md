Firebird .NET Data Provider
===========================

Read more in readme in appropriate folders.

> ### [Provider's readme](Provider/readme.txt)
> ### [DDEX's readme](DDEX/readme.txt)

[![Build status](https://ci.appveyor.com/api/projects/status/1q6arda8smaokfvs/branch/master?svg=true)](https://ci.appveyor.com/project/cincura_net/firebirdsql-data-firebirdclient/branch/master)
